﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void MainManager::Start()
extern void MainManager_Start_mC9214444CF64A4908FDF87B213F21EB4372ABAB7 (void);
// 0x00000002 System.Void MainManager::Update()
extern void MainManager_Update_m2D4BE865BE5198840B173ADDC4C5E8F647D88D46 (void);
// 0x00000003 System.Void MainManager::SetNum()
extern void MainManager_SetNum_mF26464EB17C946A754528AAAE3613C4DB26921D6 (void);
// 0x00000004 System.Void MainManager::checkNum(System.Int32)
extern void MainManager_checkNum_m99E7653A8B2403EE563C00915D1DBAEBE39E1700 (void);
// 0x00000005 System.Void MainManager::CalculateScore(System.Int32,System.Single)
extern void MainManager_CalculateScore_m384FB7A667A4A2565B3383656C28AF2070725F60 (void);
// 0x00000006 System.Void MainManager::autoSolve()
extern void MainManager_autoSolve_m5B421CC3E3F73B534A92DCE6B47492A79A6C0C72 (void);
// 0x00000007 System.Void MainManager::.ctor()
extern void MainManager__ctor_m90DF2FBE6170D98DF8F9C03C44FB914322C4D10F (void);
// 0x00000008 System.Void TitleManager::Start()
extern void TitleManager_Start_mB1BDED26067331336418D8C8F760161E62F96224 (void);
// 0x00000009 System.Void TitleManager::Update()
extern void TitleManager_Update_m3D4B2483A33278FCFEB981AA66D621FDF1A652C7 (void);
// 0x0000000A System.Void TitleManager::UpdateLabel(System.Int32)
extern void TitleManager_UpdateLabel_mFD9114D24A7161EE209C863C244AF1E8F986A43B (void);
// 0x0000000B System.Void TitleManager::.ctor()
extern void TitleManager__ctor_m0D14731249E3B6D0846A587A421CAE4FAD2056D0 (void);
// 0x0000000C System.Void TryAgain::Again()
extern void TryAgain_Again_m95188785D108D451D30B118901CF1D551FE15F3A (void);
// 0x0000000D System.Void TryAgain::.ctor()
extern void TryAgain__ctor_mBEB1E7B1EB1FD2DB6F78B9AEDEE41793AB727705 (void);
// 0x0000000E System.Void DisableButton::Start()
extern void DisableButton_Start_m336CE507ADFCE98CD8FBF99DA9458AC20366D76E (void);
// 0x0000000F System.Void DisableButton::Update()
extern void DisableButton_Update_m8AA3B5A90B7B858BAD79A98CC648262E444CC05E (void);
// 0x00000010 System.Void DisableButton::MenuOpen()
extern void DisableButton_MenuOpen_m37C3632D41F7BCDA29B21CFB90905ACD1CC4E05C (void);
// 0x00000011 System.Void DisableButton::.ctor()
extern void DisableButton__ctor_mD5A1D36B339B24747C5F70256A225F98DF3FD39F (void);
// 0x00000012 System.Void Loginsignin::Start()
extern void Loginsignin_Start_m15A7B5534BA6AF650C32B142E9AED9CA96157847 (void);
// 0x00000013 System.Void Loginsignin::Update()
extern void Loginsignin_Update_m1C97DA265B0C8A09C3626766F66E878AFAFB22D5 (void);
// 0x00000014 System.Void Loginsignin::Login()
extern void Loginsignin_Login_mF96569BB5E08061D5B75AB68A444490AB9B188EE (void);
// 0x00000015 System.Void Loginsignin::Signin()
extern void Loginsignin_Signin_mD16320818EEAD0845EEC7799C77EC409E0461BAB (void);
// 0x00000016 System.Void Loginsignin::.ctor()
extern void Loginsignin__ctor_mBEAFCFB1A68494EC72935532A78DAE449DBEAB4C (void);
// 0x00000017 System.Void Loginsignin/<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_m0D1F1ACC28DC39ADE9850A7692048F9FC73E686E (void);
// 0x00000018 System.Void Loginsignin/<>c__DisplayClass5_0::<Login>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass5_0_U3CLoginU3Eb__0_m6004CADA656A377785BD413A1A64DCBBA7E9DA6F (void);
// 0x00000019 System.Void Loginsignin/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_mD4055380BDF730E641F72E598236D3AF4462EC71 (void);
// 0x0000001A System.Void Loginsignin/<>c__DisplayClass6_0::<Signin>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass6_0_U3CSigninU3Eb__0_m0E4B873D0ACFF439817243FBC0B4E8726E0CA684 (void);
// 0x0000001B System.Void Logout::Start()
extern void Logout_Start_m40723A78773A2CD00AC9416B843128C80E514ACF (void);
// 0x0000001C System.Void Logout::Update()
extern void Logout_Update_m4C65B388F48F6B9434A851C6CC89724631EFC3AE (void);
// 0x0000001D System.Void Logout::Logout_user()
extern void Logout_Logout_user_m1846E6FCFE6C5F851D40282FBDF9092695474BD2 (void);
// 0x0000001E System.Void Logout::.ctor()
extern void Logout__ctor_mD6E90F1BF5A203FB4024B69B5BF4AA84CC60A4D2 (void);
// 0x0000001F System.Void Logout/<>c::.cctor()
extern void U3CU3Ec__cctor_m639BEF51754B783A970891523BDF86E73328E44F (void);
// 0x00000020 System.Void Logout/<>c::.ctor()
extern void U3CU3Ec__ctor_m137AFD4583C559AF95DE542F3ACE257E6BE0284A (void);
// 0x00000021 System.Void Logout/<>c::<Logout_user>b__3_0(NCMB.NCMBException)
extern void U3CU3Ec_U3CLogout_userU3Eb__3_0_mECA5FDD2F453B767357292E569B06A7522F767E2 (void);
// 0x00000022 System.Void getCurrentUser::Start()
extern void getCurrentUser_Start_m56FC0A8D73C4DF2084833804337C722F5A168F1A (void);
// 0x00000023 System.Void getCurrentUser::Update()
extern void getCurrentUser_Update_mDD65209B54EBAE61F3591833BDAB6EB22B0ECB10 (void);
// 0x00000024 System.Void getCurrentUser::.ctor()
extern void getCurrentUser__ctor_m753FDEF4FEFDFF86F75AE0774B0938A80F5A424F (void);
// 0x00000025 System.Void QuickStart::Start()
extern void QuickStart_Start_mB2E95DCFD844937D1486D4C72D3252CD0BB398F9 (void);
// 0x00000026 System.Void QuickStart::Update()
extern void QuickStart_Update_m503754BC0DE892208BBFDA1139EF3D8D1042C567 (void);
// 0x00000027 System.Void QuickStart::.ctor()
extern void QuickStart__ctor_m411963D303CC53DD2DFDA1CBE928D9B9C136621C (void);
// 0x00000028 System.Void ChatController::OnEnable()
extern void ChatController_OnEnable_mBC3BFC05A1D47069DFA58A4F0E39CFF8FAD44FF2 (void);
// 0x00000029 System.Void ChatController::OnDisable()
extern void ChatController_OnDisable_m268A7488A3FDEB850FC3BC91A0BBDA767D42876B (void);
// 0x0000002A System.Void ChatController::AddToChatOutput(System.String)
extern void ChatController_AddToChatOutput_m43856EEA133E04C24701A2616E7F10D7FFA68371 (void);
// 0x0000002B System.Void ChatController::.ctor()
extern void ChatController__ctor_m3B66A5F749B457D865E8BDA1DE481C8CF1158026 (void);
// 0x0000002C System.Void EnvMapAnimator::Awake()
extern void EnvMapAnimator_Awake_mFFC04BC5320F83CA8C45FF36A11BF43AC17C6B93 (void);
// 0x0000002D System.Collections.IEnumerator EnvMapAnimator::Start()
extern void EnvMapAnimator_Start_mC0D348CAB0F0DC920EF3D3A008688B533F66D1BE (void);
// 0x0000002E System.Void EnvMapAnimator::.ctor()
extern void EnvMapAnimator__ctor_mC151D673A394E2E7CEA8774C4004985028C5C3EC (void);
// 0x0000002F System.Void EnvMapAnimator/<Start>d__4::.ctor(System.Int32)
extern void U3CStartU3Ed__4__ctor_m4D65F4FC2207AE4B6BE963AF9B5EDC55C7E29B23 (void);
// 0x00000030 System.Void EnvMapAnimator/<Start>d__4::System.IDisposable.Dispose()
extern void U3CStartU3Ed__4_System_IDisposable_Dispose_mFEE2ACED70A3D825988E28CC61FEF8DCD7660A5B (void);
// 0x00000031 System.Boolean EnvMapAnimator/<Start>d__4::MoveNext()
extern void U3CStartU3Ed__4_MoveNext_m2F1A8053A32AD86DA80F86391EC32EDC1C396AEE (void);
// 0x00000032 System.Object EnvMapAnimator/<Start>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF03E2A57659B8F598AC450183F55D43F903C0A1E (void);
// 0x00000033 System.Void EnvMapAnimator/<Start>d__4::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m268BA538CF6812C56EB281C0CE29D5AA2E9A2CAB (void);
// 0x00000034 System.Object EnvMapAnimator/<Start>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_mFE9CA9F52F9AFA1E4C9DBADA2064F854D6931CFF (void);
// 0x00000035 System.Void Tweet::Start()
extern void Tweet_Start_m22BB6363FC587DC0EBCC55C042CDB2CD5D45D563 (void);
// 0x00000036 System.Void Tweet::tweet()
extern void Tweet_tweet_m41F85FF9A1359C08CB4432BB04A82F836A30998E (void);
// 0x00000037 System.Void Tweet::.ctor()
extern void Tweet__ctor_m47C5C4300EF8BFB335036C5ABA8B80F225112125 (void);
// 0x00000038 System.Void SampleSceneManager::OnPlusButtonPressed()
extern void SampleSceneManager_OnPlusButtonPressed_m5C2B52B5CCE4361C0604C86DC78D9A3E1F8D600A (void);
// 0x00000039 System.Void SampleSceneManager::OnMinusButtonPressed()
extern void SampleSceneManager_OnMinusButtonPressed_m12232A6C9DDDF5E386D3EB099736EEB7C60C9B5F (void);
// 0x0000003A System.Void SampleSceneManager::OnResultButton0Pressed()
extern void SampleSceneManager_OnResultButton0Pressed_m6CAE5ED91776A576AC547D5C7BF8568DFAF34A4C (void);
// 0x0000003B System.Void SampleSceneManager::OnResultButton1Pressed()
extern void SampleSceneManager_OnResultButton1Pressed_m81FD6192C6DC3D04ADB85BA7C1ABCAC462AB1BAF (void);
// 0x0000003C System.Void SampleSceneManager::LocalSaveReset()
extern void SampleSceneManager_LocalSaveReset_m72358563BB7FCF4DD6D410BDA3006FD20A2E324D (void);
// 0x0000003D System.Void SampleSceneManager::.ctor()
extern void SampleSceneManager__ctor_m7B7BD9A63528D1AC0803F7927625560D9185CDB8 (void);
// 0x0000003E naichilab.ScoreType naichilab.IScore::get_Type()
// 0x0000003F System.String naichilab.IScore::get_TextForDisplay()
// 0x00000040 System.String naichilab.IScore::get_TextForSave()
// 0x00000041 System.Double naichilab.IScore::get_Value()
// 0x00000042 System.Void naichilab.NumberScore::.ctor(System.Double,System.String)
extern void NumberScore__ctor_m59A64D336CB91E05B64FF5F5F6F69D8662023162 (void);
// 0x00000043 naichilab.ScoreType naichilab.NumberScore::get_Type()
extern void NumberScore_get_Type_m4313CDFA3902F839836B6FB926C0D4978EA37729 (void);
// 0x00000044 System.String naichilab.NumberScore::get_TextForDisplay()
extern void NumberScore_get_TextForDisplay_m88223ECE09AAC2702F12D2B3444617894FD0EE63 (void);
// 0x00000045 System.String naichilab.NumberScore::get_TextForSave()
extern void NumberScore_get_TextForSave_m783E0501D92562B8C9A3E35F9DF2F71F3E56DBED (void);
// 0x00000046 System.Double naichilab.NumberScore::get_Value()
extern void NumberScore_get_Value_m0D9B7E8ED04905AE14A918E66279343D7DC29DFA (void);
// 0x00000047 naichilab.RankingInfo naichilab.RankingBoards::GetRankingInfo(System.Int32)
extern void RankingBoards_GetRankingInfo_m5D6AEF94541E7AF29F0174AF41F2DD6C0278879C (void);
// 0x00000048 System.Void naichilab.RankingBoards::CheckDuplicateClassName()
extern void RankingBoards_CheckDuplicateClassName_m43D4B26FE9947087022615EF5ACBFBE1ECB13F7F (void);
// 0x00000049 System.Void naichilab.RankingBoards::.ctor()
extern void RankingBoards__ctor_mBA88566559E411C25CD3A24166248B966DC54490 (void);
// 0x0000004A System.Void naichilab.RankingBoards/<>c::.cctor()
extern void U3CU3Ec__cctor_mDF556E740AD6959275A6850C7637A7D78A8DE923 (void);
// 0x0000004B System.Void naichilab.RankingBoards/<>c::.ctor()
extern void U3CU3Ec__ctor_m537283CEF868925B7F06D98D5BC751F48E8806D4 (void);
// 0x0000004C System.String naichilab.RankingBoards/<>c::<CheckDuplicateClassName>b__2_0(naichilab.RankingInfo)
extern void U3CU3Ec_U3CCheckDuplicateClassNameU3Eb__2_0_m7426CF5D2C3FB1742801E8B59DECAA5278CD0461 (void);
// 0x0000004D System.Boolean naichilab.RankingBoards/<>c::<CheckDuplicateClassName>b__2_1(System.Linq.IGrouping`2<System.String,naichilab.RankingInfo>)
extern void U3CU3Ec_U3CCheckDuplicateClassNameU3Eb__2_1_mB1FAD066675DC21AF56FB9EEA8130733E79B6A26 (void);
// 0x0000004E System.String naichilab.RankingBoards/<>c::<CheckDuplicateClassName>b__2_2(System.Linq.IGrouping`2<System.String,naichilab.RankingInfo>)
extern void U3CU3Ec_U3CCheckDuplicateClassNameU3Eb__2_2_m42B549DA34F0D530ED33A66ED1E21AF05552EAE1 (void);
// 0x0000004F naichilab.IScore naichilab.RankingInfo::BuildScore(System.String)
extern void RankingInfo_BuildScore_mF2B03A45BA6A2055E8BCC8A11A62A3385876F029 (void);
// 0x00000050 System.Void naichilab.RankingInfo::.ctor()
extern void RankingInfo__ctor_mC9A5407DA93A2A01AB2BA9E076F852DA8A25300A (void);
// 0x00000051 naichilab.RankingLoader naichilab.RankingLoader::get_Instance()
extern void RankingLoader_get_Instance_m68A3888C135719A9FEFA7D3610E1BA5F16B8680F (void);
// 0x00000052 System.Void naichilab.RankingLoader::Start()
extern void RankingLoader_Start_m4F0A00230A2A701DBD97094D98914170595C56EA (void);
// 0x00000053 System.Void naichilab.RankingLoader::SendScoreAndShowRanking(System.TimeSpan,System.Int32)
extern void RankingLoader_SendScoreAndShowRanking_m368CFD531F7B05E92500D2DB6161BB3AA8BFC0A5 (void);
// 0x00000054 System.Void naichilab.RankingLoader::SendScoreAndShowRanking(System.Double,System.Int32)
extern void RankingLoader_SendScoreAndShowRanking_m819A29A1329A0B76132BDEF21D45A315BC4A4037 (void);
// 0x00000055 System.Void naichilab.RankingLoader::SendScoreAndShowRanking(naichilab.IScore,naichilab.RankingInfo)
extern void RankingLoader_SendScoreAndShowRanking_m0633E2C083AF21AC98D874B279622D5FD24EE8C9 (void);
// 0x00000056 System.Void naichilab.RankingLoader::.ctor()
extern void RankingLoader__ctor_m8F52FAC0F9D6C322508B44CAF32A6B5601D8E59C (void);
// 0x00000057 System.Void naichilab.RankingNode::.ctor()
extern void RankingNode__ctor_m2B5EA915A63A34F2F83684E096DF9CAAE1E9A260 (void);
// 0x00000058 System.String naichilab.RankingSceneManager::get_ObjectID()
extern void RankingSceneManager_get_ObjectID_m138750ED83DC56D397FF5431F0203BF492E10C4D (void);
// 0x00000059 System.Void naichilab.RankingSceneManager::set_ObjectID(System.String)
extern void RankingSceneManager_set_ObjectID_m97F1408F5DFEB82515607EF4A90C129A59BE2DB0 (void);
// 0x0000005A System.String naichilab.RankingSceneManager::get_BoardIdPlayerPrefsKey()
extern void RankingSceneManager_get_BoardIdPlayerPrefsKey_m2B41B717408B0056B688DFB3ACD7AA57392CE834 (void);
// 0x0000005B System.String naichilab.RankingSceneManager::get_InputtedNameForSave()
extern void RankingSceneManager_get_InputtedNameForSave_m975B7B1AF2F3DF0CD4B4784AC434F147DA3C215B (void);
// 0x0000005C System.Void naichilab.RankingSceneManager::Start()
extern void RankingSceneManager_Start_m7617348FD5D3E50D780B49DA641CD709BF0B8B87 (void);
// 0x0000005D System.Collections.IEnumerator naichilab.RankingSceneManager::GetHighScoreAndRankingBoard()
extern void RankingSceneManager_GetHighScoreAndRankingBoard_m20951FFD15E63A015B58D71DFEB6A4AE138061F5 (void);
// 0x0000005E System.Void naichilab.RankingSceneManager::SendScore()
extern void RankingSceneManager_SendScore_m7F3DC094584144D839420900814424D302AB31B0 (void);
// 0x0000005F System.Collections.IEnumerator naichilab.RankingSceneManager::SendScoreEnumerator()
extern void RankingSceneManager_SendScoreEnumerator_m072BD9510D878AC558B2985346C547AEF4437A51 (void);
// 0x00000060 System.Collections.IEnumerator naichilab.RankingSceneManager::LoadRankingBoard()
extern void RankingSceneManager_LoadRankingBoard_mC227D82872A5749E3C0D02167C151B2BF9492EC1 (void);
// 0x00000061 System.Void naichilab.RankingSceneManager::OnCloseButtonClick()
extern void RankingSceneManager_OnCloseButtonClick_mB9255A8A0D6C93132DF0D8EEE791096989A48DCF (void);
// 0x00000062 System.Void naichilab.RankingSceneManager::MaskOffOn()
extern void RankingSceneManager_MaskOffOn_mC0D21B1754A5D9A0F0DF847BD9C9F006023E0FD9 (void);
// 0x00000063 System.Void naichilab.RankingSceneManager::.ctor()
extern void RankingSceneManager__ctor_mF485576DB139936A313A9F0B98C55E79BF43E16A (void);
// 0x00000064 System.Void naichilab.RankingSceneManager/<GetHighScoreAndRankingBoard>d__26::.ctor(System.Int32)
extern void U3CGetHighScoreAndRankingBoardU3Ed__26__ctor_mE2C21B2F529BADF10971B67C85A4A5DDEB5E9297 (void);
// 0x00000065 System.Void naichilab.RankingSceneManager/<GetHighScoreAndRankingBoard>d__26::System.IDisposable.Dispose()
extern void U3CGetHighScoreAndRankingBoardU3Ed__26_System_IDisposable_Dispose_m60C5057D7D56D2296796393E2E2618F2DA6E4627 (void);
// 0x00000066 System.Boolean naichilab.RankingSceneManager/<GetHighScoreAndRankingBoard>d__26::MoveNext()
extern void U3CGetHighScoreAndRankingBoardU3Ed__26_MoveNext_m612BBB0DE55107FEDD983D52FA38C79566BEDA4C (void);
// 0x00000067 System.Object naichilab.RankingSceneManager/<GetHighScoreAndRankingBoard>d__26::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CGetHighScoreAndRankingBoardU3Ed__26_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m2E3EAE625533A270CC7D9EB50D21FA8DFBC6C00A (void);
// 0x00000068 System.Void naichilab.RankingSceneManager/<GetHighScoreAndRankingBoard>d__26::System.Collections.IEnumerator.Reset()
extern void U3CGetHighScoreAndRankingBoardU3Ed__26_System_Collections_IEnumerator_Reset_mC52201F256A6F4E4B180C8C548037EF2EE64C76E (void);
// 0x00000069 System.Object naichilab.RankingSceneManager/<GetHighScoreAndRankingBoard>d__26::System.Collections.IEnumerator.get_Current()
extern void U3CGetHighScoreAndRankingBoardU3Ed__26_System_Collections_IEnumerator_get_Current_m77D1E321313050E52BC4A386433F4F5FB0158A22 (void);
// 0x0000006A System.Void naichilab.RankingSceneManager/<>c__DisplayClass28_0::.ctor()
extern void U3CU3Ec__DisplayClass28_0__ctor_m32230269C1A8A9AF884DF161EB095309D580E059 (void);
// 0x0000006B System.Void naichilab.RankingSceneManager/<>c__DisplayClass28_0::<SendScoreEnumerator>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass28_0_U3CSendScoreEnumeratorU3Eb__0_m75542A1C206654B8653774644232F06E1DC9FA2B (void);
// 0x0000006C System.Void naichilab.RankingSceneManager/<>c__DisplayClass28_0::<SendScoreEnumerator>b__1(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass28_0_U3CSendScoreEnumeratorU3Eb__1_m69D290830B80CF577FA27FCFA75031A9ED3F3923 (void);
// 0x0000006D System.Void naichilab.RankingSceneManager/<SendScoreEnumerator>d__28::.ctor(System.Int32)
extern void U3CSendScoreEnumeratorU3Ed__28__ctor_m66877E59819AF86D83186A12628C64DF2CB8EDDC (void);
// 0x0000006E System.Void naichilab.RankingSceneManager/<SendScoreEnumerator>d__28::System.IDisposable.Dispose()
extern void U3CSendScoreEnumeratorU3Ed__28_System_IDisposable_Dispose_m0FFF1A3596AB087895286D95B79A176500A7B88C (void);
// 0x0000006F System.Boolean naichilab.RankingSceneManager/<SendScoreEnumerator>d__28::MoveNext()
extern void U3CSendScoreEnumeratorU3Ed__28_MoveNext_mE7E08736A0067AC40DB3380BCBAF8672694C715F (void);
// 0x00000070 System.Object naichilab.RankingSceneManager/<SendScoreEnumerator>d__28::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CSendScoreEnumeratorU3Ed__28_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA326900D08A039C31F25125DD079F77988E1F7DE (void);
// 0x00000071 System.Void naichilab.RankingSceneManager/<SendScoreEnumerator>d__28::System.Collections.IEnumerator.Reset()
extern void U3CSendScoreEnumeratorU3Ed__28_System_Collections_IEnumerator_Reset_m8AC0EAE33F3E63C94B9CF9AEDA80FA6ED0F01372 (void);
// 0x00000072 System.Object naichilab.RankingSceneManager/<SendScoreEnumerator>d__28::System.Collections.IEnumerator.get_Current()
extern void U3CSendScoreEnumeratorU3Ed__28_System_Collections_IEnumerator_get_Current_m3CDC5AE627CDE742493B953583EE9EAEDBF943AD (void);
// 0x00000073 System.Void naichilab.RankingSceneManager/<LoadRankingBoard>d__29::.ctor(System.Int32)
extern void U3CLoadRankingBoardU3Ed__29__ctor_m684F8234E11BEA91136D3CD154B4AC7C1806CD09 (void);
// 0x00000074 System.Void naichilab.RankingSceneManager/<LoadRankingBoard>d__29::System.IDisposable.Dispose()
extern void U3CLoadRankingBoardU3Ed__29_System_IDisposable_Dispose_mEB45C5DC33E509A5C611D7BA0AC7CF0EEDF59F63 (void);
// 0x00000075 System.Boolean naichilab.RankingSceneManager/<LoadRankingBoard>d__29::MoveNext()
extern void U3CLoadRankingBoardU3Ed__29_MoveNext_m628D526B47AE9EE62D9249E5709201ED31110A94 (void);
// 0x00000076 System.Object naichilab.RankingSceneManager/<LoadRankingBoard>d__29::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CLoadRankingBoardU3Ed__29_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m378D2FE633CEFE56A71AEC5906FCECA963986EF7 (void);
// 0x00000077 System.Void naichilab.RankingSceneManager/<LoadRankingBoard>d__29::System.Collections.IEnumerator.Reset()
extern void U3CLoadRankingBoardU3Ed__29_System_Collections_IEnumerator_Reset_m898F58CAEFF4BD4784E2A930B5CAEC65825CACF9 (void);
// 0x00000078 System.Object naichilab.RankingSceneManager/<LoadRankingBoard>d__29::System.Collections.IEnumerator.get_Current()
extern void U3CLoadRankingBoardU3Ed__29_System_Collections_IEnumerator_get_Current_m294D91AA26D772E6C7032529E8B5390EDA6C64FF (void);
// 0x00000079 System.Void naichilab.TimeScore::.ctor(System.TimeSpan,System.String)
extern void TimeScore__ctor_m4BAB86C3334925FC830001164D179E61B331D366 (void);
// 0x0000007A naichilab.ScoreType naichilab.TimeScore::get_Type()
extern void TimeScore_get_Type_mC0356DA85727C100BD5430CD4267D64041B15BD3 (void);
// 0x0000007B System.String naichilab.TimeScore::get_TextForDisplay()
extern void TimeScore_get_TextForDisplay_m46A36B72F2E2AFD11381C219FFF5F25DE3AB274C (void);
// 0x0000007C System.String naichilab.TimeScore::get_TextForSave()
extern void TimeScore_get_TextForSave_m351532DD5B309FEC9114BDE55C0BABE07A99A82D (void);
// 0x0000007D System.Double naichilab.TimeScore::get_Value()
extern void TimeScore_get_Value_mB95D9C69C9E3AFE0161B628FE3D44B3852C4B92E (void);
// 0x0000007E System.Char TMPro.TMP_DigitValidator::Validate(System.String&,System.Int32&,System.Char)
extern void TMP_DigitValidator_Validate_m5D303EB8CD6E9E7D526D633BA1021884051FE226 (void);
// 0x0000007F System.Void TMPro.TMP_DigitValidator::.ctor()
extern void TMP_DigitValidator__ctor_m1E838567EF38170662F1BAF52A847CC2C258333E (void);
// 0x00000080 System.Char TMPro.TMP_PhoneNumberValidator::Validate(System.String&,System.Int32&,System.Char)
extern void TMP_PhoneNumberValidator_Validate_mF0E90A277E9E91BC213DD02DC60088D03C9436B1 (void);
// 0x00000081 System.Void TMPro.TMP_PhoneNumberValidator::.ctor()
extern void TMP_PhoneNumberValidator__ctor_mB3C36CAAE3B52554C44A1D19194F0176B5A8EED3 (void);
// 0x00000082 TMPro.TMP_TextEventHandler/CharacterSelectionEvent TMPro.TMP_TextEventHandler::get_onCharacterSelection()
extern void TMP_TextEventHandler_get_onCharacterSelection_m90C39320C726E8E542D91F4BBD690697349F5385 (void);
// 0x00000083 System.Void TMPro.TMP_TextEventHandler::set_onCharacterSelection(TMPro.TMP_TextEventHandler/CharacterSelectionEvent)
extern void TMP_TextEventHandler_set_onCharacterSelection_m5ED7658EB101C6740A921FA150DE18C443BDA0C4 (void);
// 0x00000084 TMPro.TMP_TextEventHandler/SpriteSelectionEvent TMPro.TMP_TextEventHandler::get_onSpriteSelection()
extern void TMP_TextEventHandler_get_onSpriteSelection_m0E645AE1DFE19B011A3319474D0CF0DA612C8B7B (void);
// 0x00000085 System.Void TMPro.TMP_TextEventHandler::set_onSpriteSelection(TMPro.TMP_TextEventHandler/SpriteSelectionEvent)
extern void TMP_TextEventHandler_set_onSpriteSelection_m4AFC6772C3357218956A5D33B3CD19F3AAF39788 (void);
// 0x00000086 TMPro.TMP_TextEventHandler/WordSelectionEvent TMPro.TMP_TextEventHandler::get_onWordSelection()
extern void TMP_TextEventHandler_get_onWordSelection_mA42B89A37810FB659FCFA8539339A3BB8037203A (void);
// 0x00000087 System.Void TMPro.TMP_TextEventHandler::set_onWordSelection(TMPro.TMP_TextEventHandler/WordSelectionEvent)
extern void TMP_TextEventHandler_set_onWordSelection_m4A839FAFFABAFECD073B82BA8826E1CD033C0076 (void);
// 0x00000088 TMPro.TMP_TextEventHandler/LineSelectionEvent TMPro.TMP_TextEventHandler::get_onLineSelection()
extern void TMP_TextEventHandler_get_onLineSelection_mB701B6C713AD4EFC61E1B30A564EE54ADE31F58D (void);
// 0x00000089 System.Void TMPro.TMP_TextEventHandler::set_onLineSelection(TMPro.TMP_TextEventHandler/LineSelectionEvent)
extern void TMP_TextEventHandler_set_onLineSelection_m0B2337598350E51D0A17B8FCB3AAA533F312F3DA (void);
// 0x0000008A TMPro.TMP_TextEventHandler/LinkSelectionEvent TMPro.TMP_TextEventHandler::get_onLinkSelection()
extern void TMP_TextEventHandler_get_onLinkSelection_mF5C3875D661F5B1E3712566FE16D332EA37D15BB (void);
// 0x0000008B System.Void TMPro.TMP_TextEventHandler::set_onLinkSelection(TMPro.TMP_TextEventHandler/LinkSelectionEvent)
extern void TMP_TextEventHandler_set_onLinkSelection_m200566EDEB2C9299647F3EEAC588B51818D360A5 (void);
// 0x0000008C System.Void TMPro.TMP_TextEventHandler::Awake()
extern void TMP_TextEventHandler_Awake_m43EB03A4A6776A624F79457EC49E78E7B5BA1C70 (void);
// 0x0000008D System.Void TMPro.TMP_TextEventHandler::LateUpdate()
extern void TMP_TextEventHandler_LateUpdate_mE1D989C40DA8E54E116E3C60217DFCAADD6FDE11 (void);
// 0x0000008E System.Void TMPro.TMP_TextEventHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextEventHandler_OnPointerEnter_m8FC88F25858B24CE68BE80C727A3F0227A8EE5AC (void);
// 0x0000008F System.Void TMPro.TMP_TextEventHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextEventHandler_OnPointerExit_mBB2A74D55741F631A678A5D6997D40247FE75D44 (void);
// 0x00000090 System.Void TMPro.TMP_TextEventHandler::SendOnCharacterSelection(System.Char,System.Int32)
extern void TMP_TextEventHandler_SendOnCharacterSelection_m78983D3590F1B0C242BEAB0A11FDBDABDD1814EC (void);
// 0x00000091 System.Void TMPro.TMP_TextEventHandler::SendOnSpriteSelection(System.Char,System.Int32)
extern void TMP_TextEventHandler_SendOnSpriteSelection_m10C257A74F121B95E7077F7E488FBC52380A6C53 (void);
// 0x00000092 System.Void TMPro.TMP_TextEventHandler::SendOnWordSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventHandler_SendOnWordSelection_m95A4E5A00E339E5B8BA9AA63B98DB3E81C8B8F66 (void);
// 0x00000093 System.Void TMPro.TMP_TextEventHandler::SendOnLineSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventHandler_SendOnLineSelection_mE85BA6ECE1188B666FD36839B8970C3E0130BC43 (void);
// 0x00000094 System.Void TMPro.TMP_TextEventHandler::SendOnLinkSelection(System.String,System.String,System.Int32)
extern void TMP_TextEventHandler_SendOnLinkSelection_m299E6620DFD835C8258A3F48B4EA076C304E9B77 (void);
// 0x00000095 System.Void TMPro.TMP_TextEventHandler::.ctor()
extern void TMP_TextEventHandler__ctor_m6345DC1CEA2E4209E928AD1E61C3ACA4227DD9B8 (void);
// 0x00000096 System.Void TMPro.TMP_TextEventHandler/CharacterSelectionEvent::.ctor()
extern void CharacterSelectionEvent__ctor_m06BC183AF31BA4A2055A44514BC3FF0539DD04C7 (void);
// 0x00000097 System.Void TMPro.TMP_TextEventHandler/SpriteSelectionEvent::.ctor()
extern void SpriteSelectionEvent__ctor_m0F760052E9A5AF44A7AF7AC006CB4B24809590F2 (void);
// 0x00000098 System.Void TMPro.TMP_TextEventHandler/WordSelectionEvent::.ctor()
extern void WordSelectionEvent__ctor_m106CDEB17C520C9D20CE7120DE6BBBDEDB48886C (void);
// 0x00000099 System.Void TMPro.TMP_TextEventHandler/LineSelectionEvent::.ctor()
extern void LineSelectionEvent__ctor_m5D735FDA9B71B9147C6F791B331498F145D75018 (void);
// 0x0000009A System.Void TMPro.TMP_TextEventHandler/LinkSelectionEvent::.ctor()
extern void LinkSelectionEvent__ctor_m7AB7977D0D0F8883C5A98DD6BB2D390BC3CAB8E0 (void);
// 0x0000009B System.Collections.IEnumerator TMPro.Examples.Benchmark01::Start()
extern void Benchmark01_Start_mE7E5146B0D8D926CC410CAA48F3B617A0A7D955C (void);
// 0x0000009C System.Void TMPro.Examples.Benchmark01::.ctor()
extern void Benchmark01__ctor_mB92568AA7A9E13B92315B6270FCA23584A7D0F7F (void);
// 0x0000009D System.Void TMPro.Examples.Benchmark01/<Start>d__10::.ctor(System.Int32)
extern void U3CStartU3Ed__10__ctor_mBE5D8B4B98C372BD6DC3936437999DF3048DE3AB (void);
// 0x0000009E System.Void TMPro.Examples.Benchmark01/<Start>d__10::System.IDisposable.Dispose()
extern void U3CStartU3Ed__10_System_IDisposable_Dispose_m1F4180A7FDAE9AC5F11F30B67F813B3D7CD56D73 (void);
// 0x0000009F System.Boolean TMPro.Examples.Benchmark01/<Start>d__10::MoveNext()
extern void U3CStartU3Ed__10_MoveNext_mF3B1D38CD37FD5187C3192141DB380747C66AD3C (void);
// 0x000000A0 System.Object TMPro.Examples.Benchmark01/<Start>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m22B2975D42326E3DE437174BBE4F0E8790CB6591 (void);
// 0x000000A1 System.Void TMPro.Examples.Benchmark01/<Start>d__10::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_m514DA545ECA10AA62BFC239BB582FF0017B91D2B (void);
// 0x000000A2 System.Object TMPro.Examples.Benchmark01/<Start>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_m6904A738F04118BA24E473F1809B3D69E711627E (void);
// 0x000000A3 System.Collections.IEnumerator TMPro.Examples.Benchmark01_UGUI::Start()
extern void Benchmark01_UGUI_Start_m2F8F9E1798943DA8086A7C7E73BA9D7C67482BD4 (void);
// 0x000000A4 System.Void TMPro.Examples.Benchmark01_UGUI::.ctor()
extern void Benchmark01_UGUI__ctor_mACFE8D997EAB50FDBD7F671C1A25A892D9F78376 (void);
// 0x000000A5 System.Void TMPro.Examples.Benchmark01_UGUI/<Start>d__10::.ctor(System.Int32)
extern void U3CStartU3Ed__10__ctor_m653B757B49A674E239C804FFF4EDEF325B5DB651 (void);
// 0x000000A6 System.Void TMPro.Examples.Benchmark01_UGUI/<Start>d__10::System.IDisposable.Dispose()
extern void U3CStartU3Ed__10_System_IDisposable_Dispose_mAD0BC985E1E01C8369A7A955A60D3E545B0B3561 (void);
// 0x000000A7 System.Boolean TMPro.Examples.Benchmark01_UGUI/<Start>d__10::MoveNext()
extern void U3CStartU3Ed__10_MoveNext_mF9B2C8D290035BC9A79C4347772B5B7B9D404DE1 (void);
// 0x000000A8 System.Object TMPro.Examples.Benchmark01_UGUI/<Start>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF438D42D7C5A811FF9A283F8780F015FF55826CD (void);
// 0x000000A9 System.Void TMPro.Examples.Benchmark01_UGUI/<Start>d__10::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_m65545EB5B6DDDDAB5ACF92600137C1C754B322BA (void);
// 0x000000AA System.Object TMPro.Examples.Benchmark01_UGUI/<Start>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_mD4523BE1D1014AAF1C0709EB767C0B0F47D739D2 (void);
// 0x000000AB System.Void TMPro.Examples.Benchmark02::Start()
extern void Benchmark02_Start_m315C0DF3A9AC66B4F5802FDAED056E7E5F3D2046 (void);
// 0x000000AC System.Void TMPro.Examples.Benchmark02::.ctor()
extern void Benchmark02__ctor_m526B38D3B7E75905208E4E57B168D8AC1900F4E5 (void);
// 0x000000AD System.Void TMPro.Examples.Benchmark03::Awake()
extern void Benchmark03_Awake_mD23429C1EE428EEF4ED9A753385BF194BAA41A77 (void);
// 0x000000AE System.Void TMPro.Examples.Benchmark03::Start()
extern void Benchmark03_Start_m19E638DED29CB7F96362F3C346DC47217C4AF516 (void);
// 0x000000AF System.Void TMPro.Examples.Benchmark03::.ctor()
extern void Benchmark03__ctor_m89F9102259BE1694EC418E9023DC563F3999B0BE (void);
// 0x000000B0 System.Void TMPro.Examples.Benchmark04::Start()
extern void Benchmark04_Start_mEABD467C12547066E33359FDC433E8B5BAD43DB9 (void);
// 0x000000B1 System.Void TMPro.Examples.Benchmark04::.ctor()
extern void Benchmark04__ctor_m5015375E0C8D19060CB5DE14CBF4AC02DDD70E7C (void);
// 0x000000B2 System.Void TMPro.Examples.CameraController::Awake()
extern void CameraController_Awake_m420393892377B9703EC97764B34E32890FC5283E (void);
// 0x000000B3 System.Void TMPro.Examples.CameraController::Start()
extern void CameraController_Start_m32D90EE7232BE6DE08D224F824F8EB9571655610 (void);
// 0x000000B4 System.Void TMPro.Examples.CameraController::LateUpdate()
extern void CameraController_LateUpdate_m6D81DEBA4E8B443CF2AD8288F0E76E3A6B3B5373 (void);
// 0x000000B5 System.Void TMPro.Examples.CameraController::GetPlayerInput()
extern void CameraController_GetPlayerInput_m6695FE20CFC691585A6AC279EDB338EC9DD13FE3 (void);
// 0x000000B6 System.Void TMPro.Examples.CameraController::.ctor()
extern void CameraController__ctor_m09187FB27B590118043D4DC7B89B93164124C124 (void);
// 0x000000B7 System.Void TMPro.Examples.ObjectSpin::Awake()
extern void ObjectSpin_Awake_mC1EB9630B6D3BAE645D3DD79C264F71F7B18A1AA (void);
// 0x000000B8 System.Void TMPro.Examples.ObjectSpin::Update()
extern void ObjectSpin_Update_mD39DCBA0789DC0116037C442F0BA1EE6752E36D3 (void);
// 0x000000B9 System.Void TMPro.Examples.ObjectSpin::.ctor()
extern void ObjectSpin__ctor_m1827B9648659746252026432DFED907AEC6007FC (void);
// 0x000000BA System.Void TMPro.Examples.ShaderPropAnimator::Awake()
extern void ShaderPropAnimator_Awake_mE04C66A41CA53AB73733E7D2CCD21B30A360C5A8 (void);
// 0x000000BB System.Void TMPro.Examples.ShaderPropAnimator::Start()
extern void ShaderPropAnimator_Start_mC5AC59C59AF2F71E0CF65F11ACD787488140EDD2 (void);
// 0x000000BC System.Collections.IEnumerator TMPro.Examples.ShaderPropAnimator::AnimateProperties()
extern void ShaderPropAnimator_AnimateProperties_mAF49CD157AD41377CE00AA10F0C06C8BF5AA0469 (void);
// 0x000000BD System.Void TMPro.Examples.ShaderPropAnimator::.ctor()
extern void ShaderPropAnimator__ctor_mAA626BC8AEEB00C5AE362FE8690D3F2200CE6E64 (void);
// 0x000000BE System.Void TMPro.Examples.ShaderPropAnimator/<AnimateProperties>d__6::.ctor(System.Int32)
extern void U3CAnimatePropertiesU3Ed__6__ctor_mFAC0F8A7368D9D35AD2780C118E13414DA79B56A (void);
// 0x000000BF System.Void TMPro.Examples.ShaderPropAnimator/<AnimateProperties>d__6::System.IDisposable.Dispose()
extern void U3CAnimatePropertiesU3Ed__6_System_IDisposable_Dispose_m628EECBFCBC49087298185F17BC2AE7A73FC8A7B (void);
// 0x000000C0 System.Boolean TMPro.Examples.ShaderPropAnimator/<AnimateProperties>d__6::MoveNext()
extern void U3CAnimatePropertiesU3Ed__6_MoveNext_m8A58CCFDAE59F55AB1BB2C103800886E62C807CF (void);
// 0x000000C1 System.Object TMPro.Examples.ShaderPropAnimator/<AnimateProperties>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0742A0FA62C518EBD119ED5FEBF849F918E12390 (void);
// 0x000000C2 System.Void TMPro.Examples.ShaderPropAnimator/<AnimateProperties>d__6::System.Collections.IEnumerator.Reset()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_Reset_mC076F281DD17668D6CE42EB04EA974DE1FFB3F6B (void);
// 0x000000C3 System.Object TMPro.Examples.ShaderPropAnimator/<AnimateProperties>d__6::System.Collections.IEnumerator.get_Current()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_get_Current_mA585E786DA86D2589EBCA029AD9E64E8B5135362 (void);
// 0x000000C4 System.Void TMPro.Examples.SimpleScript::Start()
extern void SimpleScript_Start_m75CD9CEDCAFA9A991753478D7C28407C7329FB8F (void);
// 0x000000C5 System.Void TMPro.Examples.SimpleScript::Update()
extern void SimpleScript_Update_mE8C3930DCC1767C2DF59B622FABD188E6FB91BE5 (void);
// 0x000000C6 System.Void TMPro.Examples.SimpleScript::.ctor()
extern void SimpleScript__ctor_mEB370A69544227EF04C48C604A28502ADAA73697 (void);
// 0x000000C7 System.Void TMPro.Examples.SkewTextExample::Awake()
extern void SkewTextExample_Awake_m6FBA7E7DC9AFDD3099F0D0B9CDE91574551105DB (void);
// 0x000000C8 System.Void TMPro.Examples.SkewTextExample::Start()
extern void SkewTextExample_Start_m536F82F3A5D229332694688C59F396E07F88153F (void);
// 0x000000C9 UnityEngine.AnimationCurve TMPro.Examples.SkewTextExample::CopyAnimationCurve(UnityEngine.AnimationCurve)
extern void SkewTextExample_CopyAnimationCurve_m555177255F5828DBC7E677ED06F7EFFC052886B3 (void);
// 0x000000CA System.Collections.IEnumerator TMPro.Examples.SkewTextExample::WarpText()
extern void SkewTextExample_WarpText_m0E0C46988600673F0E5DFA3133534DC6CA5950D3 (void);
// 0x000000CB System.Void TMPro.Examples.SkewTextExample::.ctor()
extern void SkewTextExample__ctor_m945059906734DD38CF860CD32B3E07635D0E1F86 (void);
// 0x000000CC System.Void TMPro.Examples.SkewTextExample/<WarpText>d__7::.ctor(System.Int32)
extern void U3CWarpTextU3Ed__7__ctor_mEAD3C39209B75514446A44B6C2FA76F8097EBD6F (void);
// 0x000000CD System.Void TMPro.Examples.SkewTextExample/<WarpText>d__7::System.IDisposable.Dispose()
extern void U3CWarpTextU3Ed__7_System_IDisposable_Dispose_m32AA7120BE15547799BDC515FA3486488952BDCF (void);
// 0x000000CE System.Boolean TMPro.Examples.SkewTextExample/<WarpText>d__7::MoveNext()
extern void U3CWarpTextU3Ed__7_MoveNext_mB832E4A3DFDDFECC460A510BBC664F218B3D7FCF (void);
// 0x000000CF System.Object TMPro.Examples.SkewTextExample/<WarpText>d__7::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWarpTextU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m3CF506B740C16FEDE58B6E1BE4556CAC2C6AEAD1 (void);
// 0x000000D0 System.Void TMPro.Examples.SkewTextExample/<WarpText>d__7::System.Collections.IEnumerator.Reset()
extern void U3CWarpTextU3Ed__7_System_Collections_IEnumerator_Reset_mDDCDBB794F21DF70178A75747D8D8398F38A9C2F (void);
// 0x000000D1 System.Object TMPro.Examples.SkewTextExample/<WarpText>d__7::System.Collections.IEnumerator.get_Current()
extern void U3CWarpTextU3Ed__7_System_Collections_IEnumerator_get_Current_m6D89CF1910F76577E23C924B535E93FD1B01CF0A (void);
// 0x000000D2 System.Void TMPro.Examples.TMP_ExampleScript_01::Awake()
extern void TMP_ExampleScript_01_Awake_m381EF5B50E1D012B8CA1883DEFF604EEAE6D95F4 (void);
// 0x000000D3 System.Void TMPro.Examples.TMP_ExampleScript_01::Update()
extern void TMP_ExampleScript_01_Update_m31611F22A608784F164A24444195B33B714567FB (void);
// 0x000000D4 System.Void TMPro.Examples.TMP_ExampleScript_01::.ctor()
extern void TMP_ExampleScript_01__ctor_m3641F2E0D25B6666CE77773A4A493C4C4D3D3A12 (void);
// 0x000000D5 System.Void TMPro.Examples.TMP_FrameRateCounter::Awake()
extern void TMP_FrameRateCounter_Awake_m958B668086DB4A38D9C56E3F8C2DCCB6FF11FAA3 (void);
// 0x000000D6 System.Void TMPro.Examples.TMP_FrameRateCounter::Start()
extern void TMP_FrameRateCounter_Start_mC642CA714D0FB8482D2AC6192D976DA179EE3720 (void);
// 0x000000D7 System.Void TMPro.Examples.TMP_FrameRateCounter::Update()
extern void TMP_FrameRateCounter_Update_m5E41B55573D86C3D345BFE11C489B00229BCEE21 (void);
// 0x000000D8 System.Void TMPro.Examples.TMP_FrameRateCounter::Set_FrameCounter_Position(TMPro.Examples.TMP_FrameRateCounter/FpsCounterAnchorPositions)
extern void TMP_FrameRateCounter_Set_FrameCounter_Position_mA72ECDE464E3290E4F533491FC8113B8D4068BE1 (void);
// 0x000000D9 System.Void TMPro.Examples.TMP_FrameRateCounter::.ctor()
extern void TMP_FrameRateCounter__ctor_mC79D5BF3FAE2BB7D22D9955A75E3483725BA619C (void);
// 0x000000DA System.Void TMPro.Examples.TMP_TextEventCheck::OnEnable()
extern void TMP_TextEventCheck_OnEnable_mE6D5125EEE0720E6F414978A496066E7CF1592DF (void);
// 0x000000DB System.Void TMPro.Examples.TMP_TextEventCheck::OnDisable()
extern void TMP_TextEventCheck_OnDisable_m94F087C259890C48D4F5464ABA4CD1D0E5863A9A (void);
// 0x000000DC System.Void TMPro.Examples.TMP_TextEventCheck::OnCharacterSelection(System.Char,System.Int32)
extern void TMP_TextEventCheck_OnCharacterSelection_mDA044F0808D61A99CDA374075943CEB1C92C253D (void);
// 0x000000DD System.Void TMPro.Examples.TMP_TextEventCheck::OnSpriteSelection(System.Char,System.Int32)
extern void TMP_TextEventCheck_OnSpriteSelection_mE8FFA550F38F5447CA37205698A30A41ADE901E0 (void);
// 0x000000DE System.Void TMPro.Examples.TMP_TextEventCheck::OnWordSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventCheck_OnWordSelection_m6037166D18A938678A2B06F28A5DCB3E09FAC61B (void);
// 0x000000DF System.Void TMPro.Examples.TMP_TextEventCheck::OnLineSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventCheck_OnLineSelection_mD2BAA6C8ABD61F0442A40C5448FA7774D782C363 (void);
// 0x000000E0 System.Void TMPro.Examples.TMP_TextEventCheck::OnLinkSelection(System.String,System.String,System.Int32)
extern void TMP_TextEventCheck_OnLinkSelection_m184B11D5E35AC4EA7CDCE3340AB9FEE3C14BF41C (void);
// 0x000000E1 System.Void TMPro.Examples.TMP_TextEventCheck::.ctor()
extern void TMP_TextEventCheck__ctor_mA5E82EE7CE8F8836FC6CF3823CBC7356005B898B (void);
// 0x000000E2 System.Void TMPro.Examples.TMP_TextInfoDebugTool::.ctor()
extern void TMP_TextInfoDebugTool__ctor_mF6AA30660FBD4CE708B6147833853498993CB9EE (void);
// 0x000000E3 System.Void TMPro.Examples.TMP_TextSelector_A::Awake()
extern void TMP_TextSelector_A_Awake_mD7252A5075E30E3BF9BEF4353F7AA2A9203FC943 (void);
// 0x000000E4 System.Void TMPro.Examples.TMP_TextSelector_A::LateUpdate()
extern void TMP_TextSelector_A_LateUpdate_mDBBC09726332EDDEAF7C30AB6C08FB33261F79FD (void);
// 0x000000E5 System.Void TMPro.Examples.TMP_TextSelector_A::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_A_OnPointerEnter_mC19B85FB5B4E6EB47832C39F0115A513B85060D0 (void);
// 0x000000E6 System.Void TMPro.Examples.TMP_TextSelector_A::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_A_OnPointerExit_mE51C850F54B18A5C96E3BE015DFBB0F079E5AE66 (void);
// 0x000000E7 System.Void TMPro.Examples.TMP_TextSelector_A::.ctor()
extern void TMP_TextSelector_A__ctor_mEB83D3952B32CEE9A871EC60E3AE9B79048302BF (void);
// 0x000000E8 System.Void TMPro.Examples.TMP_TextSelector_B::Awake()
extern void TMP_TextSelector_B_Awake_m7E413A43C54DF9E0FE70C4E69FC682391B47205A (void);
// 0x000000E9 System.Void TMPro.Examples.TMP_TextSelector_B::OnEnable()
extern void TMP_TextSelector_B_OnEnable_m0828D13E2D407B90038442228D54FB0D7B3D29FB (void);
// 0x000000EA System.Void TMPro.Examples.TMP_TextSelector_B::OnDisable()
extern void TMP_TextSelector_B_OnDisable_m2B559A85B52C8CAFC7350CC7B4F8E5BC773EF781 (void);
// 0x000000EB System.Void TMPro.Examples.TMP_TextSelector_B::ON_TEXT_CHANGED(UnityEngine.Object)
extern void TMP_TextSelector_B_ON_TEXT_CHANGED_m1597DBE7C7EBE7CFA4DC395897A4779387B59910 (void);
// 0x000000EC System.Void TMPro.Examples.TMP_TextSelector_B::LateUpdate()
extern void TMP_TextSelector_B_LateUpdate_m8BA10E368C7F3483E9EC05589BBE45D7EFC75691 (void);
// 0x000000ED System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerEnter_m0A0064632E4C0E0ADCD4358AD5BC168BFB74AC4D (void);
// 0x000000EE System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerExit_m667659102B5B17FBAF56593B7034E5EC1C48D43F (void);
// 0x000000EF System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerClick_m8DB2D22EE2F4D3965115791C81F985D82021469F (void);
// 0x000000F0 System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerUp_m303500BE309B56F3ADCE8B461CEC50C8D5ED70BC (void);
// 0x000000F1 System.Void TMPro.Examples.TMP_TextSelector_B::RestoreCachedVertexAttributes(System.Int32)
extern void TMP_TextSelector_B_RestoreCachedVertexAttributes_m3D637CF2C6CA663922EBE56FFD672BE582E9F1F2 (void);
// 0x000000F2 System.Void TMPro.Examples.TMP_TextSelector_B::.ctor()
extern void TMP_TextSelector_B__ctor_mE654F9F1570570C4BACDA79640B8DB3033D91C33 (void);
// 0x000000F3 System.Void TMPro.Examples.TMP_UiFrameRateCounter::Awake()
extern void TMP_UiFrameRateCounter_Awake_m83DBE22B6CC551BE5E385048B92067679716179E (void);
// 0x000000F4 System.Void TMPro.Examples.TMP_UiFrameRateCounter::Start()
extern void TMP_UiFrameRateCounter_Start_m59DA342A492C9EF8AD5C4512753211BF3796C944 (void);
// 0x000000F5 System.Void TMPro.Examples.TMP_UiFrameRateCounter::Update()
extern void TMP_UiFrameRateCounter_Update_m28FC233C475AA15A3BE399BF9345977089997749 (void);
// 0x000000F6 System.Void TMPro.Examples.TMP_UiFrameRateCounter::Set_FrameCounter_Position(TMPro.Examples.TMP_UiFrameRateCounter/FpsCounterAnchorPositions)
extern void TMP_UiFrameRateCounter_Set_FrameCounter_Position_m2025933902F312C0EC4B6A864196A8BA8D545647 (void);
// 0x000000F7 System.Void TMPro.Examples.TMP_UiFrameRateCounter::.ctor()
extern void TMP_UiFrameRateCounter__ctor_m5774BF4B9389770FC34991095557B24417600F84 (void);
// 0x000000F8 System.Void TMPro.Examples.TMPro_InstructionOverlay::Awake()
extern void TMPro_InstructionOverlay_Awake_m2444EA8749D72BCEA4DC30A328E3745AB19062EC (void);
// 0x000000F9 System.Void TMPro.Examples.TMPro_InstructionOverlay::Set_FrameCounter_Position(TMPro.Examples.TMPro_InstructionOverlay/FpsCounterAnchorPositions)
extern void TMPro_InstructionOverlay_Set_FrameCounter_Position_m62B897E4DB2D6B1936833EC54D9C246D68D50EEB (void);
// 0x000000FA System.Void TMPro.Examples.TMPro_InstructionOverlay::.ctor()
extern void TMPro_InstructionOverlay__ctor_m7AB5B851B4BFB07547E460D6B7B9D969DEB4A7CF (void);
// 0x000000FB System.Void TMPro.Examples.TeleType::Awake()
extern void TeleType_Awake_m099FCB202F2A8299B133DC56ECB9D01A16C08DFE (void);
// 0x000000FC System.Collections.IEnumerator TMPro.Examples.TeleType::Start()
extern void TeleType_Start_m72DE9DE597F4FA0B1CA02115CBC1E74EB53F63F7 (void);
// 0x000000FD System.Void TMPro.Examples.TeleType::.ctor()
extern void TeleType__ctor_m12A79B34F66CBFDCA8F582F0689D1731586B90AF (void);
// 0x000000FE System.Void TMPro.Examples.TeleType/<Start>d__4::.ctor(System.Int32)
extern void U3CStartU3Ed__4__ctor_mF3575DBEBF4F153F6A899AF3362940298C11B629 (void);
// 0x000000FF System.Void TMPro.Examples.TeleType/<Start>d__4::System.IDisposable.Dispose()
extern void U3CStartU3Ed__4_System_IDisposable_Dispose_m6DABFDBC2A313BF6DD90AA1C43B4EF9D6249CBE9 (void);
// 0x00000100 System.Boolean TMPro.Examples.TeleType/<Start>d__4::MoveNext()
extern void U3CStartU3Ed__4_MoveNext_mEF7A3215376BDFB52C3DA9D26FF0459074E89715 (void);
// 0x00000101 System.Object TMPro.Examples.TeleType/<Start>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m66DC06D52865D30DAA78DBD70B6554D13E2EA70B (void);
// 0x00000102 System.Void TMPro.Examples.TeleType/<Start>d__4::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_mE854A2CECA0E01F3C2D90DA4F720CF0F387994F8 (void);
// 0x00000103 System.Object TMPro.Examples.TeleType/<Start>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m77D3936B94684C817EE9F6D2C903238A457D5261 (void);
// 0x00000104 System.Void TMPro.Examples.TextConsoleSimulator::Awake()
extern void TextConsoleSimulator_Awake_mA51EE182A528CCA5CAEA8DBE8AD30E43FDFAE7B0 (void);
// 0x00000105 System.Void TMPro.Examples.TextConsoleSimulator::Start()
extern void TextConsoleSimulator_Start_m429701BE4C9A52AA6B257172A4D85D58E091E7DA (void);
// 0x00000106 System.Void TMPro.Examples.TextConsoleSimulator::OnEnable()
extern void TextConsoleSimulator_OnEnable_m3397FBCDA8D9DA264D2149288BE4DCF63368AB50 (void);
// 0x00000107 System.Void TMPro.Examples.TextConsoleSimulator::OnDisable()
extern void TextConsoleSimulator_OnDisable_m43DF869E864789E215873192ECFCDC51ABA79712 (void);
// 0x00000108 System.Void TMPro.Examples.TextConsoleSimulator::ON_TEXT_CHANGED(UnityEngine.Object)
extern void TextConsoleSimulator_ON_TEXT_CHANGED_m51F06EE5DD9B32FEFB529743F209C6E6C41BE3B8 (void);
// 0x00000109 System.Collections.IEnumerator TMPro.Examples.TextConsoleSimulator::RevealCharacters(TMPro.TMP_Text)
extern void TextConsoleSimulator_RevealCharacters_mE8E415644F7BD2056D0809F7BB0FA9A2F9FE8534 (void);
// 0x0000010A System.Collections.IEnumerator TMPro.Examples.TextConsoleSimulator::RevealWords(TMPro.TMP_Text)
extern void TextConsoleSimulator_RevealWords_mFDBC863D30BC63ADCF2860F303AF252E27D0F4F4 (void);
// 0x0000010B System.Void TMPro.Examples.TextConsoleSimulator::.ctor()
extern void TextConsoleSimulator__ctor_m4719FB9D4D89F37234757D93876DF0193E8E2848 (void);
// 0x0000010C System.Void TMPro.Examples.TextConsoleSimulator/<RevealCharacters>d__7::.ctor(System.Int32)
extern void U3CRevealCharactersU3Ed__7__ctor_mD45A85F5F50909F70C80AC8CE460F4FD261CDE9D (void);
// 0x0000010D System.Void TMPro.Examples.TextConsoleSimulator/<RevealCharacters>d__7::System.IDisposable.Dispose()
extern void U3CRevealCharactersU3Ed__7_System_IDisposable_Dispose_m85F270FDC11A4D79E9CF47AADC9FA1FBF032F86C (void);
// 0x0000010E System.Boolean TMPro.Examples.TextConsoleSimulator/<RevealCharacters>d__7::MoveNext()
extern void U3CRevealCharactersU3Ed__7_MoveNext_mA9A6555E50889A7AA73F20749F25989165023DE3 (void);
// 0x0000010F System.Object TMPro.Examples.TextConsoleSimulator/<RevealCharacters>d__7::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRevealCharactersU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5BBAE6868EB7F1C11BE5DF001641E18C9D625F83 (void);
// 0x00000110 System.Void TMPro.Examples.TextConsoleSimulator/<RevealCharacters>d__7::System.Collections.IEnumerator.Reset()
extern void U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_Reset_mA9F4893381AB24E01EAEBFC38A88AF363A9A0691 (void);
// 0x00000111 System.Object TMPro.Examples.TextConsoleSimulator/<RevealCharacters>d__7::System.Collections.IEnumerator.get_Current()
extern void U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_get_Current_mFD0B7538B1A650FB389FFE9296B0E51AEA5B6B6F (void);
// 0x00000112 System.Void TMPro.Examples.TextConsoleSimulator/<RevealWords>d__8::.ctor(System.Int32)
extern void U3CRevealWordsU3Ed__8__ctor_m22FF9E770988107A928C5D1EA639F60239BFFEF0 (void);
// 0x00000113 System.Void TMPro.Examples.TextConsoleSimulator/<RevealWords>d__8::System.IDisposable.Dispose()
extern void U3CRevealWordsU3Ed__8_System_IDisposable_Dispose_m3EAF6EF4A8C99A71FEED251BF3F28A26BF6AD7F8 (void);
// 0x00000114 System.Boolean TMPro.Examples.TextConsoleSimulator/<RevealWords>d__8::MoveNext()
extern void U3CRevealWordsU3Ed__8_MoveNext_m3811753E2384D4CBBAD6BD712EBA4FAF00D73210 (void);
// 0x00000115 System.Object TMPro.Examples.TextConsoleSimulator/<RevealWords>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRevealWordsU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA3F93E4AA532F15D52D68B7121805C014AB2D7FB (void);
// 0x00000116 System.Void TMPro.Examples.TextConsoleSimulator/<RevealWords>d__8::System.Collections.IEnumerator.Reset()
extern void U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_Reset_mCDC8982948ED5F7743567569CA1D4A354218714F (void);
// 0x00000117 System.Object TMPro.Examples.TextConsoleSimulator/<RevealWords>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_get_Current_mF39E492D576810F58DB9031556CFD6806FD32E27 (void);
// 0x00000118 System.Void TMPro.Examples.TextMeshProFloatingText::Awake()
extern void TextMeshProFloatingText_Awake_m679E597FF18E192C1FBD263D0E5ECEA392412046 (void);
// 0x00000119 System.Void TMPro.Examples.TextMeshProFloatingText::Start()
extern void TextMeshProFloatingText_Start_m68E511DEEDA883FE0F0999B329451F3A8A7269B1 (void);
// 0x0000011A System.Collections.IEnumerator TMPro.Examples.TextMeshProFloatingText::DisplayTextMeshProFloatingText()
extern void TextMeshProFloatingText_DisplayTextMeshProFloatingText_m3C381B8A53C58CF001D7A9212B8BDA6F368CC2C7 (void);
// 0x0000011B System.Collections.IEnumerator TMPro.Examples.TextMeshProFloatingText::DisplayTextMeshFloatingText()
extern void TextMeshProFloatingText_DisplayTextMeshFloatingText_m22691E6EA41B7FCF782B03954865D8E3B890E4DF (void);
// 0x0000011C System.Void TMPro.Examples.TextMeshProFloatingText::.ctor()
extern void TextMeshProFloatingText__ctor_m968E2691E21A93C010CF8205BC3666ADF712457E (void);
// 0x0000011D System.Void TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshProFloatingText>d__12::.ctor(System.Int32)
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12__ctor_mA27BBC06A409A9D9FB03E0D2C74677486B80D168 (void);
// 0x0000011E System.Void TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshProFloatingText>d__12::System.IDisposable.Dispose()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_IDisposable_Dispose_m510FB73335FCBCBEC6AC61A4F2A0217722BF27FC (void);
// 0x0000011F System.Boolean TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshProFloatingText>d__12::MoveNext()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_MoveNext_m8DFB6850F5F9B8DF05173D4CB9C76B997EC87B57 (void);
// 0x00000120 System.Object TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshProFloatingText>d__12::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCD7B5218C81C0872AB501CD54626F1284A4F73BF (void);
// 0x00000121 System.Void TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshProFloatingText>d__12::System.Collections.IEnumerator.Reset()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_Reset_mD2D32B94CA8D5A6D502BA38BDE1969C856368F73 (void);
// 0x00000122 System.Object TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshProFloatingText>d__12::System.Collections.IEnumerator.get_Current()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_get_Current_m59B2488B0E3C72CE97659E8D19BB13C6E0A44E90 (void);
// 0x00000123 System.Void TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshFloatingText>d__13::.ctor(System.Int32)
extern void U3CDisplayTextMeshFloatingTextU3Ed__13__ctor_m359EAC129649F98C759B341846A6DC07F95230D2 (void);
// 0x00000124 System.Void TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshFloatingText>d__13::System.IDisposable.Dispose()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_IDisposable_Dispose_m36DE8722B670A7DDD9E70107024590B20A4E0B18 (void);
// 0x00000125 System.Boolean TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshFloatingText>d__13::MoveNext()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_MoveNext_mB7D320C272AAA835590B8460DA89DEBC0A243815 (void);
// 0x00000126 System.Object TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshFloatingText>d__13::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m891591B80D28B1DF2CF9EB78C19DA672A81231A2 (void);
// 0x00000127 System.Void TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshFloatingText>d__13::System.Collections.IEnumerator.Reset()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_Reset_m5EF21CA1E0C64E67D18D9355B5E064C93452F5B2 (void);
// 0x00000128 System.Object TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshFloatingText>d__13::System.Collections.IEnumerator.get_Current()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_get_Current_m4850A72D887C4DA3F53CA1A1A2BEAD5C5C6605A1 (void);
// 0x00000129 System.Void TMPro.Examples.TextMeshSpawner::Awake()
extern void TextMeshSpawner_Awake_mDF8CCC9C6B7380D6FA027263CDC3BC00EF75AEFB (void);
// 0x0000012A System.Void TMPro.Examples.TextMeshSpawner::Start()
extern void TextMeshSpawner_Start_m7CC21883CA786A846A44921D2E37C201C25439BA (void);
// 0x0000012B System.Void TMPro.Examples.TextMeshSpawner::.ctor()
extern void TextMeshSpawner__ctor_m1255777673BE591F62B4FC55EB999DBD7A7CB5A1 (void);
// 0x0000012C System.Void TMPro.Examples.VertexColorCycler::Awake()
extern void VertexColorCycler_Awake_m84B4548078500DA811F3ADFF66186373BE8EDABC (void);
// 0x0000012D System.Void TMPro.Examples.VertexColorCycler::Start()
extern void VertexColorCycler_Start_mC3FF90808EDD6A02F08375E909254778D5268B66 (void);
// 0x0000012E System.Collections.IEnumerator TMPro.Examples.VertexColorCycler::AnimateVertexColors()
extern void VertexColorCycler_AnimateVertexColors_m6960F777E4876DFCA726BCAE7A8163850D58FA42 (void);
// 0x0000012F System.Void TMPro.Examples.VertexColorCycler::.ctor()
extern void VertexColorCycler__ctor_m09990A8066C8A957A96CDBEBDA980399283B45E9 (void);
// 0x00000130 System.Void TMPro.Examples.VertexColorCycler/<AnimateVertexColors>d__3::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__3__ctor_m0038B1054BCC928D35F8C0021ED7D2E1C533E35F (void);
// 0x00000131 System.Void TMPro.Examples.VertexColorCycler/<AnimateVertexColors>d__3::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__3_System_IDisposable_Dispose_m5BAD394A0B09B3E0FF19E91521E02C2B3ADD6007 (void);
// 0x00000132 System.Boolean TMPro.Examples.VertexColorCycler/<AnimateVertexColors>d__3::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__3_MoveNext_m2842AF5B12AFC17112D1AE75E46AB1B12776D2A6 (void);
// 0x00000133 System.Object TMPro.Examples.VertexColorCycler/<AnimateVertexColors>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mAE810D7968957A09C88E61C29DAAEC68E4AF1E51 (void);
// 0x00000134 System.Void TMPro.Examples.VertexColorCycler/<AnimateVertexColors>d__3::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_Reset_m72ABAC50E9E4D972FB44CAFF387F3E23FEC5D932 (void);
// 0x00000135 System.Object TMPro.Examples.VertexColorCycler/<AnimateVertexColors>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_get_Current_m8DE595A1D01F3A507A356F8BCE020D0851412B52 (void);
// 0x00000136 System.Void TMPro.Examples.VertexJitter::Awake()
extern void VertexJitter_Awake_m9C5586A35BD9C928455D6479C93C1CE095447D8F (void);
// 0x00000137 System.Void TMPro.Examples.VertexJitter::OnEnable()
extern void VertexJitter_OnEnable_m97ED60DBD350C72D1436ADFB8009A6F33A78C825 (void);
// 0x00000138 System.Void TMPro.Examples.VertexJitter::OnDisable()
extern void VertexJitter_OnDisable_mF8D32D6E02E41A73C3E958FB6EE5D1D659D2A846 (void);
// 0x00000139 System.Void TMPro.Examples.VertexJitter::Start()
extern void VertexJitter_Start_m8A0FED7ED16F90DBF287E09BFCBD7B26E07DBF97 (void);
// 0x0000013A System.Void TMPro.Examples.VertexJitter::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexJitter_ON_TEXT_CHANGED_mC7AB0113F6823D4FF415A096314B55D9C1BE9549 (void);
// 0x0000013B System.Collections.IEnumerator TMPro.Examples.VertexJitter::AnimateVertexColors()
extern void VertexJitter_AnimateVertexColors_mECAE037FC0CBA52CAC71C0B61E88829FF18BCC16 (void);
// 0x0000013C System.Void TMPro.Examples.VertexJitter::.ctor()
extern void VertexJitter__ctor_m550C9169D6FCD6F60D6AABCB8B4955DF58A12DCE (void);
// 0x0000013D System.Void TMPro.Examples.VertexJitter/<AnimateVertexColors>d__11::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__11__ctor_m0222C3457F5ACA497FE3A8EC829DE4AD11A169F8 (void);
// 0x0000013E System.Void TMPro.Examples.VertexJitter/<AnimateVertexColors>d__11::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m717E79A39A8161ADDA9E62F7CDFB67B8F2D65099 (void);
// 0x0000013F System.Boolean TMPro.Examples.VertexJitter/<AnimateVertexColors>d__11::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__11_MoveNext_m169A75C7E2147372CB933520B670AF77907C1C6B (void);
// 0x00000140 System.Object TMPro.Examples.VertexJitter/<AnimateVertexColors>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m920EBA43D59A1A88E27FED92CF0AC0DF90179479 (void);
// 0x00000141 System.Void TMPro.Examples.VertexJitter/<AnimateVertexColors>d__11::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m6C045A6DD0B60F1512457448E615877EAB86D75D (void);
// 0x00000142 System.Object TMPro.Examples.VertexJitter/<AnimateVertexColors>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m017345FE58B497EAFC9D0CB1FB733F76EB3449AF (void);
// 0x00000143 System.Void TMPro.Examples.VertexShakeA::Awake()
extern void VertexShakeA_Awake_m005C6F9EE8A8FD816CD3A736D6AF199CD2B615A2 (void);
// 0x00000144 System.Void TMPro.Examples.VertexShakeA::OnEnable()
extern void VertexShakeA_OnEnable_m9F60F3951A7D0DF4201A0409F0ADC05243D324EA (void);
// 0x00000145 System.Void TMPro.Examples.VertexShakeA::OnDisable()
extern void VertexShakeA_OnDisable_m59B86895C03B278B2E634A7C68CC942344A8D2D2 (void);
// 0x00000146 System.Void TMPro.Examples.VertexShakeA::Start()
extern void VertexShakeA_Start_m3E623C28F873F54F4AC7579433C7C50B2A3319DE (void);
// 0x00000147 System.Void TMPro.Examples.VertexShakeA::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexShakeA_ON_TEXT_CHANGED_m7AD31F3239351E0916E4D02148F46A80DC148D7E (void);
// 0x00000148 System.Collections.IEnumerator TMPro.Examples.VertexShakeA::AnimateVertexColors()
extern void VertexShakeA_AnimateVertexColors_mC451E2732A4E3E90E2553811AD75903EEF974599 (void);
// 0x00000149 System.Void TMPro.Examples.VertexShakeA::.ctor()
extern void VertexShakeA__ctor_m7E6FD1700BD08616532AF22B3B489A18B88DFB62 (void);
// 0x0000014A System.Void TMPro.Examples.VertexShakeA/<AnimateVertexColors>d__11::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__11__ctor_m92612416BEC0EBF5E9849FB603629C0F2F95FEF2 (void);
// 0x0000014B System.Void TMPro.Examples.VertexShakeA/<AnimateVertexColors>d__11::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m77D966994D4717EAFD8EFE169F3E8A4EE8B05B81 (void);
// 0x0000014C System.Boolean TMPro.Examples.VertexShakeA/<AnimateVertexColors>d__11::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__11_MoveNext_mCEEDE03667D329386BB4AE7B8252B7A9B54F443F (void);
// 0x0000014D System.Object TMPro.Examples.VertexShakeA/<AnimateVertexColors>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mDCCD3645ACF9B18D760B341C863F853996FA9BCE (void);
// 0x0000014E System.Void TMPro.Examples.VertexShakeA/<AnimateVertexColors>d__11::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_mB9444B5E58B4E97105C447F547C0F74C51BCFBFA (void);
// 0x0000014F System.Object TMPro.Examples.VertexShakeA/<AnimateVertexColors>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m5CC464185D5C0251C6206E20AFFA681BA0525A7E (void);
// 0x00000150 System.Void TMPro.Examples.VertexShakeB::Awake()
extern void VertexShakeB_Awake_m99C9A0474DBFE462DC88C898F958C1805376F9D5 (void);
// 0x00000151 System.Void TMPro.Examples.VertexShakeB::OnEnable()
extern void VertexShakeB_OnEnable_m64299258797D745CDFE7F3CBEC4708BDBC7C3971 (void);
// 0x00000152 System.Void TMPro.Examples.VertexShakeB::OnDisable()
extern void VertexShakeB_OnDisable_m07D520A8D7BCD8D188CE9F5CC7845F47D5AD6EF4 (void);
// 0x00000153 System.Void TMPro.Examples.VertexShakeB::Start()
extern void VertexShakeB_Start_m9642281210FA5F701A324B78850331E4638B2DD1 (void);
// 0x00000154 System.Void TMPro.Examples.VertexShakeB::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexShakeB_ON_TEXT_CHANGED_m5650D69D258D0EEF35AF390D6D5086B327B308A5 (void);
// 0x00000155 System.Collections.IEnumerator TMPro.Examples.VertexShakeB::AnimateVertexColors()
extern void VertexShakeB_AnimateVertexColors_mDF7A7E7028361D288DF588D9301541E4FA1EFA87 (void);
// 0x00000156 System.Void TMPro.Examples.VertexShakeB::.ctor()
extern void VertexShakeB__ctor_m605A778C36B506B5763A1AE17B01F8DCCBCD51EC (void);
// 0x00000157 System.Void TMPro.Examples.VertexShakeB/<AnimateVertexColors>d__10::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__10__ctor_m3E3B1D286DEBED2BC028AD490308568B930C3760 (void);
// 0x00000158 System.Void TMPro.Examples.VertexShakeB/<AnimateVertexColors>d__10::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_m0F9D4B2A6ED0500C2120DBA29932CC279E8908DC (void);
// 0x00000159 System.Boolean TMPro.Examples.VertexShakeB/<AnimateVertexColors>d__10::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__10_MoveNext_m0534E436514E663BF024364E524EE5716FF15C8E (void);
// 0x0000015A System.Object TMPro.Examples.VertexShakeB/<AnimateVertexColors>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF2A8BAFC0261ACBBE8EEA74DE4B498D30C68AE3D (void);
// 0x0000015B System.Void TMPro.Examples.VertexShakeB/<AnimateVertexColors>d__10::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m5F12D7C6F2523BEB6326FE49AE972116D6157CBB (void);
// 0x0000015C System.Object TMPro.Examples.VertexShakeB/<AnimateVertexColors>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mB9C12786011A3B78517AEFAE8D5A78B95A4219AD (void);
// 0x0000015D System.Void TMPro.Examples.VertexZoom::Awake()
extern void VertexZoom_Awake_m1B5D386B98CF2EB05A8155B238D6F6E8275D181C (void);
// 0x0000015E System.Void TMPro.Examples.VertexZoom::OnEnable()
extern void VertexZoom_OnEnable_m7F980FC038FC2534C428A5FD33E3E13AEAEB4EEC (void);
// 0x0000015F System.Void TMPro.Examples.VertexZoom::OnDisable()
extern void VertexZoom_OnDisable_m880C38B62B4BB05AF49F12F75B83FFA2F0519884 (void);
// 0x00000160 System.Void TMPro.Examples.VertexZoom::Start()
extern void VertexZoom_Start_m10A182DCEF8D430DADAFBFFA3F04171F8E60C84C (void);
// 0x00000161 System.Void TMPro.Examples.VertexZoom::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexZoom_ON_TEXT_CHANGED_mB696E443C61D2212AC93A7615AA58106DD25250F (void);
// 0x00000162 System.Collections.IEnumerator TMPro.Examples.VertexZoom::AnimateVertexColors()
extern void VertexZoom_AnimateVertexColors_mEFBA6C940DFECB485236C247358A32011A7963ED (void);
// 0x00000163 System.Void TMPro.Examples.VertexZoom::.ctor()
extern void VertexZoom__ctor_mE7B36F2D3EC8EF397AB0AD7A19E988C06927A3B2 (void);
// 0x00000164 System.Void TMPro.Examples.VertexZoom/<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_m4EC5F8042B5AC645EA7D0913E50FD22144DBD348 (void);
// 0x00000165 System.Int32 TMPro.Examples.VertexZoom/<>c__DisplayClass10_0::<AnimateVertexColors>b__0(System.Int32,System.Int32)
extern void U3CU3Ec__DisplayClass10_0_U3CAnimateVertexColorsU3Eb__0_m959A7E1D6162B5AAF28B953AFB04D7943BCAB107 (void);
// 0x00000166 System.Void TMPro.Examples.VertexZoom/<AnimateVertexColors>d__10::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__10__ctor_m537CF0A5ADF5BBC2DF784BF526E3F32EB528E1B2 (void);
// 0x00000167 System.Void TMPro.Examples.VertexZoom/<AnimateVertexColors>d__10::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_mF0CD944C393771101D2718A660E1DFF22385819F (void);
// 0x00000168 System.Boolean TMPro.Examples.VertexZoom/<AnimateVertexColors>d__10::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__10_MoveNext_m8340EFEB2B2CF6EA1545CFB6967968CA171FEE66 (void);
// 0x00000169 System.Object TMPro.Examples.VertexZoom/<AnimateVertexColors>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m093E922A5A046910B2A7EE826D804CA3064A7BD9 (void);
// 0x0000016A System.Void TMPro.Examples.VertexZoom/<AnimateVertexColors>d__10::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_mDED63FD52741D58D8D5A3E53415F91B6560F680C (void);
// 0x0000016B System.Object TMPro.Examples.VertexZoom/<AnimateVertexColors>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_m933EBF7C4300C7C1E3EE60E4741110025877CA5F (void);
// 0x0000016C System.Void TMPro.Examples.WarpTextExample::Awake()
extern void WarpTextExample_Awake_mEDB072A485F3F37270FC736E1A201624D696B4B0 (void);
// 0x0000016D System.Void TMPro.Examples.WarpTextExample::Start()
extern void WarpTextExample_Start_m36448AEA494658D7C129C3B71BF3A64CC4DFEDC4 (void);
// 0x0000016E UnityEngine.AnimationCurve TMPro.Examples.WarpTextExample::CopyAnimationCurve(UnityEngine.AnimationCurve)
extern void WarpTextExample_CopyAnimationCurve_m744026E638662DA48AC81ED21E0589E3E4E05FAB (void);
// 0x0000016F System.Collections.IEnumerator TMPro.Examples.WarpTextExample::WarpText()
extern void WarpTextExample_WarpText_mA29C98CF3B92F253C2DD2BADFC76618F8324BEF2 (void);
// 0x00000170 System.Void TMPro.Examples.WarpTextExample::.ctor()
extern void WarpTextExample__ctor_m62299DFDB704027267321007E16DB87D93D0F099 (void);
// 0x00000171 System.Void TMPro.Examples.WarpTextExample/<WarpText>d__8::.ctor(System.Int32)
extern void U3CWarpTextU3Ed__8__ctor_m9FADE04C27A0034C5A276232FCA187AECDC6BF49 (void);
// 0x00000172 System.Void TMPro.Examples.WarpTextExample/<WarpText>d__8::System.IDisposable.Dispose()
extern void U3CWarpTextU3Ed__8_System_IDisposable_Dispose_m5AB0DCF4B3DE6C290487F3DBBC7BAE931130DE60 (void);
// 0x00000173 System.Boolean TMPro.Examples.WarpTextExample/<WarpText>d__8::MoveNext()
extern void U3CWarpTextU3Ed__8_MoveNext_m9C83C8455FF8ADFBAA8D05958C3048612A96EB84 (void);
// 0x00000174 System.Object TMPro.Examples.WarpTextExample/<WarpText>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWarpTextU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9D5776AF80C4227401ADD7E13D98F2530CB9E7A1 (void);
// 0x00000175 System.Void TMPro.Examples.WarpTextExample/<WarpText>d__8::System.Collections.IEnumerator.Reset()
extern void U3CWarpTextU3Ed__8_System_Collections_IEnumerator_Reset_m4F2FBBE7B375E6FC837736B4275A7B601A01F535 (void);
// 0x00000176 System.Object TMPro.Examples.WarpTextExample/<WarpText>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CWarpTextU3Ed__8_System_Collections_IEnumerator_get_Current_m01FA935D93D737C9DDD88A051F7DFC393DD7BD25 (void);
// 0x00000177 System.String SimpleJSON.Json::Serialize(System.Object)
extern void Json_Serialize_m3D53585BB85C67CF02F16F50AF185CE70B1B2C6F (void);
// 0x00000178 System.Void SimpleJSON.Json/Serializer::.ctor()
extern void Serializer__ctor_m9090E3158FD9DC53DE34759B18F7C2C6D2D68309 (void);
// 0x00000179 System.String SimpleJSON.Json/Serializer::Serialize(System.Object)
extern void Serializer_Serialize_mE51FB24524ABE5C4BD4640D274BE78538AD397F6 (void);
// 0x0000017A System.Void SimpleJSON.Json/Serializer::SerializeValue(System.Object)
extern void Serializer_SerializeValue_m2AFFC257F2288B112E11322A41317C1AC4859D62 (void);
// 0x0000017B System.Void SimpleJSON.Json/Serializer::SerializeObject(System.Collections.IDictionary)
extern void Serializer_SerializeObject_mA5E7E54F453D0BEDC714D018A4CD938C2CB1C5B5 (void);
// 0x0000017C System.Void SimpleJSON.Json/Serializer::SerializeArray(System.Collections.IList)
extern void Serializer_SerializeArray_m7162DCF619ED10C6847424939C3FA2B42ECB04B9 (void);
// 0x0000017D System.Void SimpleJSON.Json/Serializer::SerializeString(System.String)
extern void Serializer_SerializeString_m7147818113EFD8696129200E887B9F48360EBC38 (void);
// 0x0000017E System.Void SimpleJSON.Json/Serializer::SerializeOther(System.Object)
extern void Serializer_SerializeOther_m1201B846CA73DD0433A356037F3D6227051EC890 (void);
// 0x0000017F System.Object MiniJSON.Json::Deserialize(System.String)
extern void Json_Deserialize_m699D585677C2862DBAFA44EC31F8B6BEFB90970A (void);
// 0x00000180 System.String MiniJSON.Json::Serialize(System.Object)
extern void Json_Serialize_m39431EDE1526C8634DECB4F2FECF100067432169 (void);
// 0x00000181 System.Boolean MiniJSON.Json/Parser::IsWordBreak(System.Char)
extern void Parser_IsWordBreak_mC0D8CFAB5531BC6B513F269FB4DDB1A306D580DA (void);
// 0x00000182 System.Void MiniJSON.Json/Parser::.ctor(System.String)
extern void Parser__ctor_m4E1732BA0BD698178125471DC1511219299898F8 (void);
// 0x00000183 System.Object MiniJSON.Json/Parser::Parse(System.String)
extern void Parser_Parse_m0C859F2B5F4F846DE4C1BA6A25C1F5CDE0A4E225 (void);
// 0x00000184 System.Void MiniJSON.Json/Parser::Dispose()
extern void Parser_Dispose_mAA3BFFD7355890D49D822235E90A2344EBDBE6C5 (void);
// 0x00000185 System.Collections.Generic.Dictionary`2<System.String,System.Object> MiniJSON.Json/Parser::ParseObject()
extern void Parser_ParseObject_mDDD2FB38855612FD864DBA2DFEA9C11BF73DC39E (void);
// 0x00000186 System.Collections.Generic.List`1<System.Object> MiniJSON.Json/Parser::ParseArray()
extern void Parser_ParseArray_m652900CDFFD881DF9449BDD372556C340DCD75D3 (void);
// 0x00000187 System.Object MiniJSON.Json/Parser::ParseValue()
extern void Parser_ParseValue_m59151796F1BD6D3E46D554A49EF34BCDB403AA79 (void);
// 0x00000188 System.Object MiniJSON.Json/Parser::ParseByToken(MiniJSON.Json/Parser/TOKEN)
extern void Parser_ParseByToken_m911C011FACC990674C6B917558E12B9DA2CBE444 (void);
// 0x00000189 System.String MiniJSON.Json/Parser::ParseString()
extern void Parser_ParseString_m0D81629614AB969C04BBD74965821A39E1573D63 (void);
// 0x0000018A System.Object MiniJSON.Json/Parser::ParseNumber()
extern void Parser_ParseNumber_m2A376DA74162CDEE4A283B5BD92FCF80E066A04E (void);
// 0x0000018B System.Void MiniJSON.Json/Parser::EatWhitespace()
extern void Parser_EatWhitespace_m8C75236AFAB8FFF856DA2BFE53BC84F9C7E05AA1 (void);
// 0x0000018C System.Char MiniJSON.Json/Parser::get_PeekChar()
extern void Parser_get_PeekChar_mC5C7804B362B6A163532B53F1D9270D8F7F8C55A (void);
// 0x0000018D System.Char MiniJSON.Json/Parser::get_NextChar()
extern void Parser_get_NextChar_m02DE23E038D31DE928B6F89B149590A35209D4A1 (void);
// 0x0000018E System.String MiniJSON.Json/Parser::get_NextWord()
extern void Parser_get_NextWord_m7DA018BF5C404FE6FB873F46E721A512FD63ED2F (void);
// 0x0000018F MiniJSON.Json/Parser/TOKEN MiniJSON.Json/Parser::get_NextToken()
extern void Parser_get_NextToken_m889CBAFA9C9DDDE25A59F5CD4BC592654A1CA567 (void);
// 0x00000190 System.Void MiniJSON.Json/Serializer::.ctor()
extern void Serializer__ctor_mE358C3CEC17F0D9F2158C5D09F9BD1CB6B760F84 (void);
// 0x00000191 System.String MiniJSON.Json/Serializer::Serialize(System.Object)
extern void Serializer_Serialize_mBEDF816D5B952D6C2EDFEE5475395CD4249BDB9C (void);
// 0x00000192 System.Void MiniJSON.Json/Serializer::SerializeValue(System.Object)
extern void Serializer_SerializeValue_mBE0C676D8B5F4EBD76E9019A7FE931F8BB2416EE (void);
// 0x00000193 System.Void MiniJSON.Json/Serializer::SerializeObject(System.Collections.IDictionary)
extern void Serializer_SerializeObject_m8B5E760CF414451768C00F044DBC2B36A028E1D4 (void);
// 0x00000194 System.Void MiniJSON.Json/Serializer::SerializeArray(System.Collections.IList)
extern void Serializer_SerializeArray_m72FB41798EAB678E1064FC4DC830E3F34EB72302 (void);
// 0x00000195 System.Void MiniJSON.Json/Serializer::SerializeString(System.String)
extern void Serializer_SerializeString_m8EF870ACEA27199F33FA1B647B801C3E026CF31F (void);
// 0x00000196 System.Void MiniJSON.Json/Serializer::SerializeOther(System.Object)
extern void Serializer_SerializeOther_m20D11252CFA7B52079C618491BCB3AFE22332BC4 (void);
// 0x00000197 System.String MimeTypes.MimeTypeMap::GetMimeType(System.String)
extern void MimeTypeMap_GetMimeType_mE4EFCA9A399C7D1E7A7D32597BA348942DA727AF (void);
// 0x00000198 System.String MimeTypes.MimeTypeMap::GetExtension(System.String)
extern void MimeTypeMap_GetExtension_m5CDF7C52EB88F651B5B8443360341708DAE7FDDC (void);
// 0x00000199 System.Void MimeTypes.MimeTypeMap::.cctor()
extern void MimeTypeMap__cctor_m7960D90CED0FC62F54F6BD26FD1392C24F71AC78 (void);
// 0x0000019A System.Void NCMB.NCMBManager::Awake()
extern void NCMBManager_Awake_mB9D5BA5B62BA5C922B0FDE3521D20D950F2F50A8 (void);
// 0x0000019B System.Boolean NCMB.NCMBManager::get_Inited()
extern void NCMBManager_get_Inited_m1F2171355D1686CAF80FEEDCDF45FF768A109FA3 (void);
// 0x0000019C System.Void NCMB.NCMBManager::set_Inited(System.Boolean)
extern void NCMBManager_set_Inited_mE736FA9956382CF83E644BD1906B6FC35BCB02AA (void);
// 0x0000019D System.Void NCMB.NCMBManager::OnRegistration(System.String)
extern void NCMBManager_OnRegistration_m23173E5808F6BF6BB4B11B96928D3A874A5AB751 (void);
// 0x0000019E System.Void NCMB.NCMBManager::OnNotificationReceived(System.String)
extern void NCMBManager_OnNotificationReceived_mB27A9079F79053F6B97E8E989B0649E648955223 (void);
// 0x0000019F System.String NCMB.NCMBManager::SearchPath()
extern void NCMBManager_SearchPath_m08D8FE097734E1C8CC4D0016A962931463BB2480 (void);
// 0x000001A0 System.Void NCMB.NCMBManager::onTokenReceived(System.String)
extern void NCMBManager_onTokenReceived_mBD1D57B36FA470746F6F7D11322FFA5A57E4A4B1 (void);
// 0x000001A1 System.Void NCMB.NCMBManager::updateExistedInstallation(NCMB.NCMBInstallation,System.String)
extern void NCMBManager_updateExistedInstallation_mEC6DE2910A6378DBE1A861E23AB94C848F70951A (void);
// 0x000001A2 System.Void NCMB.NCMBManager::SaveFile(System.String,System.String)
extern void NCMBManager_SaveFile_m238E6D9C643891D5713BFD8DA2E1976A225E4045 (void);
// 0x000001A3 System.String NCMB.NCMBManager::ReadFile(System.String)
extern void NCMBManager_ReadFile_m67EB5D172890F834BF2E872258CB662B4BA5F182 (void);
// 0x000001A4 System.Void NCMB.NCMBManager::onAnalyticsReceived(System.String)
extern void NCMBManager_onAnalyticsReceived_m43E0E57722F636A5913A335B28DEFDE5E5ABAFC2 (void);
// 0x000001A5 System.Void NCMB.NCMBManager::DeleteCurrentInstallation(System.String)
extern void NCMBManager_DeleteCurrentInstallation_m9EA8289F7E18323C07F0B39D5D1F557F195FCC23 (void);
// 0x000001A6 System.String NCMB.NCMBManager::GetCurrentInstallation()
extern void NCMBManager_GetCurrentInstallation_m1B73955954721A4050BF5F1F8E9B8C2565B000AD (void);
// 0x000001A7 System.Void NCMB.NCMBManager::CreateInstallationProperty()
extern void NCMBManager_CreateInstallationProperty_mF7803E06EF82002435C9E457484592024AEC4065 (void);
// 0x000001A8 System.Void NCMB.NCMBManager::.ctor()
extern void NCMBManager__ctor_m084D76A3D94F025DAD4EAAE713A1FDF4A3211AF2 (void);
// 0x000001A9 System.Void NCMB.NCMBManager::.cctor()
extern void NCMBManager__cctor_mED5F3D4B00878F07488880DF6E4C01B8E41DB3C3 (void);
// 0x000001AA System.Void NCMB.NCMBManager/OnRegistrationDelegate::.ctor(System.Object,System.IntPtr)
extern void OnRegistrationDelegate__ctor_m277EDC977BFFDB91D17383A2550179F821C0BBD6 (void);
// 0x000001AB System.Void NCMB.NCMBManager/OnRegistrationDelegate::Invoke(System.String)
extern void OnRegistrationDelegate_Invoke_mAC2B1767388C2ADD8FECEF0071122FAF810AA43C (void);
// 0x000001AC System.IAsyncResult NCMB.NCMBManager/OnRegistrationDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void OnRegistrationDelegate_BeginInvoke_m509E4EBAEEFFE45D29BB99DCF52486F8819AC20F (void);
// 0x000001AD System.Void NCMB.NCMBManager/OnRegistrationDelegate::EndInvoke(System.IAsyncResult)
extern void OnRegistrationDelegate_EndInvoke_mCEDA3D45125FC270D3C25C1C4BB1821E260B3437 (void);
// 0x000001AE System.Void NCMB.NCMBManager/OnNotificationReceivedDelegate::.ctor(System.Object,System.IntPtr)
extern void OnNotificationReceivedDelegate__ctor_m0E6AA3E5CF780340E102AC41658E5F2C2D289847 (void);
// 0x000001AF System.Void NCMB.NCMBManager/OnNotificationReceivedDelegate::Invoke(NCMB.NCMBPushPayload)
extern void OnNotificationReceivedDelegate_Invoke_m2AA62B0D3406EAAAA3E61CFBADEF9676F9152ECE (void);
// 0x000001B0 System.IAsyncResult NCMB.NCMBManager/OnNotificationReceivedDelegate::BeginInvoke(NCMB.NCMBPushPayload,System.AsyncCallback,System.Object)
extern void OnNotificationReceivedDelegate_BeginInvoke_mC0CE976457FC8AFD7634273517900E032B7A6713 (void);
// 0x000001B1 System.Void NCMB.NCMBManager/OnNotificationReceivedDelegate::EndInvoke(System.IAsyncResult)
extern void OnNotificationReceivedDelegate_EndInvoke_m814C7789235DD36BED31C606FCC2C2967C9C8012 (void);
// 0x000001B2 System.Void NCMB.NCMBManager/<>c__DisplayClass15_0::.ctor()
extern void U3CU3Ec__DisplayClass15_0__ctor_mDB22A4982A0AF2138A3CD6AB2E0EF26C452A0D19 (void);
// 0x000001B3 System.Void NCMB.NCMBManager/<>c__DisplayClass15_0::<onTokenReceived>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass15_0_U3ConTokenReceivedU3Eb__0_mB18A1DBF5102DACD5EEE1EBA06BD78E9A3374DDC (void);
// 0x000001B4 System.Void NCMB.NCMBManager/<>c__DisplayClass15_0::<onTokenReceived>b__1(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass15_0_U3ConTokenReceivedU3Eb__1_m7A7C9DBA04323BBC4EACD793EB6430586C86269C (void);
// 0x000001B5 System.Void NCMB.NCMBManager/<>c__DisplayClass16_0::.ctor()
extern void U3CU3Ec__DisplayClass16_0__ctor_mBF6DBEE298B028DD8FBA07B318562DC10A1C5BAB (void);
// 0x000001B6 System.Void NCMB.NCMBManager/<>c__DisplayClass16_0::<updateExistedInstallation>b__0(System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass16_0_U3CupdateExistedInstallationU3Eb__0_m8DFF37E8265BD006B6E413CB2404B2EC1C8E0887 (void);
// 0x000001B7 System.Void NCMB.NCMBManager/<>c__DisplayClass16_0::<updateExistedInstallation>b__1(System.Collections.Generic.List`1<NCMB.NCMBInstallation>,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass16_0_U3CupdateExistedInstallationU3Eb__1_mC2A16A057A096BA46E82257DEB9168ED95B0D28F (void);
// 0x000001B8 System.Void NCMB.NCMBManager/<>c__DisplayClass16_0::<updateExistedInstallation>b__2(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass16_0_U3CupdateExistedInstallationU3Eb__2_m9B4E51D3AEB08C50DE3A517808FB93FDA9C54843 (void);
// 0x000001B9 System.String NCMB.NCMBPushPayload::get_PushId()
extern void NCMBPushPayload_get_PushId_m988C72E87E78A06B45ADA8528FC04B3F03D98968 (void);
// 0x000001BA System.Void NCMB.NCMBPushPayload::set_PushId(System.String)
extern void NCMBPushPayload_set_PushId_m3F7E8DCB48B8FBB4A919EC5FDBFA61FA97D9428D (void);
// 0x000001BB System.String NCMB.NCMBPushPayload::get_Data()
extern void NCMBPushPayload_get_Data_m8EEEA470E0BD18624CE98873BBFCE4DB77493CB0 (void);
// 0x000001BC System.Void NCMB.NCMBPushPayload::set_Data(System.String)
extern void NCMBPushPayload_set_Data_m2BBEE880905A81ADF546F0CFBBEA021E5F4A83EB (void);
// 0x000001BD System.String NCMB.NCMBPushPayload::get_Title()
extern void NCMBPushPayload_get_Title_mB5018F333CBCA72577E3F7A44D9E993493BCDE78 (void);
// 0x000001BE System.Void NCMB.NCMBPushPayload::set_Title(System.String)
extern void NCMBPushPayload_set_Title_mF39103B09D6AF982932D478157ACEB3A34097735 (void);
// 0x000001BF System.String NCMB.NCMBPushPayload::get_Message()
extern void NCMBPushPayload_get_Message_m1235E378B679140B3A79E2A885577F27193EEBE3 (void);
// 0x000001C0 System.Void NCMB.NCMBPushPayload::set_Message(System.String)
extern void NCMBPushPayload_set_Message_m0CB777379F3CEEABE7CCA2AE4BFB12CDD72AA266 (void);
// 0x000001C1 System.String NCMB.NCMBPushPayload::get_Channel()
extern void NCMBPushPayload_get_Channel_m9489EE88A990304C21F1E50570523927587EC87B (void);
// 0x000001C2 System.Void NCMB.NCMBPushPayload::set_Channel(System.String)
extern void NCMBPushPayload_set_Channel_m1FB9EBA73E77B22708007A370F4892A9FF010C66 (void);
// 0x000001C3 System.Boolean NCMB.NCMBPushPayload::get_Dialog()
extern void NCMBPushPayload_get_Dialog_mF0C1228C4A8A926BC5C5D615B83FB23BCD1F49E5 (void);
// 0x000001C4 System.Void NCMB.NCMBPushPayload::set_Dialog(System.Boolean)
extern void NCMBPushPayload_set_Dialog_m66789ED50999DF2FFDFFE113ACC765C2FD3288B7 (void);
// 0x000001C5 System.String NCMB.NCMBPushPayload::get_RichUrl()
extern void NCMBPushPayload_get_RichUrl_m63FA63B36A98C7CC6B89331F7D52A60AD9C29089 (void);
// 0x000001C6 System.Void NCMB.NCMBPushPayload::set_RichUrl(System.String)
extern void NCMBPushPayload_set_RichUrl_m4473C6A691353BF27F4155CDF352198C4DD69742 (void);
// 0x000001C7 System.Collections.IDictionary NCMB.NCMBPushPayload::get_UserInfo()
extern void NCMBPushPayload_get_UserInfo_m119D2D4BCA9197F77AAD5F20C6DD5137DCCAE557 (void);
// 0x000001C8 System.Void NCMB.NCMBPushPayload::set_UserInfo(System.Collections.IDictionary)
extern void NCMBPushPayload_set_UserInfo_m41FEC468EBC26C9C9B95F298203ACAC7140BC5FA (void);
// 0x000001C9 System.Void NCMB.NCMBPushPayload::.ctor(System.String,System.String,System.String,System.String,System.String,System.String,System.String,System.Collections.IDictionary)
extern void NCMBPushPayload__ctor_m6D1ED4AA9CE21DCF04F93B350D4B09D4124D70D1 (void);
// 0x000001CA System.String NCMB.NCMBSettings::get_CurrentUser()
extern void NCMBSettings_get_CurrentUser_mB3796DA9998CFD63310B7514F60D69B47C443F00 (void);
// 0x000001CB System.Void NCMB.NCMBSettings::set_CurrentUser(System.String)
extern void NCMBSettings_set_CurrentUser_mC5D0D6BDE837E1678D57799604D3AD927D5A951D (void);
// 0x000001CC System.String NCMB.NCMBSettings::get_ApplicationKey()
extern void NCMBSettings_get_ApplicationKey_m70D746DD7C2F3F50863D607DBC52A3960E19106F (void);
// 0x000001CD System.Void NCMB.NCMBSettings::set_ApplicationKey(System.String)
extern void NCMBSettings_set_ApplicationKey_m29F5D17D41241078E896666D342ED44EC240176F (void);
// 0x000001CE System.String NCMB.NCMBSettings::get_ClientKey()
extern void NCMBSettings_get_ClientKey_m65FF92C16B47752D909840A1EE14692FB7EC451E (void);
// 0x000001CF System.Void NCMB.NCMBSettings::set_ClientKey(System.String)
extern void NCMBSettings_set_ClientKey_mE87541A211201F79B8E989EDA0FBEE218AA3BBA7 (void);
// 0x000001D0 System.Boolean NCMB.NCMBSettings::get_UsePush()
extern void NCMBSettings_get_UsePush_m072B6C82712E6DD39C4B718B8278635DE041F422 (void);
// 0x000001D1 System.Boolean NCMB.NCMBSettings::get_UseAnalytics()
extern void NCMBSettings_get_UseAnalytics_mA88990CA4A2B715462395108A7E62B235F343AA3 (void);
// 0x000001D2 System.String NCMB.NCMBSettings::get_DomainURL()
extern void NCMBSettings_get_DomainURL_m1DE95F9FE76F5BE62BC6FF24BCB6978D50C01215 (void);
// 0x000001D3 System.Void NCMB.NCMBSettings::set_DomainURL(System.String)
extern void NCMBSettings_set_DomainURL_m563D6A73D7069454B87F78AF929EEE04A968E034 (void);
// 0x000001D4 System.String NCMB.NCMBSettings::get_APIVersion()
extern void NCMBSettings_get_APIVersion_m1793B35AD4EE5CD5B66EB1F65F1626D2BBCF1F4A (void);
// 0x000001D5 System.Void NCMB.NCMBSettings::set_APIVersion(System.String)
extern void NCMBSettings_set_APIVersion_m276F4426D0EE307C5804CDD6A2DF89F2AD871A52 (void);
// 0x000001D6 System.Void NCMB.NCMBSettings::.ctor()
extern void NCMBSettings__ctor_m2673AA9DA9DC196640D24DF026C3BE70034ABABB (void);
// 0x000001D7 System.Void NCMB.NCMBSettings::Initialize(System.String,System.String,System.String,System.String)
extern void NCMBSettings_Initialize_m9D6680754B2EA7DE5CAD6CA809949BC633C18ECB (void);
// 0x000001D8 System.Void NCMB.NCMBSettings::RegisterPush(System.Boolean,System.Boolean,System.Boolean)
extern void NCMBSettings_RegisterPush_mFC5E7AF0A4FFD8EF999E91FA5772476FB311D766 (void);
// 0x000001D9 System.Void NCMB.NCMBSettings::EnableResponseValidation(System.Boolean)
extern void NCMBSettings_EnableResponseValidation_m0801D684D13552A48E0C78883D30586481C16B4C (void);
// 0x000001DA System.Void NCMB.NCMBSettings::Awake()
extern void NCMBSettings_Awake_m8CDEE2C3DA636DC19775A24C8A720DD6C3C2CFE4 (void);
// 0x000001DB System.Void NCMB.NCMBSettings::Connection(NCMB.Internal.NCMBConnection,System.Object)
extern void NCMBSettings_Connection_mA6E3699CB589879B973BAE1F3BA6748CA3DB610E (void);
// 0x000001DC System.Void NCMB.NCMBSettings::.cctor()
extern void NCMBSettings__cctor_mC258D992797351B4813EE8986B93B135CE72CAB4 (void);
// 0x000001DD System.Void NCMB.NCMBACL::set_PublicReadAccess(System.Boolean)
extern void NCMBACL_set_PublicReadAccess_m21DB367E5FE03C2430D9770B7D0CF6856038F033 (void);
// 0x000001DE System.Boolean NCMB.NCMBACL::get_PublicReadAccess()
extern void NCMBACL_get_PublicReadAccess_m41F1607980109ED8DE01C0B190691678839C43B2 (void);
// 0x000001DF System.Void NCMB.NCMBACL::set_PublicWriteAccess(System.Boolean)
extern void NCMBACL_set_PublicWriteAccess_m19B9F11D254035D23F9512528EE60A993594EC89 (void);
// 0x000001E0 System.Boolean NCMB.NCMBACL::get_PublicWriteAccess()
extern void NCMBACL_get_PublicWriteAccess_mA2F881CA460DF3ED9DF7D9B19E7C2DFED317066E (void);
// 0x000001E1 System.Void NCMB.NCMBACL::.ctor()
extern void NCMBACL__ctor_m446FCA9252FD6448AA63FD3BFB29ABBE0F4A1FFB (void);
// 0x000001E2 System.Void NCMB.NCMBACL::.ctor(System.String)
extern void NCMBACL__ctor_m3443B9E708BEA39669B83EB77BD540BE7BAF823A (void);
// 0x000001E3 System.Boolean NCMB.NCMBACL::_isShared()
extern void NCMBACL__isShared_m02B030E5C3F0E3E7B3E8C36AE37783DFA108F342 (void);
// 0x000001E4 System.Void NCMB.NCMBACL::_setShared(System.Boolean)
extern void NCMBACL__setShared_m47F22D86FF304D517003432D2A0753CD40C3968F (void);
// 0x000001E5 NCMB.NCMBACL NCMB.NCMBACL::_copy()
extern void NCMBACL__copy_m853568424B5BA87E0ACC981B1D8442B746D3B54F (void);
// 0x000001E6 System.Void NCMB.NCMBACL::SetReadAccess(System.String,System.Boolean)
extern void NCMBACL_SetReadAccess_m77C3E082F66537FBCD12F451628295EFAFEF9427 (void);
// 0x000001E7 System.Void NCMB.NCMBACL::SetWriteAccess(System.String,System.Boolean)
extern void NCMBACL_SetWriteAccess_m13C815C1BC48FB906FA33F50749831BF991A9A08 (void);
// 0x000001E8 System.Void NCMB.NCMBACL::SetRoleReadAccess(System.String,System.Boolean)
extern void NCMBACL_SetRoleReadAccess_mF9498FEA4BBCE24450518C7F2B1A4B6973618AE9 (void);
// 0x000001E9 System.Void NCMB.NCMBACL::SetRoleWriteAccess(System.String,System.Boolean)
extern void NCMBACL_SetRoleWriteAccess_m6B35F0E488D6AE3AAD5A6B7CE1E7592930BA19A3 (void);
// 0x000001EA System.Void NCMB.NCMBACL::SetDefaultACL(NCMB.NCMBACL,System.Boolean)
extern void NCMBACL_SetDefaultACL_m0856E5BF8C8298EC795F8D21C0225656782AC8FD (void);
// 0x000001EB System.Void NCMB.NCMBACL::_setAccess(System.String,System.String,System.Boolean)
extern void NCMBACL__setAccess_m1DA5C8FA30199FD7CD60C0ED7E38D1C6FBAA2063 (void);
// 0x000001EC System.Boolean NCMB.NCMBACL::GetReadAccess(System.String)
extern void NCMBACL_GetReadAccess_m89BC9CCE9DC82EB3D6F096C5D6859BD8DB83E135 (void);
// 0x000001ED System.Boolean NCMB.NCMBACL::GetWriteAccess(System.String)
extern void NCMBACL_GetWriteAccess_m3D6BC502C10E44ED25B7A447FD7E8F22D19193BD (void);
// 0x000001EE System.Boolean NCMB.NCMBACL::GetRoleReadAccess(System.String)
extern void NCMBACL_GetRoleReadAccess_m494BBF730D602F117133702B90D8B016ADCAEA83 (void);
// 0x000001EF System.Boolean NCMB.NCMBACL::GetRoleWriteAccess(System.String)
extern void NCMBACL_GetRoleWriteAccess_mFF39E720DE7A4818416FA5CAB317F4E2A0AAEAF8 (void);
// 0x000001F0 NCMB.NCMBACL NCMB.NCMBACL::_getDefaultACL()
extern void NCMBACL__getDefaultACL_m067F11737CB42BE0AF9A14C50E6400DB95577175 (void);
// 0x000001F1 System.Boolean NCMB.NCMBACL::_getAccess(System.String,System.String)
extern void NCMBACL__getAccess_m303D273B2401DF6C582EA3D9B547DA6C54E27468 (void);
// 0x000001F2 System.Collections.Generic.IDictionary`2<System.String,System.Object> NCMB.NCMBACL::_toJSONObject()
extern void NCMBACL__toJSONObject_m6FA8557560547FF899F5F8C304278E26B6E3AA06 (void);
// 0x000001F3 NCMB.NCMBACL NCMB.NCMBACL::_createACLFromJSONObject(System.Collections.Generic.Dictionary`2<System.String,System.Object>)
extern void NCMBACL__createACLFromJSONObject_m45412E1230A6B6ABAA950B7383BBBFA848098C27 (void);
// 0x000001F4 System.Void NCMB.NCMBAnalytics::TrackAppOpened(System.String)
extern void NCMBAnalytics_TrackAppOpened_m3505A84AAE05E6F80B6204F83515E3B47C8F1D19 (void);
// 0x000001F5 System.Void NCMB.NCMBAnalytics::.ctor()
extern void NCMBAnalytics__ctor_mBD25FF53250130AD5C1000EB23E9F0D7FF26DF3D (void);
// 0x000001F6 System.String NCMB.NCMBAnalytics::_getBaseUrl(System.String)
extern void NCMBAnalytics__getBaseUrl_m5EF80B9925F3443B220095B32111477C83342660 (void);
// 0x000001F7 System.Void NCMB.NCMBAnalytics/<>c::.cctor()
extern void U3CU3Ec__cctor_mFE5756BBDD8A1AA5B249E9703351A849229FB484 (void);
// 0x000001F8 System.Void NCMB.NCMBAnalytics/<>c::.ctor()
extern void U3CU3Ec__ctor_m7E4178E0641781BBADBED41029CF09AABBDAC96E (void);
// 0x000001F9 System.Void NCMB.NCMBAnalytics/<>c::<TrackAppOpened>b__0_0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec_U3CTrackAppOpenedU3Eb__0_0_m65493F4018E34A440E38DC61D36955A7B26CC886 (void);
// 0x000001FA System.Void NCMB.NCMBAppleAuthenManager::.ctor()
extern void NCMBAppleAuthenManager__ctor_m5247F8157782A79BCFCDF36EBC3ADE181AA37D1F (void);
// 0x000001FB System.Void NCMB.NCMBAppleAuthenManager::NCMBiOSNativeLoginWithAppleId(System.Action`1<NCMB.NCMBAppleCredential>,System.Action`1<NCMB.NCMBAppleError>)
extern void NCMBAppleAuthenManager_NCMBiOSNativeLoginWithAppleId_m936B8D038D7EBA0D6572378D8340ED7141388313 (void);
// 0x000001FC System.Void NCMB.NCMBAppleAuthenManager::Update()
extern void NCMBAppleAuthenManager_Update_m2F7814B383D04C3E9D2681360DD6A249B65BD89A (void);
// 0x000001FD NCMB.NCMBAppleError NCMB.NCMBAppleResponse::get_Error()
extern void NCMBAppleResponse_get_Error_m4BEA39D5396357A504A1545CF1CDED2EACAC6EB2 (void);
// 0x000001FE NCMB.NCMBAppleCredential NCMB.NCMBAppleResponse::get_NCMBAppleCredential()
extern void NCMBAppleResponse_get_NCMBAppleCredential_m67D93B7C002FDBE19D70F07DDA9424B979702C5A (void);
// 0x000001FF System.Void NCMB.NCMBAppleResponse::OnBeforeSerialize()
extern void NCMBAppleResponse_OnBeforeSerialize_m1CDCE320A58497378F155A1747CE31BE864A79A1 (void);
// 0x00000200 System.Void NCMB.NCMBAppleResponse::OnAfterDeserialize()
extern void NCMBAppleResponse_OnAfterDeserialize_m0485C5E46BBEDA9337D76D09F3362DEFB22B0C12 (void);
// 0x00000201 System.Void NCMB.NCMBAppleResponse::.ctor()
extern void NCMBAppleResponse__ctor_mD55FB179EC208A989DBC1152436FB8F0E83AF16D (void);
// 0x00000202 System.Int32 NCMB.NCMBAppleError::get_Code()
extern void NCMBAppleError_get_Code_mBF7C4FAE5E2EE746C20F7C171B1E71BD23CF21E5 (void);
// 0x00000203 System.String NCMB.NCMBAppleError::get_Domain()
extern void NCMBAppleError_get_Domain_mFD6C3CBC84A35917697991C9865F16AAFB18D8F8 (void);
// 0x00000204 System.String NCMB.NCMBAppleError::get_UserInfo()
extern void NCMBAppleError_get_UserInfo_m32DFF88F9750C32C9FC344634FBFD8E61B2B9760 (void);
// 0x00000205 System.Void NCMB.NCMBAppleError::.ctor()
extern void NCMBAppleError__ctor_m804D9D33729A8CFBEABC02E6785556AEBF8FB19C (void);
// 0x00000206 System.String NCMB.NCMBAppleCredential::get_AuthorizationCode()
extern void NCMBAppleCredential_get_AuthorizationCode_m9462D5BE31664E8A26ADF30D165006F071C918E9 (void);
// 0x00000207 System.String NCMB.NCMBAppleCredential::get_UserId()
extern void NCMBAppleCredential_get_UserId_m4CB3B680F17C2253092A5D0609CD3AAAABCCDEF0 (void);
// 0x00000208 System.Void NCMB.NCMBAppleCredential::.ctor()
extern void NCMBAppleCredential__ctor_mA1C5B75EDA24CFA02629C636E5BB4A9DE5700CF4 (void);
// 0x00000209 System.Void NCMB.NCMBAppleParameters::.ctor(System.String,System.String,System.String)
extern void NCMBAppleParameters__ctor_m993D161AE6AE4886B148C1B4C6971B8394C6E805 (void);
// 0x0000020A System.Void NCMB.NCMBCallback::.ctor(System.Object,System.IntPtr)
extern void NCMBCallback__ctor_m2013D9A1FFC914E6DADA2CAACCA69D38AF8B40F7 (void);
// 0x0000020B System.Void NCMB.NCMBCallback::Invoke(NCMB.NCMBException)
extern void NCMBCallback_Invoke_mE5880BFA587E9DBBDE017F10C49CE35F5E87B7A3 (void);
// 0x0000020C System.IAsyncResult NCMB.NCMBCallback::BeginInvoke(NCMB.NCMBException,System.AsyncCallback,System.Object)
extern void NCMBCallback_BeginInvoke_m01B34539924486BDED7517F34FCD91CFF0E90A6B (void);
// 0x0000020D System.Void NCMB.NCMBCallback::EndInvoke(System.IAsyncResult)
extern void NCMBCallback_EndInvoke_m37852E364C642BC21DBE1BC38837EB5DE44F3116 (void);
// 0x0000020E System.Void NCMB.NCMBQueryCallback`1::.ctor(System.Object,System.IntPtr)
// 0x0000020F System.Void NCMB.NCMBQueryCallback`1::Invoke(System.Collections.Generic.List`1<T>,NCMB.NCMBException)
// 0x00000210 System.IAsyncResult NCMB.NCMBQueryCallback`1::BeginInvoke(System.Collections.Generic.List`1<T>,NCMB.NCMBException,System.AsyncCallback,System.Object)
// 0x00000211 System.Void NCMB.NCMBQueryCallback`1::EndInvoke(System.IAsyncResult)
// 0x00000212 System.Void NCMB.NCMBGetCallback`1::.ctor(System.Object,System.IntPtr)
// 0x00000213 System.Void NCMB.NCMBGetCallback`1::Invoke(T,NCMB.NCMBException)
// 0x00000214 System.IAsyncResult NCMB.NCMBGetCallback`1::BeginInvoke(T,NCMB.NCMBException,System.AsyncCallback,System.Object)
// 0x00000215 System.Void NCMB.NCMBGetCallback`1::EndInvoke(System.IAsyncResult)
// 0x00000216 System.Void NCMB.NCMBCountCallback::.ctor(System.Object,System.IntPtr)
extern void NCMBCountCallback__ctor_m1299C73EA033F181E063DC5EC996C384CCC66922 (void);
// 0x00000217 System.Void NCMB.NCMBCountCallback::Invoke(System.Int32,NCMB.NCMBException)
extern void NCMBCountCallback_Invoke_mCA37EC7315382D78119E35F38BB54FA9DEC2DCFC (void);
// 0x00000218 System.IAsyncResult NCMB.NCMBCountCallback::BeginInvoke(System.Int32,NCMB.NCMBException,System.AsyncCallback,System.Object)
extern void NCMBCountCallback_BeginInvoke_m69AAC6534F8B2097797A0E8A82DED6D72A699969 (void);
// 0x00000219 System.Void NCMB.NCMBCountCallback::EndInvoke(System.IAsyncResult)
extern void NCMBCountCallback_EndInvoke_mB53C4ECEA0C6825A5E3E0A7D9F6C206282A85CCE (void);
// 0x0000021A System.Void NCMB.HttpClientCallback::.ctor(System.Object,System.IntPtr)
extern void HttpClientCallback__ctor_m7F3B09DA80516D65A024E2FE52DD5C2C000B7532 (void);
// 0x0000021B System.Void NCMB.HttpClientCallback::Invoke(System.Int32,System.String,NCMB.NCMBException)
extern void HttpClientCallback_Invoke_m4640A453C3CF17DAA80981D95CFD3FD9286C1E19 (void);
// 0x0000021C System.IAsyncResult NCMB.HttpClientCallback::BeginInvoke(System.Int32,System.String,NCMB.NCMBException,System.AsyncCallback,System.Object)
extern void HttpClientCallback_BeginInvoke_mF42657456A9F7A4B729F9CCA9BB26FD023D39B60 (void);
// 0x0000021D System.Void NCMB.HttpClientCallback::EndInvoke(System.IAsyncResult)
extern void HttpClientCallback_EndInvoke_m2952DC6B970AA47FAC45DB8E9B231FBED1D5D770 (void);
// 0x0000021E System.Void NCMB.HttpClientFileDataCallback::.ctor(System.Object,System.IntPtr)
extern void HttpClientFileDataCallback__ctor_mA4686058C24F093793121E982092A33A9519C1DB (void);
// 0x0000021F System.Void NCMB.HttpClientFileDataCallback::Invoke(System.Int32,System.Byte[],NCMB.NCMBException)
extern void HttpClientFileDataCallback_Invoke_m647DBF047F0F28D4DFBA5DAC53089E2A6812F6C3 (void);
// 0x00000220 System.IAsyncResult NCMB.HttpClientFileDataCallback::BeginInvoke(System.Int32,System.Byte[],NCMB.NCMBException,System.AsyncCallback,System.Object)
extern void HttpClientFileDataCallback_BeginInvoke_mB02D79350A10E50AEC2DE611C9494E348954CC46 (void);
// 0x00000221 System.Void NCMB.HttpClientFileDataCallback::EndInvoke(System.IAsyncResult)
extern void HttpClientFileDataCallback_EndInvoke_mAA9FD53AA578FDD2DBC712D65F82516FBD3B36A0 (void);
// 0x00000222 System.Void NCMB.NCMBExecuteScriptCallback::.ctor(System.Object,System.IntPtr)
extern void NCMBExecuteScriptCallback__ctor_m9B1F3BE5D4B1BE2791701DA5A9783F3731ACCFD1 (void);
// 0x00000223 System.Void NCMB.NCMBExecuteScriptCallback::Invoke(System.Byte[],NCMB.NCMBException)
extern void NCMBExecuteScriptCallback_Invoke_m1F5BC3A7601EA5212EBEBA73BF6DFD70C9DD28EA (void);
// 0x00000224 System.IAsyncResult NCMB.NCMBExecuteScriptCallback::BeginInvoke(System.Byte[],NCMB.NCMBException,System.AsyncCallback,System.Object)
extern void NCMBExecuteScriptCallback_BeginInvoke_mC2A4869160BCB5A7B84CC09923AEDECF1FB7BA39 (void);
// 0x00000225 System.Void NCMB.NCMBExecuteScriptCallback::EndInvoke(System.IAsyncResult)
extern void NCMBExecuteScriptCallback_EndInvoke_mE19A1E15F532D7F3FFC604B1FB3CFE3E1A9BE855 (void);
// 0x00000226 System.Void NCMB.NCMBGetFileCallback::.ctor(System.Object,System.IntPtr)
extern void NCMBGetFileCallback__ctor_m1C817DF8DAAFBB782343C77A3579479618392250 (void);
// 0x00000227 System.Void NCMB.NCMBGetFileCallback::Invoke(System.Byte[],NCMB.NCMBException)
extern void NCMBGetFileCallback_Invoke_m1078CCA509A9755CD916D3E0E68CA726DB188411 (void);
// 0x00000228 System.IAsyncResult NCMB.NCMBGetFileCallback::BeginInvoke(System.Byte[],NCMB.NCMBException,System.AsyncCallback,System.Object)
extern void NCMBGetFileCallback_BeginInvoke_mAE6AD43706174BF26173F47A4BD6D7FD1A4DC00A (void);
// 0x00000229 System.Void NCMB.NCMBGetFileCallback::EndInvoke(System.IAsyncResult)
extern void NCMBGetFileCallback_EndInvoke_m54FE373E276BCC161DD30F22F318564AD83C45A0 (void);
// 0x0000022A System.Void NCMB.NCMBGetTokenCallback::.ctor(System.Object,System.IntPtr)
extern void NCMBGetTokenCallback__ctor_mD0A16965D8A4E9EB1A372F0A4232D686807461D8 (void);
// 0x0000022B System.Void NCMB.NCMBGetTokenCallback::Invoke(System.String,NCMB.NCMBException)
extern void NCMBGetTokenCallback_Invoke_m65DEB68A0D0C5635A49E58E210245C22DDBC76FA (void);
// 0x0000022C System.IAsyncResult NCMB.NCMBGetTokenCallback::BeginInvoke(System.String,NCMB.NCMBException,System.AsyncCallback,System.Object)
extern void NCMBGetTokenCallback_BeginInvoke_m5277A589EFA87BD2275A0FF07B68B56519DCB013 (void);
// 0x0000022D System.Void NCMB.NCMBGetTokenCallback::EndInvoke(System.IAsyncResult)
extern void NCMBGetTokenCallback_EndInvoke_m451A6CD7635A1D40C1D07377DC81B3D65BFE1D83 (void);
// 0x0000022E System.Void NCMB.NCMBException::.ctor()
extern void NCMBException__ctor_m21159EF6D1B4388C7A8057F3DC35DB7589D04282 (void);
// 0x0000022F System.Void NCMB.NCMBException::.ctor(System.Exception)
extern void NCMBException__ctor_m7110980FBF8D6D5E75A2825C3B13ED29D5E75B88 (void);
// 0x00000230 System.Void NCMB.NCMBException::.ctor(System.String)
extern void NCMBException__ctor_mF92F4634095B6729BA5B835CF9768573F62FCAA2 (void);
// 0x00000231 System.String NCMB.NCMBException::get_ErrorCode()
extern void NCMBException_get_ErrorCode_mD93261FCF162E0858142135A3E6B4D1FC94CE1D8 (void);
// 0x00000232 System.Void NCMB.NCMBException::set_ErrorCode(System.String)
extern void NCMBException_set_ErrorCode_m340DB0EA7E63757143995E685EC9ADEE97B5901D (void);
// 0x00000233 System.String NCMB.NCMBException::get_ErrorMessage()
extern void NCMBException_get_ErrorMessage_m88E58E8A729A8D2C5AFA283513C160BE065FCFDA (void);
// 0x00000234 System.Void NCMB.NCMBException::set_ErrorMessage(System.String)
extern void NCMBException_set_ErrorMessage_m87C06E9E711D2899DED6B17C2B17FA41AB93FB61 (void);
// 0x00000235 System.String NCMB.NCMBException::get_Message()
extern void NCMBException_get_Message_m54BEBFFA323F26A004EF1A663374BBBB46C04A3B (void);
// 0x00000236 System.Void NCMB.NCMBException::.cctor()
extern void NCMBException__cctor_mE390E85A82D1E2450D4C72F7D8DF4E8EA74FC1F8 (void);
// 0x00000237 System.Void NCMB.NCMBFacebookParameters::.ctor(System.String,System.String,System.DateTime)
extern void NCMBFacebookParameters__ctor_m2F3EA4DCDD2FE91B4884B582EC78B28223346DDF (void);
// 0x00000238 System.String NCMB.NCMBFile::get_FileName()
extern void NCMBFile_get_FileName_mE4EB4212140490CFAF793366FC3AA8CA7BCA8802 (void);
// 0x00000239 System.Void NCMB.NCMBFile::set_FileName(System.String)
extern void NCMBFile_set_FileName_mA43A8E610F88A2AB154D49ABD51D09199EE8D610 (void);
// 0x0000023A System.Byte[] NCMB.NCMBFile::get_FileData()
extern void NCMBFile_get_FileData_mB39D3118C646D310AD82839920951DC1C43ACB87 (void);
// 0x0000023B System.Void NCMB.NCMBFile::set_FileData(System.Byte[])
extern void NCMBFile_set_FileData_mE6747DDD1FA5B0CE0EAECEDF852740EC82BFF80F (void);
// 0x0000023C System.Void NCMB.NCMBFile::.ctor()
extern void NCMBFile__ctor_m228183B01694B99C614D0DFAF32A041BAFF50BEB (void);
// 0x0000023D System.Void NCMB.NCMBFile::.ctor(System.String)
extern void NCMBFile__ctor_m341DDE47107A33ED235F5F987FF736EC1B443A3C (void);
// 0x0000023E System.Void NCMB.NCMBFile::.ctor(System.String,System.Byte[])
extern void NCMBFile__ctor_mDC94B1C7C1E5C778A9707B016E6C2073CBF985F0 (void);
// 0x0000023F System.Void NCMB.NCMBFile::.ctor(System.String,System.Byte[],NCMB.NCMBACL)
extern void NCMBFile__ctor_mF6CBA3CBDCEAA2E0F20D707CB418AAD84AE9CC28 (void);
// 0x00000240 System.Void NCMB.NCMBFile::SaveAsync(NCMB.NCMBCallback)
extern void NCMBFile_SaveAsync_m6388C0088EE4CF3F9AFCFD0B1618A97DB1B633C9 (void);
// 0x00000241 System.Void NCMB.NCMBFile::SaveAsync()
extern void NCMBFile_SaveAsync_m5212898B0A3B4A181B245C773548D4F92B3AB3EA (void);
// 0x00000242 System.Void NCMB.NCMBFile::FetchAsync(NCMB.NCMBGetFileCallback)
extern void NCMBFile_FetchAsync_m857E250C6B7CF35F4E24F0DF8D5BD168D9430CF3 (void);
// 0x00000243 System.Void NCMB.NCMBFile::FetchAsync()
extern void NCMBFile_FetchAsync_m72D62941C375CE3F0AB8AED91236852B737EE11B (void);
// 0x00000244 NCMB.NCMBQuery`1<NCMB.NCMBFile> NCMB.NCMBFile::GetQuery()
extern void NCMBFile_GetQuery_mD4FB1B0CCB279438A00DA476A1D1CCF566B7788B (void);
// 0x00000245 System.String NCMB.NCMBFile::_getBaseUrl()
extern void NCMBFile__getBaseUrl_m98FC1CFA8DD012BFAA7CA7D8B584C5D3F39220EA (void);
// 0x00000246 System.Void NCMB.NCMBFile/<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_m7A554D4DA54BB89A01788B3C4EE671BF96B50550 (void);
// 0x00000247 System.Void NCMB.NCMBFile/<>c__DisplayClass10_0::<SaveAsync>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass10_0_U3CSaveAsyncU3Eb__0_m6E4F442DFF6EC329E70FDF9CC2179F8209473871 (void);
// 0x00000248 System.Void NCMB.NCMBFile/<>c__DisplayClass12_0::.ctor()
extern void U3CU3Ec__DisplayClass12_0__ctor_m3BD2B3A8535AFA1CF1A02A1C5D7F46EC3E9E6569 (void);
// 0x00000249 System.Void NCMB.NCMBFile/<>c__DisplayClass12_0::<FetchAsync>b__0(System.Int32,System.Byte[],NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass12_0_U3CFetchAsyncU3Eb__0_m05FC6EC736A2F945ED4501CE5906F6E11BBD36A8 (void);
// 0x0000024A System.Double NCMB.NCMBGeoPoint::get_Latitude()
extern void NCMBGeoPoint_get_Latitude_m6D2F853B7E2A0D490CC4A2A78F94DE8FD9CBA89F (void);
// 0x0000024B System.Void NCMB.NCMBGeoPoint::set_Latitude(System.Double)
extern void NCMBGeoPoint_set_Latitude_m3ED4243D413FE6BD7E2306C46A98A081278B4994 (void);
// 0x0000024C System.Double NCMB.NCMBGeoPoint::get_Longitude()
extern void NCMBGeoPoint_get_Longitude_mA071FF72500EB9DEC3817BDAB511A35F2EE95994 (void);
// 0x0000024D System.Void NCMB.NCMBGeoPoint::set_Longitude(System.Double)
extern void NCMBGeoPoint_set_Longitude_mD04AE661CCB2D10B4BEA0AC26006D2EF5EC69F83 (void);
// 0x0000024E System.Void NCMB.NCMBGeoPoint::.ctor(System.Double,System.Double)
extern void NCMBGeoPoint__ctor_m5C1631BC64BBD61E6069FF072DEE124BFF183FE8 (void);
// 0x0000024F System.Void NCMB.NCMBInstallation::setDefaultProperty()
extern void NCMBInstallation_setDefaultProperty_mFF69FAD9E899C323F375536F049497CE4EEAE84E (void);
// 0x00000250 System.Void NCMB.NCMBInstallation::.ctor()
extern void NCMBInstallation__ctor_m038D21E0B46B0CE9948EEAF7B0A7DDC85EA036BC (void);
// 0x00000251 System.Void NCMB.NCMBInstallation::.ctor(System.String)
extern void NCMBInstallation__ctor_m83450F3787E7B5D5F127225D21DBB80450C4A1C4 (void);
// 0x00000252 System.String NCMB.NCMBInstallation::get_ApplicationName()
extern void NCMBInstallation_get_ApplicationName_mBB54D8DA97101F2BDBE3F4EF5640A60B7EF0EC11 (void);
// 0x00000253 System.Void NCMB.NCMBInstallation::set_ApplicationName(System.String)
extern void NCMBInstallation_set_ApplicationName_m36EFF15C8D3AB81E5BA9BDC3C8D9AAF9F9208139 (void);
// 0x00000254 System.String NCMB.NCMBInstallation::get_AppVersion()
extern void NCMBInstallation_get_AppVersion_mAA1126E1ED86FFDAE3D2705335D28452489B6A31 (void);
// 0x00000255 System.Void NCMB.NCMBInstallation::set_AppVersion(System.String)
extern void NCMBInstallation_set_AppVersion_mD0A16DF5D5E1FC3126B85CA738821958D0EE4E55 (void);
// 0x00000256 System.Void NCMB.NCMBInstallation::set_DeviceToken(System.String)
extern void NCMBInstallation_set_DeviceToken_m544D6D4636A9175FD660358A567F7D96724463F8 (void);
// 0x00000257 System.Void NCMB.NCMBInstallation::GetDeviceToken(NCMB.NCMBGetCallback`1<System.String>)
extern void NCMBInstallation_GetDeviceToken_m68C21A111D30A56320A27DE41870E0F179ED1FD8 (void);
// 0x00000258 System.String NCMB.NCMBInstallation::get_DeviceType()
extern void NCMBInstallation_get_DeviceType_m4E20B692FC955DC5AE6DC0AD9826139C07C9A909 (void);
// 0x00000259 System.Void NCMB.NCMBInstallation::set_DeviceType(System.String)
extern void NCMBInstallation_set_DeviceType_m86432E0C4CA1D3B2A693C2B6AA2078265065B980 (void);
// 0x0000025A System.String NCMB.NCMBInstallation::get_SdkVersion()
extern void NCMBInstallation_get_SdkVersion_mCEBA677518F818F5BDBA438CCFACC86A94B1E41F (void);
// 0x0000025B System.Void NCMB.NCMBInstallation::set_SdkVersion(System.String)
extern void NCMBInstallation_set_SdkVersion_mDDCF446035B8C4A05DDBC7A99AB1729B9C7BB63D (void);
// 0x0000025C System.String NCMB.NCMBInstallation::get_TimeZone()
extern void NCMBInstallation_get_TimeZone_mAA6895035937FC02CB04DD8BD61EE6584797BB64 (void);
// 0x0000025D System.Void NCMB.NCMBInstallation::set_TimeZone(System.String)
extern void NCMBInstallation_set_TimeZone_mE5162589D787FBB0634B4026C5FB29FE989CF99A (void);
// 0x0000025E NCMB.NCMBInstallation NCMB.NCMBInstallation::getCurrentInstallation()
extern void NCMBInstallation_getCurrentInstallation_m87360B90A694B8B3061715BAD7E29C3B28722D7C (void);
// 0x0000025F NCMB.NCMBQuery`1<NCMB.NCMBInstallation> NCMB.NCMBInstallation::GetQuery()
extern void NCMBInstallation_GetQuery_mA4006F8A150A78282EFF0E848A8079BA9346E604 (void);
// 0x00000260 System.String NCMB.NCMBInstallation::_getBaseUrl()
extern void NCMBInstallation__getBaseUrl_m5FB733CCC3C7698AD79AFB31C2BCCF48238912AF (void);
// 0x00000261 System.Void NCMB.NCMBInstallation::_afterSave(System.Int32,NCMB.NCMBException)
extern void NCMBInstallation__afterSave_m844279AE608B2D63C0167C29F01EB0431B6037BD (void);
// 0x00000262 System.Void NCMB.NCMBInstallation::_saveInstallationToDisk(System.String)
extern void NCMBInstallation__saveInstallationToDisk_m41F6EEE0D3B0C261F68B84140D649629C47A5557 (void);
// 0x00000263 System.Void NCMB.NCMBInstallation/<>c__DisplayClass11_0::.ctor()
extern void U3CU3Ec__DisplayClass11_0__ctor_m80DD23EC08CE1FB8F6BFA21BF27F089CB9C07D63 (void);
// 0x00000264 System.Void NCMB.NCMBInstallation/<>c__DisplayClass11_0::<GetDeviceToken>b__0()
extern void U3CU3Ec__DisplayClass11_0_U3CGetDeviceTokenU3Eb__0_mD8F57CEB3B54AE503C771FE70B7151B5CB87E8B4 (void);
// 0x00000265 System.Object NCMB.NCMBObject::get_Item(System.String)
extern void NCMBObject_get_Item_mE77B63743998B855C6628D107043664D3789CABC (void);
// 0x00000266 System.Void NCMB.NCMBObject::set_Item(System.String,System.Object)
extern void NCMBObject_set_Item_m293FF681D3CED5C6498D161A158F80AF8F79A24C (void);
// 0x00000267 System.Void NCMB.NCMBObject::_onSettingValue(System.String,System.Object)
extern void NCMBObject__onSettingValue_mDF88FA04366E1F1501F73206DB41CA5E4EEB0D1E (void);
// 0x00000268 System.String NCMB.NCMBObject::get_ClassName()
extern void NCMBObject_get_ClassName_m3B1970F6A35F5B4D7722550CEB95513BDDD23A94 (void);
// 0x00000269 System.Void NCMB.NCMBObject::set_ClassName(System.String)
extern void NCMBObject_set_ClassName_mF75D8380F85962A986AC3197DEAF177A37F35362 (void);
// 0x0000026A System.String NCMB.NCMBObject::get_ObjectId()
extern void NCMBObject_get_ObjectId_m049628DB8A17E302FEFE8B92703BEE2E5B5D2EA0 (void);
// 0x0000026B System.Void NCMB.NCMBObject::set_ObjectId(System.String)
extern void NCMBObject_set_ObjectId_m50AD644A36BB98A0A79BA001B04944CB69337D81 (void);
// 0x0000026C System.Nullable`1<System.DateTime> NCMB.NCMBObject::get_UpdateDate()
extern void NCMBObject_get_UpdateDate_m12F60362A4C8D6AD5DE3B002D1F79799BB5B6956 (void);
// 0x0000026D System.Void NCMB.NCMBObject::set_UpdateDate(System.Nullable`1<System.DateTime>)
extern void NCMBObject_set_UpdateDate_mC27A45B029ACA357A5DCAEADE4B4E4CC2BE91FE9 (void);
// 0x0000026E System.Nullable`1<System.DateTime> NCMB.NCMBObject::get_CreateDate()
extern void NCMBObject_get_CreateDate_mBC1980D166EC686F9844A2ED00DCA618ABA92BE7 (void);
// 0x0000026F System.Void NCMB.NCMBObject::set_CreateDate(System.Nullable`1<System.DateTime>)
extern void NCMBObject_set_CreateDate_mC70968BCEAE2EB5E0C77544213F2E4DE12871F2F (void);
// 0x00000270 System.Void NCMB.NCMBObject::set_ACL(NCMB.NCMBACL)
extern void NCMBObject_set_ACL_m6FDD90D1A8AB7F57957D230A1F42FF7FF1D8E5B3 (void);
// 0x00000271 NCMB.NCMBACL NCMB.NCMBObject::get_ACL()
extern void NCMBObject_get_ACL_mCACBDCC23833E09111D86149FABC577BEC98F718 (void);
// 0x00000272 System.Boolean NCMB.NCMBObject::_checkIsDataAvailable(System.String)
extern void NCMBObject__checkIsDataAvailable_mD11E463554BFB3FA1721681642D6A6E9203B4CC0 (void);
// 0x00000273 System.Void NCMB.NCMBObject::_checkGetAccess(System.String)
extern void NCMBObject__checkGetAccess_m94D2D361C91166833CD7597F71B675B7AB49F3F2 (void);
// 0x00000274 System.Boolean NCMB.NCMBObject::get_IsDirty()
extern void NCMBObject_get_IsDirty_m0647E3102B8FFB3AC943621F9168AC2ACF675505 (void);
// 0x00000275 System.Void NCMB.NCMBObject::set_IsDirty(System.Boolean)
extern void NCMBObject_set_IsDirty_mC09C565CF17CC0740B5B028CA08304634AFA73CB (void);
// 0x00000276 System.Boolean NCMB.NCMBObject::_checkIsDirty(System.Boolean)
extern void NCMBObject__checkIsDirty_m1FD52D8903F74AEE4EB204D53BC146EED04D42EC (void);
// 0x00000277 System.Boolean NCMB.NCMBObject::_hasDirtyChildren()
extern void NCMBObject__hasDirtyChildren_m2225BB0E56724749D87CC982451F195091CE3873 (void);
// 0x00000278 System.Void NCMB.NCMBObject::_findUnsavedChildren(System.Object,System.Collections.Generic.List`1<NCMB.NCMBObject>)
extern void NCMBObject__findUnsavedChildren_m2FACE634CF13C14F8223FECEFCD80C21D280299A (void);
// 0x00000279 System.Collections.Generic.ICollection`1<System.String> NCMB.NCMBObject::get_Keys()
extern void NCMBObject_get_Keys_m0855E6A4ECF3D9CE0D433E476CB730DC7E671E94 (void);
// 0x0000027A System.Void NCMB.NCMBObject::.ctor()
extern void NCMBObject__ctor_m00AC6399758FD1B32EBCC58B0F3FC750E4FF5700 (void);
// 0x0000027B NCMB.NCMBRelation`1<T> NCMB.NCMBObject::GetRelation(System.String)
// 0x0000027C System.Void NCMB.NCMBObject::.ctor(System.String)
extern void NCMBObject__ctor_mC02E4A982F1B71A360069DA785C105C192966949 (void);
// 0x0000027D System.Void NCMB.NCMBObject::_performOperation(System.String,NCMB.Internal.INCMBFieldOperation)
extern void NCMBObject__performOperation_mC55F6E3A3561AF0B64D6D25DD98E71D749A75D8D (void);
// 0x0000027E System.Collections.Generic.IDictionary`2<System.String,NCMB.Internal.INCMBFieldOperation> NCMB.NCMBObject::get__currentOperations()
extern void NCMBObject_get__currentOperations_mD929BA6CDF06B9093C82AEBDE533F172C2B4637C (void);
// 0x0000027F System.Collections.Generic.IDictionary`2<System.String,NCMB.Internal.INCMBFieldOperation> NCMB.NCMBObject::StartSave()
extern void NCMBObject_StartSave_mBC92D5A9B649594336FEB2202168FCF32A54B82A (void);
// 0x00000280 System.Boolean NCMB.NCMBObject::_isValidType(System.Object)
extern void NCMBObject__isValidType_m290129385F0DAE22C68616D9ECFA4471843A8D47 (void);
// 0x00000281 System.Void NCMB.NCMBObject::_listIsValidType(System.Collections.IEnumerable)
extern void NCMBObject__listIsValidType_mD9B6B2DCDA248AAB81AC43272DDBFA2FE61531EA (void);
// 0x00000282 System.Void NCMB.NCMBObject::Revert()
extern void NCMBObject_Revert_m2566A4F84A29E1922B406A6FC7E0D20C7D3C2832 (void);
// 0x00000283 System.Void NCMB.NCMBObject::_rebuildEstimatedData()
extern void NCMBObject__rebuildEstimatedData_m62FC3F5862B8478B5B2A5A40CB74DC7242929EE3 (void);
// 0x00000284 System.Void NCMB.NCMBObject::_updateLatestEstimatedData()
extern void NCMBObject__updateLatestEstimatedData_mA23E2A11FD8FEA0CF3F9AAB69D41FA1212F2699B (void);
// 0x00000285 System.Void NCMB.NCMBObject::_applyOperations(System.Collections.Generic.IDictionary`2<System.String,NCMB.Internal.INCMBFieldOperation>,System.Collections.Generic.IDictionary`2<System.String,System.Object>)
extern void NCMBObject__applyOperations_m72ED278F7388E3FBCB5CDDE20EBDB5AB03B77C0B (void);
// 0x00000286 System.Void NCMB.NCMBObject::Add(System.String,System.Object)
extern void NCMBObject_Add_m3CC80DD3A45F51DF65744DB2CA1AD33138D6CFD8 (void);
// 0x00000287 System.Void NCMB.NCMBObject::Remove(System.String)
extern void NCMBObject_Remove_mBCEC810241DACFAB249BDD199DBC22CA736C85BB (void);
// 0x00000288 System.Void NCMB.NCMBObject::RemoveRangeFromList(System.String,System.Collections.IEnumerable)
extern void NCMBObject_RemoveRangeFromList_m147FCB0B1F677F0B5CB771D5FCA230584B82B408 (void);
// 0x00000289 System.Void NCMB.NCMBObject::AddToList(System.String,System.Object)
extern void NCMBObject_AddToList_mF56F94D8F64B40BB3560B219F4FEA02FFADFADF8 (void);
// 0x0000028A System.Void NCMB.NCMBObject::AddRangeToList(System.String,System.Collections.IEnumerable)
extern void NCMBObject_AddRangeToList_m79D5568BD1CE94FAFAD3632B6FEDFC8C07676A43 (void);
// 0x0000028B System.Void NCMB.NCMBObject::AddUniqueToList(System.String,System.Object)
extern void NCMBObject_AddUniqueToList_m94A24F9F99889A654BAD8183A2883EC203A58E52 (void);
// 0x0000028C System.Void NCMB.NCMBObject::AddRangeUniqueToList(System.String,System.Collections.IEnumerable)
extern void NCMBObject_AddRangeUniqueToList_m7860AA8161DB33BD70CECDDDA2B5A53C9FB26140 (void);
// 0x0000028D System.Void NCMB.NCMBObject::Increment(System.String)
extern void NCMBObject_Increment_m79F02327CE657F922B06B1FAFDF0B6EBF3292BC3 (void);
// 0x0000028E System.Void NCMB.NCMBObject::Increment(System.String,System.Int64)
extern void NCMBObject_Increment_m02A79C723B9D4BCFBBB833CF8C066AA2CE25BB23 (void);
// 0x0000028F System.Void NCMB.NCMBObject::Increment(System.String,System.Double)
extern void NCMBObject_Increment_m27522B0D176358B04A42E0BA0A95B289587FB23F (void);
// 0x00000290 System.Void NCMB.NCMBObject::_incrementMerge(System.String,System.Object)
extern void NCMBObject__incrementMerge_m3099E51C631D966C175FC0416917CB44BADD9A12 (void);
// 0x00000291 System.Object NCMB.NCMBObject::_addNumbers(System.Object,System.Object)
extern void NCMBObject__addNumbers_m0449E3AFDDBEBB589BD417549E04C458C304C831 (void);
// 0x00000292 System.String NCMB.NCMBObject::_getBaseUrl()
extern void NCMBObject__getBaseUrl_m25588576DCAB62133F004A796CE16651657C202C (void);
// 0x00000293 System.Void NCMB.NCMBObject::DeleteAsync(NCMB.NCMBCallback)
extern void NCMBObject_DeleteAsync_m15CF2D7749B66D972686DC0357C169696F413505 (void);
// 0x00000294 System.Void NCMB.NCMBObject::DeleteAsync()
extern void NCMBObject_DeleteAsync_m0F3EFD51AB77793807E7F49592A37C189F63E933 (void);
// 0x00000295 System.Void NCMB.NCMBObject::SaveAsync(NCMB.NCMBCallback)
extern void NCMBObject_SaveAsync_mA3ACAC8D708BD47D470E835856698CE5CF6A9E7A (void);
// 0x00000296 System.Void NCMB.NCMBObject::SaveAsync()
extern void NCMBObject_SaveAsync_m09B8A9D1B6DF240B02EE5E68E12BD74119B78444 (void);
// 0x00000297 System.Void NCMB.NCMBObject::Save()
extern void NCMBObject_Save_m590538B5AAE5CDD8D7E234BF6ED9E5406CD2A0AB (void);
// 0x00000298 System.Void NCMB.NCMBObject::Save(NCMB.NCMBCallback)
extern void NCMBObject_Save_m8F4C897AFE9BC806B00DEC95B1BB9D5586C8E239 (void);
// 0x00000299 System.Void NCMB.NCMBObject::_beforeSave()
extern void NCMBObject__beforeSave_mE80BFD4F45745E9CC823ACC3E24BD0733271EEDF (void);
// 0x0000029A System.Void NCMB.NCMBObject::_afterSave(System.Int32,NCMB.NCMBException)
extern void NCMBObject__afterSave_mEC31134AC1DEC1E48AF88E5DF18A9E8FEF982815 (void);
// 0x0000029B System.Void NCMB.NCMBObject::_afterDelete(NCMB.NCMBException)
extern void NCMBObject__afterDelete_m3A3D97422CB177A975C25943553E49EDEBF14696 (void);
// 0x0000029C System.String NCMB.NCMBObject::_toJSONObjectForSaving(System.Collections.Generic.IDictionary`2<System.String,NCMB.Internal.INCMBFieldOperation>)
extern void NCMBObject__toJSONObjectForSaving_mC310D77C41ED6EC5FCD535069E4F18901249ACA8 (void);
// 0x0000029D System.Void NCMB.NCMBObject::FetchAsync(NCMB.NCMBCallback)
extern void NCMBObject_FetchAsync_m2EC98E3EE55944D9E6F8EC2F69142BAC0FCFD94F (void);
// 0x0000029E System.Void NCMB.NCMBObject::FetchAsync()
extern void NCMBObject_FetchAsync_m98D1E858E9FD3BC3908EAFDFBC67FFF8F218B071 (void);
// 0x0000029F System.Boolean NCMB.NCMBObject::ContainsKey(System.String)
extern void NCMBObject_ContainsKey_mF50877A9E35BD13E60D10779E11144DE0E99C4D4 (void);
// 0x000002A0 NCMB.NCMBObject NCMB.NCMBObject::CreateWithoutData(System.String,System.String)
extern void NCMBObject_CreateWithoutData_m53AD9E5220F14FA8911D41C4ED047DF23D3359AD (void);
// 0x000002A1 System.Void NCMB.NCMBObject::_mergeFromServer(System.Collections.Generic.Dictionary`2<System.String,System.Object>,System.Boolean)
extern void NCMBObject__mergeFromServer_m4BA898360B8A36CBEB77A9D8C6705E4097A737CF (void);
// 0x000002A2 System.Void NCMB.NCMBObject::_handleSaveResult(System.Boolean,System.Collections.Generic.Dictionary`2<System.String,System.Object>,System.Collections.Generic.IDictionary`2<System.String,NCMB.Internal.INCMBFieldOperation>)
extern void NCMBObject__handleSaveResult_m25812D38AA79101C34A6E448999E4DA7D5A4214B (void);
// 0x000002A3 System.Void NCMB.NCMBObject::_handleFetchResult(System.Boolean,System.Collections.Generic.Dictionary`2<System.String,System.Object>)
extern void NCMBObject__handleFetchResult_m8AC1C7DB75A4CF4B97BC30C4C78B4CB0B0E22077 (void);
// 0x000002A4 System.Void NCMB.NCMBObject::_handleDeleteResult(System.Boolean)
extern void NCMBObject__handleDeleteResult_m22BF323A5AC1F7296D1CBAD620E93D7581A87F01 (void);
// 0x000002A5 System.Void NCMB.NCMBObject::_setCreateDate(System.String)
extern void NCMBObject__setCreateDate_m310DD2A28E363E8B729B7A1FF4B75D28CB967140 (void);
// 0x000002A6 System.Void NCMB.NCMBObject::_setUpdateDate(System.String)
extern void NCMBObject__setUpdateDate_mA6B3C8E9D7B84266771668E0591C6E43552B9CB9 (void);
// 0x000002A7 System.Void NCMB.NCMBObject::_saveToVariable()
extern void NCMBObject__saveToVariable_mAB65994C5E80E37FB92C163688076347F99CA5A5 (void);
// 0x000002A8 NCMB.NCMBObject NCMB.NCMBObject::_getFromVariable()
extern void NCMBObject__getFromVariable_m65A23EF537FB9627AE8FF12322701188170F8739 (void);
// 0x000002A9 System.Void NCMB.NCMBObject::_saveToDisk(System.String)
extern void NCMBObject__saveToDisk_mCF5DDDE660D5F4A66C9C115BE956C0EB3CE03D99 (void);
// 0x000002AA NCMB.NCMBObject NCMB.NCMBObject::_getFromDisk(System.String)
extern void NCMBObject__getFromDisk_m944E2C7470AA61FC449EDF9FF76108CE42D0ADF3 (void);
// 0x000002AB System.String NCMB.NCMBObject::_getDiskData(System.String)
extern void NCMBObject__getDiskData_m833C3BD44F6512F2CE25C4E1C105AC9CE03B6C42 (void);
// 0x000002AC System.String NCMB.NCMBObject::_toJsonDataForDataFile()
extern void NCMBObject__toJsonDataForDataFile_mE648E3FDAD862EA0B8C2FB3AC6EBFA9CBB201231 (void);
// 0x000002AD System.Void NCMB.NCMBObject::_setDefaultValues()
extern void NCMBObject__setDefaultValues_m48A0DBECA7E4BF74311D5D9C84E5120B47356FA5 (void);
// 0x000002AE System.Void NCMB.NCMBObject::.cctor()
extern void NCMBObject__cctor_mD9847C4329B1C97F6182D1DFB935F52947DB3D02 (void);
// 0x000002AF System.Void NCMB.NCMBObject/<>c__DisplayClass67_0::.ctor()
extern void U3CU3Ec__DisplayClass67_0__ctor_mF72CB14EE1A5F21E785C449B5E62850D3A61F87B (void);
// 0x000002B0 System.Void NCMB.NCMBObject/<>c__DisplayClass67_0::<DeleteAsync>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass67_0_U3CDeleteAsyncU3Eb__0_m0889D3894439C9F3CC92FC674753CAD4425EB164 (void);
// 0x000002B1 System.Void NCMB.NCMBObject/<>c__DisplayClass72_0::.ctor()
extern void U3CU3Ec__DisplayClass72_0__ctor_mEADFC5D27384BB5C32D399C76D84C1955048955C (void);
// 0x000002B2 System.Void NCMB.NCMBObject/<>c__DisplayClass72_0::<Save>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass72_0_U3CSaveU3Eb__0_m888DD40063D0BD484765130C6B3CBC13174E3A25 (void);
// 0x000002B3 System.Void NCMB.NCMBObject/<>c__DisplayClass77_0::.ctor()
extern void U3CU3Ec__DisplayClass77_0__ctor_m9465D4C47B6AB53A7729CDB7FBD342ABFFF47D0E (void);
// 0x000002B4 System.Void NCMB.NCMBObject/<>c__DisplayClass77_0::<FetchAsync>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass77_0_U3CFetchAsyncU3Eb__0_m83C169DB4ED71370CA51B1419D2BC5E171F41003 (void);
// 0x000002B5 System.Void NCMB.NCMBPush::.cctor()
extern void NCMBPush__cctor_mD0014358EA0CC0655466733D152813F8BE006446 (void);
// 0x000002B6 System.Void NCMB.NCMBPush::.ctor()
extern void NCMBPush__ctor_mDCCC49135FBD475FC9C4305DE8E65B926105B8ED (void);
// 0x000002B7 System.String NCMB.NCMBPush::get_Message()
extern void NCMBPush_get_Message_m0D527F2EA29998352533BE462C6CFAA6E6CA7CD8 (void);
// 0x000002B8 System.Void NCMB.NCMBPush::set_Message(System.String)
extern void NCMBPush_set_Message_m78D9FC34FF6F111D9FFD705B8F2BF231DC300A16 (void);
// 0x000002B9 System.Object NCMB.NCMBPush::get_SearchCondition()
extern void NCMBPush_get_SearchCondition_m4E3498138FCC1B9873846BE82D9BC87A165D034F (void);
// 0x000002BA System.Void NCMB.NCMBPush::set_SearchCondition(System.Object)
extern void NCMBPush_set_SearchCondition_mABD39EA64825F7F4CFE177506D03774AC5855E4D (void);
// 0x000002BB System.DateTime NCMB.NCMBPush::get_DeliveryTime()
extern void NCMBPush_get_DeliveryTime_m722BECCD3DC7404D2DEB924001099FAC65A8AF64 (void);
// 0x000002BC System.Void NCMB.NCMBPush::set_DeliveryTime(System.DateTime)
extern void NCMBPush_set_DeliveryTime_m8F8E5F3C57BFCC34203350ADB401FFC1B4586B4B (void);
// 0x000002BD System.Boolean NCMB.NCMBPush::get_ImmediateDeliveryFlag()
extern void NCMBPush_get_ImmediateDeliveryFlag_m4652517426951A350B496300635B9157E7C229EB (void);
// 0x000002BE System.Void NCMB.NCMBPush::set_ImmediateDeliveryFlag(System.Boolean)
extern void NCMBPush_set_ImmediateDeliveryFlag_m5787DD8F4C5E6E8F98A20B6E3118ED924B229684 (void);
// 0x000002BF System.String NCMB.NCMBPush::get_Title()
extern void NCMBPush_get_Title_m15BAA926990B50A5BDAFB59C5C8AFA578953FC21 (void);
// 0x000002C0 System.Void NCMB.NCMBPush::set_Title(System.String)
extern void NCMBPush_set_Title_mA824F29085133DC21993FB572F082A2D13CE831C (void);
// 0x000002C1 System.Boolean NCMB.NCMBPush::get_PushToIOS()
extern void NCMBPush_get_PushToIOS_mBB7A5EF5DD1DC34342C1E420D0DFCB39349BBB8B (void);
// 0x000002C2 System.Void NCMB.NCMBPush::set_PushToIOS(System.Boolean)
extern void NCMBPush_set_PushToIOS_m19AB75CE3A83054E352D6954910947E2017D6C1E (void);
// 0x000002C3 System.Boolean NCMB.NCMBPush::get_PushToAndroid()
extern void NCMBPush_get_PushToAndroid_m425F86FB596BB44AEC728743EAB2A97F890EEB27 (void);
// 0x000002C4 System.Void NCMB.NCMBPush::set_PushToAndroid(System.Boolean)
extern void NCMBPush_set_PushToAndroid_m748B0B6F0AEAA848FB9B4573A0E7F99CF30DBC20 (void);
// 0x000002C5 System.Nullable`1<System.Int32> NCMB.NCMBPush::get_Badge()
extern void NCMBPush_get_Badge_m06883CB2812D5CAD486A2F3913EA66606D70F8DD (void);
// 0x000002C6 System.Void NCMB.NCMBPush::set_Badge(System.Nullable`1<System.Int32>)
extern void NCMBPush_set_Badge_m78BF8D60E223C40D8B60A8C29ADFA751562FF7A2 (void);
// 0x000002C7 System.Boolean NCMB.NCMBPush::get_BadgeIncrementFlag()
extern void NCMBPush_get_BadgeIncrementFlag_m31CB099DFDDF1155800596BEC90E48FE8439DF45 (void);
// 0x000002C8 System.Void NCMB.NCMBPush::set_BadgeIncrementFlag(System.Boolean)
extern void NCMBPush_set_BadgeIncrementFlag_m1527CEB61FAB09572487B1110807579DB446DE68 (void);
// 0x000002C9 System.String NCMB.NCMBPush::get_RichUrl()
extern void NCMBPush_get_RichUrl_m8115F74EE163DE70C7A3512D7E176334563C9CF3 (void);
// 0x000002CA System.Void NCMB.NCMBPush::set_RichUrl(System.String)
extern void NCMBPush_set_RichUrl_m53CBA6D13E1831CF1AF9BF9ED8670C61E6A00249 (void);
// 0x000002CB System.Boolean NCMB.NCMBPush::get_Dialog()
extern void NCMBPush_get_Dialog_m3B06CD8F2D6292FAC056384AC361474F2670C2EB (void);
// 0x000002CC System.Void NCMB.NCMBPush::set_Dialog(System.Boolean)
extern void NCMBPush_set_Dialog_mDE14B69E105516EC46BE6963E59CD7C6F75321CC (void);
// 0x000002CD System.Boolean NCMB.NCMBPush::get_ContentAvailable()
extern void NCMBPush_get_ContentAvailable_mCF397305F262E516D533351D3553B223AE40A604 (void);
// 0x000002CE System.Void NCMB.NCMBPush::set_ContentAvailable(System.Boolean)
extern void NCMBPush_set_ContentAvailable_m42AC8F4A34B1F6F3F9F6772E2693E8A40811F8EB (void);
// 0x000002CF System.String NCMB.NCMBPush::get_Category()
extern void NCMBPush_get_Category_m17667A029E57E74E22F20DE7678301B77E3CCF1C (void);
// 0x000002D0 System.Void NCMB.NCMBPush::set_Category(System.String)
extern void NCMBPush_set_Category_m911EE23C0A8D333625FE9A2EFCFDF147E14D3359 (void);
// 0x000002D1 System.Nullable`1<System.DateTime> NCMB.NCMBPush::get_DeliveryExpirationDate()
extern void NCMBPush_get_DeliveryExpirationDate_m3C73CAE4ECD59556E810D979B023C9308148E59D (void);
// 0x000002D2 System.Void NCMB.NCMBPush::set_DeliveryExpirationDate(System.Nullable`1<System.DateTime>)
extern void NCMBPush_set_DeliveryExpirationDate_m0C8D0C45C7FB1C788FFE8B9F0E1C7926280DC31C (void);
// 0x000002D3 System.String NCMB.NCMBPush::get_DeliveryExpirationTime()
extern void NCMBPush_get_DeliveryExpirationTime_m88261DC34AE4EC9AD7B3332B9A47B892A0986D8B (void);
// 0x000002D4 System.Void NCMB.NCMBPush::set_DeliveryExpirationTime(System.String)
extern void NCMBPush_set_DeliveryExpirationTime_m08F414CEA2106D63A9AB3E12E9124339EF226EEC (void);
// 0x000002D5 System.Void NCMB.NCMBPush::SendPush()
extern void NCMBPush_SendPush_mAEB5364D0BD796DE9639708FEF59FEFC8017C2AD (void);
// 0x000002D6 System.Void NCMB.NCMBPush::SendPush(NCMB.NCMBCallback)
extern void NCMBPush_SendPush_mFD4C3E9A3B61E8F3EBF29EFC79CB719D0A3C8158 (void);
// 0x000002D7 NCMB.NCMBQuery`1<NCMB.NCMBPush> NCMB.NCMBPush::GetQuery()
extern void NCMBPush_GetQuery_m7E490A986B339D54101FE55D7EA59CAEE1F6F44C (void);
// 0x000002D8 System.String NCMB.NCMBPush::_getBaseUrl()
extern void NCMBPush__getBaseUrl_m8220B4A54277F8635E48AC2233879660B3962839 (void);
// 0x000002D9 System.Void NCMB.NCMBQuery`1::.ctor(System.String)
// 0x000002DA System.Int32 NCMB.NCMBQuery`1::get_Skip()
// 0x000002DB System.Void NCMB.NCMBQuery`1::set_Skip(System.Int32)
// 0x000002DC System.Int32 NCMB.NCMBQuery`1::get_Limit()
// 0x000002DD System.Void NCMB.NCMBQuery`1::set_Limit(System.Int32)
// 0x000002DE System.String NCMB.NCMBQuery`1::get_ClassName()
// 0x000002DF NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::Or(System.Collections.Generic.List`1<NCMB.NCMBQuery`1<T>>)
// 0x000002E0 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::_whereSatifiesAnyOf(System.Collections.Generic.List`1<NCMB.NCMBQuery`1<T>>)
// 0x000002E1 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::OrderByAscending(System.String)
// 0x000002E2 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::OrderByDescending(System.String)
// 0x000002E3 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::AddAscendingOrder(System.String)
// 0x000002E4 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::AddDescendingOrder(System.String)
// 0x000002E5 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereEqualTo(System.String,System.Object)
// 0x000002E6 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereNotEqualTo(System.String,System.Object)
// 0x000002E7 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereGreaterThan(System.String,System.Object)
// 0x000002E8 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereGreaterThanOrEqualTo(System.String,System.Object)
// 0x000002E9 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereLessThan(System.String,System.Object)
// 0x000002EA NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereLessThanOrEqualTo(System.String,System.Object)
// 0x000002EB NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereContainedIn(System.String,System.Collections.IEnumerable)
// 0x000002EC NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereNotContainedIn(System.String,System.Collections.IEnumerable)
// 0x000002ED NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereContainedInArray(System.String,System.Collections.IEnumerable)
// 0x000002EE NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereContainsAll(System.String,System.Collections.IEnumerable)
// 0x000002EF NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereMatchesQuery(System.String,NCMB.NCMBQuery`1<TOther>)
// 0x000002F0 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereMatchesKeyInQuery(System.String,System.String,NCMB.NCMBQuery`1<TOther>)
// 0x000002F1 System.Void NCMB.NCMBQuery`1::Include(System.String)
// 0x000002F2 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereNearGeoPoint(System.String,NCMB.NCMBGeoPoint)
// 0x000002F3 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereGeoPointWithinKilometers(System.String,NCMB.NCMBGeoPoint,System.Double)
// 0x000002F4 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereGeoPointWithinMiles(System.String,NCMB.NCMBGeoPoint,System.Double)
// 0x000002F5 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereGeoPointWithinRadians(System.String,NCMB.NCMBGeoPoint,System.Double)
// 0x000002F6 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::WhereWithinGeoBox(System.String,NCMB.NCMBGeoPoint,NCMB.NCMBGeoPoint)
// 0x000002F7 System.Collections.Generic.Dictionary`2<System.String,System.Object> NCMB.NCMBQuery`1::_geoPointToObjectWithinBox(NCMB.NCMBGeoPoint,NCMB.NCMBGeoPoint)
// 0x000002F8 System.Collections.Generic.Dictionary`2<System.String,System.Object> NCMB.NCMBQuery`1::_geoPointToObject(NCMB.NCMBGeoPoint)
// 0x000002F9 System.Void NCMB.NCMBQuery`1::_addCondition(System.String,System.String,System.Object)
// 0x000002FA System.Void NCMB.NCMBQuery`1::FindAsync(NCMB.NCMBQueryCallback`1<T>)
// 0x000002FB System.Void NCMB.NCMBQuery`1::Find(NCMB.NCMBQueryCallback`1<T>)
// 0x000002FC System.Collections.ArrayList NCMB.NCMBQuery`1::_convertFindResponse(System.Collections.Generic.Dictionary`2<System.String,System.Object>)
// 0x000002FD System.Void NCMB.NCMBQuery`1::GetAsync(System.String,NCMB.NCMBGetCallback`1<T>)
// 0x000002FE NCMB.NCMBObject NCMB.NCMBQuery`1::_convertGetResponse(System.Collections.Generic.Dictionary`2<System.String,System.Object>)
// 0x000002FF System.Void NCMB.NCMBQuery`1::CountAsync(NCMB.NCMBCountCallback)
// 0x00000300 System.String NCMB.NCMBQuery`1::_makeWhereUrl(System.String,System.Collections.Generic.Dictionary`2<System.String,System.Object>)
// 0x00000301 System.Collections.Generic.Dictionary`2<System.String,System.Object> NCMB.NCMBQuery`1::_getFindParams()
// 0x00000302 System.Object NCMB.NCMBQuery`1::_encodeSubQueries(System.Object)
// 0x00000303 System.String NCMB.NCMBQuery`1::_join(System.Collections.Generic.List`1<System.String>,System.String)
// 0x00000304 System.String NCMB.NCMBQuery`1::_getSearchUrl(System.String)
// 0x00000305 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::GetQuery(System.String)
// 0x00000306 NCMB.NCMBQuery`1<T> NCMB.NCMBQuery`1::_whereRelatedTo(NCMB.NCMBObject,System.String)
// 0x00000307 System.Void NCMB.NCMBQuery`1/<>c__DisplayClass44_0::.ctor()
// 0x00000308 System.Void NCMB.NCMBQuery`1/<>c__DisplayClass44_0::<Find>b__0(System.Int32,System.String,NCMB.NCMBException)
// 0x00000309 System.Void NCMB.NCMBQuery`1/<>c__DisplayClass46_0::.ctor()
// 0x0000030A System.Void NCMB.NCMBQuery`1/<>c__DisplayClass46_0::<GetAsync>b__0(System.Int32,System.String,NCMB.NCMBException)
// 0x0000030B System.Void NCMB.NCMBQuery`1/<>c__DisplayClass48_0::.ctor()
// 0x0000030C System.Void NCMB.NCMBQuery`1/<>c__DisplayClass48_0::<CountAsync>b__0(System.Int32,System.String,NCMB.NCMBException)
// 0x0000030D System.String NCMB.NCMBRelation`1::get_TargetClass()
// 0x0000030E System.Void NCMB.NCMBRelation`1::set_TargetClass(System.String)
// 0x0000030F System.Void NCMB.NCMBRelation`1::.ctor(NCMB.NCMBObject,System.String)
// 0x00000310 System.Void NCMB.NCMBRelation`1::.ctor(System.String)
// 0x00000311 System.Void NCMB.NCMBRelation`1::Add(T)
// 0x00000312 System.Void NCMB.NCMBRelation`1::Remove(T)
// 0x00000313 System.Void NCMB.NCMBRelation`1::_removeDuplicationCheck(T)
// 0x00000314 System.Void NCMB.NCMBRelation`1::_addDuplicationCheck(T)
// 0x00000315 System.Void NCMB.NCMBRelation`1::_ensureParentAndKey(NCMB.NCMBObject,System.String)
// 0x00000316 System.Collections.Generic.Dictionary`2<System.String,System.Object> NCMB.NCMBRelation`1::_encodeToJSON()
// 0x00000317 NCMB.NCMBQuery`1<T> NCMB.NCMBRelation`1::GetQuery()
// 0x00000318 System.Void NCMB.NCMBRole::.ctor()
extern void NCMBRole__ctor_m2241BC4F35CEDFEC1C6378352EAD77092B177D25 (void);
// 0x00000319 System.Void NCMB.NCMBRole::.ctor(System.String)
extern void NCMBRole__ctor_mC367CBEF450897F91FCAC83FB1A334050C5443A8 (void);
// 0x0000031A System.Void NCMB.NCMBRole::.ctor(System.String,NCMB.NCMBACL)
extern void NCMBRole__ctor_m46975F2B47A4F1309B04B4A415DF10E3E7E2C27D (void);
// 0x0000031B System.Void NCMB.NCMBRole::set_Name(System.String)
extern void NCMBRole_set_Name_m80E6FF97AC80A1078277CBE815AF4F51473B8394 (void);
// 0x0000031C System.String NCMB.NCMBRole::get_Name()
extern void NCMBRole_get_Name_mA7FF90769DE9FE6F5764F5517EFFEB25104404A7 (void);
// 0x0000031D NCMB.NCMBRelation`1<NCMB.NCMBUser> NCMB.NCMBRole::get_Users()
extern void NCMBRole_get_Users_mD3891E6F864E902A7D269CD59D6DEDB4A04F94F9 (void);
// 0x0000031E NCMB.NCMBRelation`1<NCMB.NCMBRole> NCMB.NCMBRole::get_Roles()
extern void NCMBRole_get_Roles_m6EB64DC66BB42E7B4AD80BF301F705AD737D6691 (void);
// 0x0000031F NCMB.NCMBQuery`1<NCMB.NCMBRole> NCMB.NCMBRole::GetQuery()
extern void NCMBRole_GetQuery_m27B9D095C95FE592250FD507E269EF7E060D643F (void);
// 0x00000320 System.Void NCMB.NCMBRole::_onSettingValue(System.String,System.Object)
extern void NCMBRole__onSettingValue_m95FF094C2527D4CAF35979C757E492D52EA59A6C (void);
// 0x00000321 System.Void NCMB.NCMBRole::_beforeSave()
extern void NCMBRole__beforeSave_m4DC8CE9CEC1A0E52E87412AB9FFD6120CA1D1D48 (void);
// 0x00000322 System.String NCMB.NCMBRole::_getBaseUrl()
extern void NCMBRole__getBaseUrl_mACA27C596898A8F73B97ED78ABF41502B02E9985 (void);
// 0x00000323 System.Void NCMB.NCMBRole::.cctor()
extern void NCMBRole__cctor_m5D0095F8F9D9138A300EE511C76E0E2904D02CA4 (void);
// 0x00000324 System.String NCMB.NCMBScript::get_ScriptName()
extern void NCMBScript_get_ScriptName_m0B9B482875C51F4D6303F8BCB63F0BE80EE5C4D7 (void);
// 0x00000325 System.Void NCMB.NCMBScript::set_ScriptName(System.String)
extern void NCMBScript_set_ScriptName_m224EC39C5D136E157F34410BE42959756502DE17 (void);
// 0x00000326 NCMB.NCMBScript/MethodType NCMB.NCMBScript::get_Method()
extern void NCMBScript_get_Method_m77BC92E37B50383334A31C763D39F8955C4CFBC7 (void);
// 0x00000327 System.Void NCMB.NCMBScript::set_Method(NCMB.NCMBScript/MethodType)
extern void NCMBScript_set_Method_mB89FF279200621612CB1A193F774CD0FBD31464D (void);
// 0x00000328 System.String NCMB.NCMBScript::get_BaseUrl()
extern void NCMBScript_get_BaseUrl_m2A143B17910AFDE8908645AD7FCFE70286057FAF (void);
// 0x00000329 System.Void NCMB.NCMBScript::set_BaseUrl(System.String)
extern void NCMBScript_set_BaseUrl_m708C15E3F8AB7A2E835D6B19DDEBE50895689444 (void);
// 0x0000032A System.Void NCMB.NCMBScript::.ctor(System.String,NCMB.NCMBScript/MethodType)
extern void NCMBScript__ctor_mFFE1E3CE04F2FEE4B303A66C46BDAD9DE6ABC34C (void);
// 0x0000032B System.Void NCMB.NCMBScript::.ctor(System.String,NCMB.NCMBScript/MethodType,System.String)
extern void NCMBScript__ctor_mA44907DF175921420B0056D9171A0141427B1D39 (void);
// 0x0000032C System.Void NCMB.NCMBScript::ExecuteAsync(System.Collections.Generic.IDictionary`2<System.String,System.Object>,System.Collections.Generic.IDictionary`2<System.String,System.Object>,System.Collections.Generic.IDictionary`2<System.String,System.Object>,NCMB.NCMBExecuteScriptCallback)
extern void NCMBScript_ExecuteAsync_m46AFE59A7F0D877B5108931FCFC041683333FC21 (void);
// 0x0000032D System.Void NCMB.NCMBScript::Connect(NCMB.Internal.NCMBConnection,NCMB.NCMBExecuteScriptCallback)
extern void NCMBScript_Connect_m872017F8D43729B5792D1A7E69E8F08B84452F6E (void);
// 0x0000032E System.Void NCMB.NCMBScript::.cctor()
extern void NCMBScript__cctor_mA637263EF3035ECFEF7C8123D09CCC326654BA3A (void);
// 0x0000032F System.Void NCMB.NCMBScript/<>c::.cctor()
extern void U3CU3Ec__cctor_m61A667115C8D01BC23BAC03DBFB9B88BF5BE8A84 (void);
// 0x00000330 System.Void NCMB.NCMBScript/<>c::.ctor()
extern void U3CU3Ec__ctor_mEDE10724AB4EF1A9C018D958BB283CE6C93351D2 (void);
// 0x00000331 System.Boolean NCMB.NCMBScript/<>c::<ExecuteAsync>b__18_0(System.Object,System.Security.Cryptography.X509Certificates.X509Certificate,System.Security.Cryptography.X509Certificates.X509Chain,System.Net.Security.SslPolicyErrors)
extern void U3CU3Ec_U3CExecuteAsyncU3Eb__18_0_m03DD7C5E99EE9130687AE390240C6C8DB360826B (void);
// 0x00000332 System.Void NCMB.NCMBTwitterParameters::.ctor(System.String,System.String,System.String,System.String,System.String,System.String)
extern void NCMBTwitterParameters__ctor_m8682588C683EF79B23C320A62A4886874264B42E (void);
// 0x00000333 System.String NCMB.NCMBUser::get_UserName()
extern void NCMBUser_get_UserName_mA9CBD8558740F3C73771A90843C042FFE2854C5A (void);
// 0x00000334 System.Void NCMB.NCMBUser::set_UserName(System.String)
extern void NCMBUser_set_UserName_m4C509E2E534BB1F00BAC4B24DA4C5E04CBF553E8 (void);
// 0x00000335 System.String NCMB.NCMBUser::get_Email()
extern void NCMBUser_get_Email_m3AD6D3E237AA9054E95D44D311FFFC9521311516 (void);
// 0x00000336 System.Void NCMB.NCMBUser::set_Email(System.String)
extern void NCMBUser_set_Email_mAF4B3799FF9D290053C075411F496A2ED4894BBF (void);
// 0x00000337 System.String NCMB.NCMBUser::get_Password()
extern void NCMBUser_get_Password_m1685C3AAF76CA930CAE720DE19024E0D7C0BBE7A (void);
// 0x00000338 System.Void NCMB.NCMBUser::set_Password(System.String)
extern void NCMBUser_set_Password_m122C48D36F37603FBE742270039EF2777A5E34B4 (void);
// 0x00000339 System.Collections.Generic.Dictionary`2<System.String,System.Object> NCMB.NCMBUser::get_AuthData()
extern void NCMBUser_get_AuthData_mA437C6CB155FAFAB80ADC2DCB17B2BF9327769D0 (void);
// 0x0000033A System.Void NCMB.NCMBUser::set_AuthData(System.Collections.Generic.Dictionary`2<System.String,System.Object>)
extern void NCMBUser_set_AuthData_mADB4BD03AC64AEABB08976FB570E8370348BE51F (void);
// 0x0000033B System.String NCMB.NCMBUser::get_SessionToken()
extern void NCMBUser_get_SessionToken_mCDE16B148A115CD7ACA105C61BAE4E8ADAF5D649 (void);
// 0x0000033C System.Void NCMB.NCMBUser::set_SessionToken(System.String)
extern void NCMBUser_set_SessionToken_mEED4844AE5489C7A932D514309E4E32981C62828 (void);
// 0x0000033D NCMB.NCMBUser NCMB.NCMBUser::get_CurrentUser()
extern void NCMBUser_get_CurrentUser_m9CDA979912677C5EA61EFC710A04A9AD59139F0D (void);
// 0x0000033E System.Void NCMB.NCMBUser::.ctor()
extern void NCMBUser__ctor_m3CB9B58FBC25CCC256A1C1B04BBAF4134DEBDA80 (void);
// 0x0000033F System.Void NCMB.NCMBUser::_onSettingValue(System.String,System.Object)
extern void NCMBUser__onSettingValue_m8CCC0F71725A26E15FAE244B0CF508E164170393 (void);
// 0x00000340 System.Void NCMB.NCMBUser::Add(System.String,System.Object)
extern void NCMBUser_Add_m8315466F367A7524064E56123A23F7802F389C25 (void);
// 0x00000341 System.Void NCMB.NCMBUser::Remove(System.String)
extern void NCMBUser_Remove_m189C39B3C24FAB42B47EF4C941D0186054801F6E (void);
// 0x00000342 NCMB.NCMBQuery`1<NCMB.NCMBUser> NCMB.NCMBUser::GetQuery()
extern void NCMBUser_GetQuery_m54F835B2D5023618B8B230C0B6874E2007D09F84 (void);
// 0x00000343 System.String NCMB.NCMBUser::_getBaseUrl()
extern void NCMBUser__getBaseUrl_mD80C773870F4E9EB8AD8416A44DAA51F81659B8C (void);
// 0x00000344 System.String NCMB.NCMBUser::_getLogInUrl()
extern void NCMBUser__getLogInUrl_m7CA282FFC465DF9D56ED836226527C1D54599FA8 (void);
// 0x00000345 System.String NCMB.NCMBUser::_getLogOutUrl()
extern void NCMBUser__getLogOutUrl_m9421E8470D3167E5C462812CBEA3148FAB93A448 (void);
// 0x00000346 System.String NCMB.NCMBUser::_getRequestPasswordResetUrl()
extern void NCMBUser__getRequestPasswordResetUrl_mA77B5B2030AD97E8AAA96AB995708B299D280F53 (void);
// 0x00000347 System.String NCMB.NCMBUser::_getmailAddressUserEntryUrl()
extern void NCMBUser__getmailAddressUserEntryUrl_m959C65223BAB93DB33C16A8D93FD68417C2E9B89 (void);
// 0x00000348 System.Void NCMB.NCMBUser::_afterSave(System.Int32,NCMB.NCMBException)
extern void NCMBUser__afterSave_m1D3E5C235EDD8EAF762FB624ABADF3C1D680BF77 (void);
// 0x00000349 System.Void NCMB.NCMBUser::_afterDelete(NCMB.NCMBException)
extern void NCMBUser__afterDelete_m2316D7CEB43351C04A65EB2808176AC94C77E8EA (void);
// 0x0000034A System.Void NCMB.NCMBUser::DeleteAsync()
extern void NCMBUser_DeleteAsync_m07D229248FEBA5715D909658A24FFC5EE10561DE (void);
// 0x0000034B System.Void NCMB.NCMBUser::DeleteAsync(NCMB.NCMBCallback)
extern void NCMBUser_DeleteAsync_m24ABC3F93D4E4C32607BF0AF270A6CD11B7BAF97 (void);
// 0x0000034C System.Void NCMB.NCMBUser::SignUpAsync(NCMB.NCMBCallback)
extern void NCMBUser_SignUpAsync_mC799649C1E3B9BF65CD5613AC0412A4CC76256A2 (void);
// 0x0000034D System.Void NCMB.NCMBUser::SignUpAsync()
extern void NCMBUser_SignUpAsync_m8174E098CE27A396486FD9F4A170DE2096478D7A (void);
// 0x0000034E System.Void NCMB.NCMBUser::SaveAsync()
extern void NCMBUser_SaveAsync_m5C3E5B2246F5A42508EBCC4E9F0C7FDC18DC1038 (void);
// 0x0000034F System.Void NCMB.NCMBUser::SaveAsync(NCMB.NCMBCallback)
extern void NCMBUser_SaveAsync_m03E1E82B82F31DE02DDDC6540A904DEB4E184490 (void);
// 0x00000350 System.Void NCMB.NCMBUser::_saveCurrentUser(NCMB.NCMBUser)
extern void NCMBUser__saveCurrentUser_m0CD7D97ADF754C1D839F3AFA82C19891F242A2BB (void);
// 0x00000351 System.Void NCMB.NCMBUser::_logOutEvent()
extern void NCMBUser__logOutEvent_m154B6140E8403CA5020C3A7DBC586D89AFCC668B (void);
// 0x00000352 System.String NCMB.NCMBUser::_getCurrentSessionToken()
extern void NCMBUser__getCurrentSessionToken_m69F093680E549A97E21805CA286AFEB16511C73A (void);
// 0x00000353 System.Boolean NCMB.NCMBUser::IsAuthenticated()
extern void NCMBUser_IsAuthenticated_m235D5C9C51F0C7B1F63C8616DAA1A975D9E853BF (void);
// 0x00000354 System.Void NCMB.NCMBUser::RequestPasswordResetAsync(System.String)
extern void NCMBUser_RequestPasswordResetAsync_m01D56E5828944CA474803430EAACDD8FABF8C827 (void);
// 0x00000355 System.Void NCMB.NCMBUser::RequestPasswordResetAsync(System.String,NCMB.NCMBCallback)
extern void NCMBUser_RequestPasswordResetAsync_m347CE587991E386059E569DF855C586E9585CE75 (void);
// 0x00000356 System.Void NCMB.NCMBUser::_requestPasswordReset(System.String,NCMB.NCMBCallback)
extern void NCMBUser__requestPasswordReset_mAD4A1F68FD13C0971C00DB834C736E770258B850 (void);
// 0x00000357 System.Void NCMB.NCMBUser::LogInAsync(System.String,System.String)
extern void NCMBUser_LogInAsync_m273DAA3A5EEDFF64AA1ACDC7BDF0AF9985FF3C1A (void);
// 0x00000358 System.Void NCMB.NCMBUser::LogInAsync(System.String,System.String,NCMB.NCMBCallback)
extern void NCMBUser_LogInAsync_m19C528DB4829716B5C032BE061B4E8986063C78A (void);
// 0x00000359 System.Void NCMB.NCMBUser::_ncmbLogIn(System.String,System.String,System.String,NCMB.NCMBCallback)
extern void NCMBUser__ncmbLogIn_m0AD0379D46B88AA18CB57F044AA909EC007AB047 (void);
// 0x0000035A System.String NCMB.NCMBUser::_makeParamUrl(System.String,System.Collections.Generic.Dictionary`2<System.String,System.Object>)
extern void NCMBUser__makeParamUrl_mBD0208E7F18A8746E1D96B0A4BBAAC589B0EA151 (void);
// 0x0000035B System.Void NCMB.NCMBUser::LogInWithMailAddressAsync(System.String,System.String,NCMB.NCMBCallback)
extern void NCMBUser_LogInWithMailAddressAsync_m1F9280472AA0A85FF2F7849957D926773CF49CDD (void);
// 0x0000035C System.Void NCMB.NCMBUser::LogInWithMailAddressAsync(System.String,System.String)
extern void NCMBUser_LogInWithMailAddressAsync_m61E7D4660D6A78E8FD1F37BCDF488B61FE14E5A7 (void);
// 0x0000035D System.Void NCMB.NCMBUser::RequestAuthenticationMailAsync(System.String)
extern void NCMBUser_RequestAuthenticationMailAsync_mE4EA5FDDBE9A4C2F564717C223B9D03E2345BF0D (void);
// 0x0000035E System.Void NCMB.NCMBUser::RequestAuthenticationMailAsync(System.String,NCMB.NCMBCallback)
extern void NCMBUser_RequestAuthenticationMailAsync_mF1322CFFF47A34ADF89D2F12E047B9ED8BC4E30C (void);
// 0x0000035F System.Void NCMB.NCMBUser::LogOutAsync()
extern void NCMBUser_LogOutAsync_mD859E8BC4698CB69A258E8A7F5442C550E74DBDF (void);
// 0x00000360 System.Void NCMB.NCMBUser::LogOutAsync(NCMB.NCMBCallback)
extern void NCMBUser_LogOutAsync_mA1F699FDD93BE95112C441F64CDCD238D244E92F (void);
// 0x00000361 System.Void NCMB.NCMBUser::_logOut(NCMB.NCMBCallback)
extern void NCMBUser__logOut_m66498054067686A27002D3D15567046FAB3F1AF9 (void);
// 0x00000362 System.Void NCMB.NCMBUser::_mergeFromServer(System.Collections.Generic.Dictionary`2<System.String,System.Object>,System.Boolean)
extern void NCMBUser__mergeFromServer_m2F6281AA9853166E3C1F1F6B1ED4B62DC083DAC1 (void);
// 0x00000363 System.Void NCMB.NCMBUser::LogInWithAuthDataAsync(NCMB.NCMBCallback)
extern void NCMBUser_LogInWithAuthDataAsync_m3EB70E3F0FFD880E2B7CA528DA6D467F382B4800 (void);
// 0x00000364 System.Void NCMB.NCMBUser::LogInWithAuthDataAsync()
extern void NCMBUser_LogInWithAuthDataAsync_m27D64B67C71B995339E480657232097F5A24B1E7 (void);
// 0x00000365 System.Void NCMB.NCMBUser::LoginWithAnonymousAsync(NCMB.NCMBCallback)
extern void NCMBUser_LoginWithAnonymousAsync_m5B791822559776B89AE67374AF57AE1809829B56 (void);
// 0x00000366 System.Void NCMB.NCMBUser::LoginWithAnonymousAsync()
extern void NCMBUser_LoginWithAnonymousAsync_mE58957466CB9CD48336B75D7D94391E330ECD727 (void);
// 0x00000367 System.Void NCMB.NCMBUser::LinkWithAuthDataAsync(System.Collections.Generic.Dictionary`2<System.String,System.Object>,NCMB.NCMBCallback)
extern void NCMBUser_LinkWithAuthDataAsync_m768FD363EA1F904441CE73B566B077E3B5EE68CB (void);
// 0x00000368 System.Void NCMB.NCMBUser::LinkWithAuthDataAsync(System.Collections.Generic.Dictionary`2<System.String,System.Object>)
extern void NCMBUser_LinkWithAuthDataAsync_m3B4A755753F24EE3E8BAF51EB0C4763FEB05E121 (void);
// 0x00000369 System.Void NCMB.NCMBUser::UnLinkWithAuthDataAsync(System.String,NCMB.NCMBCallback)
extern void NCMBUser_UnLinkWithAuthDataAsync_mB808DF50B68C9AED0FF4D039420CE9558EF1C4DC (void);
// 0x0000036A System.Void NCMB.NCMBUser::UnLinkWithAuthDataAsync(System.String)
extern void NCMBUser_UnLinkWithAuthDataAsync_m05D55C8060DAFF98AD1A65BFD71EEEC1DB38EF2C (void);
// 0x0000036B System.Boolean NCMB.NCMBUser::IsLinkWith(System.String)
extern void NCMBUser_IsLinkWith_mC4E8238DF82825656D83391C6770538CD91D58A1 (void);
// 0x0000036C System.Collections.Generic.Dictionary`2<System.String,System.Object> NCMB.NCMBUser::GetAuthDataForProvider(System.String)
extern void NCMBUser_GetAuthDataForProvider_mC2239649D16A849DCC2C7D036E868D5B541ADB03 (void);
// 0x0000036D System.String NCMB.NCMBUser::createUUID()
extern void NCMBUser_createUUID_m3B9A97C56DF1CE1EFF3C63ACF48544E873E56065 (void);
// 0x0000036E System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.NCMBUser::LogInTaskAsync(System.String,System.String)
extern void NCMBUser_LogInTaskAsync_mB0573E56923C4C6138801D82A015AA4103CE645E (void);
// 0x0000036F System.Threading.Tasks.Task`1<System.Boolean> NCMB.NCMBUser::RequestAuthenticationMailTaskAsync(System.String)
extern void NCMBUser_RequestAuthenticationMailTaskAsync_mB9539CB4833443BE53365825E995A6CE50AF6D1F (void);
// 0x00000370 System.Threading.Tasks.Task`1<System.Boolean> NCMB.NCMBUser::LogOutTaskAsync()
extern void NCMBUser_LogOutTaskAsync_mA5BF9BC08A06D55CFDC2309149B74FEE3895F13D (void);
// 0x00000371 System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.NCMBUser::LogInWithMailAddressTaskAsync(System.String,System.String)
extern void NCMBUser_LogInWithMailAddressTaskAsync_mCA98299CB79B66812EB60D37D23A545ACE79C50B (void);
// 0x00000372 System.Void NCMB.NCMBUser::.cctor()
extern void NCMBUser__cctor_mEC300EDFA46FF6EEE5AFBD63CE131197D4684B50 (void);
// 0x00000373 System.Void NCMB.NCMBUser/<>c__DisplayClass43_0::.ctor()
extern void U3CU3Ec__DisplayClass43_0__ctor_m7EB296E8511A471FB06D395CD960790E47B55A6A (void);
// 0x00000374 System.Void NCMB.NCMBUser/<>c__DisplayClass43_0::<_requestPasswordReset>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass43_0_U3C_requestPasswordResetU3Eb__0_m3BEC0F9C03351F57059C34A66FE14FCC723666A2 (void);
// 0x00000375 System.Void NCMB.NCMBUser/<>c__DisplayClass46_0::.ctor()
extern void U3CU3Ec__DisplayClass46_0__ctor_mADB89779823B511784F6688633A61DD4E3BAD4D7 (void);
// 0x00000376 System.Void NCMB.NCMBUser/<>c__DisplayClass46_0::<_ncmbLogIn>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass46_0_U3C_ncmbLogInU3Eb__0_m791262C299BCD403FE006378F35D7B237FA6EA35 (void);
// 0x00000377 System.Void NCMB.NCMBUser/<>c__DisplayClass51_0::.ctor()
extern void U3CU3Ec__DisplayClass51_0__ctor_mD5CB560B59C3E72763DDD704AE6B3669080804BF (void);
// 0x00000378 System.Void NCMB.NCMBUser/<>c__DisplayClass51_0::<RequestAuthenticationMailAsync>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass51_0_U3CRequestAuthenticationMailAsyncU3Eb__0_m7419A3B3D46419239FA3F0E303EA7B94C57E101D (void);
// 0x00000379 System.Void NCMB.NCMBUser/<>c__DisplayClass54_0::.ctor()
extern void U3CU3Ec__DisplayClass54_0__ctor_m38606879272E668B19E982C0CA3C165F242C0355 (void);
// 0x0000037A System.Void NCMB.NCMBUser/<>c__DisplayClass54_0::<_logOut>b__0(System.Int32,System.String,NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass54_0_U3C_logOutU3Eb__0_mE8BD5A3667F3DB2EEBBA0F2DD9148B6DCFE16C44 (void);
// 0x0000037B System.Void NCMB.NCMBUser/<>c__DisplayClass56_0::.ctor()
extern void U3CU3Ec__DisplayClass56_0__ctor_m8BD82E60360FEF7E8E194D61338D8610DC90B0B2 (void);
// 0x0000037C System.Void NCMB.NCMBUser/<>c__DisplayClass56_0::<LogInWithAuthDataAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass56_0_U3CLogInWithAuthDataAsyncU3Eb__0_m74399D1B8D776AFC652D2FBB80D60E7705CA7AF5 (void);
// 0x0000037D System.Void NCMB.NCMBUser/<>c__DisplayClass58_0::.ctor()
extern void U3CU3Ec__DisplayClass58_0__ctor_m84427DFCB3522479D9D3463E99F06742057BD2C8 (void);
// 0x0000037E System.Void NCMB.NCMBUser/<>c__DisplayClass58_0::<LoginWithAnonymousAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass58_0_U3CLoginWithAnonymousAsyncU3Eb__0_m8D4DF95481F256AAE13E702708FD7ACA1B85606F (void);
// 0x0000037F System.Void NCMB.NCMBUser/<>c__DisplayClass60_0::.ctor()
extern void U3CU3Ec__DisplayClass60_0__ctor_m5854838D409711853248357F276E35967349B485 (void);
// 0x00000380 System.Void NCMB.NCMBUser/<>c__DisplayClass60_0::<LinkWithAuthDataAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass60_0_U3CLinkWithAuthDataAsyncU3Eb__0_m0AE6D7A27721129B49892695480DACCBBA93ED89 (void);
// 0x00000381 System.Void NCMB.NCMBUser/<>c::.cctor()
extern void U3CU3Ec__cctor_m3D87457F24E0C0FE2CE0195510B0A41AD5414BAD (void);
// 0x00000382 System.Void NCMB.NCMBUser/<>c::.ctor()
extern void U3CU3Ec__ctor_m2A0CF1268283F749AA4DB36DCDFEE3BF0102848B (void);
// 0x00000383 System.String NCMB.NCMBUser/<>c::<LinkWithAuthDataAsync>b__60_1(System.Collections.Generic.KeyValuePair`2<System.String,System.Object>)
extern void U3CU3Ec_U3CLinkWithAuthDataAsyncU3Eb__60_1_m66BD17C2A99C776ECF3007D3F15A01D495541E32 (void);
// 0x00000384 System.Object NCMB.NCMBUser/<>c::<LinkWithAuthDataAsync>b__60_2(System.Collections.Generic.KeyValuePair`2<System.String,System.Object>)
extern void U3CU3Ec_U3CLinkWithAuthDataAsyncU3Eb__60_2_mAD2756D932486D1424B7401CAE963183DF39154A (void);
// 0x00000385 System.Void NCMB.NCMBUser/<>c__DisplayClass62_0::.ctor()
extern void U3CU3Ec__DisplayClass62_0__ctor_m50E6D46C797EDCF2B3BA726A11A6AC5D62277EBD (void);
// 0x00000386 System.Void NCMB.NCMBUser/<>c__DisplayClass62_0::<UnLinkWithAuthDataAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass62_0_U3CUnLinkWithAuthDataAsyncU3Eb__0_mEBC11A97A93936EC7DA4F6999ED3741E37DCD14A (void);
// 0x00000387 System.Void NCMB.NCMBUser/<>c__DisplayClass67_0::.ctor()
extern void U3CU3Ec__DisplayClass67_0__ctor_m6C5B7ECCA936AE2C9FCA1EBF06E42D157988C20F (void);
// 0x00000388 System.Void NCMB.NCMBUser/<>c__DisplayClass67_0::<LogInTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass67_0_U3CLogInTaskAsyncU3Eb__0_m193B8FDA7A4A21614DE23139A7A1CB0B84B91B92 (void);
// 0x00000389 System.Void NCMB.NCMBUser/<>c__DisplayClass68_0::.ctor()
extern void U3CU3Ec__DisplayClass68_0__ctor_m3C23335A77AEADDA4A6D3F945D01C8D10CF629EF (void);
// 0x0000038A System.Void NCMB.NCMBUser/<>c__DisplayClass68_0::<RequestAuthenticationMailTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass68_0_U3CRequestAuthenticationMailTaskAsyncU3Eb__0_m815AA7580173408FFF146CF1331D447A354BB285 (void);
// 0x0000038B System.Void NCMB.NCMBUser/<>c__DisplayClass69_0::.ctor()
extern void U3CU3Ec__DisplayClass69_0__ctor_mDB4B582DC5205B9877111F8C6A91CA484BD1881B (void);
// 0x0000038C System.Void NCMB.NCMBUser/<>c__DisplayClass69_0::<LogOutTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass69_0_U3CLogOutTaskAsyncU3Eb__0_m6367EB9C03A49431D599E15C46F4E7E54090E4FD (void);
// 0x0000038D System.Void NCMB.NCMBUser/<>c__DisplayClass70_0::.ctor()
extern void U3CU3Ec__DisplayClass70_0__ctor_m3F860F6BE7DE9F620A4DE095591DBACA130381E2 (void);
// 0x0000038E System.Void NCMB.NCMBUser/<>c__DisplayClass70_0::<LogInWithMailAddressTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass70_0_U3CLogInWithMailAddressTaskAsyncU3Eb__0_mF1D35CE6C3645282DD4014201D616449CC1A1AC1 (void);
// 0x0000038F System.Void NCMB.NamespaceDoc::.ctor()
extern void NamespaceDoc__ctor_mD7C5EBCBB65BEF9BF148AD137CC36EE3AE99E6A1 (void);
// 0x00000390 System.Void NCMB.Extensions.YieldableNcmbQuery`1::set_Result(System.Collections.Generic.List`1<T>)
// 0x00000391 System.Collections.Generic.List`1<T> NCMB.Extensions.YieldableNcmbQuery`1::get_Result()
// 0x00000392 System.Void NCMB.Extensions.YieldableNcmbQuery`1::set_Error(NCMB.NCMBException)
// 0x00000393 NCMB.NCMBException NCMB.Extensions.YieldableNcmbQuery`1::get_Error()
// 0x00000394 System.Int32 NCMB.Extensions.YieldableNcmbQuery`1::get_Count()
// 0x00000395 UnityEngine.CustomYieldInstruction NCMB.Extensions.YieldableNcmbQuery`1::FindAsync()
// 0x00000396 System.Void NCMB.Extensions.YieldableNcmbQuery`1::.ctor(System.String)
// 0x00000397 System.Void NCMB.Extensions.YieldableNcmbQuery`1::<FindAsync>b__10_0(System.Collections.Generic.List`1<T>,NCMB.NCMBException)
// 0x00000398 System.Boolean NCMB.Extensions.YieldableNcmbQuery`1::<FindAsync>b__10_1()
// 0x00000399 UnityEngine.CustomYieldInstruction NCMB.Extensions.NCMBExtensions::YieldableFindAsync(NCMB.NCMBQuery`1<T>,NCMB.NCMBQueryCallback`1<T>)
// 0x0000039A UnityEngine.CustomYieldInstruction NCMB.Extensions.NCMBExtensions::YieldableSaveAsync(NCMB.NCMBObject,NCMB.NCMBCallback)
extern void NCMBExtensions_YieldableSaveAsync_m6F374D9276B142C8CEFC8B8C80A195D68C740A22 (void);
// 0x0000039B System.Void NCMB.Extensions.NCMBExtensions/<>c__DisplayClass0_0`1::.ctor()
// 0x0000039C System.Void NCMB.Extensions.NCMBExtensions/<>c__DisplayClass0_0`1::<YieldableFindAsync>b__0(System.Collections.Generic.List`1<T>,NCMB.NCMBException)
// 0x0000039D System.Boolean NCMB.Extensions.NCMBExtensions/<>c__DisplayClass0_0`1::<YieldableFindAsync>b__1()
// 0x0000039E System.Void NCMB.Extensions.NCMBExtensions/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_mEB0C55E6AAB143EC50AA8680C3786C66A2D9751A (void);
// 0x0000039F System.Void NCMB.Extensions.NCMBExtensions/<>c__DisplayClass1_0::<YieldableSaveAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass1_0_U3CYieldableSaveAsyncU3Eb__0_m9BCFF24D6D6CD494831772EDA29592DAD57CE07C (void);
// 0x000003A0 System.Boolean NCMB.Extensions.NCMBExtensions/<>c__DisplayClass1_0::<YieldableSaveAsync>b__1()
extern void U3CU3Ec__DisplayClass1_0_U3CYieldableSaveAsyncU3Eb__1_m76B3130A82AD094D35E99A4C33D9780956BE600C (void);
// 0x000003A1 System.Threading.Tasks.Task`1<T> NCMB.Tasks.NCMBObjectTaskExtension::FetchTaskAsync(T)
// 0x000003A2 System.Threading.Tasks.Task`1<T> NCMB.Tasks.NCMBObjectTaskExtension::SaveTaskAsync(T)
// 0x000003A3 System.Threading.Tasks.Task`1<T> NCMB.Tasks.NCMBObjectTaskExtension::DeleteTaskAsync(T)
// 0x000003A4 System.Void NCMB.Tasks.NCMBObjectTaskExtension/<>c__DisplayClass0_0`1::.ctor()
// 0x000003A5 System.Void NCMB.Tasks.NCMBObjectTaskExtension/<>c__DisplayClass0_0`1::<FetchTaskAsync>b__0(NCMB.NCMBException)
// 0x000003A6 System.Void NCMB.Tasks.NCMBObjectTaskExtension/<>c__DisplayClass1_0`1::.ctor()
// 0x000003A7 System.Void NCMB.Tasks.NCMBObjectTaskExtension/<>c__DisplayClass1_0`1::<SaveTaskAsync>b__0(NCMB.NCMBException)
// 0x000003A8 System.Void NCMB.Tasks.NCMBObjectTaskExtension/<>c__DisplayClass2_0`1::.ctor()
// 0x000003A9 System.Void NCMB.Tasks.NCMBObjectTaskExtension/<>c__DisplayClass2_0`1::<DeleteTaskAsync>b__0(NCMB.NCMBException)
// 0x000003AA System.Threading.Tasks.Task`1<NCMB.NCMBPush> NCMB.Tasks.NCMBPushTaskExtension::SendPushTaskAsync(NCMB.NCMBPush)
extern void NCMBPushTaskExtension_SendPushTaskAsync_mBF0DB383368144CD42EA20A2BF091CA56A4FE033 (void);
// 0x000003AB System.Void NCMB.Tasks.NCMBPushTaskExtension/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m641564EB7F5B122D8EA3D2BB305D50F8DB4CBE25 (void);
// 0x000003AC System.Void NCMB.Tasks.NCMBPushTaskExtension/<>c__DisplayClass0_0::<SendPushTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass0_0_U3CSendPushTaskAsyncU3Eb__0_m1888674F7F6B2169C039B3DBB5B7AEA4178D58FE (void);
// 0x000003AD System.Threading.Tasks.Task`1<System.Byte[]> NCMB.Tasks.NCMBScriptTaskExtension::ExecuteTaskAsync(NCMB.NCMBScript,System.Collections.Generic.IDictionary`2<System.String,System.Object>,System.Collections.Generic.IDictionary`2<System.String,System.Object>,System.Collections.Generic.IDictionary`2<System.String,System.Object>)
extern void NCMBScriptTaskExtension_ExecuteTaskAsync_m2458816FDD7B8A571390D285EF1AA8AF351BEC5B (void);
// 0x000003AE System.Void NCMB.Tasks.NCMBScriptTaskExtension/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m83CE98221A611A8A09A553F008F411B608A35CCA (void);
// 0x000003AF System.Void NCMB.Tasks.NCMBScriptTaskExtension/<>c__DisplayClass0_0::<ExecuteTaskAsync>b__0(System.Byte[],NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass0_0_U3CExecuteTaskAsyncU3Eb__0_m9556AA768426F637D1998343358C4932260DFC32 (void);
// 0x000003B0 System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.Tasks.NCMBUserTaskExtension::FetchTaskAsync(NCMB.NCMBUser)
extern void NCMBUserTaskExtension_FetchTaskAsync_m4758D27F4CD245DBA32574097BFF039D1DB8EDD4 (void);
// 0x000003B1 System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.Tasks.NCMBUserTaskExtension::SaveTaskAsync(NCMB.NCMBUser)
extern void NCMBUserTaskExtension_SaveTaskAsync_m14C5E77BEC14E8BE513C8F095729CC5AB434EAB0 (void);
// 0x000003B2 System.Threading.Tasks.Task`1<System.Boolean> NCMB.Tasks.NCMBUserTaskExtension::DeleteTaskAsync(NCMB.NCMBUser)
extern void NCMBUserTaskExtension_DeleteTaskAsync_mC0E92F162780CC2048A5B02C58991432F6CCF6A8 (void);
// 0x000003B3 System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.Tasks.NCMBUserTaskExtension::UnLinkWithAuthDataTaskAsync(NCMB.NCMBUser,System.String)
extern void NCMBUserTaskExtension_UnLinkWithAuthDataTaskAsync_mDE457802917A38559CC6E5D10E9F5F2F6C637403 (void);
// 0x000003B4 System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.Tasks.NCMBUserTaskExtension::LinkWithAuthDataTaskAsync(NCMB.NCMBUser,System.Collections.Generic.Dictionary`2<System.String,System.Object>)
extern void NCMBUserTaskExtension_LinkWithAuthDataTaskAsync_m5404938E388D8724DA331CE3C9CF9615D6ADE651 (void);
// 0x000003B5 System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.Tasks.NCMBUserTaskExtension::LogInWithAuthDataTaskAsync(NCMB.NCMBUser)
extern void NCMBUserTaskExtension_LogInWithAuthDataTaskAsync_mE89C2EF2FD55C6A1934D79A864F631990E20CD1F (void);
// 0x000003B6 System.Threading.Tasks.Task`1<NCMB.NCMBUser> NCMB.Tasks.NCMBUserTaskExtension::SignUpTaskAsync(NCMB.NCMBUser)
extern void NCMBUserTaskExtension_SignUpTaskAsync_mDCC2AC5EE15B869E21B093D732ECC62DBE4E1284 (void);
// 0x000003B7 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m31F8301194B707721CC9E1902FB3FCF784C58DDB (void);
// 0x000003B8 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass0_0::<FetchTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass0_0_U3CFetchTaskAsyncU3Eb__0_mFEC07ED8E0557679A1FAEEAC8EF573761F8DBA97 (void);
// 0x000003B9 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_m2D4A19ABD30F5988AA923A98141F0E2C5CFF2B7C (void);
// 0x000003BA System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass1_0::<SaveTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass1_0_U3CSaveTaskAsyncU3Eb__0_m73C74B3556AF0F5C2A5A4BCA47CD7D76EB655F58 (void);
// 0x000003BB System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m2A74FB6834E8162600E5711907476958EE4A878A (void);
// 0x000003BC System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass2_0::<DeleteTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass2_0_U3CDeleteTaskAsyncU3Eb__0_m3DAE5FE6816B93B4458FABEEEA02C637856BD2D1 (void);
// 0x000003BD System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m7CC10F61F331306FF8A88FCCF79F4B49DC71EA8C (void);
// 0x000003BE System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass3_0::<UnLinkWithAuthDataTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass3_0_U3CUnLinkWithAuthDataTaskAsyncU3Eb__0_mC118D033A06DDA7427D84C649FA16B5429CA9B56 (void);
// 0x000003BF System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass4_0::.ctor()
extern void U3CU3Ec__DisplayClass4_0__ctor_m56E401CA9D7F9834CE34AC7338AAB48C6B6FBA36 (void);
// 0x000003C0 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass4_0::<LinkWithAuthDataTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass4_0_U3CLinkWithAuthDataTaskAsyncU3Eb__0_m27234468683D22967BBC60B0E552F1650AE47E57 (void);
// 0x000003C1 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_m19D75EEBEE00298753BEAC055ADAF29425DA044B (void);
// 0x000003C2 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass5_0::<LogInWithAuthDataTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass5_0_U3CLogInWithAuthDataTaskAsyncU3Eb__0_mF0D7E9E23F2F1BA4D2D528A85CA65796131E10F2 (void);
// 0x000003C3 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m57A9C06ED8982317A28337173844CC0ACF7D5045 (void);
// 0x000003C4 System.Void NCMB.Tasks.NCMBUserTaskExtension/<>c__DisplayClass6_0::<SignUpTaskAsync>b__0(NCMB.NCMBException)
extern void U3CU3Ec__DisplayClass6_0_U3CSignUpTaskAsyncU3Eb__0_m8828946194A8230D8EE6C08E1F7F9D6AE57E6D3B (void);
// 0x000003C5 System.Threading.Tasks.Task`1<System.Collections.Generic.IList`1<T>> NCMB.Tasks.NCMBQueryTaskExtension::FindTaskAsync(NCMB.NCMBQuery`1<T>)
// 0x000003C6 System.Threading.Tasks.Task`1<T> NCMB.Tasks.NCMBQueryTaskExtension::GetTaskAsync(NCMB.NCMBQuery`1<T>,System.String)
// 0x000003C7 System.Threading.Tasks.Task`1<System.Int32> NCMB.Tasks.NCMBQueryTaskExtension::CountTaskAsync(NCMB.NCMBQuery`1<T>)
// 0x000003C8 System.Void NCMB.Tasks.NCMBQueryTaskExtension/<>c__DisplayClass0_0`1::.ctor()
// 0x000003C9 System.Void NCMB.Tasks.NCMBQueryTaskExtension/<>c__DisplayClass0_0`1::<FindTaskAsync>b__0(System.Collections.Generic.List`1<T>,NCMB.NCMBException)
// 0x000003CA System.Void NCMB.Tasks.NCMBQueryTaskExtension/<>c__DisplayClass1_0`1::.ctor()
// 0x000003CB System.Void NCMB.Tasks.NCMBQueryTaskExtension/<>c__DisplayClass1_0`1::<GetTaskAsync>b__0(T,NCMB.NCMBException)
// 0x000003CC System.Void NCMB.Tasks.NCMBQueryTaskExtension/<>c__DisplayClass2_0`1::.ctor()
// 0x000003CD System.Void NCMB.Tasks.NCMBQueryTaskExtension/<>c__DisplayClass2_0`1::<CountTaskAsync>b__0(System.Int32,NCMB.NCMBException)
// 0x000003CE System.Void NCMB.Internal.CommonConstant::.cctor()
extern void CommonConstant__cctor_m6FC2F00CE3E9FD701029E3E350BFF76FC51DDAD7 (void);
// 0x000003CF System.Type NCMB.Internal.ExtensionsClass::GetTypeInfo(System.Type)
extern void ExtensionsClass_GetTypeInfo_m204CAF3A1FFCB24742075BD4CAF3429387BA962E (void);
// 0x000003D0 System.Boolean NCMB.Internal.ExtensionsClass::IsPrimitive(System.Type)
extern void ExtensionsClass_IsPrimitive_m33944F7BD8D98ABDC2DA4E761CDEC75E7E9A7E9F (void);
// 0x000003D1 System.Void NCMB.Internal.NCMBAddOperation::.ctor(System.Object)
extern void NCMBAddOperation__ctor_m3D74C3EB8055FB19C4910157B4F33550326CB87F (void);
// 0x000003D2 System.Object NCMB.Internal.NCMBAddOperation::Encode()
extern void NCMBAddOperation_Encode_m5BCA3092EA21D279E09B20CF2BBDB7E0C9DA34A7 (void);
// 0x000003D3 NCMB.Internal.INCMBFieldOperation NCMB.Internal.NCMBAddOperation::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
extern void NCMBAddOperation_MergeWithPrevious_mCB716BEF1F6C66128C07F38C50811DEEB082E948 (void);
// 0x000003D4 System.Object NCMB.Internal.NCMBAddOperation::Apply(System.Object,NCMB.NCMBObject,System.String)
extern void NCMBAddOperation_Apply_m7F10BB3F9F85136E554F0935C9CF0B2CFFB99340 (void);
// 0x000003D5 System.Void NCMB.Internal.NCMBAddUniqueOperation::.ctor(System.Object)
extern void NCMBAddUniqueOperation__ctor_m8A538D50CABF015D7F07CC243264D0A1FE1FB23A (void);
// 0x000003D6 System.Object NCMB.Internal.NCMBAddUniqueOperation::Encode()
extern void NCMBAddUniqueOperation_Encode_m8C794525A5199858CBB3A0B048199F0C34315774 (void);
// 0x000003D7 NCMB.Internal.INCMBFieldOperation NCMB.Internal.NCMBAddUniqueOperation::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
extern void NCMBAddUniqueOperation_MergeWithPrevious_mF5A5675651C7CB6101F5C7341E273CEEB22243F2 (void);
// 0x000003D8 System.Object NCMB.Internal.NCMBAddUniqueOperation::Apply(System.Object,NCMB.NCMBObject,System.String)
extern void NCMBAddUniqueOperation_Apply_m9A6365280C58C8503012C8A7AA5B7255833FEF26 (void);
// 0x000003D9 System.String NCMB.Internal.NCMBClassNameAttribute::get_ClassName()
extern void NCMBClassNameAttribute_get_ClassName_mD67B6633E7C259F5C29E207E6300B0898EA99BCE (void);
// 0x000003DA System.Void NCMB.Internal.NCMBClassNameAttribute::set_ClassName(System.String)
extern void NCMBClassNameAttribute_set_ClassName_m5F98F9C398EA3EC87D2351EF6226FC04299D3A13 (void);
// 0x000003DB System.Void NCMB.Internal.NCMBClassNameAttribute::.ctor(System.String)
extern void NCMBClassNameAttribute__ctor_m943265AE2D4753298948F6C53B3C3948214D1D8F (void);
// 0x000003DC System.Void NCMB.Internal.NCMBConnection::.ctor(System.String,NCMB.Internal.ConnectType,System.String,System.String)
extern void NCMBConnection__ctor_m1F93FAD147BCAFB68CCCA87E792CA8AAC6365543 (void);
// 0x000003DD System.Void NCMB.Internal.NCMBConnection::.ctor(System.String,NCMB.Internal.ConnectType,System.String,System.String,NCMB.NCMBFile)
extern void NCMBConnection__ctor_m2B04448C56AD92DB18B7E38C81541F2D96B671DC (void);
// 0x000003DE System.Void NCMB.Internal.NCMBConnection::.ctor(System.String,NCMB.Internal.ConnectType,System.String,System.String,NCMB.NCMBFile,System.String)
extern void NCMBConnection__ctor_m131F77AF6465A2BEE382B3CB3AC1E44681ED691A (void);
// 0x000003DF System.Void NCMB.Internal.NCMBConnection::Connect(NCMB.HttpClientFileDataCallback)
extern void NCMBConnection_Connect_mD0C2D0ADCE0F9A1BDDD73B5D21F69ED908F6A950 (void);
// 0x000003E0 System.Void NCMB.Internal.NCMBConnection::Connect(NCMB.HttpClientCallback)
extern void NCMBConnection_Connect_mF0D27CB12F3FA82B8D452290034087184C4CF1CC (void);
// 0x000003E1 System.Void NCMB.Internal.NCMBConnection::_Connection(System.Object)
extern void NCMBConnection__Connection_mF71ADBF17149FFF0226B8C5EAA1C426B4856988E (void);
// 0x000003E2 System.Void NCMB.Internal.NCMBConnection::_signatureCheck(System.String,System.String,System.String,System.Byte[],NCMB.NCMBException&)
extern void NCMBConnection__signatureCheck_mD7610DF8E74B5FBE561D349E279D05170D74333F (void);
// 0x000003E3 System.String NCMB.Internal.NCMBConnection::AsHex(System.Byte[])
extern void NCMBConnection_AsHex_m4C72A9343A4F13B4CB690536413898A0DEF9EA15 (void);
// 0x000003E4 UnityEngine.Networking.UnityWebRequest NCMB.Internal.NCMBConnection::_setUploadHandlerForFile(UnityEngine.Networking.UnityWebRequest)
extern void NCMBConnection__setUploadHandlerForFile_m6795ADBFB7DA8258CA91C0DEBE28ED7A102519AB (void);
// 0x000003E5 UnityEngine.Networking.UnityWebRequest NCMB.Internal.NCMBConnection::_returnRequest()
extern void NCMBConnection__returnRequest_mE2F121DC5784E5A60671B2A401D1872852E359F7 (void);
// 0x000003E6 System.Text.StringBuilder NCMB.Internal.NCMBConnection::_makeSignatureHashData()
extern void NCMBConnection__makeSignatureHashData_m093565CC48DB70168412BBD389301E4923392320 (void);
// 0x000003E7 System.String NCMB.Internal.NCMBConnection::_makeSignature(System.String)
extern void NCMBConnection__makeSignature_m69DE17AC2D026D456EFA855001C349ADAF8C3B18 (void);
// 0x000003E8 System.Void NCMB.Internal.NCMBConnection::_makeTimeStamp()
extern void NCMBConnection__makeTimeStamp_m4D22498DFF74E57CE9DF7197BE027384D97338FB (void);
// 0x000003E9 System.Void NCMB.Internal.NCMBConnection::_checkInvalidSessionToken(System.String)
extern void NCMBConnection__checkInvalidSessionToken_m602BAF2B2BAEE049D462852088933031EFCF4917 (void);
// 0x000003EA System.Void NCMB.Internal.NCMBConnection::_checkResponseSignature(System.String,System.String,UnityEngine.Networking.UnityWebRequest,NCMB.NCMBException&)
extern void NCMBConnection__checkResponseSignature_m6BB0E7A2195876EC3CC1B0F6D680E7F83925D323 (void);
// 0x000003EB System.Collections.IEnumerator NCMB.Internal.NCMBConnection::SendRequest(NCMB.Internal.NCMBConnection,UnityEngine.Networking.UnityWebRequest,System.Object)
extern void NCMBConnection_SendRequest_m853E0EFEC6079B49731AFD8DD21FF1944CD9A25E (void);
// 0x000003EC System.Void NCMB.Internal.NCMBConnection::.cctor()
extern void NCMBConnection__cctor_m683EBC8B76046B76756669EE10A924E038A6D20C (void);
// 0x000003ED System.Void NCMB.Internal.NCMBConnection/<SendRequest>d__37::.ctor(System.Int32)
extern void U3CSendRequestU3Ed__37__ctor_mF0B90F3722F9A84ADD92FF168F2ABDC5B513890B (void);
// 0x000003EE System.Void NCMB.Internal.NCMBConnection/<SendRequest>d__37::System.IDisposable.Dispose()
extern void U3CSendRequestU3Ed__37_System_IDisposable_Dispose_m539955284CBD4E5953898E35F7C192EF59005E3A (void);
// 0x000003EF System.Boolean NCMB.Internal.NCMBConnection/<SendRequest>d__37::MoveNext()
extern void U3CSendRequestU3Ed__37_MoveNext_mA76D300551A9F84B5EB77ED0E24BF1C0F59BB66B (void);
// 0x000003F0 System.Object NCMB.Internal.NCMBConnection/<SendRequest>d__37::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CSendRequestU3Ed__37_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mFD89908E7E692F8CC98042951C7CF5BDB3F60DD0 (void);
// 0x000003F1 System.Void NCMB.Internal.NCMBConnection/<SendRequest>d__37::System.Collections.IEnumerator.Reset()
extern void U3CSendRequestU3Ed__37_System_Collections_IEnumerator_Reset_mB7840C04BBD99F4D7DAD963397B66B7F71E33BF2 (void);
// 0x000003F2 System.Object NCMB.Internal.NCMBConnection/<SendRequest>d__37::System.Collections.IEnumerator.get_Current()
extern void U3CSendRequestU3Ed__37_System_Collections_IEnumerator_get_Current_mF0E32AE1B302AA47A6CCE71B35E7042EA2FF88A7 (void);
// 0x000003F3 System.Void NCMB.Internal.NCMBDebug::Log(System.String)
extern void NCMBDebug_Log_m9DFC269D444C3B6BBD99400EA23E359B43AE605D (void);
// 0x000003F4 System.Void NCMB.Internal.NCMBDebug::LogWarning(System.String)
extern void NCMBDebug_LogWarning_m7A6F2053A309E622C082BEF8FF3AC3CBC9B06571 (void);
// 0x000003F5 System.Void NCMB.Internal.NCMBDebug::LogError(System.String)
extern void NCMBDebug_LogError_mAF72313E29BD0231B6C668D7DB2A632381649261 (void);
// 0x000003F6 System.Void NCMB.Internal.NCMBDebug::LogError(System.Object,System.Object)
extern void NCMBDebug_LogError_mF0C83CBEC29778712619E6F8C26BAF0402EEE40B (void);
// 0x000003F7 System.Void NCMB.Internal.NCMBDebug::List(System.String,System.Collections.IList)
extern void NCMBDebug_List_m4EE28648D73A9D8A01FB366F31DD6DE43794FD91 (void);
// 0x000003F8 System.Void NCMB.Internal.NCMBDebug::Dictionary(System.String,System.Collections.Generic.Dictionary`2<T,K>)
// 0x000003F9 System.Void NCMB.Internal.NCMBDebug::.cctor()
extern void NCMBDebug__cctor_m286FF670A33A5B39B514DF67DFB6669ACF330A07 (void);
// 0x000003FA System.Void NCMB.Internal.NCMBDeleteOperation::.ctor()
extern void NCMBDeleteOperation__ctor_m47F4BDCF349F5AA0A92EC101794221D877C648EC (void);
// 0x000003FB System.Object NCMB.Internal.NCMBDeleteOperation::getValue()
extern void NCMBDeleteOperation_getValue_mF257567AF68F4C1DEC7D74F548F3529253AFC388 (void);
// 0x000003FC System.Object NCMB.Internal.NCMBDeleteOperation::Encode()
extern void NCMBDeleteOperation_Encode_mC9ACD6F5C54D898D876D13D308C9CE20EA1E43D4 (void);
// 0x000003FD NCMB.Internal.INCMBFieldOperation NCMB.Internal.NCMBDeleteOperation::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
extern void NCMBDeleteOperation_MergeWithPrevious_mB60C420F41A98D5AB2F44243B847218C560A6990 (void);
// 0x000003FE System.Object NCMB.Internal.NCMBDeleteOperation::Apply(System.Object,NCMB.NCMBObject,System.String)
extern void NCMBDeleteOperation_Apply_m98E6FDE4E74A3D5450A8B964B2F281E5D70996F4 (void);
// 0x000003FF System.Object NCMB.Internal.INCMBFieldOperation::Encode()
// 0x00000400 NCMB.Internal.INCMBFieldOperation NCMB.Internal.INCMBFieldOperation::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
// 0x00000401 System.Object NCMB.Internal.INCMBFieldOperation::Apply(System.Object,NCMB.NCMBObject,System.String)
// 0x00000402 System.Void NCMB.Internal.NCMBIncrementOperation::.ctor(System.Object)
extern void NCMBIncrementOperation__ctor_m45CA5C337BEC59082407327FD9325EBFB707455E (void);
// 0x00000403 System.Object NCMB.Internal.NCMBIncrementOperation::Encode()
extern void NCMBIncrementOperation_Encode_m60E3FE51E95DF78386AC13794DB8F96BC7DDDA59 (void);
// 0x00000404 NCMB.Internal.INCMBFieldOperation NCMB.Internal.NCMBIncrementOperation::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
extern void NCMBIncrementOperation_MergeWithPrevious_mCCEF9250AF730EA7234D6114CB2BBF627C706F73 (void);
// 0x00000405 System.Object NCMB.Internal.NCMBIncrementOperation::Apply(System.Object,NCMB.NCMBObject,System.String)
extern void NCMBIncrementOperation_Apply_m911A7A70E40E9CEDED6C5037A72BCF084FC2A71C (void);
// 0x00000406 System.String NCMB.Internal.NCMBRelationOperation`1::get_TargetClass()
// 0x00000407 System.Void NCMB.Internal.NCMBRelationOperation`1::.ctor(System.Collections.Generic.HashSet`1<T>,System.Collections.Generic.HashSet`1<T>)
// 0x00000408 System.Void NCMB.Internal.NCMBRelationOperation`1::.ctor(System.String,System.Collections.Generic.HashSet`1<System.String>,System.Collections.Generic.HashSet`1<System.String>)
// 0x00000409 System.Object NCMB.Internal.NCMBRelationOperation`1::Encode()
// 0x0000040A System.Collections.ArrayList NCMB.Internal.NCMBRelationOperation`1::_convertSetToArray(System.Collections.Generic.HashSet`1<System.String>)
// 0x0000040B NCMB.Internal.INCMBFieldOperation NCMB.Internal.NCMBRelationOperation`1::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
// 0x0000040C System.Object NCMB.Internal.NCMBRelationOperation`1::Apply(System.Object,NCMB.NCMBObject,System.String)
// 0x0000040D System.Void NCMB.Internal.NCMBRemoveOperation::.ctor(System.Object)
extern void NCMBRemoveOperation__ctor_m6B74AA997A820AEE2A6B44FC14EDA67B7D2ED400 (void);
// 0x0000040E System.Object NCMB.Internal.NCMBRemoveOperation::Encode()
extern void NCMBRemoveOperation_Encode_mFE869AD8D711AB767065AA78DF5DE9DA3F5B837C (void);
// 0x0000040F NCMB.Internal.INCMBFieldOperation NCMB.Internal.NCMBRemoveOperation::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
extern void NCMBRemoveOperation_MergeWithPrevious_m35A557BBDE5E3000E9FFDC67B7585CD2F95F3629 (void);
// 0x00000410 System.Object NCMB.Internal.NCMBRemoveOperation::Apply(System.Object,NCMB.NCMBObject,System.String)
extern void NCMBRemoveOperation_Apply_mFE6D7607D88054CE7D4F25567A0D7E8264A82543 (void);
// 0x00000411 System.Void NCMB.Internal.NCMBSetOperation::.ctor(System.Object)
extern void NCMBSetOperation__ctor_m4A3296DF276965EE3E2AD0412319D8DA717EA361 (void);
// 0x00000412 System.Object NCMB.Internal.NCMBSetOperation::getValue()
extern void NCMBSetOperation_getValue_m10A778E1BB4D3E0238F3B45589DCD6076578ACC8 (void);
// 0x00000413 System.Object NCMB.Internal.NCMBSetOperation::Encode()
extern void NCMBSetOperation_Encode_m98366CA2D36375E666BDC2D52A4AA5F80048B352 (void);
// 0x00000414 NCMB.Internal.INCMBFieldOperation NCMB.Internal.NCMBSetOperation::MergeWithPrevious(NCMB.Internal.INCMBFieldOperation)
extern void NCMBSetOperation_MergeWithPrevious_m9EA55F66374EB75D5CAD7EF52603F40712DD7951 (void);
// 0x00000415 System.Object NCMB.Internal.NCMBSetOperation::Apply(System.Object,NCMB.NCMBObject,System.String)
extern void NCMBSetOperation_Apply_m8BBC63354C98819A4F85C298B582B423B646BB06 (void);
// 0x00000416 System.String NCMB.Internal.NCMBUtility::GetClassName(System.Object)
extern void NCMBUtility_GetClassName_m7B1A3A6D76F28972063547B761A1F2E36C15ED33 (void);
// 0x00000417 System.Void NCMB.Internal.NCMBUtility::CopyDictionary(System.Collections.Generic.IDictionary`2<System.String,System.Object>,System.Collections.Generic.IDictionary`2<System.String,System.Object>)
extern void NCMBUtility_CopyDictionary_m75D33199A3C4BB47919C2326212AF247A73A85AC (void);
// 0x00000418 System.Collections.Generic.IDictionary`2<System.String,System.Object> NCMB.Internal.NCMBUtility::_encodeJSONObject(System.Object,System.Boolean)
extern void NCMBUtility__encodeJSONObject_m8A58CE7D02BA55D6747C5AE4DC682E49F10E61D2 (void);
// 0x00000419 System.Collections.Generic.List`1<System.Object> NCMB.Internal.NCMBUtility::_encodeAsJSONArray(System.Collections.IList,System.Boolean)
extern void NCMBUtility__encodeAsJSONArray_m475ADCE049819B9B07373831FC396A47D555845D (void);
// 0x0000041A System.Object NCMB.Internal.NCMBUtility::_maybeEncodeJSONObject(System.Object,System.Boolean)
extern void NCMBUtility__maybeEncodeJSONObject_mAD8EE0EDE13CEFC885BEB0FAA962C8D65D1C4FFB (void);
// 0x0000041B System.Object NCMB.Internal.NCMBUtility::decodeJSONObject(System.Object)
extern void NCMBUtility_decodeJSONObject_m29F76E0017B924CA78C5DD34E2F6160752C1FEE7 (void);
// 0x0000041C System.DateTime NCMB.Internal.NCMBUtility::parseDate(System.String)
extern void NCMBUtility_parseDate_mF04E84D494016DC147C6E7BC3AF0EB92BFA6E765 (void);
// 0x0000041D System.String NCMB.Internal.NCMBUtility::encodeDate(System.DateTime)
extern void NCMBUtility_encodeDate_m8BDD92B672BC92BE92D0FCD202778B23B25633E7 (void);
// 0x0000041E System.Boolean NCMB.Internal.NCMBUtility::isContainerObject(System.Object)
extern void NCMBUtility_isContainerObject_mB6EDB0FB968B569703F5AE6C961FBDC18E92DB82 (void);
// 0x0000041F System.String NCMB.Internal.NCMBUtility::_encodeString(System.String)
extern void NCMBUtility__encodeString_m81719E94266783C5EA39D45F1DEAA7050FD09A83 (void);
// 0x00000420 System.String NCMB.Internal.NCMBUtility::unicodeUnescape(System.String)
extern void NCMBUtility_unicodeUnescape_m23A5B4EFCDAFE7E2C2A2E6EFC5140B6904AA550E (void);
// 0x00000421 System.Void NCMB.Internal.NCMBUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_mB6D72F2685B909C42D626BA499F0E2A6D6DC435B (void);
// 0x00000422 System.Void NCMB.Internal.NCMBUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_m8FC99A1B9A2738CA143DF98212AF125AD3DA920C (void);
// 0x00000423 System.String NCMB.Internal.NCMBUtility/<>c::<unicodeUnescape>b__10_0(System.Text.RegularExpressions.Match)
extern void U3CU3Ec_U3CunicodeUnescapeU3Eb__10_0_mC42ED9FFF002B23E73E1B67CBFB8BB59666E9020 (void);
static Il2CppMethodPointer s_methodPointers[1059] = 
{
	MainManager_Start_mC9214444CF64A4908FDF87B213F21EB4372ABAB7,
	MainManager_Update_m2D4BE865BE5198840B173ADDC4C5E8F647D88D46,
	MainManager_SetNum_mF26464EB17C946A754528AAAE3613C4DB26921D6,
	MainManager_checkNum_m99E7653A8B2403EE563C00915D1DBAEBE39E1700,
	MainManager_CalculateScore_m384FB7A667A4A2565B3383656C28AF2070725F60,
	MainManager_autoSolve_m5B421CC3E3F73B534A92DCE6B47492A79A6C0C72,
	MainManager__ctor_m90DF2FBE6170D98DF8F9C03C44FB914322C4D10F,
	TitleManager_Start_mB1BDED26067331336418D8C8F760161E62F96224,
	TitleManager_Update_m3D4B2483A33278FCFEB981AA66D621FDF1A652C7,
	TitleManager_UpdateLabel_mFD9114D24A7161EE209C863C244AF1E8F986A43B,
	TitleManager__ctor_m0D14731249E3B6D0846A587A421CAE4FAD2056D0,
	TryAgain_Again_m95188785D108D451D30B118901CF1D551FE15F3A,
	TryAgain__ctor_mBEB1E7B1EB1FD2DB6F78B9AEDEE41793AB727705,
	DisableButton_Start_m336CE507ADFCE98CD8FBF99DA9458AC20366D76E,
	DisableButton_Update_m8AA3B5A90B7B858BAD79A98CC648262E444CC05E,
	DisableButton_MenuOpen_m37C3632D41F7BCDA29B21CFB90905ACD1CC4E05C,
	DisableButton__ctor_mD5A1D36B339B24747C5F70256A225F98DF3FD39F,
	Loginsignin_Start_m15A7B5534BA6AF650C32B142E9AED9CA96157847,
	Loginsignin_Update_m1C97DA265B0C8A09C3626766F66E878AFAFB22D5,
	Loginsignin_Login_mF96569BB5E08061D5B75AB68A444490AB9B188EE,
	Loginsignin_Signin_mD16320818EEAD0845EEC7799C77EC409E0461BAB,
	Loginsignin__ctor_mBEAFCFB1A68494EC72935532A78DAE449DBEAB4C,
	U3CU3Ec__DisplayClass5_0__ctor_m0D1F1ACC28DC39ADE9850A7692048F9FC73E686E,
	U3CU3Ec__DisplayClass5_0_U3CLoginU3Eb__0_m6004CADA656A377785BD413A1A64DCBBA7E9DA6F,
	U3CU3Ec__DisplayClass6_0__ctor_mD4055380BDF730E641F72E598236D3AF4462EC71,
	U3CU3Ec__DisplayClass6_0_U3CSigninU3Eb__0_m0E4B873D0ACFF439817243FBC0B4E8726E0CA684,
	Logout_Start_m40723A78773A2CD00AC9416B843128C80E514ACF,
	Logout_Update_m4C65B388F48F6B9434A851C6CC89724631EFC3AE,
	Logout_Logout_user_m1846E6FCFE6C5F851D40282FBDF9092695474BD2,
	Logout__ctor_mD6E90F1BF5A203FB4024B69B5BF4AA84CC60A4D2,
	U3CU3Ec__cctor_m639BEF51754B783A970891523BDF86E73328E44F,
	U3CU3Ec__ctor_m137AFD4583C559AF95DE542F3ACE257E6BE0284A,
	U3CU3Ec_U3CLogout_userU3Eb__3_0_mECA5FDD2F453B767357292E569B06A7522F767E2,
	getCurrentUser_Start_m56FC0A8D73C4DF2084833804337C722F5A168F1A,
	getCurrentUser_Update_mDD65209B54EBAE61F3591833BDAB6EB22B0ECB10,
	getCurrentUser__ctor_m753FDEF4FEFDFF86F75AE0774B0938A80F5A424F,
	QuickStart_Start_mB2E95DCFD844937D1486D4C72D3252CD0BB398F9,
	QuickStart_Update_m503754BC0DE892208BBFDA1139EF3D8D1042C567,
	QuickStart__ctor_m411963D303CC53DD2DFDA1CBE928D9B9C136621C,
	ChatController_OnEnable_mBC3BFC05A1D47069DFA58A4F0E39CFF8FAD44FF2,
	ChatController_OnDisable_m268A7488A3FDEB850FC3BC91A0BBDA767D42876B,
	ChatController_AddToChatOutput_m43856EEA133E04C24701A2616E7F10D7FFA68371,
	ChatController__ctor_m3B66A5F749B457D865E8BDA1DE481C8CF1158026,
	EnvMapAnimator_Awake_mFFC04BC5320F83CA8C45FF36A11BF43AC17C6B93,
	EnvMapAnimator_Start_mC0D348CAB0F0DC920EF3D3A008688B533F66D1BE,
	EnvMapAnimator__ctor_mC151D673A394E2E7CEA8774C4004985028C5C3EC,
	U3CStartU3Ed__4__ctor_m4D65F4FC2207AE4B6BE963AF9B5EDC55C7E29B23,
	U3CStartU3Ed__4_System_IDisposable_Dispose_mFEE2ACED70A3D825988E28CC61FEF8DCD7660A5B,
	U3CStartU3Ed__4_MoveNext_m2F1A8053A32AD86DA80F86391EC32EDC1C396AEE,
	U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF03E2A57659B8F598AC450183F55D43F903C0A1E,
	U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m268BA538CF6812C56EB281C0CE29D5AA2E9A2CAB,
	U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_mFE9CA9F52F9AFA1E4C9DBADA2064F854D6931CFF,
	Tweet_Start_m22BB6363FC587DC0EBCC55C042CDB2CD5D45D563,
	Tweet_tweet_m41F85FF9A1359C08CB4432BB04A82F836A30998E,
	Tweet__ctor_m47C5C4300EF8BFB335036C5ABA8B80F225112125,
	SampleSceneManager_OnPlusButtonPressed_m5C2B52B5CCE4361C0604C86DC78D9A3E1F8D600A,
	SampleSceneManager_OnMinusButtonPressed_m12232A6C9DDDF5E386D3EB099736EEB7C60C9B5F,
	SampleSceneManager_OnResultButton0Pressed_m6CAE5ED91776A576AC547D5C7BF8568DFAF34A4C,
	SampleSceneManager_OnResultButton1Pressed_m81FD6192C6DC3D04ADB85BA7C1ABCAC462AB1BAF,
	SampleSceneManager_LocalSaveReset_m72358563BB7FCF4DD6D410BDA3006FD20A2E324D,
	SampleSceneManager__ctor_m7B7BD9A63528D1AC0803F7927625560D9185CDB8,
	NULL,
	NULL,
	NULL,
	NULL,
	NumberScore__ctor_m59A64D336CB91E05B64FF5F5F6F69D8662023162,
	NumberScore_get_Type_m4313CDFA3902F839836B6FB926C0D4978EA37729,
	NumberScore_get_TextForDisplay_m88223ECE09AAC2702F12D2B3444617894FD0EE63,
	NumberScore_get_TextForSave_m783E0501D92562B8C9A3E35F9DF2F71F3E56DBED,
	NumberScore_get_Value_m0D9B7E8ED04905AE14A918E66279343D7DC29DFA,
	RankingBoards_GetRankingInfo_m5D6AEF94541E7AF29F0174AF41F2DD6C0278879C,
	RankingBoards_CheckDuplicateClassName_m43D4B26FE9947087022615EF5ACBFBE1ECB13F7F,
	RankingBoards__ctor_mBA88566559E411C25CD3A24166248B966DC54490,
	U3CU3Ec__cctor_mDF556E740AD6959275A6850C7637A7D78A8DE923,
	U3CU3Ec__ctor_m537283CEF868925B7F06D98D5BC751F48E8806D4,
	U3CU3Ec_U3CCheckDuplicateClassNameU3Eb__2_0_m7426CF5D2C3FB1742801E8B59DECAA5278CD0461,
	U3CU3Ec_U3CCheckDuplicateClassNameU3Eb__2_1_mB1FAD066675DC21AF56FB9EEA8130733E79B6A26,
	U3CU3Ec_U3CCheckDuplicateClassNameU3Eb__2_2_m42B549DA34F0D530ED33A66ED1E21AF05552EAE1,
	RankingInfo_BuildScore_mF2B03A45BA6A2055E8BCC8A11A62A3385876F029,
	RankingInfo__ctor_mC9A5407DA93A2A01AB2BA9E076F852DA8A25300A,
	RankingLoader_get_Instance_m68A3888C135719A9FEFA7D3610E1BA5F16B8680F,
	RankingLoader_Start_m4F0A00230A2A701DBD97094D98914170595C56EA,
	RankingLoader_SendScoreAndShowRanking_m368CFD531F7B05E92500D2DB6161BB3AA8BFC0A5,
	RankingLoader_SendScoreAndShowRanking_m819A29A1329A0B76132BDEF21D45A315BC4A4037,
	RankingLoader_SendScoreAndShowRanking_m0633E2C083AF21AC98D874B279622D5FD24EE8C9,
	RankingLoader__ctor_m8F52FAC0F9D6C322508B44CAF32A6B5601D8E59C,
	RankingNode__ctor_m2B5EA915A63A34F2F83684E096DF9CAAE1E9A260,
	RankingSceneManager_get_ObjectID_m138750ED83DC56D397FF5431F0203BF492E10C4D,
	RankingSceneManager_set_ObjectID_m97F1408F5DFEB82515607EF4A90C129A59BE2DB0,
	RankingSceneManager_get_BoardIdPlayerPrefsKey_m2B41B717408B0056B688DFB3ACD7AA57392CE834,
	RankingSceneManager_get_InputtedNameForSave_m975B7B1AF2F3DF0CD4B4784AC434F147DA3C215B,
	RankingSceneManager_Start_m7617348FD5D3E50D780B49DA641CD709BF0B8B87,
	RankingSceneManager_GetHighScoreAndRankingBoard_m20951FFD15E63A015B58D71DFEB6A4AE138061F5,
	RankingSceneManager_SendScore_m7F3DC094584144D839420900814424D302AB31B0,
	RankingSceneManager_SendScoreEnumerator_m072BD9510D878AC558B2985346C547AEF4437A51,
	RankingSceneManager_LoadRankingBoard_mC227D82872A5749E3C0D02167C151B2BF9492EC1,
	RankingSceneManager_OnCloseButtonClick_mB9255A8A0D6C93132DF0D8EEE791096989A48DCF,
	RankingSceneManager_MaskOffOn_mC0D21B1754A5D9A0F0DF847BD9C9F006023E0FD9,
	RankingSceneManager__ctor_mF485576DB139936A313A9F0B98C55E79BF43E16A,
	U3CGetHighScoreAndRankingBoardU3Ed__26__ctor_mE2C21B2F529BADF10971B67C85A4A5DDEB5E9297,
	U3CGetHighScoreAndRankingBoardU3Ed__26_System_IDisposable_Dispose_m60C5057D7D56D2296796393E2E2618F2DA6E4627,
	U3CGetHighScoreAndRankingBoardU3Ed__26_MoveNext_m612BBB0DE55107FEDD983D52FA38C79566BEDA4C,
	U3CGetHighScoreAndRankingBoardU3Ed__26_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m2E3EAE625533A270CC7D9EB50D21FA8DFBC6C00A,
	U3CGetHighScoreAndRankingBoardU3Ed__26_System_Collections_IEnumerator_Reset_mC52201F256A6F4E4B180C8C548037EF2EE64C76E,
	U3CGetHighScoreAndRankingBoardU3Ed__26_System_Collections_IEnumerator_get_Current_m77D1E321313050E52BC4A386433F4F5FB0158A22,
	U3CU3Ec__DisplayClass28_0__ctor_m32230269C1A8A9AF884DF161EB095309D580E059,
	U3CU3Ec__DisplayClass28_0_U3CSendScoreEnumeratorU3Eb__0_m75542A1C206654B8653774644232F06E1DC9FA2B,
	U3CU3Ec__DisplayClass28_0_U3CSendScoreEnumeratorU3Eb__1_m69D290830B80CF577FA27FCFA75031A9ED3F3923,
	U3CSendScoreEnumeratorU3Ed__28__ctor_m66877E59819AF86D83186A12628C64DF2CB8EDDC,
	U3CSendScoreEnumeratorU3Ed__28_System_IDisposable_Dispose_m0FFF1A3596AB087895286D95B79A176500A7B88C,
	U3CSendScoreEnumeratorU3Ed__28_MoveNext_mE7E08736A0067AC40DB3380BCBAF8672694C715F,
	U3CSendScoreEnumeratorU3Ed__28_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA326900D08A039C31F25125DD079F77988E1F7DE,
	U3CSendScoreEnumeratorU3Ed__28_System_Collections_IEnumerator_Reset_m8AC0EAE33F3E63C94B9CF9AEDA80FA6ED0F01372,
	U3CSendScoreEnumeratorU3Ed__28_System_Collections_IEnumerator_get_Current_m3CDC5AE627CDE742493B953583EE9EAEDBF943AD,
	U3CLoadRankingBoardU3Ed__29__ctor_m684F8234E11BEA91136D3CD154B4AC7C1806CD09,
	U3CLoadRankingBoardU3Ed__29_System_IDisposable_Dispose_mEB45C5DC33E509A5C611D7BA0AC7CF0EEDF59F63,
	U3CLoadRankingBoardU3Ed__29_MoveNext_m628D526B47AE9EE62D9249E5709201ED31110A94,
	U3CLoadRankingBoardU3Ed__29_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m378D2FE633CEFE56A71AEC5906FCECA963986EF7,
	U3CLoadRankingBoardU3Ed__29_System_Collections_IEnumerator_Reset_m898F58CAEFF4BD4784E2A930B5CAEC65825CACF9,
	U3CLoadRankingBoardU3Ed__29_System_Collections_IEnumerator_get_Current_m294D91AA26D772E6C7032529E8B5390EDA6C64FF,
	TimeScore__ctor_m4BAB86C3334925FC830001164D179E61B331D366,
	TimeScore_get_Type_mC0356DA85727C100BD5430CD4267D64041B15BD3,
	TimeScore_get_TextForDisplay_m46A36B72F2E2AFD11381C219FFF5F25DE3AB274C,
	TimeScore_get_TextForSave_m351532DD5B309FEC9114BDE55C0BABE07A99A82D,
	TimeScore_get_Value_mB95D9C69C9E3AFE0161B628FE3D44B3852C4B92E,
	TMP_DigitValidator_Validate_m5D303EB8CD6E9E7D526D633BA1021884051FE226,
	TMP_DigitValidator__ctor_m1E838567EF38170662F1BAF52A847CC2C258333E,
	TMP_PhoneNumberValidator_Validate_mF0E90A277E9E91BC213DD02DC60088D03C9436B1,
	TMP_PhoneNumberValidator__ctor_mB3C36CAAE3B52554C44A1D19194F0176B5A8EED3,
	TMP_TextEventHandler_get_onCharacterSelection_m90C39320C726E8E542D91F4BBD690697349F5385,
	TMP_TextEventHandler_set_onCharacterSelection_m5ED7658EB101C6740A921FA150DE18C443BDA0C4,
	TMP_TextEventHandler_get_onSpriteSelection_m0E645AE1DFE19B011A3319474D0CF0DA612C8B7B,
	TMP_TextEventHandler_set_onSpriteSelection_m4AFC6772C3357218956A5D33B3CD19F3AAF39788,
	TMP_TextEventHandler_get_onWordSelection_mA42B89A37810FB659FCFA8539339A3BB8037203A,
	TMP_TextEventHandler_set_onWordSelection_m4A839FAFFABAFECD073B82BA8826E1CD033C0076,
	TMP_TextEventHandler_get_onLineSelection_mB701B6C713AD4EFC61E1B30A564EE54ADE31F58D,
	TMP_TextEventHandler_set_onLineSelection_m0B2337598350E51D0A17B8FCB3AAA533F312F3DA,
	TMP_TextEventHandler_get_onLinkSelection_mF5C3875D661F5B1E3712566FE16D332EA37D15BB,
	TMP_TextEventHandler_set_onLinkSelection_m200566EDEB2C9299647F3EEAC588B51818D360A5,
	TMP_TextEventHandler_Awake_m43EB03A4A6776A624F79457EC49E78E7B5BA1C70,
	TMP_TextEventHandler_LateUpdate_mE1D989C40DA8E54E116E3C60217DFCAADD6FDE11,
	TMP_TextEventHandler_OnPointerEnter_m8FC88F25858B24CE68BE80C727A3F0227A8EE5AC,
	TMP_TextEventHandler_OnPointerExit_mBB2A74D55741F631A678A5D6997D40247FE75D44,
	TMP_TextEventHandler_SendOnCharacterSelection_m78983D3590F1B0C242BEAB0A11FDBDABDD1814EC,
	TMP_TextEventHandler_SendOnSpriteSelection_m10C257A74F121B95E7077F7E488FBC52380A6C53,
	TMP_TextEventHandler_SendOnWordSelection_m95A4E5A00E339E5B8BA9AA63B98DB3E81C8B8F66,
	TMP_TextEventHandler_SendOnLineSelection_mE85BA6ECE1188B666FD36839B8970C3E0130BC43,
	TMP_TextEventHandler_SendOnLinkSelection_m299E6620DFD835C8258A3F48B4EA076C304E9B77,
	TMP_TextEventHandler__ctor_m6345DC1CEA2E4209E928AD1E61C3ACA4227DD9B8,
	CharacterSelectionEvent__ctor_m06BC183AF31BA4A2055A44514BC3FF0539DD04C7,
	SpriteSelectionEvent__ctor_m0F760052E9A5AF44A7AF7AC006CB4B24809590F2,
	WordSelectionEvent__ctor_m106CDEB17C520C9D20CE7120DE6BBBDEDB48886C,
	LineSelectionEvent__ctor_m5D735FDA9B71B9147C6F791B331498F145D75018,
	LinkSelectionEvent__ctor_m7AB7977D0D0F8883C5A98DD6BB2D390BC3CAB8E0,
	Benchmark01_Start_mE7E5146B0D8D926CC410CAA48F3B617A0A7D955C,
	Benchmark01__ctor_mB92568AA7A9E13B92315B6270FCA23584A7D0F7F,
	U3CStartU3Ed__10__ctor_mBE5D8B4B98C372BD6DC3936437999DF3048DE3AB,
	U3CStartU3Ed__10_System_IDisposable_Dispose_m1F4180A7FDAE9AC5F11F30B67F813B3D7CD56D73,
	U3CStartU3Ed__10_MoveNext_mF3B1D38CD37FD5187C3192141DB380747C66AD3C,
	U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m22B2975D42326E3DE437174BBE4F0E8790CB6591,
	U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_m514DA545ECA10AA62BFC239BB582FF0017B91D2B,
	U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_m6904A738F04118BA24E473F1809B3D69E711627E,
	Benchmark01_UGUI_Start_m2F8F9E1798943DA8086A7C7E73BA9D7C67482BD4,
	Benchmark01_UGUI__ctor_mACFE8D997EAB50FDBD7F671C1A25A892D9F78376,
	U3CStartU3Ed__10__ctor_m653B757B49A674E239C804FFF4EDEF325B5DB651,
	U3CStartU3Ed__10_System_IDisposable_Dispose_mAD0BC985E1E01C8369A7A955A60D3E545B0B3561,
	U3CStartU3Ed__10_MoveNext_mF9B2C8D290035BC9A79C4347772B5B7B9D404DE1,
	U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF438D42D7C5A811FF9A283F8780F015FF55826CD,
	U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_m65545EB5B6DDDDAB5ACF92600137C1C754B322BA,
	U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_mD4523BE1D1014AAF1C0709EB767C0B0F47D739D2,
	Benchmark02_Start_m315C0DF3A9AC66B4F5802FDAED056E7E5F3D2046,
	Benchmark02__ctor_m526B38D3B7E75905208E4E57B168D8AC1900F4E5,
	Benchmark03_Awake_mD23429C1EE428EEF4ED9A753385BF194BAA41A77,
	Benchmark03_Start_m19E638DED29CB7F96362F3C346DC47217C4AF516,
	Benchmark03__ctor_m89F9102259BE1694EC418E9023DC563F3999B0BE,
	Benchmark04_Start_mEABD467C12547066E33359FDC433E8B5BAD43DB9,
	Benchmark04__ctor_m5015375E0C8D19060CB5DE14CBF4AC02DDD70E7C,
	CameraController_Awake_m420393892377B9703EC97764B34E32890FC5283E,
	CameraController_Start_m32D90EE7232BE6DE08D224F824F8EB9571655610,
	CameraController_LateUpdate_m6D81DEBA4E8B443CF2AD8288F0E76E3A6B3B5373,
	CameraController_GetPlayerInput_m6695FE20CFC691585A6AC279EDB338EC9DD13FE3,
	CameraController__ctor_m09187FB27B590118043D4DC7B89B93164124C124,
	ObjectSpin_Awake_mC1EB9630B6D3BAE645D3DD79C264F71F7B18A1AA,
	ObjectSpin_Update_mD39DCBA0789DC0116037C442F0BA1EE6752E36D3,
	ObjectSpin__ctor_m1827B9648659746252026432DFED907AEC6007FC,
	ShaderPropAnimator_Awake_mE04C66A41CA53AB73733E7D2CCD21B30A360C5A8,
	ShaderPropAnimator_Start_mC5AC59C59AF2F71E0CF65F11ACD787488140EDD2,
	ShaderPropAnimator_AnimateProperties_mAF49CD157AD41377CE00AA10F0C06C8BF5AA0469,
	ShaderPropAnimator__ctor_mAA626BC8AEEB00C5AE362FE8690D3F2200CE6E64,
	U3CAnimatePropertiesU3Ed__6__ctor_mFAC0F8A7368D9D35AD2780C118E13414DA79B56A,
	U3CAnimatePropertiesU3Ed__6_System_IDisposable_Dispose_m628EECBFCBC49087298185F17BC2AE7A73FC8A7B,
	U3CAnimatePropertiesU3Ed__6_MoveNext_m8A58CCFDAE59F55AB1BB2C103800886E62C807CF,
	U3CAnimatePropertiesU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0742A0FA62C518EBD119ED5FEBF849F918E12390,
	U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_Reset_mC076F281DD17668D6CE42EB04EA974DE1FFB3F6B,
	U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_get_Current_mA585E786DA86D2589EBCA029AD9E64E8B5135362,
	SimpleScript_Start_m75CD9CEDCAFA9A991753478D7C28407C7329FB8F,
	SimpleScript_Update_mE8C3930DCC1767C2DF59B622FABD188E6FB91BE5,
	SimpleScript__ctor_mEB370A69544227EF04C48C604A28502ADAA73697,
	SkewTextExample_Awake_m6FBA7E7DC9AFDD3099F0D0B9CDE91574551105DB,
	SkewTextExample_Start_m536F82F3A5D229332694688C59F396E07F88153F,
	SkewTextExample_CopyAnimationCurve_m555177255F5828DBC7E677ED06F7EFFC052886B3,
	SkewTextExample_WarpText_m0E0C46988600673F0E5DFA3133534DC6CA5950D3,
	SkewTextExample__ctor_m945059906734DD38CF860CD32B3E07635D0E1F86,
	U3CWarpTextU3Ed__7__ctor_mEAD3C39209B75514446A44B6C2FA76F8097EBD6F,
	U3CWarpTextU3Ed__7_System_IDisposable_Dispose_m32AA7120BE15547799BDC515FA3486488952BDCF,
	U3CWarpTextU3Ed__7_MoveNext_mB832E4A3DFDDFECC460A510BBC664F218B3D7FCF,
	U3CWarpTextU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m3CF506B740C16FEDE58B6E1BE4556CAC2C6AEAD1,
	U3CWarpTextU3Ed__7_System_Collections_IEnumerator_Reset_mDDCDBB794F21DF70178A75747D8D8398F38A9C2F,
	U3CWarpTextU3Ed__7_System_Collections_IEnumerator_get_Current_m6D89CF1910F76577E23C924B535E93FD1B01CF0A,
	TMP_ExampleScript_01_Awake_m381EF5B50E1D012B8CA1883DEFF604EEAE6D95F4,
	TMP_ExampleScript_01_Update_m31611F22A608784F164A24444195B33B714567FB,
	TMP_ExampleScript_01__ctor_m3641F2E0D25B6666CE77773A4A493C4C4D3D3A12,
	TMP_FrameRateCounter_Awake_m958B668086DB4A38D9C56E3F8C2DCCB6FF11FAA3,
	TMP_FrameRateCounter_Start_mC642CA714D0FB8482D2AC6192D976DA179EE3720,
	TMP_FrameRateCounter_Update_m5E41B55573D86C3D345BFE11C489B00229BCEE21,
	TMP_FrameRateCounter_Set_FrameCounter_Position_mA72ECDE464E3290E4F533491FC8113B8D4068BE1,
	TMP_FrameRateCounter__ctor_mC79D5BF3FAE2BB7D22D9955A75E3483725BA619C,
	TMP_TextEventCheck_OnEnable_mE6D5125EEE0720E6F414978A496066E7CF1592DF,
	TMP_TextEventCheck_OnDisable_m94F087C259890C48D4F5464ABA4CD1D0E5863A9A,
	TMP_TextEventCheck_OnCharacterSelection_mDA044F0808D61A99CDA374075943CEB1C92C253D,
	TMP_TextEventCheck_OnSpriteSelection_mE8FFA550F38F5447CA37205698A30A41ADE901E0,
	TMP_TextEventCheck_OnWordSelection_m6037166D18A938678A2B06F28A5DCB3E09FAC61B,
	TMP_TextEventCheck_OnLineSelection_mD2BAA6C8ABD61F0442A40C5448FA7774D782C363,
	TMP_TextEventCheck_OnLinkSelection_m184B11D5E35AC4EA7CDCE3340AB9FEE3C14BF41C,
	TMP_TextEventCheck__ctor_mA5E82EE7CE8F8836FC6CF3823CBC7356005B898B,
	TMP_TextInfoDebugTool__ctor_mF6AA30660FBD4CE708B6147833853498993CB9EE,
	TMP_TextSelector_A_Awake_mD7252A5075E30E3BF9BEF4353F7AA2A9203FC943,
	TMP_TextSelector_A_LateUpdate_mDBBC09726332EDDEAF7C30AB6C08FB33261F79FD,
	TMP_TextSelector_A_OnPointerEnter_mC19B85FB5B4E6EB47832C39F0115A513B85060D0,
	TMP_TextSelector_A_OnPointerExit_mE51C850F54B18A5C96E3BE015DFBB0F079E5AE66,
	TMP_TextSelector_A__ctor_mEB83D3952B32CEE9A871EC60E3AE9B79048302BF,
	TMP_TextSelector_B_Awake_m7E413A43C54DF9E0FE70C4E69FC682391B47205A,
	TMP_TextSelector_B_OnEnable_m0828D13E2D407B90038442228D54FB0D7B3D29FB,
	TMP_TextSelector_B_OnDisable_m2B559A85B52C8CAFC7350CC7B4F8E5BC773EF781,
	TMP_TextSelector_B_ON_TEXT_CHANGED_m1597DBE7C7EBE7CFA4DC395897A4779387B59910,
	TMP_TextSelector_B_LateUpdate_m8BA10E368C7F3483E9EC05589BBE45D7EFC75691,
	TMP_TextSelector_B_OnPointerEnter_m0A0064632E4C0E0ADCD4358AD5BC168BFB74AC4D,
	TMP_TextSelector_B_OnPointerExit_m667659102B5B17FBAF56593B7034E5EC1C48D43F,
	TMP_TextSelector_B_OnPointerClick_m8DB2D22EE2F4D3965115791C81F985D82021469F,
	TMP_TextSelector_B_OnPointerUp_m303500BE309B56F3ADCE8B461CEC50C8D5ED70BC,
	TMP_TextSelector_B_RestoreCachedVertexAttributes_m3D637CF2C6CA663922EBE56FFD672BE582E9F1F2,
	TMP_TextSelector_B__ctor_mE654F9F1570570C4BACDA79640B8DB3033D91C33,
	TMP_UiFrameRateCounter_Awake_m83DBE22B6CC551BE5E385048B92067679716179E,
	TMP_UiFrameRateCounter_Start_m59DA342A492C9EF8AD5C4512753211BF3796C944,
	TMP_UiFrameRateCounter_Update_m28FC233C475AA15A3BE399BF9345977089997749,
	TMP_UiFrameRateCounter_Set_FrameCounter_Position_m2025933902F312C0EC4B6A864196A8BA8D545647,
	TMP_UiFrameRateCounter__ctor_m5774BF4B9389770FC34991095557B24417600F84,
	TMPro_InstructionOverlay_Awake_m2444EA8749D72BCEA4DC30A328E3745AB19062EC,
	TMPro_InstructionOverlay_Set_FrameCounter_Position_m62B897E4DB2D6B1936833EC54D9C246D68D50EEB,
	TMPro_InstructionOverlay__ctor_m7AB5B851B4BFB07547E460D6B7B9D969DEB4A7CF,
	TeleType_Awake_m099FCB202F2A8299B133DC56ECB9D01A16C08DFE,
	TeleType_Start_m72DE9DE597F4FA0B1CA02115CBC1E74EB53F63F7,
	TeleType__ctor_m12A79B34F66CBFDCA8F582F0689D1731586B90AF,
	U3CStartU3Ed__4__ctor_mF3575DBEBF4F153F6A899AF3362940298C11B629,
	U3CStartU3Ed__4_System_IDisposable_Dispose_m6DABFDBC2A313BF6DD90AA1C43B4EF9D6249CBE9,
	U3CStartU3Ed__4_MoveNext_mEF7A3215376BDFB52C3DA9D26FF0459074E89715,
	U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m66DC06D52865D30DAA78DBD70B6554D13E2EA70B,
	U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_mE854A2CECA0E01F3C2D90DA4F720CF0F387994F8,
	U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m77D3936B94684C817EE9F6D2C903238A457D5261,
	TextConsoleSimulator_Awake_mA51EE182A528CCA5CAEA8DBE8AD30E43FDFAE7B0,
	TextConsoleSimulator_Start_m429701BE4C9A52AA6B257172A4D85D58E091E7DA,
	TextConsoleSimulator_OnEnable_m3397FBCDA8D9DA264D2149288BE4DCF63368AB50,
	TextConsoleSimulator_OnDisable_m43DF869E864789E215873192ECFCDC51ABA79712,
	TextConsoleSimulator_ON_TEXT_CHANGED_m51F06EE5DD9B32FEFB529743F209C6E6C41BE3B8,
	TextConsoleSimulator_RevealCharacters_mE8E415644F7BD2056D0809F7BB0FA9A2F9FE8534,
	TextConsoleSimulator_RevealWords_mFDBC863D30BC63ADCF2860F303AF252E27D0F4F4,
	TextConsoleSimulator__ctor_m4719FB9D4D89F37234757D93876DF0193E8E2848,
	U3CRevealCharactersU3Ed__7__ctor_mD45A85F5F50909F70C80AC8CE460F4FD261CDE9D,
	U3CRevealCharactersU3Ed__7_System_IDisposable_Dispose_m85F270FDC11A4D79E9CF47AADC9FA1FBF032F86C,
	U3CRevealCharactersU3Ed__7_MoveNext_mA9A6555E50889A7AA73F20749F25989165023DE3,
	U3CRevealCharactersU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5BBAE6868EB7F1C11BE5DF001641E18C9D625F83,
	U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_Reset_mA9F4893381AB24E01EAEBFC38A88AF363A9A0691,
	U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_get_Current_mFD0B7538B1A650FB389FFE9296B0E51AEA5B6B6F,
	U3CRevealWordsU3Ed__8__ctor_m22FF9E770988107A928C5D1EA639F60239BFFEF0,
	U3CRevealWordsU3Ed__8_System_IDisposable_Dispose_m3EAF6EF4A8C99A71FEED251BF3F28A26BF6AD7F8,
	U3CRevealWordsU3Ed__8_MoveNext_m3811753E2384D4CBBAD6BD712EBA4FAF00D73210,
	U3CRevealWordsU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA3F93E4AA532F15D52D68B7121805C014AB2D7FB,
	U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_Reset_mCDC8982948ED5F7743567569CA1D4A354218714F,
	U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_get_Current_mF39E492D576810F58DB9031556CFD6806FD32E27,
	TextMeshProFloatingText_Awake_m679E597FF18E192C1FBD263D0E5ECEA392412046,
	TextMeshProFloatingText_Start_m68E511DEEDA883FE0F0999B329451F3A8A7269B1,
	TextMeshProFloatingText_DisplayTextMeshProFloatingText_m3C381B8A53C58CF001D7A9212B8BDA6F368CC2C7,
	TextMeshProFloatingText_DisplayTextMeshFloatingText_m22691E6EA41B7FCF782B03954865D8E3B890E4DF,
	TextMeshProFloatingText__ctor_m968E2691E21A93C010CF8205BC3666ADF712457E,
	U3CDisplayTextMeshProFloatingTextU3Ed__12__ctor_mA27BBC06A409A9D9FB03E0D2C74677486B80D168,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_IDisposable_Dispose_m510FB73335FCBCBEC6AC61A4F2A0217722BF27FC,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_MoveNext_m8DFB6850F5F9B8DF05173D4CB9C76B997EC87B57,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCD7B5218C81C0872AB501CD54626F1284A4F73BF,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_Reset_mD2D32B94CA8D5A6D502BA38BDE1969C856368F73,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_get_Current_m59B2488B0E3C72CE97659E8D19BB13C6E0A44E90,
	U3CDisplayTextMeshFloatingTextU3Ed__13__ctor_m359EAC129649F98C759B341846A6DC07F95230D2,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_IDisposable_Dispose_m36DE8722B670A7DDD9E70107024590B20A4E0B18,
	U3CDisplayTextMeshFloatingTextU3Ed__13_MoveNext_mB7D320C272AAA835590B8460DA89DEBC0A243815,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m891591B80D28B1DF2CF9EB78C19DA672A81231A2,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_Reset_m5EF21CA1E0C64E67D18D9355B5E064C93452F5B2,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_get_Current_m4850A72D887C4DA3F53CA1A1A2BEAD5C5C6605A1,
	TextMeshSpawner_Awake_mDF8CCC9C6B7380D6FA027263CDC3BC00EF75AEFB,
	TextMeshSpawner_Start_m7CC21883CA786A846A44921D2E37C201C25439BA,
	TextMeshSpawner__ctor_m1255777673BE591F62B4FC55EB999DBD7A7CB5A1,
	VertexColorCycler_Awake_m84B4548078500DA811F3ADFF66186373BE8EDABC,
	VertexColorCycler_Start_mC3FF90808EDD6A02F08375E909254778D5268B66,
	VertexColorCycler_AnimateVertexColors_m6960F777E4876DFCA726BCAE7A8163850D58FA42,
	VertexColorCycler__ctor_m09990A8066C8A957A96CDBEBDA980399283B45E9,
	U3CAnimateVertexColorsU3Ed__3__ctor_m0038B1054BCC928D35F8C0021ED7D2E1C533E35F,
	U3CAnimateVertexColorsU3Ed__3_System_IDisposable_Dispose_m5BAD394A0B09B3E0FF19E91521E02C2B3ADD6007,
	U3CAnimateVertexColorsU3Ed__3_MoveNext_m2842AF5B12AFC17112D1AE75E46AB1B12776D2A6,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mAE810D7968957A09C88E61C29DAAEC68E4AF1E51,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_Reset_m72ABAC50E9E4D972FB44CAFF387F3E23FEC5D932,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_get_Current_m8DE595A1D01F3A507A356F8BCE020D0851412B52,
	VertexJitter_Awake_m9C5586A35BD9C928455D6479C93C1CE095447D8F,
	VertexJitter_OnEnable_m97ED60DBD350C72D1436ADFB8009A6F33A78C825,
	VertexJitter_OnDisable_mF8D32D6E02E41A73C3E958FB6EE5D1D659D2A846,
	VertexJitter_Start_m8A0FED7ED16F90DBF287E09BFCBD7B26E07DBF97,
	VertexJitter_ON_TEXT_CHANGED_mC7AB0113F6823D4FF415A096314B55D9C1BE9549,
	VertexJitter_AnimateVertexColors_mECAE037FC0CBA52CAC71C0B61E88829FF18BCC16,
	VertexJitter__ctor_m550C9169D6FCD6F60D6AABCB8B4955DF58A12DCE,
	U3CAnimateVertexColorsU3Ed__11__ctor_m0222C3457F5ACA497FE3A8EC829DE4AD11A169F8,
	U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m717E79A39A8161ADDA9E62F7CDFB67B8F2D65099,
	U3CAnimateVertexColorsU3Ed__11_MoveNext_m169A75C7E2147372CB933520B670AF77907C1C6B,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m920EBA43D59A1A88E27FED92CF0AC0DF90179479,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m6C045A6DD0B60F1512457448E615877EAB86D75D,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m017345FE58B497EAFC9D0CB1FB733F76EB3449AF,
	VertexShakeA_Awake_m005C6F9EE8A8FD816CD3A736D6AF199CD2B615A2,
	VertexShakeA_OnEnable_m9F60F3951A7D0DF4201A0409F0ADC05243D324EA,
	VertexShakeA_OnDisable_m59B86895C03B278B2E634A7C68CC942344A8D2D2,
	VertexShakeA_Start_m3E623C28F873F54F4AC7579433C7C50B2A3319DE,
	VertexShakeA_ON_TEXT_CHANGED_m7AD31F3239351E0916E4D02148F46A80DC148D7E,
	VertexShakeA_AnimateVertexColors_mC451E2732A4E3E90E2553811AD75903EEF974599,
	VertexShakeA__ctor_m7E6FD1700BD08616532AF22B3B489A18B88DFB62,
	U3CAnimateVertexColorsU3Ed__11__ctor_m92612416BEC0EBF5E9849FB603629C0F2F95FEF2,
	U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m77D966994D4717EAFD8EFE169F3E8A4EE8B05B81,
	U3CAnimateVertexColorsU3Ed__11_MoveNext_mCEEDE03667D329386BB4AE7B8252B7A9B54F443F,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mDCCD3645ACF9B18D760B341C863F853996FA9BCE,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_mB9444B5E58B4E97105C447F547C0F74C51BCFBFA,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m5CC464185D5C0251C6206E20AFFA681BA0525A7E,
	VertexShakeB_Awake_m99C9A0474DBFE462DC88C898F958C1805376F9D5,
	VertexShakeB_OnEnable_m64299258797D745CDFE7F3CBEC4708BDBC7C3971,
	VertexShakeB_OnDisable_m07D520A8D7BCD8D188CE9F5CC7845F47D5AD6EF4,
	VertexShakeB_Start_m9642281210FA5F701A324B78850331E4638B2DD1,
	VertexShakeB_ON_TEXT_CHANGED_m5650D69D258D0EEF35AF390D6D5086B327B308A5,
	VertexShakeB_AnimateVertexColors_mDF7A7E7028361D288DF588D9301541E4FA1EFA87,
	VertexShakeB__ctor_m605A778C36B506B5763A1AE17B01F8DCCBCD51EC,
	U3CAnimateVertexColorsU3Ed__10__ctor_m3E3B1D286DEBED2BC028AD490308568B930C3760,
	U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_m0F9D4B2A6ED0500C2120DBA29932CC279E8908DC,
	U3CAnimateVertexColorsU3Ed__10_MoveNext_m0534E436514E663BF024364E524EE5716FF15C8E,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF2A8BAFC0261ACBBE8EEA74DE4B498D30C68AE3D,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m5F12D7C6F2523BEB6326FE49AE972116D6157CBB,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mB9C12786011A3B78517AEFAE8D5A78B95A4219AD,
	VertexZoom_Awake_m1B5D386B98CF2EB05A8155B238D6F6E8275D181C,
	VertexZoom_OnEnable_m7F980FC038FC2534C428A5FD33E3E13AEAEB4EEC,
	VertexZoom_OnDisable_m880C38B62B4BB05AF49F12F75B83FFA2F0519884,
	VertexZoom_Start_m10A182DCEF8D430DADAFBFFA3F04171F8E60C84C,
	VertexZoom_ON_TEXT_CHANGED_mB696E443C61D2212AC93A7615AA58106DD25250F,
	VertexZoom_AnimateVertexColors_mEFBA6C940DFECB485236C247358A32011A7963ED,
	VertexZoom__ctor_mE7B36F2D3EC8EF397AB0AD7A19E988C06927A3B2,
	U3CU3Ec__DisplayClass10_0__ctor_m4EC5F8042B5AC645EA7D0913E50FD22144DBD348,
	U3CU3Ec__DisplayClass10_0_U3CAnimateVertexColorsU3Eb__0_m959A7E1D6162B5AAF28B953AFB04D7943BCAB107,
	U3CAnimateVertexColorsU3Ed__10__ctor_m537CF0A5ADF5BBC2DF784BF526E3F32EB528E1B2,
	U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_mF0CD944C393771101D2718A660E1DFF22385819F,
	U3CAnimateVertexColorsU3Ed__10_MoveNext_m8340EFEB2B2CF6EA1545CFB6967968CA171FEE66,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m093E922A5A046910B2A7EE826D804CA3064A7BD9,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_mDED63FD52741D58D8D5A3E53415F91B6560F680C,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_m933EBF7C4300C7C1E3EE60E4741110025877CA5F,
	WarpTextExample_Awake_mEDB072A485F3F37270FC736E1A201624D696B4B0,
	WarpTextExample_Start_m36448AEA494658D7C129C3B71BF3A64CC4DFEDC4,
	WarpTextExample_CopyAnimationCurve_m744026E638662DA48AC81ED21E0589E3E4E05FAB,
	WarpTextExample_WarpText_mA29C98CF3B92F253C2DD2BADFC76618F8324BEF2,
	WarpTextExample__ctor_m62299DFDB704027267321007E16DB87D93D0F099,
	U3CWarpTextU3Ed__8__ctor_m9FADE04C27A0034C5A276232FCA187AECDC6BF49,
	U3CWarpTextU3Ed__8_System_IDisposable_Dispose_m5AB0DCF4B3DE6C290487F3DBBC7BAE931130DE60,
	U3CWarpTextU3Ed__8_MoveNext_m9C83C8455FF8ADFBAA8D05958C3048612A96EB84,
	U3CWarpTextU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9D5776AF80C4227401ADD7E13D98F2530CB9E7A1,
	U3CWarpTextU3Ed__8_System_Collections_IEnumerator_Reset_m4F2FBBE7B375E6FC837736B4275A7B601A01F535,
	U3CWarpTextU3Ed__8_System_Collections_IEnumerator_get_Current_m01FA935D93D737C9DDD88A051F7DFC393DD7BD25,
	Json_Serialize_m3D53585BB85C67CF02F16F50AF185CE70B1B2C6F,
	Serializer__ctor_m9090E3158FD9DC53DE34759B18F7C2C6D2D68309,
	Serializer_Serialize_mE51FB24524ABE5C4BD4640D274BE78538AD397F6,
	Serializer_SerializeValue_m2AFFC257F2288B112E11322A41317C1AC4859D62,
	Serializer_SerializeObject_mA5E7E54F453D0BEDC714D018A4CD938C2CB1C5B5,
	Serializer_SerializeArray_m7162DCF619ED10C6847424939C3FA2B42ECB04B9,
	Serializer_SerializeString_m7147818113EFD8696129200E887B9F48360EBC38,
	Serializer_SerializeOther_m1201B846CA73DD0433A356037F3D6227051EC890,
	Json_Deserialize_m699D585677C2862DBAFA44EC31F8B6BEFB90970A,
	Json_Serialize_m39431EDE1526C8634DECB4F2FECF100067432169,
	Parser_IsWordBreak_mC0D8CFAB5531BC6B513F269FB4DDB1A306D580DA,
	Parser__ctor_m4E1732BA0BD698178125471DC1511219299898F8,
	Parser_Parse_m0C859F2B5F4F846DE4C1BA6A25C1F5CDE0A4E225,
	Parser_Dispose_mAA3BFFD7355890D49D822235E90A2344EBDBE6C5,
	Parser_ParseObject_mDDD2FB38855612FD864DBA2DFEA9C11BF73DC39E,
	Parser_ParseArray_m652900CDFFD881DF9449BDD372556C340DCD75D3,
	Parser_ParseValue_m59151796F1BD6D3E46D554A49EF34BCDB403AA79,
	Parser_ParseByToken_m911C011FACC990674C6B917558E12B9DA2CBE444,
	Parser_ParseString_m0D81629614AB969C04BBD74965821A39E1573D63,
	Parser_ParseNumber_m2A376DA74162CDEE4A283B5BD92FCF80E066A04E,
	Parser_EatWhitespace_m8C75236AFAB8FFF856DA2BFE53BC84F9C7E05AA1,
	Parser_get_PeekChar_mC5C7804B362B6A163532B53F1D9270D8F7F8C55A,
	Parser_get_NextChar_m02DE23E038D31DE928B6F89B149590A35209D4A1,
	Parser_get_NextWord_m7DA018BF5C404FE6FB873F46E721A512FD63ED2F,
	Parser_get_NextToken_m889CBAFA9C9DDDE25A59F5CD4BC592654A1CA567,
	Serializer__ctor_mE358C3CEC17F0D9F2158C5D09F9BD1CB6B760F84,
	Serializer_Serialize_mBEDF816D5B952D6C2EDFEE5475395CD4249BDB9C,
	Serializer_SerializeValue_mBE0C676D8B5F4EBD76E9019A7FE931F8BB2416EE,
	Serializer_SerializeObject_m8B5E760CF414451768C00F044DBC2B36A028E1D4,
	Serializer_SerializeArray_m72FB41798EAB678E1064FC4DC830E3F34EB72302,
	Serializer_SerializeString_m8EF870ACEA27199F33FA1B647B801C3E026CF31F,
	Serializer_SerializeOther_m20D11252CFA7B52079C618491BCB3AFE22332BC4,
	MimeTypeMap_GetMimeType_mE4EFCA9A399C7D1E7A7D32597BA348942DA727AF,
	MimeTypeMap_GetExtension_m5CDF7C52EB88F651B5B8443360341708DAE7FDDC,
	MimeTypeMap__cctor_m7960D90CED0FC62F54F6BD26FD1392C24F71AC78,
	NCMBManager_Awake_mB9D5BA5B62BA5C922B0FDE3521D20D950F2F50A8,
	NCMBManager_get_Inited_m1F2171355D1686CAF80FEEDCDF45FF768A109FA3,
	NCMBManager_set_Inited_mE736FA9956382CF83E644BD1906B6FC35BCB02AA,
	NCMBManager_OnRegistration_m23173E5808F6BF6BB4B11B96928D3A874A5AB751,
	NCMBManager_OnNotificationReceived_mB27A9079F79053F6B97E8E989B0649E648955223,
	NCMBManager_SearchPath_m08D8FE097734E1C8CC4D0016A962931463BB2480,
	NCMBManager_onTokenReceived_mBD1D57B36FA470746F6F7D11322FFA5A57E4A4B1,
	NCMBManager_updateExistedInstallation_mEC6DE2910A6378DBE1A861E23AB94C848F70951A,
	NCMBManager_SaveFile_m238E6D9C643891D5713BFD8DA2E1976A225E4045,
	NCMBManager_ReadFile_m67EB5D172890F834BF2E872258CB662B4BA5F182,
	NCMBManager_onAnalyticsReceived_m43E0E57722F636A5913A335B28DEFDE5E5ABAFC2,
	NCMBManager_DeleteCurrentInstallation_m9EA8289F7E18323C07F0B39D5D1F557F195FCC23,
	NCMBManager_GetCurrentInstallation_m1B73955954721A4050BF5F1F8E9B8C2565B000AD,
	NCMBManager_CreateInstallationProperty_mF7803E06EF82002435C9E457484592024AEC4065,
	NCMBManager__ctor_m084D76A3D94F025DAD4EAAE713A1FDF4A3211AF2,
	NCMBManager__cctor_mED5F3D4B00878F07488880DF6E4C01B8E41DB3C3,
	OnRegistrationDelegate__ctor_m277EDC977BFFDB91D17383A2550179F821C0BBD6,
	OnRegistrationDelegate_Invoke_mAC2B1767388C2ADD8FECEF0071122FAF810AA43C,
	OnRegistrationDelegate_BeginInvoke_m509E4EBAEEFFE45D29BB99DCF52486F8819AC20F,
	OnRegistrationDelegate_EndInvoke_mCEDA3D45125FC270D3C25C1C4BB1821E260B3437,
	OnNotificationReceivedDelegate__ctor_m0E6AA3E5CF780340E102AC41658E5F2C2D289847,
	OnNotificationReceivedDelegate_Invoke_m2AA62B0D3406EAAAA3E61CFBADEF9676F9152ECE,
	OnNotificationReceivedDelegate_BeginInvoke_mC0CE976457FC8AFD7634273517900E032B7A6713,
	OnNotificationReceivedDelegate_EndInvoke_m814C7789235DD36BED31C606FCC2C2967C9C8012,
	U3CU3Ec__DisplayClass15_0__ctor_mDB22A4982A0AF2138A3CD6AB2E0EF26C452A0D19,
	U3CU3Ec__DisplayClass15_0_U3ConTokenReceivedU3Eb__0_mB18A1DBF5102DACD5EEE1EBA06BD78E9A3374DDC,
	U3CU3Ec__DisplayClass15_0_U3ConTokenReceivedU3Eb__1_m7A7C9DBA04323BBC4EACD793EB6430586C86269C,
	U3CU3Ec__DisplayClass16_0__ctor_mBF6DBEE298B028DD8FBA07B318562DC10A1C5BAB,
	U3CU3Ec__DisplayClass16_0_U3CupdateExistedInstallationU3Eb__0_m8DFF37E8265BD006B6E413CB2404B2EC1C8E0887,
	U3CU3Ec__DisplayClass16_0_U3CupdateExistedInstallationU3Eb__1_mC2A16A057A096BA46E82257DEB9168ED95B0D28F,
	U3CU3Ec__DisplayClass16_0_U3CupdateExistedInstallationU3Eb__2_m9B4E51D3AEB08C50DE3A517808FB93FDA9C54843,
	NCMBPushPayload_get_PushId_m988C72E87E78A06B45ADA8528FC04B3F03D98968,
	NCMBPushPayload_set_PushId_m3F7E8DCB48B8FBB4A919EC5FDBFA61FA97D9428D,
	NCMBPushPayload_get_Data_m8EEEA470E0BD18624CE98873BBFCE4DB77493CB0,
	NCMBPushPayload_set_Data_m2BBEE880905A81ADF546F0CFBBEA021E5F4A83EB,
	NCMBPushPayload_get_Title_mB5018F333CBCA72577E3F7A44D9E993493BCDE78,
	NCMBPushPayload_set_Title_mF39103B09D6AF982932D478157ACEB3A34097735,
	NCMBPushPayload_get_Message_m1235E378B679140B3A79E2A885577F27193EEBE3,
	NCMBPushPayload_set_Message_m0CB777379F3CEEABE7CCA2AE4BFB12CDD72AA266,
	NCMBPushPayload_get_Channel_m9489EE88A990304C21F1E50570523927587EC87B,
	NCMBPushPayload_set_Channel_m1FB9EBA73E77B22708007A370F4892A9FF010C66,
	NCMBPushPayload_get_Dialog_mF0C1228C4A8A926BC5C5D615B83FB23BCD1F49E5,
	NCMBPushPayload_set_Dialog_m66789ED50999DF2FFDFFE113ACC765C2FD3288B7,
	NCMBPushPayload_get_RichUrl_m63FA63B36A98C7CC6B89331F7D52A60AD9C29089,
	NCMBPushPayload_set_RichUrl_m4473C6A691353BF27F4155CDF352198C4DD69742,
	NCMBPushPayload_get_UserInfo_m119D2D4BCA9197F77AAD5F20C6DD5137DCCAE557,
	NCMBPushPayload_set_UserInfo_m41FEC468EBC26C9C9B95F298203ACAC7140BC5FA,
	NCMBPushPayload__ctor_m6D1ED4AA9CE21DCF04F93B350D4B09D4124D70D1,
	NCMBSettings_get_CurrentUser_mB3796DA9998CFD63310B7514F60D69B47C443F00,
	NCMBSettings_set_CurrentUser_mC5D0D6BDE837E1678D57799604D3AD927D5A951D,
	NCMBSettings_get_ApplicationKey_m70D746DD7C2F3F50863D607DBC52A3960E19106F,
	NCMBSettings_set_ApplicationKey_m29F5D17D41241078E896666D342ED44EC240176F,
	NCMBSettings_get_ClientKey_m65FF92C16B47752D909840A1EE14692FB7EC451E,
	NCMBSettings_set_ClientKey_mE87541A211201F79B8E989EDA0FBEE218AA3BBA7,
	NCMBSettings_get_UsePush_m072B6C82712E6DD39C4B718B8278635DE041F422,
	NCMBSettings_get_UseAnalytics_mA88990CA4A2B715462395108A7E62B235F343AA3,
	NCMBSettings_get_DomainURL_m1DE95F9FE76F5BE62BC6FF24BCB6978D50C01215,
	NCMBSettings_set_DomainURL_m563D6A73D7069454B87F78AF929EEE04A968E034,
	NCMBSettings_get_APIVersion_m1793B35AD4EE5CD5B66EB1F65F1626D2BBCF1F4A,
	NCMBSettings_set_APIVersion_m276F4426D0EE307C5804CDD6A2DF89F2AD871A52,
	NCMBSettings__ctor_m2673AA9DA9DC196640D24DF026C3BE70034ABABB,
	NCMBSettings_Initialize_m9D6680754B2EA7DE5CAD6CA809949BC633C18ECB,
	NCMBSettings_RegisterPush_mFC5E7AF0A4FFD8EF999E91FA5772476FB311D766,
	NCMBSettings_EnableResponseValidation_m0801D684D13552A48E0C78883D30586481C16B4C,
	NCMBSettings_Awake_m8CDEE2C3DA636DC19775A24C8A720DD6C3C2CFE4,
	NCMBSettings_Connection_mA6E3699CB589879B973BAE1F3BA6748CA3DB610E,
	NCMBSettings__cctor_mC258D992797351B4813EE8986B93B135CE72CAB4,
	NCMBACL_set_PublicReadAccess_m21DB367E5FE03C2430D9770B7D0CF6856038F033,
	NCMBACL_get_PublicReadAccess_m41F1607980109ED8DE01C0B190691678839C43B2,
	NCMBACL_set_PublicWriteAccess_m19B9F11D254035D23F9512528EE60A993594EC89,
	NCMBACL_get_PublicWriteAccess_mA2F881CA460DF3ED9DF7D9B19E7C2DFED317066E,
	NCMBACL__ctor_m446FCA9252FD6448AA63FD3BFB29ABBE0F4A1FFB,
	NCMBACL__ctor_m3443B9E708BEA39669B83EB77BD540BE7BAF823A,
	NCMBACL__isShared_m02B030E5C3F0E3E7B3E8C36AE37783DFA108F342,
	NCMBACL__setShared_m47F22D86FF304D517003432D2A0753CD40C3968F,
	NCMBACL__copy_m853568424B5BA87E0ACC981B1D8442B746D3B54F,
	NCMBACL_SetReadAccess_m77C3E082F66537FBCD12F451628295EFAFEF9427,
	NCMBACL_SetWriteAccess_m13C815C1BC48FB906FA33F50749831BF991A9A08,
	NCMBACL_SetRoleReadAccess_mF9498FEA4BBCE24450518C7F2B1A4B6973618AE9,
	NCMBACL_SetRoleWriteAccess_m6B35F0E488D6AE3AAD5A6B7CE1E7592930BA19A3,
	NCMBACL_SetDefaultACL_m0856E5BF8C8298EC795F8D21C0225656782AC8FD,
	NCMBACL__setAccess_m1DA5C8FA30199FD7CD60C0ED7E38D1C6FBAA2063,
	NCMBACL_GetReadAccess_m89BC9CCE9DC82EB3D6F096C5D6859BD8DB83E135,
	NCMBACL_GetWriteAccess_m3D6BC502C10E44ED25B7A447FD7E8F22D19193BD,
	NCMBACL_GetRoleReadAccess_m494BBF730D602F117133702B90D8B016ADCAEA83,
	NCMBACL_GetRoleWriteAccess_mFF39E720DE7A4818416FA5CAB317F4E2A0AAEAF8,
	NCMBACL__getDefaultACL_m067F11737CB42BE0AF9A14C50E6400DB95577175,
	NCMBACL__getAccess_m303D273B2401DF6C582EA3D9B547DA6C54E27468,
	NCMBACL__toJSONObject_m6FA8557560547FF899F5F8C304278E26B6E3AA06,
	NCMBACL__createACLFromJSONObject_m45412E1230A6B6ABAA950B7383BBBFA848098C27,
	NCMBAnalytics_TrackAppOpened_m3505A84AAE05E6F80B6204F83515E3B47C8F1D19,
	NCMBAnalytics__ctor_mBD25FF53250130AD5C1000EB23E9F0D7FF26DF3D,
	NCMBAnalytics__getBaseUrl_m5EF80B9925F3443B220095B32111477C83342660,
	U3CU3Ec__cctor_mFE5756BBDD8A1AA5B249E9703351A849229FB484,
	U3CU3Ec__ctor_m7E4178E0641781BBADBED41029CF09AABBDAC96E,
	U3CU3Ec_U3CTrackAppOpenedU3Eb__0_0_m65493F4018E34A440E38DC61D36955A7B26CC886,
	NCMBAppleAuthenManager__ctor_m5247F8157782A79BCFCDF36EBC3ADE181AA37D1F,
	NCMBAppleAuthenManager_NCMBiOSNativeLoginWithAppleId_m936B8D038D7EBA0D6572378D8340ED7141388313,
	NCMBAppleAuthenManager_Update_m2F7814B383D04C3E9D2681360DD6A249B65BD89A,
	NCMBAppleResponse_get_Error_m4BEA39D5396357A504A1545CF1CDED2EACAC6EB2,
	NCMBAppleResponse_get_NCMBAppleCredential_m67D93B7C002FDBE19D70F07DDA9424B979702C5A,
	NCMBAppleResponse_OnBeforeSerialize_m1CDCE320A58497378F155A1747CE31BE864A79A1,
	NCMBAppleResponse_OnAfterDeserialize_m0485C5E46BBEDA9337D76D09F3362DEFB22B0C12,
	NCMBAppleResponse__ctor_mD55FB179EC208A989DBC1152436FB8F0E83AF16D,
	NCMBAppleError_get_Code_mBF7C4FAE5E2EE746C20F7C171B1E71BD23CF21E5,
	NCMBAppleError_get_Domain_mFD6C3CBC84A35917697991C9865F16AAFB18D8F8,
	NCMBAppleError_get_UserInfo_m32DFF88F9750C32C9FC344634FBFD8E61B2B9760,
	NCMBAppleError__ctor_m804D9D33729A8CFBEABC02E6785556AEBF8FB19C,
	NCMBAppleCredential_get_AuthorizationCode_m9462D5BE31664E8A26ADF30D165006F071C918E9,
	NCMBAppleCredential_get_UserId_m4CB3B680F17C2253092A5D0609CD3AAAABCCDEF0,
	NCMBAppleCredential__ctor_mA1C5B75EDA24CFA02629C636E5BB4A9DE5700CF4,
	NCMBAppleParameters__ctor_m993D161AE6AE4886B148C1B4C6971B8394C6E805,
	NCMBCallback__ctor_m2013D9A1FFC914E6DADA2CAACCA69D38AF8B40F7,
	NCMBCallback_Invoke_mE5880BFA587E9DBBDE017F10C49CE35F5E87B7A3,
	NCMBCallback_BeginInvoke_m01B34539924486BDED7517F34FCD91CFF0E90A6B,
	NCMBCallback_EndInvoke_m37852E364C642BC21DBE1BC38837EB5DE44F3116,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NCMBCountCallback__ctor_m1299C73EA033F181E063DC5EC996C384CCC66922,
	NCMBCountCallback_Invoke_mCA37EC7315382D78119E35F38BB54FA9DEC2DCFC,
	NCMBCountCallback_BeginInvoke_m69AAC6534F8B2097797A0E8A82DED6D72A699969,
	NCMBCountCallback_EndInvoke_mB53C4ECEA0C6825A5E3E0A7D9F6C206282A85CCE,
	HttpClientCallback__ctor_m7F3B09DA80516D65A024E2FE52DD5C2C000B7532,
	HttpClientCallback_Invoke_m4640A453C3CF17DAA80981D95CFD3FD9286C1E19,
	HttpClientCallback_BeginInvoke_mF42657456A9F7A4B729F9CCA9BB26FD023D39B60,
	HttpClientCallback_EndInvoke_m2952DC6B970AA47FAC45DB8E9B231FBED1D5D770,
	HttpClientFileDataCallback__ctor_mA4686058C24F093793121E982092A33A9519C1DB,
	HttpClientFileDataCallback_Invoke_m647DBF047F0F28D4DFBA5DAC53089E2A6812F6C3,
	HttpClientFileDataCallback_BeginInvoke_mB02D79350A10E50AEC2DE611C9494E348954CC46,
	HttpClientFileDataCallback_EndInvoke_mAA9FD53AA578FDD2DBC712D65F82516FBD3B36A0,
	NCMBExecuteScriptCallback__ctor_m9B1F3BE5D4B1BE2791701DA5A9783F3731ACCFD1,
	NCMBExecuteScriptCallback_Invoke_m1F5BC3A7601EA5212EBEBA73BF6DFD70C9DD28EA,
	NCMBExecuteScriptCallback_BeginInvoke_mC2A4869160BCB5A7B84CC09923AEDECF1FB7BA39,
	NCMBExecuteScriptCallback_EndInvoke_mE19A1E15F532D7F3FFC604B1FB3CFE3E1A9BE855,
	NCMBGetFileCallback__ctor_m1C817DF8DAAFBB782343C77A3579479618392250,
	NCMBGetFileCallback_Invoke_m1078CCA509A9755CD916D3E0E68CA726DB188411,
	NCMBGetFileCallback_BeginInvoke_mAE6AD43706174BF26173F47A4BD6D7FD1A4DC00A,
	NCMBGetFileCallback_EndInvoke_m54FE373E276BCC161DD30F22F318564AD83C45A0,
	NCMBGetTokenCallback__ctor_mD0A16965D8A4E9EB1A372F0A4232D686807461D8,
	NCMBGetTokenCallback_Invoke_m65DEB68A0D0C5635A49E58E210245C22DDBC76FA,
	NCMBGetTokenCallback_BeginInvoke_m5277A589EFA87BD2275A0FF07B68B56519DCB013,
	NCMBGetTokenCallback_EndInvoke_m451A6CD7635A1D40C1D07377DC81B3D65BFE1D83,
	NCMBException__ctor_m21159EF6D1B4388C7A8057F3DC35DB7589D04282,
	NCMBException__ctor_m7110980FBF8D6D5E75A2825C3B13ED29D5E75B88,
	NCMBException__ctor_mF92F4634095B6729BA5B835CF9768573F62FCAA2,
	NCMBException_get_ErrorCode_mD93261FCF162E0858142135A3E6B4D1FC94CE1D8,
	NCMBException_set_ErrorCode_m340DB0EA7E63757143995E685EC9ADEE97B5901D,
	NCMBException_get_ErrorMessage_m88E58E8A729A8D2C5AFA283513C160BE065FCFDA,
	NCMBException_set_ErrorMessage_m87C06E9E711D2899DED6B17C2B17FA41AB93FB61,
	NCMBException_get_Message_m54BEBFFA323F26A004EF1A663374BBBB46C04A3B,
	NCMBException__cctor_mE390E85A82D1E2450D4C72F7D8DF4E8EA74FC1F8,
	NCMBFacebookParameters__ctor_m2F3EA4DCDD2FE91B4884B582EC78B28223346DDF,
	NCMBFile_get_FileName_mE4EB4212140490CFAF793366FC3AA8CA7BCA8802,
	NCMBFile_set_FileName_mA43A8E610F88A2AB154D49ABD51D09199EE8D610,
	NCMBFile_get_FileData_mB39D3118C646D310AD82839920951DC1C43ACB87,
	NCMBFile_set_FileData_mE6747DDD1FA5B0CE0EAECEDF852740EC82BFF80F,
	NCMBFile__ctor_m228183B01694B99C614D0DFAF32A041BAFF50BEB,
	NCMBFile__ctor_m341DDE47107A33ED235F5F987FF736EC1B443A3C,
	NCMBFile__ctor_mDC94B1C7C1E5C778A9707B016E6C2073CBF985F0,
	NCMBFile__ctor_mF6CBA3CBDCEAA2E0F20D707CB418AAD84AE9CC28,
	NCMBFile_SaveAsync_m6388C0088EE4CF3F9AFCFD0B1618A97DB1B633C9,
	NCMBFile_SaveAsync_m5212898B0A3B4A181B245C773548D4F92B3AB3EA,
	NCMBFile_FetchAsync_m857E250C6B7CF35F4E24F0DF8D5BD168D9430CF3,
	NCMBFile_FetchAsync_m72D62941C375CE3F0AB8AED91236852B737EE11B,
	NCMBFile_GetQuery_mD4FB1B0CCB279438A00DA476A1D1CCF566B7788B,
	NCMBFile__getBaseUrl_m98FC1CFA8DD012BFAA7CA7D8B584C5D3F39220EA,
	U3CU3Ec__DisplayClass10_0__ctor_m7A554D4DA54BB89A01788B3C4EE671BF96B50550,
	U3CU3Ec__DisplayClass10_0_U3CSaveAsyncU3Eb__0_m6E4F442DFF6EC329E70FDF9CC2179F8209473871,
	U3CU3Ec__DisplayClass12_0__ctor_m3BD2B3A8535AFA1CF1A02A1C5D7F46EC3E9E6569,
	U3CU3Ec__DisplayClass12_0_U3CFetchAsyncU3Eb__0_m05FC6EC736A2F945ED4501CE5906F6E11BBD36A8,
	NCMBGeoPoint_get_Latitude_m6D2F853B7E2A0D490CC4A2A78F94DE8FD9CBA89F,
	NCMBGeoPoint_set_Latitude_m3ED4243D413FE6BD7E2306C46A98A081278B4994,
	NCMBGeoPoint_get_Longitude_mA071FF72500EB9DEC3817BDAB511A35F2EE95994,
	NCMBGeoPoint_set_Longitude_mD04AE661CCB2D10B4BEA0AC26006D2EF5EC69F83,
	NCMBGeoPoint__ctor_m5C1631BC64BBD61E6069FF072DEE124BFF183FE8,
	NCMBInstallation_setDefaultProperty_mFF69FAD9E899C323F375536F049497CE4EEAE84E,
	NCMBInstallation__ctor_m038D21E0B46B0CE9948EEAF7B0A7DDC85EA036BC,
	NCMBInstallation__ctor_m83450F3787E7B5D5F127225D21DBB80450C4A1C4,
	NCMBInstallation_get_ApplicationName_mBB54D8DA97101F2BDBE3F4EF5640A60B7EF0EC11,
	NCMBInstallation_set_ApplicationName_m36EFF15C8D3AB81E5BA9BDC3C8D9AAF9F9208139,
	NCMBInstallation_get_AppVersion_mAA1126E1ED86FFDAE3D2705335D28452489B6A31,
	NCMBInstallation_set_AppVersion_mD0A16DF5D5E1FC3126B85CA738821958D0EE4E55,
	NCMBInstallation_set_DeviceToken_m544D6D4636A9175FD660358A567F7D96724463F8,
	NCMBInstallation_GetDeviceToken_m68C21A111D30A56320A27DE41870E0F179ED1FD8,
	NCMBInstallation_get_DeviceType_m4E20B692FC955DC5AE6DC0AD9826139C07C9A909,
	NCMBInstallation_set_DeviceType_m86432E0C4CA1D3B2A693C2B6AA2078265065B980,
	NCMBInstallation_get_SdkVersion_mCEBA677518F818F5BDBA438CCFACC86A94B1E41F,
	NCMBInstallation_set_SdkVersion_mDDCF446035B8C4A05DDBC7A99AB1729B9C7BB63D,
	NCMBInstallation_get_TimeZone_mAA6895035937FC02CB04DD8BD61EE6584797BB64,
	NCMBInstallation_set_TimeZone_mE5162589D787FBB0634B4026C5FB29FE989CF99A,
	NCMBInstallation_getCurrentInstallation_m87360B90A694B8B3061715BAD7E29C3B28722D7C,
	NCMBInstallation_GetQuery_mA4006F8A150A78282EFF0E848A8079BA9346E604,
	NCMBInstallation__getBaseUrl_m5FB733CCC3C7698AD79AFB31C2BCCF48238912AF,
	NCMBInstallation__afterSave_m844279AE608B2D63C0167C29F01EB0431B6037BD,
	NCMBInstallation__saveInstallationToDisk_m41F6EEE0D3B0C261F68B84140D649629C47A5557,
	U3CU3Ec__DisplayClass11_0__ctor_m80DD23EC08CE1FB8F6BFA21BF27F089CB9C07D63,
	U3CU3Ec__DisplayClass11_0_U3CGetDeviceTokenU3Eb__0_mD8F57CEB3B54AE503C771FE70B7151B5CB87E8B4,
	NCMBObject_get_Item_mE77B63743998B855C6628D107043664D3789CABC,
	NCMBObject_set_Item_m293FF681D3CED5C6498D161A158F80AF8F79A24C,
	NCMBObject__onSettingValue_mDF88FA04366E1F1501F73206DB41CA5E4EEB0D1E,
	NCMBObject_get_ClassName_m3B1970F6A35F5B4D7722550CEB95513BDDD23A94,
	NCMBObject_set_ClassName_mF75D8380F85962A986AC3197DEAF177A37F35362,
	NCMBObject_get_ObjectId_m049628DB8A17E302FEFE8B92703BEE2E5B5D2EA0,
	NCMBObject_set_ObjectId_m50AD644A36BB98A0A79BA001B04944CB69337D81,
	NCMBObject_get_UpdateDate_m12F60362A4C8D6AD5DE3B002D1F79799BB5B6956,
	NCMBObject_set_UpdateDate_mC27A45B029ACA357A5DCAEADE4B4E4CC2BE91FE9,
	NCMBObject_get_CreateDate_mBC1980D166EC686F9844A2ED00DCA618ABA92BE7,
	NCMBObject_set_CreateDate_mC70968BCEAE2EB5E0C77544213F2E4DE12871F2F,
	NCMBObject_set_ACL_m6FDD90D1A8AB7F57957D230A1F42FF7FF1D8E5B3,
	NCMBObject_get_ACL_mCACBDCC23833E09111D86149FABC577BEC98F718,
	NCMBObject__checkIsDataAvailable_mD11E463554BFB3FA1721681642D6A6E9203B4CC0,
	NCMBObject__checkGetAccess_m94D2D361C91166833CD7597F71B675B7AB49F3F2,
	NCMBObject_get_IsDirty_m0647E3102B8FFB3AC943621F9168AC2ACF675505,
	NCMBObject_set_IsDirty_mC09C565CF17CC0740B5B028CA08304634AFA73CB,
	NCMBObject__checkIsDirty_m1FD52D8903F74AEE4EB204D53BC146EED04D42EC,
	NCMBObject__hasDirtyChildren_m2225BB0E56724749D87CC982451F195091CE3873,
	NCMBObject__findUnsavedChildren_m2FACE634CF13C14F8223FECEFCD80C21D280299A,
	NCMBObject_get_Keys_m0855E6A4ECF3D9CE0D433E476CB730DC7E671E94,
	NCMBObject__ctor_m00AC6399758FD1B32EBCC58B0F3FC750E4FF5700,
	NULL,
	NCMBObject__ctor_mC02E4A982F1B71A360069DA785C105C192966949,
	NCMBObject__performOperation_mC55F6E3A3561AF0B64D6D25DD98E71D749A75D8D,
	NCMBObject_get__currentOperations_mD929BA6CDF06B9093C82AEBDE533F172C2B4637C,
	NCMBObject_StartSave_mBC92D5A9B649594336FEB2202168FCF32A54B82A,
	NCMBObject__isValidType_m290129385F0DAE22C68616D9ECFA4471843A8D47,
	NCMBObject__listIsValidType_mD9B6B2DCDA248AAB81AC43272DDBFA2FE61531EA,
	NCMBObject_Revert_m2566A4F84A29E1922B406A6FC7E0D20C7D3C2832,
	NCMBObject__rebuildEstimatedData_m62FC3F5862B8478B5B2A5A40CB74DC7242929EE3,
	NCMBObject__updateLatestEstimatedData_mA23E2A11FD8FEA0CF3F9AAB69D41FA1212F2699B,
	NCMBObject__applyOperations_m72ED278F7388E3FBCB5CDDE20EBDB5AB03B77C0B,
	NCMBObject_Add_m3CC80DD3A45F51DF65744DB2CA1AD33138D6CFD8,
	NCMBObject_Remove_mBCEC810241DACFAB249BDD199DBC22CA736C85BB,
	NCMBObject_RemoveRangeFromList_m147FCB0B1F677F0B5CB771D5FCA230584B82B408,
	NCMBObject_AddToList_mF56F94D8F64B40BB3560B219F4FEA02FFADFADF8,
	NCMBObject_AddRangeToList_m79D5568BD1CE94FAFAD3632B6FEDFC8C07676A43,
	NCMBObject_AddUniqueToList_m94A24F9F99889A654BAD8183A2883EC203A58E52,
	NCMBObject_AddRangeUniqueToList_m7860AA8161DB33BD70CECDDDA2B5A53C9FB26140,
	NCMBObject_Increment_m79F02327CE657F922B06B1FAFDF0B6EBF3292BC3,
	NCMBObject_Increment_m02A79C723B9D4BCFBBB833CF8C066AA2CE25BB23,
	NCMBObject_Increment_m27522B0D176358B04A42E0BA0A95B289587FB23F,
	NCMBObject__incrementMerge_m3099E51C631D966C175FC0416917CB44BADD9A12,
	NCMBObject__addNumbers_m0449E3AFDDBEBB589BD417549E04C458C304C831,
	NCMBObject__getBaseUrl_m25588576DCAB62133F004A796CE16651657C202C,
	NCMBObject_DeleteAsync_m15CF2D7749B66D972686DC0357C169696F413505,
	NCMBObject_DeleteAsync_m0F3EFD51AB77793807E7F49592A37C189F63E933,
	NCMBObject_SaveAsync_mA3ACAC8D708BD47D470E835856698CE5CF6A9E7A,
	NCMBObject_SaveAsync_m09B8A9D1B6DF240B02EE5E68E12BD74119B78444,
	NCMBObject_Save_m590538B5AAE5CDD8D7E234BF6ED9E5406CD2A0AB,
	NCMBObject_Save_m8F4C897AFE9BC806B00DEC95B1BB9D5586C8E239,
	NCMBObject__beforeSave_mE80BFD4F45745E9CC823ACC3E24BD0733271EEDF,
	NCMBObject__afterSave_mEC31134AC1DEC1E48AF88E5DF18A9E8FEF982815,
	NCMBObject__afterDelete_m3A3D97422CB177A975C25943553E49EDEBF14696,
	NCMBObject__toJSONObjectForSaving_mC310D77C41ED6EC5FCD535069E4F18901249ACA8,
	NCMBObject_FetchAsync_m2EC98E3EE55944D9E6F8EC2F69142BAC0FCFD94F,
	NCMBObject_FetchAsync_m98D1E858E9FD3BC3908EAFDFBC67FFF8F218B071,
	NCMBObject_ContainsKey_mF50877A9E35BD13E60D10779E11144DE0E99C4D4,
	NCMBObject_CreateWithoutData_m53AD9E5220F14FA8911D41C4ED047DF23D3359AD,
	NCMBObject__mergeFromServer_m4BA898360B8A36CBEB77A9D8C6705E4097A737CF,
	NCMBObject__handleSaveResult_m25812D38AA79101C34A6E448999E4DA7D5A4214B,
	NCMBObject__handleFetchResult_m8AC1C7DB75A4CF4B97BC30C4C78B4CB0B0E22077,
	NCMBObject__handleDeleteResult_m22BF323A5AC1F7296D1CBAD620E93D7581A87F01,
	NCMBObject__setCreateDate_m310DD2A28E363E8B729B7A1FF4B75D28CB967140,
	NCMBObject__setUpdateDate_mA6B3C8E9D7B84266771668E0591C6E43552B9CB9,
	NCMBObject__saveToVariable_mAB65994C5E80E37FB92C163688076347F99CA5A5,
	NCMBObject__getFromVariable_m65A23EF537FB9627AE8FF12322701188170F8739,
	NCMBObject__saveToDisk_mCF5DDDE660D5F4A66C9C115BE956C0EB3CE03D99,
	NCMBObject__getFromDisk_m944E2C7470AA61FC449EDF9FF76108CE42D0ADF3,
	NCMBObject__getDiskData_m833C3BD44F6512F2CE25C4E1C105AC9CE03B6C42,
	NCMBObject__toJsonDataForDataFile_mE648E3FDAD862EA0B8C2FB3AC6EBFA9CBB201231,
	NCMBObject__setDefaultValues_m48A0DBECA7E4BF74311D5D9C84E5120B47356FA5,
	NCMBObject__cctor_mD9847C4329B1C97F6182D1DFB935F52947DB3D02,
	U3CU3Ec__DisplayClass67_0__ctor_mF72CB14EE1A5F21E785C449B5E62850D3A61F87B,
	U3CU3Ec__DisplayClass67_0_U3CDeleteAsyncU3Eb__0_m0889D3894439C9F3CC92FC674753CAD4425EB164,
	U3CU3Ec__DisplayClass72_0__ctor_mEADFC5D27384BB5C32D399C76D84C1955048955C,
	U3CU3Ec__DisplayClass72_0_U3CSaveU3Eb__0_m888DD40063D0BD484765130C6B3CBC13174E3A25,
	U3CU3Ec__DisplayClass77_0__ctor_m9465D4C47B6AB53A7729CDB7FBD342ABFFF47D0E,
	U3CU3Ec__DisplayClass77_0_U3CFetchAsyncU3Eb__0_m83C169DB4ED71370CA51B1419D2BC5E171F41003,
	NCMBPush__cctor_mD0014358EA0CC0655466733D152813F8BE006446,
	NCMBPush__ctor_mDCCC49135FBD475FC9C4305DE8E65B926105B8ED,
	NCMBPush_get_Message_m0D527F2EA29998352533BE462C6CFAA6E6CA7CD8,
	NCMBPush_set_Message_m78D9FC34FF6F111D9FFD705B8F2BF231DC300A16,
	NCMBPush_get_SearchCondition_m4E3498138FCC1B9873846BE82D9BC87A165D034F,
	NCMBPush_set_SearchCondition_mABD39EA64825F7F4CFE177506D03774AC5855E4D,
	NCMBPush_get_DeliveryTime_m722BECCD3DC7404D2DEB924001099FAC65A8AF64,
	NCMBPush_set_DeliveryTime_m8F8E5F3C57BFCC34203350ADB401FFC1B4586B4B,
	NCMBPush_get_ImmediateDeliveryFlag_m4652517426951A350B496300635B9157E7C229EB,
	NCMBPush_set_ImmediateDeliveryFlag_m5787DD8F4C5E6E8F98A20B6E3118ED924B229684,
	NCMBPush_get_Title_m15BAA926990B50A5BDAFB59C5C8AFA578953FC21,
	NCMBPush_set_Title_mA824F29085133DC21993FB572F082A2D13CE831C,
	NCMBPush_get_PushToIOS_mBB7A5EF5DD1DC34342C1E420D0DFCB39349BBB8B,
	NCMBPush_set_PushToIOS_m19AB75CE3A83054E352D6954910947E2017D6C1E,
	NCMBPush_get_PushToAndroid_m425F86FB596BB44AEC728743EAB2A97F890EEB27,
	NCMBPush_set_PushToAndroid_m748B0B6F0AEAA848FB9B4573A0E7F99CF30DBC20,
	NCMBPush_get_Badge_m06883CB2812D5CAD486A2F3913EA66606D70F8DD,
	NCMBPush_set_Badge_m78BF8D60E223C40D8B60A8C29ADFA751562FF7A2,
	NCMBPush_get_BadgeIncrementFlag_m31CB099DFDDF1155800596BEC90E48FE8439DF45,
	NCMBPush_set_BadgeIncrementFlag_m1527CEB61FAB09572487B1110807579DB446DE68,
	NCMBPush_get_RichUrl_m8115F74EE163DE70C7A3512D7E176334563C9CF3,
	NCMBPush_set_RichUrl_m53CBA6D13E1831CF1AF9BF9ED8670C61E6A00249,
	NCMBPush_get_Dialog_m3B06CD8F2D6292FAC056384AC361474F2670C2EB,
	NCMBPush_set_Dialog_mDE14B69E105516EC46BE6963E59CD7C6F75321CC,
	NCMBPush_get_ContentAvailable_mCF397305F262E516D533351D3553B223AE40A604,
	NCMBPush_set_ContentAvailable_m42AC8F4A34B1F6F3F9F6772E2693E8A40811F8EB,
	NCMBPush_get_Category_m17667A029E57E74E22F20DE7678301B77E3CCF1C,
	NCMBPush_set_Category_m911EE23C0A8D333625FE9A2EFCFDF147E14D3359,
	NCMBPush_get_DeliveryExpirationDate_m3C73CAE4ECD59556E810D979B023C9308148E59D,
	NCMBPush_set_DeliveryExpirationDate_m0C8D0C45C7FB1C788FFE8B9F0E1C7926280DC31C,
	NCMBPush_get_DeliveryExpirationTime_m88261DC34AE4EC9AD7B3332B9A47B892A0986D8B,
	NCMBPush_set_DeliveryExpirationTime_m08F414CEA2106D63A9AB3E12E9124339EF226EEC,
	NCMBPush_SendPush_mAEB5364D0BD796DE9639708FEF59FEFC8017C2AD,
	NCMBPush_SendPush_mFD4C3E9A3B61E8F3EBF29EFC79CB719D0A3C8158,
	NCMBPush_GetQuery_m7E490A986B339D54101FE55D7EA59CAEE1F6F44C,
	NCMBPush__getBaseUrl_m8220B4A54277F8635E48AC2233879660B3962839,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NCMBRole__ctor_m2241BC4F35CEDFEC1C6378352EAD77092B177D25,
	NCMBRole__ctor_mC367CBEF450897F91FCAC83FB1A334050C5443A8,
	NCMBRole__ctor_m46975F2B47A4F1309B04B4A415DF10E3E7E2C27D,
	NCMBRole_set_Name_m80E6FF97AC80A1078277CBE815AF4F51473B8394,
	NCMBRole_get_Name_mA7FF90769DE9FE6F5764F5517EFFEB25104404A7,
	NCMBRole_get_Users_mD3891E6F864E902A7D269CD59D6DEDB4A04F94F9,
	NCMBRole_get_Roles_m6EB64DC66BB42E7B4AD80BF301F705AD737D6691,
	NCMBRole_GetQuery_m27B9D095C95FE592250FD507E269EF7E060D643F,
	NCMBRole__onSettingValue_m95FF094C2527D4CAF35979C757E492D52EA59A6C,
	NCMBRole__beforeSave_m4DC8CE9CEC1A0E52E87412AB9FFD6120CA1D1D48,
	NCMBRole__getBaseUrl_mACA27C596898A8F73B97ED78ABF41502B02E9985,
	NCMBRole__cctor_m5D0095F8F9D9138A300EE511C76E0E2904D02CA4,
	NCMBScript_get_ScriptName_m0B9B482875C51F4D6303F8BCB63F0BE80EE5C4D7,
	NCMBScript_set_ScriptName_m224EC39C5D136E157F34410BE42959756502DE17,
	NCMBScript_get_Method_m77BC92E37B50383334A31C763D39F8955C4CFBC7,
	NCMBScript_set_Method_mB89FF279200621612CB1A193F774CD0FBD31464D,
	NCMBScript_get_BaseUrl_m2A143B17910AFDE8908645AD7FCFE70286057FAF,
	NCMBScript_set_BaseUrl_m708C15E3F8AB7A2E835D6B19DDEBE50895689444,
	NCMBScript__ctor_mFFE1E3CE04F2FEE4B303A66C46BDAD9DE6ABC34C,
	NCMBScript__ctor_mA44907DF175921420B0056D9171A0141427B1D39,
	NCMBScript_ExecuteAsync_m46AFE59A7F0D877B5108931FCFC041683333FC21,
	NCMBScript_Connect_m872017F8D43729B5792D1A7E69E8F08B84452F6E,
	NCMBScript__cctor_mA637263EF3035ECFEF7C8123D09CCC326654BA3A,
	U3CU3Ec__cctor_m61A667115C8D01BC23BAC03DBFB9B88BF5BE8A84,
	U3CU3Ec__ctor_mEDE10724AB4EF1A9C018D958BB283CE6C93351D2,
	U3CU3Ec_U3CExecuteAsyncU3Eb__18_0_m03DD7C5E99EE9130687AE390240C6C8DB360826B,
	NCMBTwitterParameters__ctor_m8682588C683EF79B23C320A62A4886874264B42E,
	NCMBUser_get_UserName_mA9CBD8558740F3C73771A90843C042FFE2854C5A,
	NCMBUser_set_UserName_m4C509E2E534BB1F00BAC4B24DA4C5E04CBF553E8,
	NCMBUser_get_Email_m3AD6D3E237AA9054E95D44D311FFFC9521311516,
	NCMBUser_set_Email_mAF4B3799FF9D290053C075411F496A2ED4894BBF,
	NCMBUser_get_Password_m1685C3AAF76CA930CAE720DE19024E0D7C0BBE7A,
	NCMBUser_set_Password_m122C48D36F37603FBE742270039EF2777A5E34B4,
	NCMBUser_get_AuthData_mA437C6CB155FAFAB80ADC2DCB17B2BF9327769D0,
	NCMBUser_set_AuthData_mADB4BD03AC64AEABB08976FB570E8370348BE51F,
	NCMBUser_get_SessionToken_mCDE16B148A115CD7ACA105C61BAE4E8ADAF5D649,
	NCMBUser_set_SessionToken_mEED4844AE5489C7A932D514309E4E32981C62828,
	NCMBUser_get_CurrentUser_m9CDA979912677C5EA61EFC710A04A9AD59139F0D,
	NCMBUser__ctor_m3CB9B58FBC25CCC256A1C1B04BBAF4134DEBDA80,
	NCMBUser__onSettingValue_m8CCC0F71725A26E15FAE244B0CF508E164170393,
	NCMBUser_Add_m8315466F367A7524064E56123A23F7802F389C25,
	NCMBUser_Remove_m189C39B3C24FAB42B47EF4C941D0186054801F6E,
	NCMBUser_GetQuery_m54F835B2D5023618B8B230C0B6874E2007D09F84,
	NCMBUser__getBaseUrl_mD80C773870F4E9EB8AD8416A44DAA51F81659B8C,
	NCMBUser__getLogInUrl_m7CA282FFC465DF9D56ED836226527C1D54599FA8,
	NCMBUser__getLogOutUrl_m9421E8470D3167E5C462812CBEA3148FAB93A448,
	NCMBUser__getRequestPasswordResetUrl_mA77B5B2030AD97E8AAA96AB995708B299D280F53,
	NCMBUser__getmailAddressUserEntryUrl_m959C65223BAB93DB33C16A8D93FD68417C2E9B89,
	NCMBUser__afterSave_m1D3E5C235EDD8EAF762FB624ABADF3C1D680BF77,
	NCMBUser__afterDelete_m2316D7CEB43351C04A65EB2808176AC94C77E8EA,
	NCMBUser_DeleteAsync_m07D229248FEBA5715D909658A24FFC5EE10561DE,
	NCMBUser_DeleteAsync_m24ABC3F93D4E4C32607BF0AF270A6CD11B7BAF97,
	NCMBUser_SignUpAsync_mC799649C1E3B9BF65CD5613AC0412A4CC76256A2,
	NCMBUser_SignUpAsync_m8174E098CE27A396486FD9F4A170DE2096478D7A,
	NCMBUser_SaveAsync_m5C3E5B2246F5A42508EBCC4E9F0C7FDC18DC1038,
	NCMBUser_SaveAsync_m03E1E82B82F31DE02DDDC6540A904DEB4E184490,
	NCMBUser__saveCurrentUser_m0CD7D97ADF754C1D839F3AFA82C19891F242A2BB,
	NCMBUser__logOutEvent_m154B6140E8403CA5020C3A7DBC586D89AFCC668B,
	NCMBUser__getCurrentSessionToken_m69F093680E549A97E21805CA286AFEB16511C73A,
	NCMBUser_IsAuthenticated_m235D5C9C51F0C7B1F63C8616DAA1A975D9E853BF,
	NCMBUser_RequestPasswordResetAsync_m01D56E5828944CA474803430EAACDD8FABF8C827,
	NCMBUser_RequestPasswordResetAsync_m347CE587991E386059E569DF855C586E9585CE75,
	NCMBUser__requestPasswordReset_mAD4A1F68FD13C0971C00DB834C736E770258B850,
	NCMBUser_LogInAsync_m273DAA3A5EEDFF64AA1ACDC7BDF0AF9985FF3C1A,
	NCMBUser_LogInAsync_m19C528DB4829716B5C032BE061B4E8986063C78A,
	NCMBUser__ncmbLogIn_m0AD0379D46B88AA18CB57F044AA909EC007AB047,
	NCMBUser__makeParamUrl_mBD0208E7F18A8746E1D96B0A4BBAAC589B0EA151,
	NCMBUser_LogInWithMailAddressAsync_m1F9280472AA0A85FF2F7849957D926773CF49CDD,
	NCMBUser_LogInWithMailAddressAsync_m61E7D4660D6A78E8FD1F37BCDF488B61FE14E5A7,
	NCMBUser_RequestAuthenticationMailAsync_mE4EA5FDDBE9A4C2F564717C223B9D03E2345BF0D,
	NCMBUser_RequestAuthenticationMailAsync_mF1322CFFF47A34ADF89D2F12E047B9ED8BC4E30C,
	NCMBUser_LogOutAsync_mD859E8BC4698CB69A258E8A7F5442C550E74DBDF,
	NCMBUser_LogOutAsync_mA1F699FDD93BE95112C441F64CDCD238D244E92F,
	NCMBUser__logOut_m66498054067686A27002D3D15567046FAB3F1AF9,
	NCMBUser__mergeFromServer_m2F6281AA9853166E3C1F1F6B1ED4B62DC083DAC1,
	NCMBUser_LogInWithAuthDataAsync_m3EB70E3F0FFD880E2B7CA528DA6D467F382B4800,
	NCMBUser_LogInWithAuthDataAsync_m27D64B67C71B995339E480657232097F5A24B1E7,
	NCMBUser_LoginWithAnonymousAsync_m5B791822559776B89AE67374AF57AE1809829B56,
	NCMBUser_LoginWithAnonymousAsync_mE58957466CB9CD48336B75D7D94391E330ECD727,
	NCMBUser_LinkWithAuthDataAsync_m768FD363EA1F904441CE73B566B077E3B5EE68CB,
	NCMBUser_LinkWithAuthDataAsync_m3B4A755753F24EE3E8BAF51EB0C4763FEB05E121,
	NCMBUser_UnLinkWithAuthDataAsync_mB808DF50B68C9AED0FF4D039420CE9558EF1C4DC,
	NCMBUser_UnLinkWithAuthDataAsync_m05D55C8060DAFF98AD1A65BFD71EEEC1DB38EF2C,
	NCMBUser_IsLinkWith_mC4E8238DF82825656D83391C6770538CD91D58A1,
	NCMBUser_GetAuthDataForProvider_mC2239649D16A849DCC2C7D036E868D5B541ADB03,
	NCMBUser_createUUID_m3B9A97C56DF1CE1EFF3C63ACF48544E873E56065,
	NCMBUser_LogInTaskAsync_mB0573E56923C4C6138801D82A015AA4103CE645E,
	NCMBUser_RequestAuthenticationMailTaskAsync_mB9539CB4833443BE53365825E995A6CE50AF6D1F,
	NCMBUser_LogOutTaskAsync_mA5BF9BC08A06D55CFDC2309149B74FEE3895F13D,
	NCMBUser_LogInWithMailAddressTaskAsync_mCA98299CB79B66812EB60D37D23A545ACE79C50B,
	NCMBUser__cctor_mEC300EDFA46FF6EEE5AFBD63CE131197D4684B50,
	U3CU3Ec__DisplayClass43_0__ctor_m7EB296E8511A471FB06D395CD960790E47B55A6A,
	U3CU3Ec__DisplayClass43_0_U3C_requestPasswordResetU3Eb__0_m3BEC0F9C03351F57059C34A66FE14FCC723666A2,
	U3CU3Ec__DisplayClass46_0__ctor_mADB89779823B511784F6688633A61DD4E3BAD4D7,
	U3CU3Ec__DisplayClass46_0_U3C_ncmbLogInU3Eb__0_m791262C299BCD403FE006378F35D7B237FA6EA35,
	U3CU3Ec__DisplayClass51_0__ctor_mD5CB560B59C3E72763DDD704AE6B3669080804BF,
	U3CU3Ec__DisplayClass51_0_U3CRequestAuthenticationMailAsyncU3Eb__0_m7419A3B3D46419239FA3F0E303EA7B94C57E101D,
	U3CU3Ec__DisplayClass54_0__ctor_m38606879272E668B19E982C0CA3C165F242C0355,
	U3CU3Ec__DisplayClass54_0_U3C_logOutU3Eb__0_mE8BD5A3667F3DB2EEBBA0F2DD9148B6DCFE16C44,
	U3CU3Ec__DisplayClass56_0__ctor_m8BD82E60360FEF7E8E194D61338D8610DC90B0B2,
	U3CU3Ec__DisplayClass56_0_U3CLogInWithAuthDataAsyncU3Eb__0_m74399D1B8D776AFC652D2FBB80D60E7705CA7AF5,
	U3CU3Ec__DisplayClass58_0__ctor_m84427DFCB3522479D9D3463E99F06742057BD2C8,
	U3CU3Ec__DisplayClass58_0_U3CLoginWithAnonymousAsyncU3Eb__0_m8D4DF95481F256AAE13E702708FD7ACA1B85606F,
	U3CU3Ec__DisplayClass60_0__ctor_m5854838D409711853248357F276E35967349B485,
	U3CU3Ec__DisplayClass60_0_U3CLinkWithAuthDataAsyncU3Eb__0_m0AE6D7A27721129B49892695480DACCBBA93ED89,
	U3CU3Ec__cctor_m3D87457F24E0C0FE2CE0195510B0A41AD5414BAD,
	U3CU3Ec__ctor_m2A0CF1268283F749AA4DB36DCDFEE3BF0102848B,
	U3CU3Ec_U3CLinkWithAuthDataAsyncU3Eb__60_1_m66BD17C2A99C776ECF3007D3F15A01D495541E32,
	U3CU3Ec_U3CLinkWithAuthDataAsyncU3Eb__60_2_mAD2756D932486D1424B7401CAE963183DF39154A,
	U3CU3Ec__DisplayClass62_0__ctor_m50E6D46C797EDCF2B3BA726A11A6AC5D62277EBD,
	U3CU3Ec__DisplayClass62_0_U3CUnLinkWithAuthDataAsyncU3Eb__0_mEBC11A97A93936EC7DA4F6999ED3741E37DCD14A,
	U3CU3Ec__DisplayClass67_0__ctor_m6C5B7ECCA936AE2C9FCA1EBF06E42D157988C20F,
	U3CU3Ec__DisplayClass67_0_U3CLogInTaskAsyncU3Eb__0_m193B8FDA7A4A21614DE23139A7A1CB0B84B91B92,
	U3CU3Ec__DisplayClass68_0__ctor_m3C23335A77AEADDA4A6D3F945D01C8D10CF629EF,
	U3CU3Ec__DisplayClass68_0_U3CRequestAuthenticationMailTaskAsyncU3Eb__0_m815AA7580173408FFF146CF1331D447A354BB285,
	U3CU3Ec__DisplayClass69_0__ctor_mDB4B582DC5205B9877111F8C6A91CA484BD1881B,
	U3CU3Ec__DisplayClass69_0_U3CLogOutTaskAsyncU3Eb__0_m6367EB9C03A49431D599E15C46F4E7E54090E4FD,
	U3CU3Ec__DisplayClass70_0__ctor_m3F860F6BE7DE9F620A4DE095591DBACA130381E2,
	U3CU3Ec__DisplayClass70_0_U3CLogInWithMailAddressTaskAsyncU3Eb__0_mF1D35CE6C3645282DD4014201D616449CC1A1AC1,
	NamespaceDoc__ctor_mD7C5EBCBB65BEF9BF148AD137CC36EE3AE99E6A1,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NCMBExtensions_YieldableSaveAsync_m6F374D9276B142C8CEFC8B8C80A195D68C740A22,
	NULL,
	NULL,
	NULL,
	U3CU3Ec__DisplayClass1_0__ctor_mEB0C55E6AAB143EC50AA8680C3786C66A2D9751A,
	U3CU3Ec__DisplayClass1_0_U3CYieldableSaveAsyncU3Eb__0_m9BCFF24D6D6CD494831772EDA29592DAD57CE07C,
	U3CU3Ec__DisplayClass1_0_U3CYieldableSaveAsyncU3Eb__1_m76B3130A82AD094D35E99A4C33D9780956BE600C,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NCMBPushTaskExtension_SendPushTaskAsync_mBF0DB383368144CD42EA20A2BF091CA56A4FE033,
	U3CU3Ec__DisplayClass0_0__ctor_m641564EB7F5B122D8EA3D2BB305D50F8DB4CBE25,
	U3CU3Ec__DisplayClass0_0_U3CSendPushTaskAsyncU3Eb__0_m1888674F7F6B2169C039B3DBB5B7AEA4178D58FE,
	NCMBScriptTaskExtension_ExecuteTaskAsync_m2458816FDD7B8A571390D285EF1AA8AF351BEC5B,
	U3CU3Ec__DisplayClass0_0__ctor_m83CE98221A611A8A09A553F008F411B608A35CCA,
	U3CU3Ec__DisplayClass0_0_U3CExecuteTaskAsyncU3Eb__0_m9556AA768426F637D1998343358C4932260DFC32,
	NCMBUserTaskExtension_FetchTaskAsync_m4758D27F4CD245DBA32574097BFF039D1DB8EDD4,
	NCMBUserTaskExtension_SaveTaskAsync_m14C5E77BEC14E8BE513C8F095729CC5AB434EAB0,
	NCMBUserTaskExtension_DeleteTaskAsync_mC0E92F162780CC2048A5B02C58991432F6CCF6A8,
	NCMBUserTaskExtension_UnLinkWithAuthDataTaskAsync_mDE457802917A38559CC6E5D10E9F5F2F6C637403,
	NCMBUserTaskExtension_LinkWithAuthDataTaskAsync_m5404938E388D8724DA331CE3C9CF9615D6ADE651,
	NCMBUserTaskExtension_LogInWithAuthDataTaskAsync_mE89C2EF2FD55C6A1934D79A864F631990E20CD1F,
	NCMBUserTaskExtension_SignUpTaskAsync_mDCC2AC5EE15B869E21B093D732ECC62DBE4E1284,
	U3CU3Ec__DisplayClass0_0__ctor_m31F8301194B707721CC9E1902FB3FCF784C58DDB,
	U3CU3Ec__DisplayClass0_0_U3CFetchTaskAsyncU3Eb__0_mFEC07ED8E0557679A1FAEEAC8EF573761F8DBA97,
	U3CU3Ec__DisplayClass1_0__ctor_m2D4A19ABD30F5988AA923A98141F0E2C5CFF2B7C,
	U3CU3Ec__DisplayClass1_0_U3CSaveTaskAsyncU3Eb__0_m73C74B3556AF0F5C2A5A4BCA47CD7D76EB655F58,
	U3CU3Ec__DisplayClass2_0__ctor_m2A74FB6834E8162600E5711907476958EE4A878A,
	U3CU3Ec__DisplayClass2_0_U3CDeleteTaskAsyncU3Eb__0_m3DAE5FE6816B93B4458FABEEEA02C637856BD2D1,
	U3CU3Ec__DisplayClass3_0__ctor_m7CC10F61F331306FF8A88FCCF79F4B49DC71EA8C,
	U3CU3Ec__DisplayClass3_0_U3CUnLinkWithAuthDataTaskAsyncU3Eb__0_mC118D033A06DDA7427D84C649FA16B5429CA9B56,
	U3CU3Ec__DisplayClass4_0__ctor_m56E401CA9D7F9834CE34AC7338AAB48C6B6FBA36,
	U3CU3Ec__DisplayClass4_0_U3CLinkWithAuthDataTaskAsyncU3Eb__0_m27234468683D22967BBC60B0E552F1650AE47E57,
	U3CU3Ec__DisplayClass5_0__ctor_m19D75EEBEE00298753BEAC055ADAF29425DA044B,
	U3CU3Ec__DisplayClass5_0_U3CLogInWithAuthDataTaskAsyncU3Eb__0_mF0D7E9E23F2F1BA4D2D528A85CA65796131E10F2,
	U3CU3Ec__DisplayClass6_0__ctor_m57A9C06ED8982317A28337173844CC0ACF7D5045,
	U3CU3Ec__DisplayClass6_0_U3CSignUpTaskAsyncU3Eb__0_m8828946194A8230D8EE6C08E1F7F9D6AE57E6D3B,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CommonConstant__cctor_m6FC2F00CE3E9FD701029E3E350BFF76FC51DDAD7,
	ExtensionsClass_GetTypeInfo_m204CAF3A1FFCB24742075BD4CAF3429387BA962E,
	ExtensionsClass_IsPrimitive_m33944F7BD8D98ABDC2DA4E761CDEC75E7E9A7E9F,
	NCMBAddOperation__ctor_m3D74C3EB8055FB19C4910157B4F33550326CB87F,
	NCMBAddOperation_Encode_m5BCA3092EA21D279E09B20CF2BBDB7E0C9DA34A7,
	NCMBAddOperation_MergeWithPrevious_mCB716BEF1F6C66128C07F38C50811DEEB082E948,
	NCMBAddOperation_Apply_m7F10BB3F9F85136E554F0935C9CF0B2CFFB99340,
	NCMBAddUniqueOperation__ctor_m8A538D50CABF015D7F07CC243264D0A1FE1FB23A,
	NCMBAddUniqueOperation_Encode_m8C794525A5199858CBB3A0B048199F0C34315774,
	NCMBAddUniqueOperation_MergeWithPrevious_mF5A5675651C7CB6101F5C7341E273CEEB22243F2,
	NCMBAddUniqueOperation_Apply_m9A6365280C58C8503012C8A7AA5B7255833FEF26,
	NCMBClassNameAttribute_get_ClassName_mD67B6633E7C259F5C29E207E6300B0898EA99BCE,
	NCMBClassNameAttribute_set_ClassName_m5F98F9C398EA3EC87D2351EF6226FC04299D3A13,
	NCMBClassNameAttribute__ctor_m943265AE2D4753298948F6C53B3C3948214D1D8F,
	NCMBConnection__ctor_m1F93FAD147BCAFB68CCCA87E792CA8AAC6365543,
	NCMBConnection__ctor_m2B04448C56AD92DB18B7E38C81541F2D96B671DC,
	NCMBConnection__ctor_m131F77AF6465A2BEE382B3CB3AC1E44681ED691A,
	NCMBConnection_Connect_mD0C2D0ADCE0F9A1BDDD73B5D21F69ED908F6A950,
	NCMBConnection_Connect_mF0D27CB12F3FA82B8D452290034087184C4CF1CC,
	NCMBConnection__Connection_mF71ADBF17149FFF0226B8C5EAA1C426B4856988E,
	NCMBConnection__signatureCheck_mD7610DF8E74B5FBE561D349E279D05170D74333F,
	NCMBConnection_AsHex_m4C72A9343A4F13B4CB690536413898A0DEF9EA15,
	NCMBConnection__setUploadHandlerForFile_m6795ADBFB7DA8258CA91C0DEBE28ED7A102519AB,
	NCMBConnection__returnRequest_mE2F121DC5784E5A60671B2A401D1872852E359F7,
	NCMBConnection__makeSignatureHashData_m093565CC48DB70168412BBD389301E4923392320,
	NCMBConnection__makeSignature_m69DE17AC2D026D456EFA855001C349ADAF8C3B18,
	NCMBConnection__makeTimeStamp_m4D22498DFF74E57CE9DF7197BE027384D97338FB,
	NCMBConnection__checkInvalidSessionToken_m602BAF2B2BAEE049D462852088933031EFCF4917,
	NCMBConnection__checkResponseSignature_m6BB0E7A2195876EC3CC1B0F6D680E7F83925D323,
	NCMBConnection_SendRequest_m853E0EFEC6079B49731AFD8DD21FF1944CD9A25E,
	NCMBConnection__cctor_m683EBC8B76046B76756669EE10A924E038A6D20C,
	U3CSendRequestU3Ed__37__ctor_mF0B90F3722F9A84ADD92FF168F2ABDC5B513890B,
	U3CSendRequestU3Ed__37_System_IDisposable_Dispose_m539955284CBD4E5953898E35F7C192EF59005E3A,
	U3CSendRequestU3Ed__37_MoveNext_mA76D300551A9F84B5EB77ED0E24BF1C0F59BB66B,
	U3CSendRequestU3Ed__37_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mFD89908E7E692F8CC98042951C7CF5BDB3F60DD0,
	U3CSendRequestU3Ed__37_System_Collections_IEnumerator_Reset_mB7840C04BBD99F4D7DAD963397B66B7F71E33BF2,
	U3CSendRequestU3Ed__37_System_Collections_IEnumerator_get_Current_mF0E32AE1B302AA47A6CCE71B35E7042EA2FF88A7,
	NCMBDebug_Log_m9DFC269D444C3B6BBD99400EA23E359B43AE605D,
	NCMBDebug_LogWarning_m7A6F2053A309E622C082BEF8FF3AC3CBC9B06571,
	NCMBDebug_LogError_mAF72313E29BD0231B6C668D7DB2A632381649261,
	NCMBDebug_LogError_mF0C83CBEC29778712619E6F8C26BAF0402EEE40B,
	NCMBDebug_List_m4EE28648D73A9D8A01FB366F31DD6DE43794FD91,
	NULL,
	NCMBDebug__cctor_m286FF670A33A5B39B514DF67DFB6669ACF330A07,
	NCMBDeleteOperation__ctor_m47F4BDCF349F5AA0A92EC101794221D877C648EC,
	NCMBDeleteOperation_getValue_mF257567AF68F4C1DEC7D74F548F3529253AFC388,
	NCMBDeleteOperation_Encode_mC9ACD6F5C54D898D876D13D308C9CE20EA1E43D4,
	NCMBDeleteOperation_MergeWithPrevious_mB60C420F41A98D5AB2F44243B847218C560A6990,
	NCMBDeleteOperation_Apply_m98E6FDE4E74A3D5450A8B964B2F281E5D70996F4,
	NULL,
	NULL,
	NULL,
	NCMBIncrementOperation__ctor_m45CA5C337BEC59082407327FD9325EBFB707455E,
	NCMBIncrementOperation_Encode_m60E3FE51E95DF78386AC13794DB8F96BC7DDDA59,
	NCMBIncrementOperation_MergeWithPrevious_mCCEF9250AF730EA7234D6114CB2BBF627C706F73,
	NCMBIncrementOperation_Apply_m911A7A70E40E9CEDED6C5037A72BCF084FC2A71C,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NCMBRemoveOperation__ctor_m6B74AA997A820AEE2A6B44FC14EDA67B7D2ED400,
	NCMBRemoveOperation_Encode_mFE869AD8D711AB767065AA78DF5DE9DA3F5B837C,
	NCMBRemoveOperation_MergeWithPrevious_m35A557BBDE5E3000E9FFDC67B7585CD2F95F3629,
	NCMBRemoveOperation_Apply_mFE6D7607D88054CE7D4F25567A0D7E8264A82543,
	NCMBSetOperation__ctor_m4A3296DF276965EE3E2AD0412319D8DA717EA361,
	NCMBSetOperation_getValue_m10A778E1BB4D3E0238F3B45589DCD6076578ACC8,
	NCMBSetOperation_Encode_m98366CA2D36375E666BDC2D52A4AA5F80048B352,
	NCMBSetOperation_MergeWithPrevious_m9EA55F66374EB75D5CAD7EF52603F40712DD7951,
	NCMBSetOperation_Apply_m8BBC63354C98819A4F85C298B582B423B646BB06,
	NCMBUtility_GetClassName_m7B1A3A6D76F28972063547B761A1F2E36C15ED33,
	NCMBUtility_CopyDictionary_m75D33199A3C4BB47919C2326212AF247A73A85AC,
	NCMBUtility__encodeJSONObject_m8A58CE7D02BA55D6747C5AE4DC682E49F10E61D2,
	NCMBUtility__encodeAsJSONArray_m475ADCE049819B9B07373831FC396A47D555845D,
	NCMBUtility__maybeEncodeJSONObject_mAD8EE0EDE13CEFC885BEB0FAA962C8D65D1C4FFB,
	NCMBUtility_decodeJSONObject_m29F76E0017B924CA78C5DD34E2F6160752C1FEE7,
	NCMBUtility_parseDate_mF04E84D494016DC147C6E7BC3AF0EB92BFA6E765,
	NCMBUtility_encodeDate_m8BDD92B672BC92BE92D0FCD202778B23B25633E7,
	NCMBUtility_isContainerObject_mB6EDB0FB968B569703F5AE6C961FBDC18E92DB82,
	NCMBUtility__encodeString_m81719E94266783C5EA39D45F1DEAA7050FD09A83,
	NCMBUtility_unicodeUnescape_m23A5B4EFCDAFE7E2C2A2E6EFC5140B6904AA550E,
	U3CU3Ec__cctor_mB6D72F2685B909C42D626BA499F0E2A6D6DC435B,
	U3CU3Ec__ctor_m8FC99A1B9A2738CA143DF98212AF125AD3DA920C,
	U3CU3Ec_U3CunicodeUnescapeU3Eb__10_0_mC42ED9FFF002B23E73E1B67CBFB8BB59666E9020,
};
extern void NCMBGeoPoint_get_Latitude_m6D2F853B7E2A0D490CC4A2A78F94DE8FD9CBA89F_AdjustorThunk (void);
extern void NCMBGeoPoint_set_Latitude_m3ED4243D413FE6BD7E2306C46A98A081278B4994_AdjustorThunk (void);
extern void NCMBGeoPoint_get_Longitude_mA071FF72500EB9DEC3817BDAB511A35F2EE95994_AdjustorThunk (void);
extern void NCMBGeoPoint_set_Longitude_mD04AE661CCB2D10B4BEA0AC26006D2EF5EC69F83_AdjustorThunk (void);
extern void NCMBGeoPoint__ctor_m5C1631BC64BBD61E6069FF072DEE124BFF183FE8_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[5] = 
{
	{ 0x0600024A, NCMBGeoPoint_get_Latitude_m6D2F853B7E2A0D490CC4A2A78F94DE8FD9CBA89F_AdjustorThunk },
	{ 0x0600024B, NCMBGeoPoint_set_Latitude_m3ED4243D413FE6BD7E2306C46A98A081278B4994_AdjustorThunk },
	{ 0x0600024C, NCMBGeoPoint_get_Longitude_mA071FF72500EB9DEC3817BDAB511A35F2EE95994_AdjustorThunk },
	{ 0x0600024D, NCMBGeoPoint_set_Longitude_mD04AE661CCB2D10B4BEA0AC26006D2EF5EC69F83_AdjustorThunk },
	{ 0x0600024E, NCMBGeoPoint__ctor_m5C1631BC64BBD61E6069FF072DEE124BFF183FE8_AdjustorThunk },
};
static const int32_t s_InvokerIndices[1059] = 
{
	1690,
	1690,
	1690,
	1391,
	795,
	1690,
	1690,
	1690,
	1690,
	1391,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1403,
	1690,
	1403,
	1690,
	1690,
	1690,
	1690,
	2638,
	1690,
	1403,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1403,
	1690,
	1690,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1634,
	1647,
	1647,
	1620,
	711,
	1634,
	1647,
	1647,
	1620,
	1084,
	1690,
	1690,
	2638,
	1690,
	1088,
	1212,
	1088,
	1088,
	1690,
	2622,
	1690,
	862,
	710,
	843,
	1690,
	1690,
	1647,
	1403,
	1647,
	1647,
	1690,
	1647,
	1690,
	1647,
	1647,
	1690,
	1690,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1403,
	1403,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	863,
	1634,
	1647,
	1647,
	1620,
	369,
	1690,
	369,
	1690,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1690,
	1690,
	1403,
	1403,
	714,
	714,
	519,
	519,
	528,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1690,
	1088,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1690,
	1690,
	1391,
	1690,
	1690,
	1690,
	714,
	714,
	519,
	519,
	528,
	1690,
	1690,
	1690,
	1690,
	1403,
	1403,
	1690,
	1690,
	1690,
	1690,
	1403,
	1690,
	1403,
	1403,
	1403,
	1403,
	1391,
	1690,
	1690,
	1690,
	1690,
	1391,
	1690,
	1690,
	1391,
	1690,
	1690,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1403,
	1088,
	1088,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1647,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1690,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1403,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1403,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1403,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1690,
	1690,
	1403,
	1647,
	1690,
	1690,
	574,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	1690,
	1690,
	1088,
	1647,
	1690,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	2533,
	1690,
	2533,
	1403,
	1403,
	1403,
	1403,
	1403,
	2533,
	2533,
	2552,
	1403,
	2533,
	1690,
	1647,
	1647,
	1647,
	1084,
	1647,
	1647,
	1690,
	1633,
	1633,
	1647,
	1634,
	1690,
	2533,
	1403,
	1403,
	1403,
	1403,
	1403,
	2533,
	2533,
	2638,
	1690,
	2630,
	2597,
	1403,
	1403,
	2622,
	1403,
	843,
	843,
	2533,
	1403,
	2595,
	2622,
	2638,
	1690,
	2638,
	841,
	1403,
	414,
	1403,
	841,
	1403,
	414,
	1403,
	1690,
	1403,
	1403,
	1690,
	843,
	843,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1667,
	1422,
	1647,
	1403,
	1647,
	1403,
	35,
	2622,
	2595,
	2622,
	2595,
	2622,
	2595,
	2630,
	2630,
	2622,
	2595,
	2622,
	2595,
	1690,
	2044,
	2225,
	2597,
	1690,
	843,
	2638,
	1422,
	1667,
	1422,
	1667,
	1690,
	1403,
	1667,
	1422,
	1647,
	845,
	845,
	845,
	845,
	2432,
	530,
	1212,
	1212,
	1212,
	1212,
	2622,
	661,
	1647,
	2533,
	2595,
	1690,
	2533,
	2638,
	1690,
	503,
	1690,
	843,
	1690,
	1647,
	1647,
	1690,
	1690,
	1690,
	1634,
	1647,
	1647,
	1690,
	1647,
	1647,
	1690,
	529,
	841,
	1403,
	414,
	1403,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	841,
	783,
	231,
	1403,
	841,
	503,
	128,
	1403,
	841,
	503,
	128,
	1403,
	841,
	843,
	246,
	1403,
	841,
	843,
	246,
	1403,
	841,
	843,
	246,
	1403,
	1690,
	1403,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	2638,
	527,
	1647,
	1403,
	1647,
	1403,
	1690,
	1403,
	843,
	529,
	1403,
	1690,
	1403,
	1690,
	2622,
	1647,
	1690,
	503,
	1690,
	503,
	1620,
	1374,
	1620,
	1374,
	709,
	1690,
	1690,
	1403,
	1647,
	1403,
	1647,
	1403,
	1403,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	2622,
	2622,
	1647,
	783,
	1403,
	1690,
	1690,
	1088,
	843,
	843,
	1647,
	1403,
	1647,
	1403,
	1587,
	1340,
	1587,
	1340,
	1403,
	1647,
	1212,
	1403,
	1667,
	1422,
	1232,
	1667,
	2430,
	1647,
	1690,
	-1,
	1403,
	843,
	1647,
	1647,
	2556,
	1403,
	1690,
	1690,
	1690,
	843,
	843,
	1403,
	843,
	843,
	843,
	843,
	843,
	1403,
	840,
	837,
	843,
	2304,
	1647,
	1403,
	1690,
	1403,
	1690,
	1690,
	1403,
	1690,
	783,
	1403,
	1088,
	1403,
	1690,
	1212,
	2304,
	845,
	547,
	853,
	1422,
	1403,
	1403,
	1690,
	2622,
	1403,
	2533,
	2533,
	1647,
	1690,
	2638,
	1690,
	503,
	1690,
	503,
	1690,
	503,
	2638,
	1690,
	1647,
	1403,
	1647,
	1403,
	1617,
	1371,
	1667,
	1422,
	1647,
	1403,
	1667,
	1422,
	1667,
	1422,
	1588,
	1341,
	1667,
	1422,
	1647,
	1403,
	1667,
	1422,
	1667,
	1422,
	1647,
	1403,
	1587,
	1340,
	1647,
	1403,
	1690,
	1403,
	2622,
	1647,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1690,
	1403,
	843,
	1403,
	1647,
	1647,
	1647,
	2622,
	843,
	1690,
	1647,
	2638,
	1647,
	1403,
	1634,
	1391,
	1647,
	1403,
	839,
	521,
	337,
	843,
	2638,
	2638,
	1690,
	285,
	111,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	1647,
	1403,
	2622,
	1690,
	843,
	843,
	1403,
	2622,
	1647,
	2622,
	2622,
	2622,
	2622,
	783,
	1403,
	1690,
	1403,
	1403,
	1690,
	1690,
	1403,
	2595,
	2638,
	2622,
	1667,
	2595,
	2430,
	2430,
	2430,
	2216,
	2044,
	2304,
	2216,
	2430,
	2595,
	2430,
	2638,
	2595,
	2595,
	845,
	1403,
	1690,
	1403,
	1690,
	843,
	1403,
	843,
	1403,
	1212,
	1088,
	2622,
	2304,
	2533,
	2622,
	2304,
	2638,
	1690,
	503,
	1690,
	503,
	1690,
	503,
	1690,
	503,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	2638,
	1690,
	1079,
	1079,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	1690,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2304,
	-1,
	-1,
	-1,
	1690,
	1403,
	1667,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2533,
	1690,
	1403,
	1973,
	1690,
	843,
	2533,
	2533,
	2533,
	2304,
	2304,
	2533,
	2533,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	1690,
	1403,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2638,
	2533,
	2556,
	1403,
	1647,
	1088,
	414,
	1403,
	1647,
	1088,
	414,
	1647,
	1403,
	1403,
	323,
	165,
	101,
	1403,
	1403,
	1403,
	171,
	2533,
	1088,
	1647,
	1647,
	1088,
	1690,
	1403,
	335,
	2128,
	2638,
	1391,
	1690,
	1667,
	1647,
	1690,
	1647,
	2595,
	2595,
	2595,
	2430,
	2430,
	-1,
	2638,
	1690,
	1647,
	1647,
	1088,
	414,
	1647,
	1088,
	414,
	1403,
	1647,
	1088,
	414,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1403,
	1647,
	1088,
	414,
	1403,
	1647,
	1647,
	1088,
	414,
	2533,
	2430,
	2305,
	2305,
	2305,
	2533,
	2457,
	2524,
	2556,
	2533,
	2533,
	2638,
	1690,
	1088,
};
static const Il2CppTokenRangePair s_rgctxIndices[21] = 
{
	{ 0x02000088, { 4, 30 } },
	{ 0x02000089, { 34, 6 } },
	{ 0x0200008A, { 40, 3 } },
	{ 0x0200008C, { 43, 12 } },
	{ 0x020000A1, { 55, 12 } },
	{ 0x020000A3, { 74, 1 } },
	{ 0x020000A6, { 96, 2 } },
	{ 0x020000A7, { 98, 2 } },
	{ 0x020000A8, { 100, 2 } },
	{ 0x020000B6, { 124, 2 } },
	{ 0x020000B7, { 126, 2 } },
	{ 0x020000C5, { 137, 12 } },
	{ 0x0600027B, { 0, 4 } },
	{ 0x06000399, { 67, 7 } },
	{ 0x060003A1, { 75, 7 } },
	{ 0x060003A2, { 82, 7 } },
	{ 0x060003A3, { 89, 7 } },
	{ 0x060003C5, { 102, 9 } },
	{ 0x060003C6, { 111, 9 } },
	{ 0x060003C7, { 120, 4 } },
	{ 0x060003F8, { 128, 9 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[149] = 
{
	{ (Il2CppRGCTXDataType)2, 1800 },
	{ (Il2CppRGCTXDataType)3, 6763 },
	{ (Il2CppRGCTXDataType)3, 6764 },
	{ (Il2CppRGCTXDataType)3, 6765 },
	{ (Il2CppRGCTXDataType)2, 1584 },
	{ (Il2CppRGCTXDataType)3, 5391 },
	{ (Il2CppRGCTXDataType)3, 5394 },
	{ (Il2CppRGCTXDataType)3, 5395 },
	{ (Il2CppRGCTXDataType)3, 5392 },
	{ (Il2CppRGCTXDataType)2, 1783 },
	{ (Il2CppRGCTXDataType)3, 6673 },
	{ (Il2CppRGCTXDataType)3, 6683 },
	{ (Il2CppRGCTXDataType)3, 6675 },
	{ (Il2CppRGCTXDataType)3, 6677 },
	{ (Il2CppRGCTXDataType)3, 6678 },
	{ (Il2CppRGCTXDataType)3, 6674 },
	{ (Il2CppRGCTXDataType)2, 512 },
	{ (Il2CppRGCTXDataType)3, 54 },
	{ (Il2CppRGCTXDataType)3, 6680 },
	{ (Il2CppRGCTXDataType)3, 6679 },
	{ (Il2CppRGCTXDataType)3, 6682 },
	{ (Il2CppRGCTXDataType)3, 55 },
	{ (Il2CppRGCTXDataType)2, 513 },
	{ (Il2CppRGCTXDataType)3, 58 },
	{ (Il2CppRGCTXDataType)3, 59 },
	{ (Il2CppRGCTXDataType)2, 514 },
	{ (Il2CppRGCTXDataType)3, 62 },
	{ (Il2CppRGCTXDataType)3, 63 },
	{ (Il2CppRGCTXDataType)3, 5393 },
	{ (Il2CppRGCTXDataType)3, 2620 },
	{ (Il2CppRGCTXDataType)3, 2619 },
	{ (Il2CppRGCTXDataType)2, 803 },
	{ (Il2CppRGCTXDataType)3, 6676 },
	{ (Il2CppRGCTXDataType)3, 6681 },
	{ (Il2CppRGCTXDataType)2, 1578 },
	{ (Il2CppRGCTXDataType)3, 5331 },
	{ (Il2CppRGCTXDataType)3, 6688 },
	{ (Il2CppRGCTXDataType)2, 373 },
	{ (Il2CppRGCTXDataType)3, 5332 },
	{ (Il2CppRGCTXDataType)3, 6663 },
	{ (Il2CppRGCTXDataType)3, 6689 },
	{ (Il2CppRGCTXDataType)2, 374 },
	{ (Il2CppRGCTXDataType)3, 6652 },
	{ (Il2CppRGCTXDataType)3, 6769 },
	{ (Il2CppRGCTXDataType)2, 1019 },
	{ (Il2CppRGCTXDataType)3, 3796 },
	{ (Il2CppRGCTXDataType)3, 3797 },
	{ (Il2CppRGCTXDataType)2, 1796 },
	{ (Il2CppRGCTXDataType)3, 6754 },
	{ (Il2CppRGCTXDataType)3, 6755 },
	{ (Il2CppRGCTXDataType)3, 6770 },
	{ (Il2CppRGCTXDataType)2, 277 },
	{ (Il2CppRGCTXDataType)3, 6684 },
	{ (Il2CppRGCTXDataType)2, 1784 },
	{ (Il2CppRGCTXDataType)3, 6685 },
	{ (Il2CppRGCTXDataType)3, 8300 },
	{ (Il2CppRGCTXDataType)3, 5328 },
	{ (Il2CppRGCTXDataType)3, 8302 },
	{ (Il2CppRGCTXDataType)3, 8301 },
	{ (Il2CppRGCTXDataType)3, 8297 },
	{ (Il2CppRGCTXDataType)2, 1772 },
	{ (Il2CppRGCTXDataType)3, 6661 },
	{ (Il2CppRGCTXDataType)3, 6687 },
	{ (Il2CppRGCTXDataType)3, 8298 },
	{ (Il2CppRGCTXDataType)3, 6686 },
	{ (Il2CppRGCTXDataType)2, 1785 },
	{ (Il2CppRGCTXDataType)3, 8299 },
	{ (Il2CppRGCTXDataType)2, 505 },
	{ (Il2CppRGCTXDataType)3, 24 },
	{ (Il2CppRGCTXDataType)3, 25 },
	{ (Il2CppRGCTXDataType)2, 1768 },
	{ (Il2CppRGCTXDataType)3, 6659 },
	{ (Il2CppRGCTXDataType)3, 6669 },
	{ (Il2CppRGCTXDataType)3, 26 },
	{ (Il2CppRGCTXDataType)3, 6662 },
	{ (Il2CppRGCTXDataType)2, 506 },
	{ (Il2CppRGCTXDataType)3, 27 },
	{ (Il2CppRGCTXDataType)2, 1954 },
	{ (Il2CppRGCTXDataType)3, 7653 },
	{ (Il2CppRGCTXDataType)2, 139 },
	{ (Il2CppRGCTXDataType)3, 28 },
	{ (Il2CppRGCTXDataType)3, 7654 },
	{ (Il2CppRGCTXDataType)2, 508 },
	{ (Il2CppRGCTXDataType)3, 38 },
	{ (Il2CppRGCTXDataType)2, 1955 },
	{ (Il2CppRGCTXDataType)3, 7655 },
	{ (Il2CppRGCTXDataType)2, 140 },
	{ (Il2CppRGCTXDataType)3, 39 },
	{ (Il2CppRGCTXDataType)3, 7656 },
	{ (Il2CppRGCTXDataType)2, 510 },
	{ (Il2CppRGCTXDataType)3, 46 },
	{ (Il2CppRGCTXDataType)2, 1953 },
	{ (Il2CppRGCTXDataType)3, 7651 },
	{ (Il2CppRGCTXDataType)2, 138 },
	{ (Il2CppRGCTXDataType)3, 47 },
	{ (Il2CppRGCTXDataType)3, 7652 },
	{ (Il2CppRGCTXDataType)3, 7662 },
	{ (Il2CppRGCTXDataType)3, 7663 },
	{ (Il2CppRGCTXDataType)3, 7664 },
	{ (Il2CppRGCTXDataType)3, 7665 },
	{ (Il2CppRGCTXDataType)3, 7666 },
	{ (Il2CppRGCTXDataType)3, 7667 },
	{ (Il2CppRGCTXDataType)2, 507 },
	{ (Il2CppRGCTXDataType)3, 29 },
	{ (Il2CppRGCTXDataType)2, 1961 },
	{ (Il2CppRGCTXDataType)3, 7670 },
	{ (Il2CppRGCTXDataType)3, 30 },
	{ (Il2CppRGCTXDataType)2, 1770 },
	{ (Il2CppRGCTXDataType)3, 6660 },
	{ (Il2CppRGCTXDataType)3, 6670 },
	{ (Il2CppRGCTXDataType)3, 7671 },
	{ (Il2CppRGCTXDataType)2, 509 },
	{ (Il2CppRGCTXDataType)3, 40 },
	{ (Il2CppRGCTXDataType)2, 1956 },
	{ (Il2CppRGCTXDataType)3, 7657 },
	{ (Il2CppRGCTXDataType)3, 41 },
	{ (Il2CppRGCTXDataType)2, 1763 },
	{ (Il2CppRGCTXDataType)3, 6651 },
	{ (Il2CppRGCTXDataType)3, 6672 },
	{ (Il2CppRGCTXDataType)3, 7658 },
	{ (Il2CppRGCTXDataType)2, 511 },
	{ (Il2CppRGCTXDataType)3, 48 },
	{ (Il2CppRGCTXDataType)3, 49 },
	{ (Il2CppRGCTXDataType)3, 6671 },
	{ (Il2CppRGCTXDataType)3, 7672 },
	{ (Il2CppRGCTXDataType)3, 7673 },
	{ (Il2CppRGCTXDataType)3, 7668 },
	{ (Il2CppRGCTXDataType)3, 7669 },
	{ (Il2CppRGCTXDataType)3, 952 },
	{ (Il2CppRGCTXDataType)3, 2869 },
	{ (Il2CppRGCTXDataType)3, 5035 },
	{ (Il2CppRGCTXDataType)2, 201 },
	{ (Il2CppRGCTXDataType)3, 5036 },
	{ (Il2CppRGCTXDataType)2, 407 },
	{ (Il2CppRGCTXDataType)3, 953 },
	{ (Il2CppRGCTXDataType)3, 2868 },
	{ (Il2CppRGCTXDataType)2, 806 },
	{ (Il2CppRGCTXDataType)3, 3795 },
	{ (Il2CppRGCTXDataType)3, 2596 },
	{ (Il2CppRGCTXDataType)2, 276 },
	{ (Il2CppRGCTXDataType)3, 2595 },
	{ (Il2CppRGCTXDataType)2, 798 },
	{ (Il2CppRGCTXDataType)3, 6753 },
	{ (Il2CppRGCTXDataType)2, 1795 },
	{ (Il2CppRGCTXDataType)3, 6752 },
	{ (Il2CppRGCTXDataType)2, 1801 },
	{ (Il2CppRGCTXDataType)3, 6766 },
	{ (Il2CppRGCTXDataType)3, 6768 },
	{ (Il2CppRGCTXDataType)3, 6767 },
};
extern const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	1059,
	s_methodPointers,
	5,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	21,
	s_rgctxIndices,
	149,
	s_rgctxValues,
	NULL,
	g_AssemblyU2DCSharp_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
