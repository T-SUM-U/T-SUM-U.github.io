【标题】N10
【版本】1.2
【作者】T_SUM_U

禁止私自转载、加工。
在进行视频制作和其他二次制作时，应同时提及以下网址。
https://t-sum-u.github.io/games/n10

Copyright (C) 2021 T_SUM_U All Right Reserved.

【联系】tzsumhu@gmail.com

＜更新记录＞
2021/05/02:Ver1.0
发布

2021/05/04:Ver1.1
添加推文机能

2022/06/14:Ver1.2
改善UI
防止破音
小的改善

2022/06/15:Ver1.3
修改推文的网址