【　タイトル】N10
【バージョン】1.2
【　作　者　】T_SUM_U

無断転載、複製を禁じます。
動画制作などの二次創作を行う際は下記のURLを併記してください。
https://t-sum-u.github.io/games/n10

Copyright (C) 2021 T_SUM_U All Right Reserved.

【連絡先】tzsumhu@gmail.com

＜更新履歴＞
2021/05/02:Ver1.0
公開

2021/05/04:Ver1.1
ツイート実装

2022/06/14:Ver1.2
UI改善
音割れ防止処理を追加
その他細かな改善

2022/06/15:Ver1.3
ツイートのURLを修正