【 Title 】 N10
【Version】1.2
【 Author】T_SUM_U

Unauthorised reproduction or reprinting is prohibited.
When creating secondary works such as video production, please include the following URL.
https://t-sum-u.github.io/games/n10

Copyright (C) 2021 T_SUM_U All Right Reserved.

【Contact】tzsumhu@gmail.com

<Update log>
2021/05/02: Ver 1.0
Published

2021/05/04:Ver1.1
Tweet implementation

2022/06/14:Ver1.2
UI improvement
Sound cracking prevention processing added
Other minor improvements

2022/06/15:Ver1.3
Fixed URL of tweets