﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void MainGameManager::Start()
extern void MainGameManager_Start_m2F565E036D5616568F5DD11B6EF25E8D06D729FA (void);
// 0x00000002 System.Void MainGameManager::Update()
extern void MainGameManager_Update_mADE244B8A04904537378FCB5A02B12BE123FB327 (void);
// 0x00000003 System.Void MainGameManager::generateStage()
extern void MainGameManager_generateStage_mACCE2CAB40727A6ECDFC550150C699C036FEEB97 (void);
// 0x00000004 System.Void MainGameManager::goNextStage()
extern void MainGameManager_goNextStage_m941FBAEA01264E29001D851839F02FE02665DA7E (void);
// 0x00000005 System.Void MainGameManager::goTitle()
extern void MainGameManager_goTitle_m8B8D5AC60CC176DDCC99E736E9AED3C6746DDBAD (void);
// 0x00000006 System.Void MainGameManager::loadSelf()
extern void MainGameManager_loadSelf_mCAD29627F78B89D8EFB412D3B4A796EAC7DECB79 (void);
// 0x00000007 System.Void MainGameManager::setCanvesActive(System.Boolean)
extern void MainGameManager_setCanvesActive_mB2D2B2AEB306B5063502C824E457620DEEEACDA9 (void);
// 0x00000008 System.Void MainGameManager::switchAutoRetry()
extern void MainGameManager_switchAutoRetry_m09C893F433E0685D31857B5B53A57B2EC22FFA3E (void);
// 0x00000009 System.Void MainGameManager::switchPause()
extern void MainGameManager_switchPause_mA34A3C637F6A5919EA14A8F79321BE4A8C277CAE (void);
// 0x0000000A System.Void MainGameManager::.ctor()
extern void MainGameManager__ctor_mD5EF849C53422DCB7971DD3CA76A5360BAE6D648 (void);
// 0x0000000B System.Void MainGameManager::.cctor()
extern void MainGameManager__cctor_m48B9999F35461BE7E81987118B877D20775F25E9 (void);
// 0x0000000C System.Void MusicManager::Start()
extern void MusicManager_Start_m1F72199B30EAA11A29F14D822F58533A045DEE6C (void);
// 0x0000000D System.Void MusicManager::.ctor()
extern void MusicManager__ctor_m94AF2B626CF1C068F5FA6D685B09D615BC0558F1 (void);
// 0x0000000E System.Void PlayerManager::Start()
extern void PlayerManager_Start_mA587FD881326FC1FBCEE2699E54A8A0ACCF83455 (void);
// 0x0000000F System.Void PlayerManager::Update()
extern void PlayerManager_Update_mA0EE0A117D34258508935E958CF715FD930D066A (void);
// 0x00000010 System.Void PlayerManager::OnCollisionEnter(UnityEngine.Collision)
extern void PlayerManager_OnCollisionEnter_m36092D4986E0F456A95F641B33AC6D57790331D0 (void);
// 0x00000011 System.Void PlayerManager::OnTriggerEnter(UnityEngine.Collider)
extern void PlayerManager_OnTriggerEnter_m63B072A77CF38CDCCD90C4C5D59DC443B79F917C (void);
// 0x00000012 System.Void PlayerManager::LoadMainScene()
extern void PlayerManager_LoadMainScene_mD99CF480981DE75C61B5E0ECDB28DB5D02207D05 (void);
// 0x00000013 System.Void PlayerManager::loadStage(System.Int32)
extern void PlayerManager_loadStage_mEA31662275CFD57A213EA40C1DDD20599709CC00 (void);
// 0x00000014 System.Void PlayerManager::challengeManager(System.Int32)
extern void PlayerManager_challengeManager_m3B695215655DAF690D60D26DFD87A05C36635652 (void);
// 0x00000015 System.Void PlayerManager::savechallenge(System.Int32)
extern void PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC (void);
// 0x00000016 System.Void PlayerManager::resetChallengeFlags()
extern void PlayerManager_resetChallengeFlags_m4CA13CBC872BF5439D424C23371D097C883D2986 (void);
// 0x00000017 System.Void PlayerManager::.ctor()
extern void PlayerManager__ctor_m4C7CA12A8243D6CA73C1EA65B361E7B717070471 (void);
// 0x00000018 System.Void Sinus::Update()
extern void Sinus_Update_m300775C3067A37B6178D41E1CBC37AC943A6596C (void);
// 0x00000019 System.Void Sinus::OnAudioFilterRead(System.Single[],System.Int32)
extern void Sinus_OnAudioFilterRead_mE68358DF4BDC9EDD2579CC6F47CE390CC83561C3 (void);
// 0x0000001A System.Void Sinus::.ctor()
extern void Sinus__ctor_m1BC3745EA32E5938E775EC28811534DC44D6B752 (void);
// 0x0000001B System.Void SoundPlaySystem::SetSoundData(UnityEngine.AudioClip)
extern void SoundPlaySystem_SetSoundData_mC95E81C797E4E7D7210309AE5D3B8687EAB0BB9A (void);
// 0x0000001C System.Void SoundPlaySystem::OnAudioFilterRead(System.Single[],System.Int32)
extern void SoundPlaySystem_OnAudioFilterRead_m061FC034774FEA48CA4A5DAC3308E1F48AA240F4 (void);
// 0x0000001D System.Void SoundPlaySystem::.ctor()
extern void SoundPlaySystem__ctor_m6D117931BD6F4A62D1218EBC1E6B103FE6B269FA (void);
// 0x0000001E System.Void SoundSettingManager::Start()
extern void SoundSettingManager_Start_mF0B4919F9BC3631E3D1D19AEE8627041A9C27592 (void);
// 0x0000001F System.Void SoundSettingManager::SwitchSetting()
extern void SoundSettingManager_SwitchSetting_mFAE5529A141B1DB639333B99B6E70D8FE0AF9A68 (void);
// 0x00000020 System.Void SoundSettingManager::ChangeSoundVolume()
extern void SoundSettingManager_ChangeSoundVolume_mFC169E6974C7D9D7084966E72D51C50C772E209A (void);
// 0x00000021 System.Void SoundSettingManager::.ctor()
extern void SoundSettingManager__ctor_mDE9BF93657572442CE4ED24BFEE306F8118BE54B (void);
// 0x00000022 stageData datas::getStageData(System.Int32)
extern void datas_getStageData_m0D19D87CDF47A697BFB2A35294B70E4B221DEA2F (void);
// 0x00000023 System.Void datas::goStage(System.Int32)
extern void datas_goStage_m25C4F57045373560EC4458957FEF4E28A2E43D09 (void);
// 0x00000024 System.Void datas::.ctor()
extern void datas__ctor_mE6BBE9C089031DEEA352E2A6D402729C8D064E8D (void);
// 0x00000025 System.Void TitleManager::Awake()
extern void TitleManager_Awake_mF129104373A2C819440233C959692D0AE46284B9 (void);
// 0x00000026 System.Void TitleManager::Start()
extern void TitleManager_Start_mB1BDED26067331336418D8C8F760161E62F96224 (void);
// 0x00000027 System.Void TitleManager::Update()
extern void TitleManager_Update_m3D4B2483A33278FCFEB981AA66D621FDF1A652C7 (void);
// 0x00000028 System.Void TitleManager::onStageSelected(System.Int32)
extern void TitleManager_onStageSelected_m6A34F2AC410BA4F9EE6E0863D88DECA94A0C8BCD (void);
// 0x00000029 System.Void TitleManager::checkData()
extern void TitleManager_checkData_m02820912FEEAD00B0B83CBFD98B4F0B1114AC945 (void);
// 0x0000002A System.Void TitleManager::setRTA()
extern void TitleManager_setRTA_mD882541C9B3BFE96F02EAE79F49263D1BE606367 (void);
// 0x0000002B System.Void TitleManager::switchCanvas()
extern void TitleManager_switchCanvas_mCBA6B182DE57659C28603C9CE8EF0EC04173A883 (void);
// 0x0000002C System.Void TitleManager::setChallengeLabel(System.Int32)
extern void TitleManager_setChallengeLabel_m4BB922BE830CBA6E275AC7449A2DD0454A91D5CD (void);
// 0x0000002D System.Void TitleManager::clearChallengeLabel()
extern void TitleManager_clearChallengeLabel_m2535E499AD7E402F0D39BA01D9831CB05C10773E (void);
// 0x0000002E System.Void TitleManager::switchCredit()
extern void TitleManager_switchCredit_m0B27C6EE30E7F4BF36C236C6E40E983D70542B40 (void);
// 0x0000002F System.Void TitleManager::.ctor()
extern void TitleManager__ctor_m0D14731249E3B6D0846A587A421CAE4FAD2056D0 (void);
// 0x00000030 System.Void UniversalGravity::Start()
extern void UniversalGravity_Start_m335253E1A5593A42D276E963A17437DAC7312B10 (void);
// 0x00000031 System.Void UniversalGravity::FixedUpdate()
extern void UniversalGravity_FixedUpdate_mE3584B3DB200CB655417B33AD139D51CC56213FB (void);
// 0x00000032 System.Void UniversalGravity::GetAstroObjs()
extern void UniversalGravity_GetAstroObjs_mAC081AB221E0E3D34E9633FE0E4A8002ADF22EAA (void);
// 0x00000033 System.Void UniversalGravity::changeMode()
extern void UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4 (void);
// 0x00000034 System.Void UniversalGravity::.ctor()
extern void UniversalGravity__ctor_mCB784BD312F5B3C9907DFAF1543DBDF7C640910D (void);
static Il2CppMethodPointer s_methodPointers[52] = 
{
	MainGameManager_Start_m2F565E036D5616568F5DD11B6EF25E8D06D729FA,
	MainGameManager_Update_mADE244B8A04904537378FCB5A02B12BE123FB327,
	MainGameManager_generateStage_mACCE2CAB40727A6ECDFC550150C699C036FEEB97,
	MainGameManager_goNextStage_m941FBAEA01264E29001D851839F02FE02665DA7E,
	MainGameManager_goTitle_m8B8D5AC60CC176DDCC99E736E9AED3C6746DDBAD,
	MainGameManager_loadSelf_mCAD29627F78B89D8EFB412D3B4A796EAC7DECB79,
	MainGameManager_setCanvesActive_mB2D2B2AEB306B5063502C824E457620DEEEACDA9,
	MainGameManager_switchAutoRetry_m09C893F433E0685D31857B5B53A57B2EC22FFA3E,
	MainGameManager_switchPause_mA34A3C637F6A5919EA14A8F79321BE4A8C277CAE,
	MainGameManager__ctor_mD5EF849C53422DCB7971DD3CA76A5360BAE6D648,
	MainGameManager__cctor_m48B9999F35461BE7E81987118B877D20775F25E9,
	MusicManager_Start_m1F72199B30EAA11A29F14D822F58533A045DEE6C,
	MusicManager__ctor_m94AF2B626CF1C068F5FA6D685B09D615BC0558F1,
	PlayerManager_Start_mA587FD881326FC1FBCEE2699E54A8A0ACCF83455,
	PlayerManager_Update_mA0EE0A117D34258508935E958CF715FD930D066A,
	PlayerManager_OnCollisionEnter_m36092D4986E0F456A95F641B33AC6D57790331D0,
	PlayerManager_OnTriggerEnter_m63B072A77CF38CDCCD90C4C5D59DC443B79F917C,
	PlayerManager_LoadMainScene_mD99CF480981DE75C61B5E0ECDB28DB5D02207D05,
	PlayerManager_loadStage_mEA31662275CFD57A213EA40C1DDD20599709CC00,
	PlayerManager_challengeManager_m3B695215655DAF690D60D26DFD87A05C36635652,
	PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC,
	PlayerManager_resetChallengeFlags_m4CA13CBC872BF5439D424C23371D097C883D2986,
	PlayerManager__ctor_m4C7CA12A8243D6CA73C1EA65B361E7B717070471,
	Sinus_Update_m300775C3067A37B6178D41E1CBC37AC943A6596C,
	Sinus_OnAudioFilterRead_mE68358DF4BDC9EDD2579CC6F47CE390CC83561C3,
	Sinus__ctor_m1BC3745EA32E5938E775EC28811534DC44D6B752,
	SoundPlaySystem_SetSoundData_mC95E81C797E4E7D7210309AE5D3B8687EAB0BB9A,
	SoundPlaySystem_OnAudioFilterRead_m061FC034774FEA48CA4A5DAC3308E1F48AA240F4,
	SoundPlaySystem__ctor_m6D117931BD6F4A62D1218EBC1E6B103FE6B269FA,
	SoundSettingManager_Start_mF0B4919F9BC3631E3D1D19AEE8627041A9C27592,
	SoundSettingManager_SwitchSetting_mFAE5529A141B1DB639333B99B6E70D8FE0AF9A68,
	SoundSettingManager_ChangeSoundVolume_mFC169E6974C7D9D7084966E72D51C50C772E209A,
	SoundSettingManager__ctor_mDE9BF93657572442CE4ED24BFEE306F8118BE54B,
	datas_getStageData_m0D19D87CDF47A697BFB2A35294B70E4B221DEA2F,
	datas_goStage_m25C4F57045373560EC4458957FEF4E28A2E43D09,
	datas__ctor_mE6BBE9C089031DEEA352E2A6D402729C8D064E8D,
	TitleManager_Awake_mF129104373A2C819440233C959692D0AE46284B9,
	TitleManager_Start_mB1BDED26067331336418D8C8F760161E62F96224,
	TitleManager_Update_m3D4B2483A33278FCFEB981AA66D621FDF1A652C7,
	TitleManager_onStageSelected_m6A34F2AC410BA4F9EE6E0863D88DECA94A0C8BCD,
	TitleManager_checkData_m02820912FEEAD00B0B83CBFD98B4F0B1114AC945,
	TitleManager_setRTA_mD882541C9B3BFE96F02EAE79F49263D1BE606367,
	TitleManager_switchCanvas_mCBA6B182DE57659C28603C9CE8EF0EC04173A883,
	TitleManager_setChallengeLabel_m4BB922BE830CBA6E275AC7449A2DD0454A91D5CD,
	TitleManager_clearChallengeLabel_m2535E499AD7E402F0D39BA01D9831CB05C10773E,
	TitleManager_switchCredit_m0B27C6EE30E7F4BF36C236C6E40E983D70542B40,
	TitleManager__ctor_m0D14731249E3B6D0846A587A421CAE4FAD2056D0,
	UniversalGravity_Start_m335253E1A5593A42D276E963A17437DAC7312B10,
	UniversalGravity_FixedUpdate_mE3584B3DB200CB655417B33AD139D51CC56213FB,
	UniversalGravity_GetAstroObjs_mAC081AB221E0E3D34E9633FE0E4A8002ADF22EAA,
	UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4,
	UniversalGravity__ctor_mCB784BD312F5B3C9907DFAF1543DBDF7C640910D,
};
static const int32_t s_InvokerIndices[52] = 
{
	1246,
	1246,
	1246,
	1246,
	1246,
	1246,
	1076,
	1246,
	1246,
	1246,
	2089,
	1246,
	1246,
	1246,
	1246,
	1059,
	1059,
	1246,
	1048,
	1048,
	1048,
	1246,
	1246,
	1246,
	686,
	1246,
	1059,
	686,
	1246,
	1246,
	1246,
	1246,
	1246,
	1111,
	1048,
	1246,
	1246,
	1246,
	1246,
	1048,
	1246,
	1246,
	1246,
	1048,
	1246,
	1246,
	1246,
	1246,
	1246,
	1246,
	1246,
	1246,
};
extern const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	52,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_AssemblyU2DCSharp_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
