﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>


template <typename R>
struct VirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
struct VirtActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1>
struct VirtActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};

// System.Action`1<System.Object>
struct Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC;
// System.Comparison`1<UnityEngine.EventSystems.RaycastResult>
struct Comparison_1_t47C8B3739FFDD51D29B281A2FD2C36A57DDF9E38;
// System.Func`2<System.Object,System.Int32>
struct Func_2_t0CEE9D1C856153BA9C23BB9D7E929D577AF37A2C;
// System.Func`2<System.Object,System.String>
struct Func_2_t060A650AB95DEF14D4F579FA5999ACEFEEE0FD82;
// System.Collections.Generic.List`1<UnityEngine.EventSystems.BaseInputModule>
struct List_1_t39946D94B66FAE9B0DED5D3A84AD116AF9DDDCC1;
// System.Collections.Generic.List`1<UnityEngine.CanvasGroup>
struct List_1_t34AA4AF4E7352129CA58045901530E41445AC16D;
// System.Collections.Generic.List`1<UnityEngine.EventSystems.EventSystem>
struct List_1_tEF3D2378B547F18609950BEABF54AF34FBBC9733;
// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween>
struct TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3;
// System.Byte[]
struct ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726;
// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
// UnityEngine.ContactPoint[]
struct ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B;
// UnityEngine.GameObject[]
struct GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642;
// System.Object[]
struct ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE;
// UnityEngine.Rigidbody[]
struct RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B;
// UnityEngine.UI.Selectable[]
struct SelectableU5BU5D_tECF9F5BDBF0652A937D18F10C883EFDAE2E62535;
// System.Single[]
struct SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA;
// System.String[]
struct StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A;
// UnityEngine.UIVertex[]
struct UIVertexU5BU5D_tE3D523C48DFEBC775876720DE2539A79FB7E5E5A;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4;
// UnityEngine.UI.AnimationTriggers
struct AnimationTriggers_tF38CA7FA631709E096B57D732668D86081F44C11;
// UnityEngine.AudioClip
struct AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE;
// UnityEngine.EventSystems.BaseEventData
struct BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E;
// UnityEngine.EventSystems.BaseInputModule
struct BaseInputModule_t395DEB45C225A941B2C831CBDB000A23E5899924;
// UnityEngine.UI.Button
struct Button_tA893FC15AB26E1439AC25BDCA7079530587BB65D;
// UnityEngine.Canvas
struct Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA;
// UnityEngine.CanvasRenderer
struct CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E;
// System.Globalization.CodePageDataItem
struct CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E;
// UnityEngine.Collider
struct Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02;
// UnityEngine.Collision
struct Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0;
// UnityEngine.Component
struct Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684;
// System.Text.Decoder
struct Decoder_t91B2ED8AEC25AA24D23A00265203BE992B12C370;
// System.Text.DecoderFallback
struct DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D;
// System.IO.DirectoryInfo
struct DirectoryInfo_t4EF3610F45F0D234800D01ADA8F3F476AE0CF5CD;
// System.Text.Encoder
struct Encoder_t5095F24D3B1D0F70D08762B980731B9F1ADEE56A;
// System.Text.EncoderFallback
struct EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4;
// System.Text.Encoding
struct Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827;
// UnityEngine.EventSystems.EventSystem
struct EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C;
// UnityEngine.UI.FontData
struct FontData_t0F1E9B3ED8136CD40782AC9A6AFB69CAD127C738;
// UnityEngine.GameObject
struct GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319;
// UnityEngine.UI.Graphic
struct Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24;
// System.Collections.Hashtable
struct Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC;
// System.IFormatProvider
struct IFormatProvider_tF2AECC4B14F41D36718920D67F930CED940412DF;
// UnityEngine.UI.Image
struct Image_t4021FF27176E44BFEDDCBE43C7FE6B713EC70D3C;
// MainGameManager
struct MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4;
// UnityEngine.Material
struct Material_t8927C00353A72755313F046D0CE85178AE8218EE;
// UnityEngine.Mesh
struct Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6;
// UnityEngine.MonoBehaviour
struct MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A;
// MusicManager
struct MusicManager_tFC710AB7CA46AF229C4B937E8F9E0119AE59182D;
// UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A;
// PlayerManager
struct PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48;
// UnityEngine.UI.RectMask2D
struct RectMask2D_tD909811991B341D752E4C978C89EFB80FA7A2B15;
// UnityEngine.RectTransform
struct RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072;
// UnityEngine.Renderer
struct Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C;
// UnityEngine.Rigidbody
struct Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A;
// UnityEngine.UI.Selectable
struct Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD;
// Sinus
struct Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5;
// UnityEngine.UI.Slider
struct Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A;
// SoundPlaySystem
struct SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E;
// SoundSettingManager
struct SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12;
// UnityEngine.Sprite
struct Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9;
// System.IO.Stream
struct Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB;
// System.IO.StreamReader
struct StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3;
// System.IO.StreamWriter
struct StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6;
// System.String
struct String_t;
// System.Text.StringBuilder
struct StringBuilder_t;
// System.Threading.Tasks.Task
struct Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60;
// UnityEngine.UI.Text
struct Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1;
// UnityEngine.TextGenerator
struct TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70;
// UnityEngine.Texture2D
struct Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF;
// TitleManager
struct TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4;
// UnityEngine.UI.Toggle
struct Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E;
// UnityEngine.UI.ToggleGroup
struct ToggleGroup_t12E1DFDEB3FFD979A20299EE42A94388AC619C95;
// UnityEngine.TrailRenderer
struct TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01;
// UnityEngine.Transform
struct Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1;
// UnityEngine.Events.UnityAction
struct UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099;
// UniversalGravity
struct UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9;
// UnityEngine.UI.VertexHelper
struct VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55;
// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5;
// datas
struct datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0;
// UnityEngine.AudioClip/PCMReaderCallback
struct PCMReaderCallback_t9CA1437D36509A9FAC5EDD8FF2BC3259C24D0E0B;
// UnityEngine.AudioClip/PCMSetPositionCallback
struct PCMSetPositionCallback_tBDD99E7C0697687F1E7B06CDD5DE444A3709CF4C;
// UnityEngine.UI.Button/ButtonClickedEvent
struct ButtonClickedEvent_tE6D6D94ED8100451CF00D2BED1FB2253F37BB14F;
// UnityEngine.UI.MaskableGraphic/CullStateChangedEvent
struct CullStateChangedEvent_t9B69755DEBEF041C3CC15C3604610BDD72856BD4;
// UnityEngine.UI.Slider/SliderEvent
struct SliderEvent_t312D89AE02E00DD965D68D6F7F813BDF455FD780;
// UnityEngine.UI.Toggle/ToggleEvent
struct ToggleEvent_t7B9EFE80B7D7F16F3E7B8FA75FEF45B00E0C0075;

IL2CPP_EXTERN_C RuntimeClass* Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Debug_tEB68BCBEB8EFD60F8043C67146DC05E7F50F374B_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StringBuilder_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral0375962E83E838E0A86F6EB54ECAD5AD338AF627;
IL2CPP_EXTERN_C String_t* _stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA;
IL2CPP_EXTERN_C String_t* _stringLiteral095F11D31FCE39BCB9C4F377E423D637323A437F;
IL2CPP_EXTERN_C String_t* _stringLiteral097BDACD66FAD850156FED9F725F9CC4873080ED;
IL2CPP_EXTERN_C String_t* _stringLiteral09BC0067B93715551994AF937074AACB2BC46F45;
IL2CPP_EXTERN_C String_t* _stringLiteral181EA86C68EBB2997047E26C99EDFF7B17E18DBB;
IL2CPP_EXTERN_C String_t* _stringLiteral18DFC76CE558A95E4B965CF15DB25F8772BAD6BE;
IL2CPP_EXTERN_C String_t* _stringLiteral1AE3DFDF095F1A9D00C82F9DE68A906D657A1BA5;
IL2CPP_EXTERN_C String_t* _stringLiteral2342ED095E8746444A44CFCD5D8ACA13F0E7EEF8;
IL2CPP_EXTERN_C String_t* _stringLiteral27F8F1C579FF819E3522ABC61DA3B4E399DCF184;
IL2CPP_EXTERN_C String_t* _stringLiteral28A00C6C2538607194DCD2548EF0DFB07D324A14;
IL2CPP_EXTERN_C String_t* _stringLiteral2B86D66477376A42A49B3CD3983CF53BEF4E55A0;
IL2CPP_EXTERN_C String_t* _stringLiteral2F0971EEB34F669DA121AFE1DB3967AE709E3CE6;
IL2CPP_EXTERN_C String_t* _stringLiteral2FC0DC959FF52C9FB2EAD49C873F17BD1F1D0689;
IL2CPP_EXTERN_C String_t* _stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0;
IL2CPP_EXTERN_C String_t* _stringLiteral32FD1C2CD95565F20E77CF2BAF251A2BBE2177E4;
IL2CPP_EXTERN_C String_t* _stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D;
IL2CPP_EXTERN_C String_t* _stringLiteral40E83ACCE0D042A519B971EC5FA530E519DEAD8E;
IL2CPP_EXTERN_C String_t* _stringLiteral420E59722344B7BBF7D2AD7BAADC29DE98149298;
IL2CPP_EXTERN_C String_t* _stringLiteral43D9F7275E270582D83C15A95CEE78A24DFA363A;
IL2CPP_EXTERN_C String_t* _stringLiteral458F0853AD35AB3C88EE592FD6A04E76A9C9C22A;
IL2CPP_EXTERN_C String_t* _stringLiteral53EF8123784329433012CFAFBE65A775DA74906E;
IL2CPP_EXTERN_C String_t* _stringLiteral591B0174416DB6050EA3BA13A1D32B8C6FE72F0C;
IL2CPP_EXTERN_C String_t* _stringLiteral6016AF1CE72794A6C2FF2B0D3605A9649CE69719;
IL2CPP_EXTERN_C String_t* _stringLiteral6BA2B8FA5CFC29F65A5DDF3DDB50406BF7EF826A;
IL2CPP_EXTERN_C String_t* _stringLiteral7374AAEDBB17A9B4E1F4E7C44C8B168FF56495B3;
IL2CPP_EXTERN_C String_t* _stringLiteral751ED465D17C903AD85E4E0D66A7122959CA8A62;
IL2CPP_EXTERN_C String_t* _stringLiteral7649AEE062EE200D5810926162F39A75BCEE5287;
IL2CPP_EXTERN_C String_t* _stringLiteral7831B7715AA09703BEA6DAB66D910E60EB689C3F;
IL2CPP_EXTERN_C String_t* _stringLiteral7D0383344321A8EB9F670DF59AB1502AE480A331;
IL2CPP_EXTERN_C String_t* _stringLiteral81C6B56546B7CAF0C90DC134E1582EEDDD65C2F2;
IL2CPP_EXTERN_C String_t* _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D;
IL2CPP_EXTERN_C String_t* _stringLiteral892E1AB895E27AFF8AB5474D79F8D5C76BE64F01;
IL2CPP_EXTERN_C String_t* _stringLiteral8BB6FD18AC8C106620676F49BEB172C77C1549CA;
IL2CPP_EXTERN_C String_t* _stringLiteral920ABEDD47410DA9C7554955C460817D580178ED;
IL2CPP_EXTERN_C String_t* _stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1;
IL2CPP_EXTERN_C String_t* _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3;
IL2CPP_EXTERN_C String_t* _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D;
IL2CPP_EXTERN_C String_t* _stringLiteral9B469AD8D3831F081E8E4B97777919CC5F65D853;
IL2CPP_EXTERN_C String_t* _stringLiteral9CB11ACA5A88BD2B601F12BC6D2090EB273F7DAB;
IL2CPP_EXTERN_C String_t* _stringLiteral9FCD15851E70A26784E98AFC64621C56BC0BBFD0;
IL2CPP_EXTERN_C String_t* _stringLiteralA251A204B5A2874A8CD540A624F660C7638CA9F5;
IL2CPP_EXTERN_C String_t* _stringLiteralA461C945895BA5F3EBE497F50FE9845AAA6F3782;
IL2CPP_EXTERN_C String_t* _stringLiteralAC0D425DEDD91FCD849100926AE866C23736FB5A;
IL2CPP_EXTERN_C String_t* _stringLiteralB20BB0B2D8D418EF3CDB10A09869E584A012E8CE;
IL2CPP_EXTERN_C String_t* _stringLiteralB60DAB3032F143FD7C8052FD9EA179FE7A4F18BB;
IL2CPP_EXTERN_C String_t* _stringLiteralC8EA0F7A3B3C7A6868670228490AEA985E92164D;
IL2CPP_EXTERN_C String_t* _stringLiteralCAF8804297181FF007CA835529DD4477CFD94A70;
IL2CPP_EXTERN_C String_t* _stringLiteralCE863626383155D02291456632E72C0FBEC22C3C;
IL2CPP_EXTERN_C String_t* _stringLiteralD131397F1FB7BFF3B5A8A63CC32384739F6D42AC;
IL2CPP_EXTERN_C String_t* _stringLiteralD9AB4BD1D01DB5E2C32CFA950256355AA98BEE29;
IL2CPP_EXTERN_C String_t* _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709;
IL2CPP_EXTERN_C String_t* _stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81;
IL2CPP_EXTERN_C String_t* _stringLiteralDAFC4BB68B649F31995F74799A69A3414294F814;
IL2CPP_EXTERN_C String_t* _stringLiteralE070A0F7AE650838CAC9FB9703A37D7A8775247C;
IL2CPP_EXTERN_C String_t* _stringLiteralE146753D0BD9B838630EAF1D9A8B7E8385F405AC;
IL2CPP_EXTERN_C String_t* _stringLiteralE91FE173F59B063D620A934CE1A010F2B114C1F3;
IL2CPP_EXTERN_C String_t* _stringLiteralEA138C6D14D8FDCE6394BF7F95D836B105671B79;
IL2CPP_EXTERN_C String_t* _stringLiteralFCD384615BA1CF7639363F707CDE70D1A4DFDA91;
IL2CPP_EXTERN_C const RuntimeMethod* Array_Resize_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m5F039C66CEB5890529B35E8E0EF57322FD099EF9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Component_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF0ABC826AA3E324A387AE7C6716E2776405AC583_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Component_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m3BF8F0D99AB14A2C6D2C3DCC33AC2AFAC49B29D1_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Component_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m7F9CE8DE7ACB08AC5198A03E9B4A1B64CAD17A4F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisButton_tA893FC15AB26E1439AC25BDCA7079530587BB65D_mC89B59084AF54D6861DE55F9F1FC4226E4F616A8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisPlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48_m9D6451632C23946A0F702FE50879B5BF75CEF829_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m6BF02D14A2BF23863B8F688EEA112E78DD7B4AB8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1_RuntimeMethod_var;
struct ContactPoint_tC179732A8E0014F5EFF5977ED1ADF12CF14A9017 ;
struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E ;

struct GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642;
struct RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B;
struct SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA;
struct StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A;
struct Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct U3CModuleU3E_tFDCAFCBB4B3431CFF2DC4D3E03FBFDF54EFF7E9A 
{
public:

public:
};


// System.Object

struct Il2CppArrayBounds;

// System.Array


// System.Text.Encoding
struct Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827  : public RuntimeObject
{
public:
	// System.Int32 System.Text.Encoding::m_codePage
	int32_t ___m_codePage_9;
	// System.Globalization.CodePageDataItem System.Text.Encoding::dataItem
	CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E * ___dataItem_10;
	// System.Boolean System.Text.Encoding::m_deserializedFromEverett
	bool ___m_deserializedFromEverett_11;
	// System.Boolean System.Text.Encoding::m_isReadOnly
	bool ___m_isReadOnly_12;
	// System.Text.EncoderFallback System.Text.Encoding::encoderFallback
	EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 * ___encoderFallback_13;
	// System.Text.DecoderFallback System.Text.Encoding::decoderFallback
	DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D * ___decoderFallback_14;

public:
	inline static int32_t get_offset_of_m_codePage_9() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___m_codePage_9)); }
	inline int32_t get_m_codePage_9() const { return ___m_codePage_9; }
	inline int32_t* get_address_of_m_codePage_9() { return &___m_codePage_9; }
	inline void set_m_codePage_9(int32_t value)
	{
		___m_codePage_9 = value;
	}

	inline static int32_t get_offset_of_dataItem_10() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___dataItem_10)); }
	inline CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E * get_dataItem_10() const { return ___dataItem_10; }
	inline CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E ** get_address_of_dataItem_10() { return &___dataItem_10; }
	inline void set_dataItem_10(CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E * value)
	{
		___dataItem_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___dataItem_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_deserializedFromEverett_11() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___m_deserializedFromEverett_11)); }
	inline bool get_m_deserializedFromEverett_11() const { return ___m_deserializedFromEverett_11; }
	inline bool* get_address_of_m_deserializedFromEverett_11() { return &___m_deserializedFromEverett_11; }
	inline void set_m_deserializedFromEverett_11(bool value)
	{
		___m_deserializedFromEverett_11 = value;
	}

	inline static int32_t get_offset_of_m_isReadOnly_12() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___m_isReadOnly_12)); }
	inline bool get_m_isReadOnly_12() const { return ___m_isReadOnly_12; }
	inline bool* get_address_of_m_isReadOnly_12() { return &___m_isReadOnly_12; }
	inline void set_m_isReadOnly_12(bool value)
	{
		___m_isReadOnly_12 = value;
	}

	inline static int32_t get_offset_of_encoderFallback_13() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___encoderFallback_13)); }
	inline EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 * get_encoderFallback_13() const { return ___encoderFallback_13; }
	inline EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 ** get_address_of_encoderFallback_13() { return &___encoderFallback_13; }
	inline void set_encoderFallback_13(EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 * value)
	{
		___encoderFallback_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encoderFallback_13), (void*)value);
	}

	inline static int32_t get_offset_of_decoderFallback_14() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___decoderFallback_14)); }
	inline DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D * get_decoderFallback_14() const { return ___decoderFallback_14; }
	inline DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D ** get_address_of_decoderFallback_14() { return &___decoderFallback_14; }
	inline void set_decoderFallback_14(DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D * value)
	{
		___decoderFallback_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___decoderFallback_14), (void*)value);
	}
};

struct Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields
{
public:
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::defaultEncoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___defaultEncoding_0;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::unicodeEncoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___unicodeEncoding_1;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::bigEndianUnicode
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___bigEndianUnicode_2;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf7Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___utf7Encoding_3;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf8Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___utf8Encoding_4;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf32Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___utf32Encoding_5;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::asciiEncoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___asciiEncoding_6;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::latin1Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___latin1Encoding_7;
	// System.Collections.Hashtable modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::encodings
	Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC * ___encodings_8;
	// System.Object System.Text.Encoding::s_InternalSyncObject
	RuntimeObject * ___s_InternalSyncObject_15;

public:
	inline static int32_t get_offset_of_defaultEncoding_0() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___defaultEncoding_0)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_defaultEncoding_0() const { return ___defaultEncoding_0; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_defaultEncoding_0() { return &___defaultEncoding_0; }
	inline void set_defaultEncoding_0(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___defaultEncoding_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultEncoding_0), (void*)value);
	}

	inline static int32_t get_offset_of_unicodeEncoding_1() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___unicodeEncoding_1)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_unicodeEncoding_1() const { return ___unicodeEncoding_1; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_unicodeEncoding_1() { return &___unicodeEncoding_1; }
	inline void set_unicodeEncoding_1(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___unicodeEncoding_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___unicodeEncoding_1), (void*)value);
	}

	inline static int32_t get_offset_of_bigEndianUnicode_2() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___bigEndianUnicode_2)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_bigEndianUnicode_2() const { return ___bigEndianUnicode_2; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_bigEndianUnicode_2() { return &___bigEndianUnicode_2; }
	inline void set_bigEndianUnicode_2(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___bigEndianUnicode_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bigEndianUnicode_2), (void*)value);
	}

	inline static int32_t get_offset_of_utf7Encoding_3() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___utf7Encoding_3)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_utf7Encoding_3() const { return ___utf7Encoding_3; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_utf7Encoding_3() { return &___utf7Encoding_3; }
	inline void set_utf7Encoding_3(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___utf7Encoding_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf7Encoding_3), (void*)value);
	}

	inline static int32_t get_offset_of_utf8Encoding_4() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___utf8Encoding_4)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_utf8Encoding_4() const { return ___utf8Encoding_4; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_utf8Encoding_4() { return &___utf8Encoding_4; }
	inline void set_utf8Encoding_4(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___utf8Encoding_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf8Encoding_4), (void*)value);
	}

	inline static int32_t get_offset_of_utf32Encoding_5() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___utf32Encoding_5)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_utf32Encoding_5() const { return ___utf32Encoding_5; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_utf32Encoding_5() { return &___utf32Encoding_5; }
	inline void set_utf32Encoding_5(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___utf32Encoding_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf32Encoding_5), (void*)value);
	}

	inline static int32_t get_offset_of_asciiEncoding_6() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___asciiEncoding_6)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_asciiEncoding_6() const { return ___asciiEncoding_6; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_asciiEncoding_6() { return &___asciiEncoding_6; }
	inline void set_asciiEncoding_6(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___asciiEncoding_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___asciiEncoding_6), (void*)value);
	}

	inline static int32_t get_offset_of_latin1Encoding_7() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___latin1Encoding_7)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_latin1Encoding_7() const { return ___latin1Encoding_7; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_latin1Encoding_7() { return &___latin1Encoding_7; }
	inline void set_latin1Encoding_7(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___latin1Encoding_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___latin1Encoding_7), (void*)value);
	}

	inline static int32_t get_offset_of_encodings_8() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___encodings_8)); }
	inline Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC * get_encodings_8() const { return ___encodings_8; }
	inline Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC ** get_address_of_encodings_8() { return &___encodings_8; }
	inline void set_encodings_8(Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC * value)
	{
		___encodings_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encodings_8), (void*)value);
	}

	inline static int32_t get_offset_of_s_InternalSyncObject_15() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___s_InternalSyncObject_15)); }
	inline RuntimeObject * get_s_InternalSyncObject_15() const { return ___s_InternalSyncObject_15; }
	inline RuntimeObject ** get_address_of_s_InternalSyncObject_15() { return &___s_InternalSyncObject_15; }
	inline void set_s_InternalSyncObject_15(RuntimeObject * value)
	{
		___s_InternalSyncObject_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_InternalSyncObject_15), (void*)value);
	}
};


// System.MarshalByRefObject
struct MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8  : public RuntimeObject
{
public:
	// System.Object System.MarshalByRefObject::_identity
	RuntimeObject * ____identity_0;

public:
	inline static int32_t get_offset_of__identity_0() { return static_cast<int32_t>(offsetof(MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8, ____identity_0)); }
	inline RuntimeObject * get__identity_0() const { return ____identity_0; }
	inline RuntimeObject ** get_address_of__identity_0() { return &____identity_0; }
	inline void set__identity_0(RuntimeObject * value)
	{
		____identity_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____identity_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MarshalByRefObject
struct MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8_marshaled_pinvoke
{
	Il2CppIUnknown* ____identity_0;
};
// Native definition for COM marshalling of System.MarshalByRefObject
struct MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8_marshaled_com
{
	Il2CppIUnknown* ____identity_0;
};

// System.String
struct String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// System.Text.StringBuilder
struct StringBuilder_t  : public RuntimeObject
{
public:
	// System.Char[] System.Text.StringBuilder::m_ChunkChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___m_ChunkChars_0;
	// System.Text.StringBuilder System.Text.StringBuilder::m_ChunkPrevious
	StringBuilder_t * ___m_ChunkPrevious_1;
	// System.Int32 System.Text.StringBuilder::m_ChunkLength
	int32_t ___m_ChunkLength_2;
	// System.Int32 System.Text.StringBuilder::m_ChunkOffset
	int32_t ___m_ChunkOffset_3;
	// System.Int32 System.Text.StringBuilder::m_MaxCapacity
	int32_t ___m_MaxCapacity_4;

public:
	inline static int32_t get_offset_of_m_ChunkChars_0() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkChars_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_m_ChunkChars_0() const { return ___m_ChunkChars_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_m_ChunkChars_0() { return &___m_ChunkChars_0; }
	inline void set_m_ChunkChars_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___m_ChunkChars_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ChunkChars_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_ChunkPrevious_1() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkPrevious_1)); }
	inline StringBuilder_t * get_m_ChunkPrevious_1() const { return ___m_ChunkPrevious_1; }
	inline StringBuilder_t ** get_address_of_m_ChunkPrevious_1() { return &___m_ChunkPrevious_1; }
	inline void set_m_ChunkPrevious_1(StringBuilder_t * value)
	{
		___m_ChunkPrevious_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ChunkPrevious_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_ChunkLength_2() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkLength_2)); }
	inline int32_t get_m_ChunkLength_2() const { return ___m_ChunkLength_2; }
	inline int32_t* get_address_of_m_ChunkLength_2() { return &___m_ChunkLength_2; }
	inline void set_m_ChunkLength_2(int32_t value)
	{
		___m_ChunkLength_2 = value;
	}

	inline static int32_t get_offset_of_m_ChunkOffset_3() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkOffset_3)); }
	inline int32_t get_m_ChunkOffset_3() const { return ___m_ChunkOffset_3; }
	inline int32_t* get_address_of_m_ChunkOffset_3() { return &___m_ChunkOffset_3; }
	inline void set_m_ChunkOffset_3(int32_t value)
	{
		___m_ChunkOffset_3 = value;
	}

	inline static int32_t get_offset_of_m_MaxCapacity_4() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_MaxCapacity_4)); }
	inline int32_t get_m_MaxCapacity_4() const { return ___m_MaxCapacity_4; }
	inline int32_t* get_address_of_m_MaxCapacity_4() { return &___m_MaxCapacity_4; }
	inline void set_m_MaxCapacity_4(int32_t value)
	{
		___m_MaxCapacity_4 = value;
	}
};


// System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// datas
struct datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0  : public RuntimeObject
{
public:

public:
};

struct datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields
{
public:
	// System.Int32 datas::currentStageNum
	int32_t ___currentStageNum_0;

public:
	inline static int32_t get_offset_of_currentStageNum_0() { return static_cast<int32_t>(offsetof(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields, ___currentStageNum_0)); }
	inline int32_t get_currentStageNum_0() const { return ___currentStageNum_0; }
	inline int32_t* get_address_of_currentStageNum_0() { return &___currentStageNum_0; }
	inline void set_currentStageNum_0(int32_t value)
	{
		___currentStageNum_0 = value;
	}
};


// System.Boolean
struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Byte
struct Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056, ___m_value_0)); }
	inline uint8_t get_m_value_0() const { return ___m_value_0; }
	inline uint8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint8_t value)
	{
		___m_value_0 = value;
	}
};


// UnityEngine.Color
struct Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};


// UnityEngine.Color32
struct Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D 
{
public:
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Int32 UnityEngine.Color32::rgba
			int32_t ___rgba_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___rgba_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Byte UnityEngine.Color32::r
			uint8_t ___r_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			uint8_t ___r_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___g_2_OffsetPadding[1];
			// System.Byte UnityEngine.Color32::g
			uint8_t ___g_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___g_2_OffsetPadding_forAlignmentOnly[1];
			uint8_t ___g_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___b_3_OffsetPadding[2];
			// System.Byte UnityEngine.Color32::b
			uint8_t ___b_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___b_3_OffsetPadding_forAlignmentOnly[2];
			uint8_t ___b_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___a_4_OffsetPadding[3];
			// System.Byte UnityEngine.Color32::a
			uint8_t ___a_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___a_4_OffsetPadding_forAlignmentOnly[3];
			uint8_t ___a_4_forAlignmentOnly;
		};
	};

public:
	inline static int32_t get_offset_of_rgba_0() { return static_cast<int32_t>(offsetof(Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D, ___rgba_0)); }
	inline int32_t get_rgba_0() const { return ___rgba_0; }
	inline int32_t* get_address_of_rgba_0() { return &___rgba_0; }
	inline void set_rgba_0(int32_t value)
	{
		___rgba_0 = value;
	}

	inline static int32_t get_offset_of_r_1() { return static_cast<int32_t>(offsetof(Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D, ___r_1)); }
	inline uint8_t get_r_1() const { return ___r_1; }
	inline uint8_t* get_address_of_r_1() { return &___r_1; }
	inline void set_r_1(uint8_t value)
	{
		___r_1 = value;
	}

	inline static int32_t get_offset_of_g_2() { return static_cast<int32_t>(offsetof(Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D, ___g_2)); }
	inline uint8_t get_g_2() const { return ___g_2; }
	inline uint8_t* get_address_of_g_2() { return &___g_2; }
	inline void set_g_2(uint8_t value)
	{
		___g_2 = value;
	}

	inline static int32_t get_offset_of_b_3() { return static_cast<int32_t>(offsetof(Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D, ___b_3)); }
	inline uint8_t get_b_3() const { return ___b_3; }
	inline uint8_t* get_address_of_b_3() { return &___b_3; }
	inline void set_b_3(uint8_t value)
	{
		___b_3 = value;
	}

	inline static int32_t get_offset_of_a_4() { return static_cast<int32_t>(offsetof(Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D, ___a_4)); }
	inline uint8_t get_a_4() const { return ___a_4; }
	inline uint8_t* get_address_of_a_4() { return &___a_4; }
	inline void set_a_4(uint8_t value)
	{
		___a_4 = value;
	}
};


// System.Double
struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};


// UnityEngine.DrivenRectTransformTracker
struct DrivenRectTransformTracker_t7DAF937E47C63B899C7BA0E9B0F206AAB4D85AC2 
{
public:
	union
	{
		struct
		{
		};
		uint8_t DrivenRectTransformTracker_t7DAF937E47C63B899C7BA0E9B0F206AAB4D85AC2__padding[1];
	};

public:
};


// System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA  : public ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52
{
public:

public:
};

struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_com
{
};

// System.Int32
struct Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// UnityEngine.Quaternion
struct Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  value)
	{
		___identityQuaternion_4 = value;
	}
};


// UnityEngine.SceneManagement.Scene
struct Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE 
{
public:
	// System.Int32 UnityEngine.SceneManagement.Scene::m_Handle
	int32_t ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE, ___m_Handle_0)); }
	inline int32_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline int32_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(int32_t value)
	{
		___m_Handle_0 = value;
	}
};


// System.Single
struct Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// UnityEngine.UI.SpriteState
struct SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E 
{
public:
	// UnityEngine.Sprite UnityEngine.UI.SpriteState::m_HighlightedSprite
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_HighlightedSprite_0;
	// UnityEngine.Sprite UnityEngine.UI.SpriteState::m_PressedSprite
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_PressedSprite_1;
	// UnityEngine.Sprite UnityEngine.UI.SpriteState::m_SelectedSprite
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_SelectedSprite_2;
	// UnityEngine.Sprite UnityEngine.UI.SpriteState::m_DisabledSprite
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_DisabledSprite_3;

public:
	inline static int32_t get_offset_of_m_HighlightedSprite_0() { return static_cast<int32_t>(offsetof(SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E, ___m_HighlightedSprite_0)); }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * get_m_HighlightedSprite_0() const { return ___m_HighlightedSprite_0; }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 ** get_address_of_m_HighlightedSprite_0() { return &___m_HighlightedSprite_0; }
	inline void set_m_HighlightedSprite_0(Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * value)
	{
		___m_HighlightedSprite_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_HighlightedSprite_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_PressedSprite_1() { return static_cast<int32_t>(offsetof(SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E, ___m_PressedSprite_1)); }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * get_m_PressedSprite_1() const { return ___m_PressedSprite_1; }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 ** get_address_of_m_PressedSprite_1() { return &___m_PressedSprite_1; }
	inline void set_m_PressedSprite_1(Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * value)
	{
		___m_PressedSprite_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_PressedSprite_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_SelectedSprite_2() { return static_cast<int32_t>(offsetof(SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E, ___m_SelectedSprite_2)); }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * get_m_SelectedSprite_2() const { return ___m_SelectedSprite_2; }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 ** get_address_of_m_SelectedSprite_2() { return &___m_SelectedSprite_2; }
	inline void set_m_SelectedSprite_2(Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * value)
	{
		___m_SelectedSprite_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_SelectedSprite_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_DisabledSprite_3() { return static_cast<int32_t>(offsetof(SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E, ___m_DisabledSprite_3)); }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * get_m_DisabledSprite_3() const { return ___m_DisabledSprite_3; }
	inline Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 ** get_address_of_m_DisabledSprite_3() { return &___m_DisabledSprite_3; }
	inline void set_m_DisabledSprite_3(Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * value)
	{
		___m_DisabledSprite_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DisabledSprite_3), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.UI.SpriteState
struct SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E_marshaled_pinvoke
{
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_HighlightedSprite_0;
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_PressedSprite_1;
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_SelectedSprite_2;
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_DisabledSprite_3;
};
// Native definition for COM marshalling of UnityEngine.UI.SpriteState
struct SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E_marshaled_com
{
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_HighlightedSprite_0;
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_PressedSprite_1;
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_SelectedSprite_2;
	Sprite_t5B10B1178EC2E6F53D33FFD77557F31C08A51ED9 * ___m_DisabledSprite_3;
};

// System.IO.TextReader
struct TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F  : public MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8
{
public:

public:
};

struct TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F_StaticFields
{
public:
	// System.Func`2<System.Object,System.String> System.IO.TextReader::_ReadLineDelegate
	Func_2_t060A650AB95DEF14D4F579FA5999ACEFEEE0FD82 * ____ReadLineDelegate_1;
	// System.Func`2<System.Object,System.Int32> System.IO.TextReader::_ReadDelegate
	Func_2_t0CEE9D1C856153BA9C23BB9D7E929D577AF37A2C * ____ReadDelegate_2;
	// System.IO.TextReader System.IO.TextReader::Null
	TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F * ___Null_3;

public:
	inline static int32_t get_offset_of__ReadLineDelegate_1() { return static_cast<int32_t>(offsetof(TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F_StaticFields, ____ReadLineDelegate_1)); }
	inline Func_2_t060A650AB95DEF14D4F579FA5999ACEFEEE0FD82 * get__ReadLineDelegate_1() const { return ____ReadLineDelegate_1; }
	inline Func_2_t060A650AB95DEF14D4F579FA5999ACEFEEE0FD82 ** get_address_of__ReadLineDelegate_1() { return &____ReadLineDelegate_1; }
	inline void set__ReadLineDelegate_1(Func_2_t060A650AB95DEF14D4F579FA5999ACEFEEE0FD82 * value)
	{
		____ReadLineDelegate_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____ReadLineDelegate_1), (void*)value);
	}

	inline static int32_t get_offset_of__ReadDelegate_2() { return static_cast<int32_t>(offsetof(TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F_StaticFields, ____ReadDelegate_2)); }
	inline Func_2_t0CEE9D1C856153BA9C23BB9D7E929D577AF37A2C * get__ReadDelegate_2() const { return ____ReadDelegate_2; }
	inline Func_2_t0CEE9D1C856153BA9C23BB9D7E929D577AF37A2C ** get_address_of__ReadDelegate_2() { return &____ReadDelegate_2; }
	inline void set__ReadDelegate_2(Func_2_t0CEE9D1C856153BA9C23BB9D7E929D577AF37A2C * value)
	{
		____ReadDelegate_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____ReadDelegate_2), (void*)value);
	}

	inline static int32_t get_offset_of_Null_3() { return static_cast<int32_t>(offsetof(TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F_StaticFields, ___Null_3)); }
	inline TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F * get_Null_3() const { return ___Null_3; }
	inline TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F ** get_address_of_Null_3() { return &___Null_3; }
	inline void set_Null_3(TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F * value)
	{
		___Null_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Null_3), (void*)value);
	}
};


// System.IO.TextWriter
struct TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643  : public MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8
{
public:
	// System.Char[] System.IO.TextWriter::CoreNewLine
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___CoreNewLine_9;
	// System.IFormatProvider System.IO.TextWriter::InternalFormatProvider
	RuntimeObject* ___InternalFormatProvider_10;

public:
	inline static int32_t get_offset_of_CoreNewLine_9() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643, ___CoreNewLine_9)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_CoreNewLine_9() const { return ___CoreNewLine_9; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_CoreNewLine_9() { return &___CoreNewLine_9; }
	inline void set_CoreNewLine_9(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___CoreNewLine_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___CoreNewLine_9), (void*)value);
	}

	inline static int32_t get_offset_of_InternalFormatProvider_10() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643, ___InternalFormatProvider_10)); }
	inline RuntimeObject* get_InternalFormatProvider_10() const { return ___InternalFormatProvider_10; }
	inline RuntimeObject** get_address_of_InternalFormatProvider_10() { return &___InternalFormatProvider_10; }
	inline void set_InternalFormatProvider_10(RuntimeObject* value)
	{
		___InternalFormatProvider_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___InternalFormatProvider_10), (void*)value);
	}
};

struct TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields
{
public:
	// System.IO.TextWriter System.IO.TextWriter::Null
	TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643 * ___Null_1;
	// System.Action`1<System.Object> System.IO.TextWriter::_WriteCharDelegate
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ____WriteCharDelegate_2;
	// System.Action`1<System.Object> System.IO.TextWriter::_WriteStringDelegate
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ____WriteStringDelegate_3;
	// System.Action`1<System.Object> System.IO.TextWriter::_WriteCharArrayRangeDelegate
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ____WriteCharArrayRangeDelegate_4;
	// System.Action`1<System.Object> System.IO.TextWriter::_WriteLineCharDelegate
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ____WriteLineCharDelegate_5;
	// System.Action`1<System.Object> System.IO.TextWriter::_WriteLineStringDelegate
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ____WriteLineStringDelegate_6;
	// System.Action`1<System.Object> System.IO.TextWriter::_WriteLineCharArrayRangeDelegate
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ____WriteLineCharArrayRangeDelegate_7;
	// System.Action`1<System.Object> System.IO.TextWriter::_FlushDelegate
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ____FlushDelegate_8;

public:
	inline static int32_t get_offset_of_Null_1() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ___Null_1)); }
	inline TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643 * get_Null_1() const { return ___Null_1; }
	inline TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643 ** get_address_of_Null_1() { return &___Null_1; }
	inline void set_Null_1(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643 * value)
	{
		___Null_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Null_1), (void*)value);
	}

	inline static int32_t get_offset_of__WriteCharDelegate_2() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ____WriteCharDelegate_2)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get__WriteCharDelegate_2() const { return ____WriteCharDelegate_2; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of__WriteCharDelegate_2() { return &____WriteCharDelegate_2; }
	inline void set__WriteCharDelegate_2(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		____WriteCharDelegate_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____WriteCharDelegate_2), (void*)value);
	}

	inline static int32_t get_offset_of__WriteStringDelegate_3() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ____WriteStringDelegate_3)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get__WriteStringDelegate_3() const { return ____WriteStringDelegate_3; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of__WriteStringDelegate_3() { return &____WriteStringDelegate_3; }
	inline void set__WriteStringDelegate_3(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		____WriteStringDelegate_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____WriteStringDelegate_3), (void*)value);
	}

	inline static int32_t get_offset_of__WriteCharArrayRangeDelegate_4() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ____WriteCharArrayRangeDelegate_4)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get__WriteCharArrayRangeDelegate_4() const { return ____WriteCharArrayRangeDelegate_4; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of__WriteCharArrayRangeDelegate_4() { return &____WriteCharArrayRangeDelegate_4; }
	inline void set__WriteCharArrayRangeDelegate_4(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		____WriteCharArrayRangeDelegate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____WriteCharArrayRangeDelegate_4), (void*)value);
	}

	inline static int32_t get_offset_of__WriteLineCharDelegate_5() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ____WriteLineCharDelegate_5)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get__WriteLineCharDelegate_5() const { return ____WriteLineCharDelegate_5; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of__WriteLineCharDelegate_5() { return &____WriteLineCharDelegate_5; }
	inline void set__WriteLineCharDelegate_5(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		____WriteLineCharDelegate_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____WriteLineCharDelegate_5), (void*)value);
	}

	inline static int32_t get_offset_of__WriteLineStringDelegate_6() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ____WriteLineStringDelegate_6)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get__WriteLineStringDelegate_6() const { return ____WriteLineStringDelegate_6; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of__WriteLineStringDelegate_6() { return &____WriteLineStringDelegate_6; }
	inline void set__WriteLineStringDelegate_6(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		____WriteLineStringDelegate_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____WriteLineStringDelegate_6), (void*)value);
	}

	inline static int32_t get_offset_of__WriteLineCharArrayRangeDelegate_7() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ____WriteLineCharArrayRangeDelegate_7)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get__WriteLineCharArrayRangeDelegate_7() const { return ____WriteLineCharArrayRangeDelegate_7; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of__WriteLineCharArrayRangeDelegate_7() { return &____WriteLineCharArrayRangeDelegate_7; }
	inline void set__WriteLineCharArrayRangeDelegate_7(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		____WriteLineCharArrayRangeDelegate_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____WriteLineCharArrayRangeDelegate_7), (void*)value);
	}

	inline static int32_t get_offset_of__FlushDelegate_8() { return static_cast<int32_t>(offsetof(TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643_StaticFields, ____FlushDelegate_8)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get__FlushDelegate_8() const { return ____FlushDelegate_8; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of__FlushDelegate_8() { return &____FlushDelegate_8; }
	inline void set__FlushDelegate_8(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		____FlushDelegate_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____FlushDelegate_8), (void*)value);
	}
};


// UnityEngine.Vector2
struct Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___zeroVector_2)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___oneVector_3)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___upVector_4)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___downVector_5)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___leftVector_6)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___rightVector_7)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___negativeInfinityVector_9 = value;
	}
};


// UnityEngine.Vector3
struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___zeroVector_5)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___oneVector_6)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___upVector_7)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___downVector_8)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___leftVector_9)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___rightVector_10)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___forwardVector_11)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___backVector_12)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___negativeInfinityVector_14 = value;
	}
};


// UnityEngine.Vector4
struct Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 
{
public:
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}

	inline static int32_t get_offset_of_w_4() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___w_4)); }
	inline float get_w_4() const { return ___w_4; }
	inline float* get_address_of_w_4() { return &___w_4; }
	inline void set_w_4(float value)
	{
		___w_4 = value;
	}
};

struct Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___negativeInfinityVector_8;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___zeroVector_5)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___oneVector_6)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_7() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___positiveInfinityVector_7)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_positiveInfinityVector_7() const { return ___positiveInfinityVector_7; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_positiveInfinityVector_7() { return &___positiveInfinityVector_7; }
	inline void set_positiveInfinityVector_7(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___positiveInfinityVector_7 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___negativeInfinityVector_8)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_negativeInfinityVector_8() const { return ___negativeInfinityVector_8; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_negativeInfinityVector_8() { return &___negativeInfinityVector_8; }
	inline void set_negativeInfinityVector_8(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___negativeInfinityVector_8 = value;
	}
};


// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5__padding[1];
	};

public:
};


// UnityEngine.Collision
struct Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0  : public RuntimeObject
{
public:
	// UnityEngine.Vector3 UnityEngine.Collision::m_Impulse
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___m_Impulse_0;
	// UnityEngine.Vector3 UnityEngine.Collision::m_RelativeVelocity
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___m_RelativeVelocity_1;
	// UnityEngine.Component UnityEngine.Collision::m_Body
	Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * ___m_Body_2;
	// UnityEngine.Collider UnityEngine.Collision::m_Collider
	Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 * ___m_Collider_3;
	// System.Int32 UnityEngine.Collision::m_ContactCount
	int32_t ___m_ContactCount_4;
	// UnityEngine.ContactPoint[] UnityEngine.Collision::m_ReusedContacts
	ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B* ___m_ReusedContacts_5;
	// UnityEngine.ContactPoint[] UnityEngine.Collision::m_LegacyContacts
	ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B* ___m_LegacyContacts_6;

public:
	inline static int32_t get_offset_of_m_Impulse_0() { return static_cast<int32_t>(offsetof(Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0, ___m_Impulse_0)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_m_Impulse_0() const { return ___m_Impulse_0; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_m_Impulse_0() { return &___m_Impulse_0; }
	inline void set_m_Impulse_0(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___m_Impulse_0 = value;
	}

	inline static int32_t get_offset_of_m_RelativeVelocity_1() { return static_cast<int32_t>(offsetof(Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0, ___m_RelativeVelocity_1)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_m_RelativeVelocity_1() const { return ___m_RelativeVelocity_1; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_m_RelativeVelocity_1() { return &___m_RelativeVelocity_1; }
	inline void set_m_RelativeVelocity_1(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___m_RelativeVelocity_1 = value;
	}

	inline static int32_t get_offset_of_m_Body_2() { return static_cast<int32_t>(offsetof(Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0, ___m_Body_2)); }
	inline Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * get_m_Body_2() const { return ___m_Body_2; }
	inline Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 ** get_address_of_m_Body_2() { return &___m_Body_2; }
	inline void set_m_Body_2(Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * value)
	{
		___m_Body_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Body_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_Collider_3() { return static_cast<int32_t>(offsetof(Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0, ___m_Collider_3)); }
	inline Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 * get_m_Collider_3() const { return ___m_Collider_3; }
	inline Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 ** get_address_of_m_Collider_3() { return &___m_Collider_3; }
	inline void set_m_Collider_3(Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 * value)
	{
		___m_Collider_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Collider_3), (void*)value);
	}

	inline static int32_t get_offset_of_m_ContactCount_4() { return static_cast<int32_t>(offsetof(Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0, ___m_ContactCount_4)); }
	inline int32_t get_m_ContactCount_4() const { return ___m_ContactCount_4; }
	inline int32_t* get_address_of_m_ContactCount_4() { return &___m_ContactCount_4; }
	inline void set_m_ContactCount_4(int32_t value)
	{
		___m_ContactCount_4 = value;
	}

	inline static int32_t get_offset_of_m_ReusedContacts_5() { return static_cast<int32_t>(offsetof(Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0, ___m_ReusedContacts_5)); }
	inline ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B* get_m_ReusedContacts_5() const { return ___m_ReusedContacts_5; }
	inline ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B** get_address_of_m_ReusedContacts_5() { return &___m_ReusedContacts_5; }
	inline void set_m_ReusedContacts_5(ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B* value)
	{
		___m_ReusedContacts_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ReusedContacts_5), (void*)value);
	}

	inline static int32_t get_offset_of_m_LegacyContacts_6() { return static_cast<int32_t>(offsetof(Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0, ___m_LegacyContacts_6)); }
	inline ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B* get_m_LegacyContacts_6() const { return ___m_LegacyContacts_6; }
	inline ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B** get_address_of_m_LegacyContacts_6() { return &___m_LegacyContacts_6; }
	inline void set_m_LegacyContacts_6(ContactPointU5BU5D_t1ACD262B1EA44CD48E2039381DE96847F203E62B* value)
	{
		___m_LegacyContacts_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_LegacyContacts_6), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Collision
struct Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0_marshaled_pinvoke
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___m_Impulse_0;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___m_RelativeVelocity_1;
	Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * ___m_Body_2;
	Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 * ___m_Collider_3;
	int32_t ___m_ContactCount_4;
	ContactPoint_tC179732A8E0014F5EFF5977ED1ADF12CF14A9017 * ___m_ReusedContacts_5;
	ContactPoint_tC179732A8E0014F5EFF5977ED1ADF12CF14A9017 * ___m_LegacyContacts_6;
};
// Native definition for COM marshalling of UnityEngine.Collision
struct Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0_marshaled_com
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___m_Impulse_0;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___m_RelativeVelocity_1;
	Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * ___m_Body_2;
	Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 * ___m_Collider_3;
	int32_t ___m_ContactCount_4;
	ContactPoint_tC179732A8E0014F5EFF5977ED1ADF12CF14A9017 * ___m_ReusedContacts_5;
	ContactPoint_tC179732A8E0014F5EFF5977ED1ADF12CF14A9017 * ___m_LegacyContacts_6;
};

// UnityEngine.UI.ColorBlock
struct ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955 
{
public:
	// UnityEngine.Color UnityEngine.UI.ColorBlock::m_NormalColor
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___m_NormalColor_0;
	// UnityEngine.Color UnityEngine.UI.ColorBlock::m_HighlightedColor
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___m_HighlightedColor_1;
	// UnityEngine.Color UnityEngine.UI.ColorBlock::m_PressedColor
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___m_PressedColor_2;
	// UnityEngine.Color UnityEngine.UI.ColorBlock::m_SelectedColor
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___m_SelectedColor_3;
	// UnityEngine.Color UnityEngine.UI.ColorBlock::m_DisabledColor
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___m_DisabledColor_4;
	// System.Single UnityEngine.UI.ColorBlock::m_ColorMultiplier
	float ___m_ColorMultiplier_5;
	// System.Single UnityEngine.UI.ColorBlock::m_FadeDuration
	float ___m_FadeDuration_6;

public:
	inline static int32_t get_offset_of_m_NormalColor_0() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955, ___m_NormalColor_0)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_m_NormalColor_0() const { return ___m_NormalColor_0; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_m_NormalColor_0() { return &___m_NormalColor_0; }
	inline void set_m_NormalColor_0(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___m_NormalColor_0 = value;
	}

	inline static int32_t get_offset_of_m_HighlightedColor_1() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955, ___m_HighlightedColor_1)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_m_HighlightedColor_1() const { return ___m_HighlightedColor_1; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_m_HighlightedColor_1() { return &___m_HighlightedColor_1; }
	inline void set_m_HighlightedColor_1(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___m_HighlightedColor_1 = value;
	}

	inline static int32_t get_offset_of_m_PressedColor_2() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955, ___m_PressedColor_2)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_m_PressedColor_2() const { return ___m_PressedColor_2; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_m_PressedColor_2() { return &___m_PressedColor_2; }
	inline void set_m_PressedColor_2(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___m_PressedColor_2 = value;
	}

	inline static int32_t get_offset_of_m_SelectedColor_3() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955, ___m_SelectedColor_3)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_m_SelectedColor_3() const { return ___m_SelectedColor_3; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_m_SelectedColor_3() { return &___m_SelectedColor_3; }
	inline void set_m_SelectedColor_3(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___m_SelectedColor_3 = value;
	}

	inline static int32_t get_offset_of_m_DisabledColor_4() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955, ___m_DisabledColor_4)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_m_DisabledColor_4() const { return ___m_DisabledColor_4; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_m_DisabledColor_4() { return &___m_DisabledColor_4; }
	inline void set_m_DisabledColor_4(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___m_DisabledColor_4 = value;
	}

	inline static int32_t get_offset_of_m_ColorMultiplier_5() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955, ___m_ColorMultiplier_5)); }
	inline float get_m_ColorMultiplier_5() const { return ___m_ColorMultiplier_5; }
	inline float* get_address_of_m_ColorMultiplier_5() { return &___m_ColorMultiplier_5; }
	inline void set_m_ColorMultiplier_5(float value)
	{
		___m_ColorMultiplier_5 = value;
	}

	inline static int32_t get_offset_of_m_FadeDuration_6() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955, ___m_FadeDuration_6)); }
	inline float get_m_FadeDuration_6() const { return ___m_FadeDuration_6; }
	inline float* get_address_of_m_FadeDuration_6() { return &___m_FadeDuration_6; }
	inline void set_m_FadeDuration_6(float value)
	{
		___m_FadeDuration_6 = value;
	}
};

struct ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955_StaticFields
{
public:
	// UnityEngine.UI.ColorBlock UnityEngine.UI.ColorBlock::defaultColorBlock
	ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955  ___defaultColorBlock_7;

public:
	inline static int32_t get_offset_of_defaultColorBlock_7() { return static_cast<int32_t>(offsetof(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955_StaticFields, ___defaultColorBlock_7)); }
	inline ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955  get_defaultColorBlock_7() const { return ___defaultColorBlock_7; }
	inline ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955 * get_address_of_defaultColorBlock_7() { return &___defaultColorBlock_7; }
	inline void set_defaultColorBlock_7(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955  value)
	{
		___defaultColorBlock_7 = value;
	}
};


// System.IO.FileAttributes
struct FileAttributes_t47DBB9A73CF80C7CA21C9AAB8D5336C92D32C1AE 
{
public:
	// System.Int32 System.IO.FileAttributes::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FileAttributes_t47DBB9A73CF80C7CA21C9AAB8D5336C92D32C1AE, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.KeyCode
struct KeyCode_t1D303F7D061BF4429872E9F109ADDBCB431671F4 
{
public:
	// System.Int32 UnityEngine.KeyCode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(KeyCode_t1D303F7D061BF4429872E9F109ADDBCB431671F4, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.RigidbodyConstraints
struct RigidbodyConstraints_tB1AC534C460083518E5C8664CE62334E3B5A0F97 
{
public:
	// System.Int32 UnityEngine.RigidbodyConstraints::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RigidbodyConstraints_tB1AC534C460083518E5C8664CE62334E3B5A0F97, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.IO.StreamReader
struct StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3  : public TextReader_t25B06DCA1906FEAD02150DB14313EBEA4CD78D2F
{
public:
	// System.IO.Stream System.IO.StreamReader::stream
	Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * ___stream_5;
	// System.Text.Encoding System.IO.StreamReader::encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___encoding_6;
	// System.Text.Decoder System.IO.StreamReader::decoder
	Decoder_t91B2ED8AEC25AA24D23A00265203BE992B12C370 * ___decoder_7;
	// System.Byte[] System.IO.StreamReader::byteBuffer
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___byteBuffer_8;
	// System.Char[] System.IO.StreamReader::charBuffer
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___charBuffer_9;
	// System.Byte[] System.IO.StreamReader::_preamble
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ____preamble_10;
	// System.Int32 System.IO.StreamReader::charPos
	int32_t ___charPos_11;
	// System.Int32 System.IO.StreamReader::charLen
	int32_t ___charLen_12;
	// System.Int32 System.IO.StreamReader::byteLen
	int32_t ___byteLen_13;
	// System.Int32 System.IO.StreamReader::bytePos
	int32_t ___bytePos_14;
	// System.Int32 System.IO.StreamReader::_maxCharsPerBuffer
	int32_t ____maxCharsPerBuffer_15;
	// System.Boolean System.IO.StreamReader::_detectEncoding
	bool ____detectEncoding_16;
	// System.Boolean System.IO.StreamReader::_checkPreamble
	bool ____checkPreamble_17;
	// System.Boolean System.IO.StreamReader::_isBlocked
	bool ____isBlocked_18;
	// System.Boolean System.IO.StreamReader::_closable
	bool ____closable_19;
	// System.Threading.Tasks.Task modreq(System.Runtime.CompilerServices.IsVolatile) System.IO.StreamReader::_asyncReadTask
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ____asyncReadTask_20;

public:
	inline static int32_t get_offset_of_stream_5() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___stream_5)); }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * get_stream_5() const { return ___stream_5; }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB ** get_address_of_stream_5() { return &___stream_5; }
	inline void set_stream_5(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * value)
	{
		___stream_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___stream_5), (void*)value);
	}

	inline static int32_t get_offset_of_encoding_6() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___encoding_6)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_encoding_6() const { return ___encoding_6; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_encoding_6() { return &___encoding_6; }
	inline void set_encoding_6(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___encoding_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encoding_6), (void*)value);
	}

	inline static int32_t get_offset_of_decoder_7() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___decoder_7)); }
	inline Decoder_t91B2ED8AEC25AA24D23A00265203BE992B12C370 * get_decoder_7() const { return ___decoder_7; }
	inline Decoder_t91B2ED8AEC25AA24D23A00265203BE992B12C370 ** get_address_of_decoder_7() { return &___decoder_7; }
	inline void set_decoder_7(Decoder_t91B2ED8AEC25AA24D23A00265203BE992B12C370 * value)
	{
		___decoder_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___decoder_7), (void*)value);
	}

	inline static int32_t get_offset_of_byteBuffer_8() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___byteBuffer_8)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_byteBuffer_8() const { return ___byteBuffer_8; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_byteBuffer_8() { return &___byteBuffer_8; }
	inline void set_byteBuffer_8(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___byteBuffer_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___byteBuffer_8), (void*)value);
	}

	inline static int32_t get_offset_of_charBuffer_9() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___charBuffer_9)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_charBuffer_9() const { return ___charBuffer_9; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_charBuffer_9() { return &___charBuffer_9; }
	inline void set_charBuffer_9(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___charBuffer_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___charBuffer_9), (void*)value);
	}

	inline static int32_t get_offset_of__preamble_10() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ____preamble_10)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get__preamble_10() const { return ____preamble_10; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of__preamble_10() { return &____preamble_10; }
	inline void set__preamble_10(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		____preamble_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____preamble_10), (void*)value);
	}

	inline static int32_t get_offset_of_charPos_11() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___charPos_11)); }
	inline int32_t get_charPos_11() const { return ___charPos_11; }
	inline int32_t* get_address_of_charPos_11() { return &___charPos_11; }
	inline void set_charPos_11(int32_t value)
	{
		___charPos_11 = value;
	}

	inline static int32_t get_offset_of_charLen_12() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___charLen_12)); }
	inline int32_t get_charLen_12() const { return ___charLen_12; }
	inline int32_t* get_address_of_charLen_12() { return &___charLen_12; }
	inline void set_charLen_12(int32_t value)
	{
		___charLen_12 = value;
	}

	inline static int32_t get_offset_of_byteLen_13() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___byteLen_13)); }
	inline int32_t get_byteLen_13() const { return ___byteLen_13; }
	inline int32_t* get_address_of_byteLen_13() { return &___byteLen_13; }
	inline void set_byteLen_13(int32_t value)
	{
		___byteLen_13 = value;
	}

	inline static int32_t get_offset_of_bytePos_14() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ___bytePos_14)); }
	inline int32_t get_bytePos_14() const { return ___bytePos_14; }
	inline int32_t* get_address_of_bytePos_14() { return &___bytePos_14; }
	inline void set_bytePos_14(int32_t value)
	{
		___bytePos_14 = value;
	}

	inline static int32_t get_offset_of__maxCharsPerBuffer_15() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ____maxCharsPerBuffer_15)); }
	inline int32_t get__maxCharsPerBuffer_15() const { return ____maxCharsPerBuffer_15; }
	inline int32_t* get_address_of__maxCharsPerBuffer_15() { return &____maxCharsPerBuffer_15; }
	inline void set__maxCharsPerBuffer_15(int32_t value)
	{
		____maxCharsPerBuffer_15 = value;
	}

	inline static int32_t get_offset_of__detectEncoding_16() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ____detectEncoding_16)); }
	inline bool get__detectEncoding_16() const { return ____detectEncoding_16; }
	inline bool* get_address_of__detectEncoding_16() { return &____detectEncoding_16; }
	inline void set__detectEncoding_16(bool value)
	{
		____detectEncoding_16 = value;
	}

	inline static int32_t get_offset_of__checkPreamble_17() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ____checkPreamble_17)); }
	inline bool get__checkPreamble_17() const { return ____checkPreamble_17; }
	inline bool* get_address_of__checkPreamble_17() { return &____checkPreamble_17; }
	inline void set__checkPreamble_17(bool value)
	{
		____checkPreamble_17 = value;
	}

	inline static int32_t get_offset_of__isBlocked_18() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ____isBlocked_18)); }
	inline bool get__isBlocked_18() const { return ____isBlocked_18; }
	inline bool* get_address_of__isBlocked_18() { return &____isBlocked_18; }
	inline void set__isBlocked_18(bool value)
	{
		____isBlocked_18 = value;
	}

	inline static int32_t get_offset_of__closable_19() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ____closable_19)); }
	inline bool get__closable_19() const { return ____closable_19; }
	inline bool* get_address_of__closable_19() { return &____closable_19; }
	inline void set__closable_19(bool value)
	{
		____closable_19 = value;
	}

	inline static int32_t get_offset_of__asyncReadTask_20() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3, ____asyncReadTask_20)); }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * get__asyncReadTask_20() const { return ____asyncReadTask_20; }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 ** get_address_of__asyncReadTask_20() { return &____asyncReadTask_20; }
	inline void set__asyncReadTask_20(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * value)
	{
		____asyncReadTask_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____asyncReadTask_20), (void*)value);
	}
};

struct StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_StaticFields
{
public:
	// System.IO.StreamReader System.IO.StreamReader::Null
	StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * ___Null_4;

public:
	inline static int32_t get_offset_of_Null_4() { return static_cast<int32_t>(offsetof(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_StaticFields, ___Null_4)); }
	inline StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * get_Null_4() const { return ___Null_4; }
	inline StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 ** get_address_of_Null_4() { return &___Null_4; }
	inline void set_Null_4(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * value)
	{
		___Null_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Null_4), (void*)value);
	}
};


// System.IO.StreamWriter
struct StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6  : public TextWriter_t4CB195237F3B6CADD850FBC3604A049C7C564643
{
public:
	// System.IO.Stream System.IO.StreamWriter::stream
	Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * ___stream_12;
	// System.Text.Encoding System.IO.StreamWriter::encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___encoding_13;
	// System.Text.Encoder System.IO.StreamWriter::encoder
	Encoder_t5095F24D3B1D0F70D08762B980731B9F1ADEE56A * ___encoder_14;
	// System.Byte[] System.IO.StreamWriter::byteBuffer
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___byteBuffer_15;
	// System.Char[] System.IO.StreamWriter::charBuffer
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___charBuffer_16;
	// System.Int32 System.IO.StreamWriter::charPos
	int32_t ___charPos_17;
	// System.Int32 System.IO.StreamWriter::charLen
	int32_t ___charLen_18;
	// System.Boolean System.IO.StreamWriter::autoFlush
	bool ___autoFlush_19;
	// System.Boolean System.IO.StreamWriter::haveWrittenPreamble
	bool ___haveWrittenPreamble_20;
	// System.Boolean System.IO.StreamWriter::closable
	bool ___closable_21;
	// System.Threading.Tasks.Task modreq(System.Runtime.CompilerServices.IsVolatile) System.IO.StreamWriter::_asyncWriteTask
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ____asyncWriteTask_22;

public:
	inline static int32_t get_offset_of_stream_12() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___stream_12)); }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * get_stream_12() const { return ___stream_12; }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB ** get_address_of_stream_12() { return &___stream_12; }
	inline void set_stream_12(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * value)
	{
		___stream_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___stream_12), (void*)value);
	}

	inline static int32_t get_offset_of_encoding_13() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___encoding_13)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_encoding_13() const { return ___encoding_13; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_encoding_13() { return &___encoding_13; }
	inline void set_encoding_13(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___encoding_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encoding_13), (void*)value);
	}

	inline static int32_t get_offset_of_encoder_14() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___encoder_14)); }
	inline Encoder_t5095F24D3B1D0F70D08762B980731B9F1ADEE56A * get_encoder_14() const { return ___encoder_14; }
	inline Encoder_t5095F24D3B1D0F70D08762B980731B9F1ADEE56A ** get_address_of_encoder_14() { return &___encoder_14; }
	inline void set_encoder_14(Encoder_t5095F24D3B1D0F70D08762B980731B9F1ADEE56A * value)
	{
		___encoder_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encoder_14), (void*)value);
	}

	inline static int32_t get_offset_of_byteBuffer_15() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___byteBuffer_15)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_byteBuffer_15() const { return ___byteBuffer_15; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_byteBuffer_15() { return &___byteBuffer_15; }
	inline void set_byteBuffer_15(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___byteBuffer_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___byteBuffer_15), (void*)value);
	}

	inline static int32_t get_offset_of_charBuffer_16() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___charBuffer_16)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_charBuffer_16() const { return ___charBuffer_16; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_charBuffer_16() { return &___charBuffer_16; }
	inline void set_charBuffer_16(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___charBuffer_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___charBuffer_16), (void*)value);
	}

	inline static int32_t get_offset_of_charPos_17() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___charPos_17)); }
	inline int32_t get_charPos_17() const { return ___charPos_17; }
	inline int32_t* get_address_of_charPos_17() { return &___charPos_17; }
	inline void set_charPos_17(int32_t value)
	{
		___charPos_17 = value;
	}

	inline static int32_t get_offset_of_charLen_18() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___charLen_18)); }
	inline int32_t get_charLen_18() const { return ___charLen_18; }
	inline int32_t* get_address_of_charLen_18() { return &___charLen_18; }
	inline void set_charLen_18(int32_t value)
	{
		___charLen_18 = value;
	}

	inline static int32_t get_offset_of_autoFlush_19() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___autoFlush_19)); }
	inline bool get_autoFlush_19() const { return ___autoFlush_19; }
	inline bool* get_address_of_autoFlush_19() { return &___autoFlush_19; }
	inline void set_autoFlush_19(bool value)
	{
		___autoFlush_19 = value;
	}

	inline static int32_t get_offset_of_haveWrittenPreamble_20() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___haveWrittenPreamble_20)); }
	inline bool get_haveWrittenPreamble_20() const { return ___haveWrittenPreamble_20; }
	inline bool* get_address_of_haveWrittenPreamble_20() { return &___haveWrittenPreamble_20; }
	inline void set_haveWrittenPreamble_20(bool value)
	{
		___haveWrittenPreamble_20 = value;
	}

	inline static int32_t get_offset_of_closable_21() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ___closable_21)); }
	inline bool get_closable_21() const { return ___closable_21; }
	inline bool* get_address_of_closable_21() { return &___closable_21; }
	inline void set_closable_21(bool value)
	{
		___closable_21 = value;
	}

	inline static int32_t get_offset_of__asyncWriteTask_22() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6, ____asyncWriteTask_22)); }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * get__asyncWriteTask_22() const { return ____asyncWriteTask_22; }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 ** get_address_of__asyncWriteTask_22() { return &____asyncWriteTask_22; }
	inline void set__asyncWriteTask_22(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * value)
	{
		____asyncWriteTask_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____asyncWriteTask_22), (void*)value);
	}
};

struct StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_StaticFields
{
public:
	// System.IO.StreamWriter System.IO.StreamWriter::Null
	StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * ___Null_11;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.IO.StreamWriter::_UTF8NoBOM
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ____UTF8NoBOM_23;

public:
	inline static int32_t get_offset_of_Null_11() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_StaticFields, ___Null_11)); }
	inline StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * get_Null_11() const { return ___Null_11; }
	inline StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 ** get_address_of_Null_11() { return &___Null_11; }
	inline void set_Null_11(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * value)
	{
		___Null_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Null_11), (void*)value);
	}

	inline static int32_t get_offset_of__UTF8NoBOM_23() { return static_cast<int32_t>(offsetof(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_StaticFields, ____UTF8NoBOM_23)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get__UTF8NoBOM_23() const { return ____UTF8NoBOM_23; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of__UTF8NoBOM_23() { return &____UTF8NoBOM_23; }
	inline void set__UTF8NoBOM_23(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		____UTF8NoBOM_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____UTF8NoBOM_23), (void*)value);
	}
};


// stageData
struct stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 
{
public:
	// UnityEngine.Vector3 stageData::playerPos
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___playerPos_0;
	// UnityEngine.Vector3[] stageData::inPoss
	Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* ___inPoss_1;
	// UnityEngine.Vector3[] stageData::sekiPoss
	Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* ___sekiPoss_2;
	// UnityEngine.Vector3 stageData::goalPos
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___goalPos_3;
	// UnityEngine.Vector3 stageData::goalSize
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___goalSize_4;
	// UnityEngine.Vector3[] stageData::wallPoss
	Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* ___wallPoss_5;
	// UnityEngine.Vector3[] stageData::wallSizes
	Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* ___wallSizes_6;

public:
	inline static int32_t get_offset_of_playerPos_0() { return static_cast<int32_t>(offsetof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512, ___playerPos_0)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_playerPos_0() const { return ___playerPos_0; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_playerPos_0() { return &___playerPos_0; }
	inline void set_playerPos_0(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___playerPos_0 = value;
	}

	inline static int32_t get_offset_of_inPoss_1() { return static_cast<int32_t>(offsetof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512, ___inPoss_1)); }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* get_inPoss_1() const { return ___inPoss_1; }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4** get_address_of_inPoss_1() { return &___inPoss_1; }
	inline void set_inPoss_1(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* value)
	{
		___inPoss_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___inPoss_1), (void*)value);
	}

	inline static int32_t get_offset_of_sekiPoss_2() { return static_cast<int32_t>(offsetof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512, ___sekiPoss_2)); }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* get_sekiPoss_2() const { return ___sekiPoss_2; }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4** get_address_of_sekiPoss_2() { return &___sekiPoss_2; }
	inline void set_sekiPoss_2(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* value)
	{
		___sekiPoss_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___sekiPoss_2), (void*)value);
	}

	inline static int32_t get_offset_of_goalPos_3() { return static_cast<int32_t>(offsetof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512, ___goalPos_3)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_goalPos_3() const { return ___goalPos_3; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_goalPos_3() { return &___goalPos_3; }
	inline void set_goalPos_3(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___goalPos_3 = value;
	}

	inline static int32_t get_offset_of_goalSize_4() { return static_cast<int32_t>(offsetof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512, ___goalSize_4)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_goalSize_4() const { return ___goalSize_4; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_goalSize_4() { return &___goalSize_4; }
	inline void set_goalSize_4(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___goalSize_4 = value;
	}

	inline static int32_t get_offset_of_wallPoss_5() { return static_cast<int32_t>(offsetof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512, ___wallPoss_5)); }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* get_wallPoss_5() const { return ___wallPoss_5; }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4** get_address_of_wallPoss_5() { return &___wallPoss_5; }
	inline void set_wallPoss_5(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* value)
	{
		___wallPoss_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___wallPoss_5), (void*)value);
	}

	inline static int32_t get_offset_of_wallSizes_6() { return static_cast<int32_t>(offsetof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512, ___wallSizes_6)); }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* get_wallSizes_6() const { return ___wallSizes_6; }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4** get_address_of_wallSizes_6() { return &___wallSizes_6; }
	inline void set_wallSizes_6(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* value)
	{
		___wallSizes_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___wallSizes_6), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of stageData
struct stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_pinvoke
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___playerPos_0;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___inPoss_1;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___sekiPoss_2;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___goalPos_3;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___goalSize_4;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___wallPoss_5;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___wallSizes_6;
};
// Native definition for COM marshalling of stageData
struct stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_com
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___playerPos_0;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___inPoss_1;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___sekiPoss_2;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___goalPos_3;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___goalSize_4;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___wallPoss_5;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * ___wallSizes_6;
};

// UnityEngine.UI.Navigation/Mode
struct Mode_t3113FDF05158BBA1DFC78D7F69E4C1D25135CB0F 
{
public:
	// System.Int32 UnityEngine.UI.Navigation/Mode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Mode_t3113FDF05158BBA1DFC78D7F69E4C1D25135CB0F, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.UI.Selectable/Transition
struct Transition_t1FC449676815A798E758D32E8BE6DC0A2511DF14 
{
public:
	// System.Int32 UnityEngine.UI.Selectable/Transition::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Transition_t1FC449676815A798E758D32E8BE6DC0A2511DF14, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.UI.Slider/Direction
struct Direction_tFC329DCFF9844C052301C90100CA0F5FA9C65961 
{
public:
	// System.Int32 UnityEngine.UI.Slider/Direction::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Direction_tFC329DCFF9844C052301C90100CA0F5FA9C65961, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.UI.Toggle/ToggleTransition
struct ToggleTransition_t4D1AA30F2BA24242EB9D1DD2E3DF839F0BAC5167 
{
public:
	// System.Int32 UnityEngine.UI.Toggle/ToggleTransition::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ToggleTransition_t4D1AA30F2BA24242EB9D1DD2E3DF839F0BAC5167, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.AudioClip
struct AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:
	// UnityEngine.AudioClip/PCMReaderCallback UnityEngine.AudioClip::m_PCMReaderCallback
	PCMReaderCallback_t9CA1437D36509A9FAC5EDD8FF2BC3259C24D0E0B * ___m_PCMReaderCallback_4;
	// UnityEngine.AudioClip/PCMSetPositionCallback UnityEngine.AudioClip::m_PCMSetPositionCallback
	PCMSetPositionCallback_tBDD99E7C0697687F1E7B06CDD5DE444A3709CF4C * ___m_PCMSetPositionCallback_5;

public:
	inline static int32_t get_offset_of_m_PCMReaderCallback_4() { return static_cast<int32_t>(offsetof(AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE, ___m_PCMReaderCallback_4)); }
	inline PCMReaderCallback_t9CA1437D36509A9FAC5EDD8FF2BC3259C24D0E0B * get_m_PCMReaderCallback_4() const { return ___m_PCMReaderCallback_4; }
	inline PCMReaderCallback_t9CA1437D36509A9FAC5EDD8FF2BC3259C24D0E0B ** get_address_of_m_PCMReaderCallback_4() { return &___m_PCMReaderCallback_4; }
	inline void set_m_PCMReaderCallback_4(PCMReaderCallback_t9CA1437D36509A9FAC5EDD8FF2BC3259C24D0E0B * value)
	{
		___m_PCMReaderCallback_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_PCMReaderCallback_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_PCMSetPositionCallback_5() { return static_cast<int32_t>(offsetof(AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE, ___m_PCMSetPositionCallback_5)); }
	inline PCMSetPositionCallback_tBDD99E7C0697687F1E7B06CDD5DE444A3709CF4C * get_m_PCMSetPositionCallback_5() const { return ___m_PCMSetPositionCallback_5; }
	inline PCMSetPositionCallback_tBDD99E7C0697687F1E7B06CDD5DE444A3709CF4C ** get_address_of_m_PCMSetPositionCallback_5() { return &___m_PCMSetPositionCallback_5; }
	inline void set_m_PCMSetPositionCallback_5(PCMSetPositionCallback_tBDD99E7C0697687F1E7B06CDD5DE444A3709CF4C * value)
	{
		___m_PCMSetPositionCallback_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_PCMSetPositionCallback_5), (void*)value);
	}
};


// UnityEngine.Component
struct Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:

public:
};


// UnityEngine.GameObject
struct GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:

public:
};


// UnityEngine.Material
struct Material_t8927C00353A72755313F046D0CE85178AE8218EE  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:

public:
};


// System.IO.MonoIOStat
struct MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71 
{
public:
	// System.IO.FileAttributes System.IO.MonoIOStat::fileAttributes
	int32_t ___fileAttributes_0;
	// System.Int64 System.IO.MonoIOStat::Length
	int64_t ___Length_1;
	// System.Int64 System.IO.MonoIOStat::CreationTime
	int64_t ___CreationTime_2;
	// System.Int64 System.IO.MonoIOStat::LastAccessTime
	int64_t ___LastAccessTime_3;
	// System.Int64 System.IO.MonoIOStat::LastWriteTime
	int64_t ___LastWriteTime_4;

public:
	inline static int32_t get_offset_of_fileAttributes_0() { return static_cast<int32_t>(offsetof(MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71, ___fileAttributes_0)); }
	inline int32_t get_fileAttributes_0() const { return ___fileAttributes_0; }
	inline int32_t* get_address_of_fileAttributes_0() { return &___fileAttributes_0; }
	inline void set_fileAttributes_0(int32_t value)
	{
		___fileAttributes_0 = value;
	}

	inline static int32_t get_offset_of_Length_1() { return static_cast<int32_t>(offsetof(MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71, ___Length_1)); }
	inline int64_t get_Length_1() const { return ___Length_1; }
	inline int64_t* get_address_of_Length_1() { return &___Length_1; }
	inline void set_Length_1(int64_t value)
	{
		___Length_1 = value;
	}

	inline static int32_t get_offset_of_CreationTime_2() { return static_cast<int32_t>(offsetof(MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71, ___CreationTime_2)); }
	inline int64_t get_CreationTime_2() const { return ___CreationTime_2; }
	inline int64_t* get_address_of_CreationTime_2() { return &___CreationTime_2; }
	inline void set_CreationTime_2(int64_t value)
	{
		___CreationTime_2 = value;
	}

	inline static int32_t get_offset_of_LastAccessTime_3() { return static_cast<int32_t>(offsetof(MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71, ___LastAccessTime_3)); }
	inline int64_t get_LastAccessTime_3() const { return ___LastAccessTime_3; }
	inline int64_t* get_address_of_LastAccessTime_3() { return &___LastAccessTime_3; }
	inline void set_LastAccessTime_3(int64_t value)
	{
		___LastAccessTime_3 = value;
	}

	inline static int32_t get_offset_of_LastWriteTime_4() { return static_cast<int32_t>(offsetof(MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71, ___LastWriteTime_4)); }
	inline int64_t get_LastWriteTime_4() const { return ___LastWriteTime_4; }
	inline int64_t* get_address_of_LastWriteTime_4() { return &___LastWriteTime_4; }
	inline void set_LastWriteTime_4(int64_t value)
	{
		___LastWriteTime_4 = value;
	}
};


// UnityEngine.UI.Navigation
struct Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A 
{
public:
	// UnityEngine.UI.Navigation/Mode UnityEngine.UI.Navigation::m_Mode
	int32_t ___m_Mode_0;
	// System.Boolean UnityEngine.UI.Navigation::m_WrapAround
	bool ___m_WrapAround_1;
	// UnityEngine.UI.Selectable UnityEngine.UI.Navigation::m_SelectOnUp
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnUp_2;
	// UnityEngine.UI.Selectable UnityEngine.UI.Navigation::m_SelectOnDown
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnDown_3;
	// UnityEngine.UI.Selectable UnityEngine.UI.Navigation::m_SelectOnLeft
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnLeft_4;
	// UnityEngine.UI.Selectable UnityEngine.UI.Navigation::m_SelectOnRight
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnRight_5;

public:
	inline static int32_t get_offset_of_m_Mode_0() { return static_cast<int32_t>(offsetof(Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A, ___m_Mode_0)); }
	inline int32_t get_m_Mode_0() const { return ___m_Mode_0; }
	inline int32_t* get_address_of_m_Mode_0() { return &___m_Mode_0; }
	inline void set_m_Mode_0(int32_t value)
	{
		___m_Mode_0 = value;
	}

	inline static int32_t get_offset_of_m_WrapAround_1() { return static_cast<int32_t>(offsetof(Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A, ___m_WrapAround_1)); }
	inline bool get_m_WrapAround_1() const { return ___m_WrapAround_1; }
	inline bool* get_address_of_m_WrapAround_1() { return &___m_WrapAround_1; }
	inline void set_m_WrapAround_1(bool value)
	{
		___m_WrapAround_1 = value;
	}

	inline static int32_t get_offset_of_m_SelectOnUp_2() { return static_cast<int32_t>(offsetof(Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A, ___m_SelectOnUp_2)); }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * get_m_SelectOnUp_2() const { return ___m_SelectOnUp_2; }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD ** get_address_of_m_SelectOnUp_2() { return &___m_SelectOnUp_2; }
	inline void set_m_SelectOnUp_2(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * value)
	{
		___m_SelectOnUp_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_SelectOnUp_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_SelectOnDown_3() { return static_cast<int32_t>(offsetof(Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A, ___m_SelectOnDown_3)); }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * get_m_SelectOnDown_3() const { return ___m_SelectOnDown_3; }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD ** get_address_of_m_SelectOnDown_3() { return &___m_SelectOnDown_3; }
	inline void set_m_SelectOnDown_3(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * value)
	{
		___m_SelectOnDown_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_SelectOnDown_3), (void*)value);
	}

	inline static int32_t get_offset_of_m_SelectOnLeft_4() { return static_cast<int32_t>(offsetof(Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A, ___m_SelectOnLeft_4)); }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * get_m_SelectOnLeft_4() const { return ___m_SelectOnLeft_4; }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD ** get_address_of_m_SelectOnLeft_4() { return &___m_SelectOnLeft_4; }
	inline void set_m_SelectOnLeft_4(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * value)
	{
		___m_SelectOnLeft_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_SelectOnLeft_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_SelectOnRight_5() { return static_cast<int32_t>(offsetof(Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A, ___m_SelectOnRight_5)); }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * get_m_SelectOnRight_5() const { return ___m_SelectOnRight_5; }
	inline Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD ** get_address_of_m_SelectOnRight_5() { return &___m_SelectOnRight_5; }
	inline void set_m_SelectOnRight_5(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * value)
	{
		___m_SelectOnRight_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_SelectOnRight_5), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.UI.Navigation
struct Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A_marshaled_pinvoke
{
	int32_t ___m_Mode_0;
	int32_t ___m_WrapAround_1;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnUp_2;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnDown_3;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnLeft_4;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnRight_5;
};
// Native definition for COM marshalling of UnityEngine.UI.Navigation
struct Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A_marshaled_com
{
	int32_t ___m_Mode_0;
	int32_t ___m_WrapAround_1;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnUp_2;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnDown_3;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnLeft_4;
	Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * ___m_SelectOnRight_5;
};

// UnityEngine.Behaviour
struct Behaviour_t1A3DDDCF73B4627928FBFE02ED52B7251777DBD9  : public Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684
{
public:

public:
};


// UnityEngine.Collider
struct Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02  : public Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684
{
public:

public:
};


// System.IO.FileSystemInfo
struct FileSystemInfo_t4479D65BB34DEAFCDA2A98F8B797D7C19EFDA246  : public MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8
{
public:
	// System.IO.MonoIOStat System.IO.FileSystemInfo::_data
	MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71  ____data_1;
	// System.Int32 System.IO.FileSystemInfo::_dataInitialised
	int32_t ____dataInitialised_2;
	// System.String System.IO.FileSystemInfo::FullPath
	String_t* ___FullPath_3;
	// System.String System.IO.FileSystemInfo::OriginalPath
	String_t* ___OriginalPath_4;
	// System.String System.IO.FileSystemInfo::_displayPath
	String_t* ____displayPath_5;

public:
	inline static int32_t get_offset_of__data_1() { return static_cast<int32_t>(offsetof(FileSystemInfo_t4479D65BB34DEAFCDA2A98F8B797D7C19EFDA246, ____data_1)); }
	inline MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71  get__data_1() const { return ____data_1; }
	inline MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71 * get_address_of__data_1() { return &____data_1; }
	inline void set__data_1(MonoIOStat_t24C11A45B0B5F84242B31BA1EF48458595FF5F71  value)
	{
		____data_1 = value;
	}

	inline static int32_t get_offset_of__dataInitialised_2() { return static_cast<int32_t>(offsetof(FileSystemInfo_t4479D65BB34DEAFCDA2A98F8B797D7C19EFDA246, ____dataInitialised_2)); }
	inline int32_t get__dataInitialised_2() const { return ____dataInitialised_2; }
	inline int32_t* get_address_of__dataInitialised_2() { return &____dataInitialised_2; }
	inline void set__dataInitialised_2(int32_t value)
	{
		____dataInitialised_2 = value;
	}

	inline static int32_t get_offset_of_FullPath_3() { return static_cast<int32_t>(offsetof(FileSystemInfo_t4479D65BB34DEAFCDA2A98F8B797D7C19EFDA246, ___FullPath_3)); }
	inline String_t* get_FullPath_3() const { return ___FullPath_3; }
	inline String_t** get_address_of_FullPath_3() { return &___FullPath_3; }
	inline void set_FullPath_3(String_t* value)
	{
		___FullPath_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FullPath_3), (void*)value);
	}

	inline static int32_t get_offset_of_OriginalPath_4() { return static_cast<int32_t>(offsetof(FileSystemInfo_t4479D65BB34DEAFCDA2A98F8B797D7C19EFDA246, ___OriginalPath_4)); }
	inline String_t* get_OriginalPath_4() const { return ___OriginalPath_4; }
	inline String_t** get_address_of_OriginalPath_4() { return &___OriginalPath_4; }
	inline void set_OriginalPath_4(String_t* value)
	{
		___OriginalPath_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OriginalPath_4), (void*)value);
	}

	inline static int32_t get_offset_of__displayPath_5() { return static_cast<int32_t>(offsetof(FileSystemInfo_t4479D65BB34DEAFCDA2A98F8B797D7C19EFDA246, ____displayPath_5)); }
	inline String_t* get__displayPath_5() const { return ____displayPath_5; }
	inline String_t** get_address_of__displayPath_5() { return &____displayPath_5; }
	inline void set__displayPath_5(String_t* value)
	{
		____displayPath_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____displayPath_5), (void*)value);
	}
};


// UnityEngine.Renderer
struct Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C  : public Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684
{
public:

public:
};


// UnityEngine.Rigidbody
struct Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A  : public Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684
{
public:

public:
};


// UnityEngine.Transform
struct Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1  : public Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684
{
public:

public:
};


// System.IO.DirectoryInfo
struct DirectoryInfo_t4EF3610F45F0D234800D01ADA8F3F476AE0CF5CD  : public FileSystemInfo_t4479D65BB34DEAFCDA2A98F8B797D7C19EFDA246
{
public:
	// System.String System.IO.DirectoryInfo::current
	String_t* ___current_6;
	// System.String System.IO.DirectoryInfo::parent
	String_t* ___parent_7;

public:
	inline static int32_t get_offset_of_current_6() { return static_cast<int32_t>(offsetof(DirectoryInfo_t4EF3610F45F0D234800D01ADA8F3F476AE0CF5CD, ___current_6)); }
	inline String_t* get_current_6() const { return ___current_6; }
	inline String_t** get_address_of_current_6() { return &___current_6; }
	inline void set_current_6(String_t* value)
	{
		___current_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___current_6), (void*)value);
	}

	inline static int32_t get_offset_of_parent_7() { return static_cast<int32_t>(offsetof(DirectoryInfo_t4EF3610F45F0D234800D01ADA8F3F476AE0CF5CD, ___parent_7)); }
	inline String_t* get_parent_7() const { return ___parent_7; }
	inline String_t** get_address_of_parent_7() { return &___parent_7; }
	inline void set_parent_7(String_t* value)
	{
		___parent_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___parent_7), (void*)value);
	}
};


// UnityEngine.MonoBehaviour
struct MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A  : public Behaviour_t1A3DDDCF73B4627928FBFE02ED52B7251777DBD9
{
public:

public:
};


// UnityEngine.TrailRenderer
struct TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01  : public Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C
{
public:

public:
};


// MainGameManager
struct MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.GameObject MainGameManager::player
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___player_4;
	// UnityEngine.GameObject MainGameManager::In
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___In_5;
	// UnityEngine.GameObject MainGameManager::Seki
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___Seki_6;
	// UnityEngine.GameObject MainGameManager::wall
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___wall_7;
	// UnityEngine.GameObject MainGameManager::goal
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___goal_8;
	// UnityEngine.GameObject MainGameManager::clearCanvasGroup
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___clearCanvasGroup_9;
	// UnityEngine.GameObject MainGameManager::btn_nextStage
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___btn_nextStage_10;
	// UnityEngine.GameObject MainGameManager::btn_retry
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___btn_retry_11;
	// UnityEngine.GameObject MainGameManager::btn_resume
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___btn_resume_12;
	// UnityEngine.GameObject MainGameManager::btn_setting
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___btn_setting_13;
	// UnityEngine.GameObject MainGameManager::toggle_autoRetry
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___toggle_autoRetry_14;
	// UniversalGravity MainGameManager::ug
	UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * ___ug_15;
	// System.Boolean MainGameManager::autoRetry
	bool ___autoRetry_16;
	// System.Boolean MainGameManager::isPausing
	bool ___isPausing_17;
	// UnityEngine.UI.Text MainGameManager::Label
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___Label_20;
	// UnityEngine.UI.Text MainGameManager::timeLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___timeLabel_21;
	// UnityEngine.UI.Text MainGameManager::stageLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___stageLabel_22;
	// UnityEngine.UI.Text MainGameManager::rtaResultLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___rtaResultLabel_23;
	// UnityEngine.UI.Text MainGameManager::challengeLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___challengeLabel_24;
	// System.String MainGameManager::temp
	String_t* ___temp_25;
	// datas MainGameManager::dat
	datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * ___dat_26;
	// UnityEngine.TrailRenderer MainGameManager::tr
	TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * ___tr_27;
	// stageData MainGameManager::sdata
	stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  ___sdata_28;
	// System.Single MainGameManager::t
	float ___t_29;
	// UnityEngine.Vector3 MainGameManager::playerVel
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___playerVel_30;
	// UnityEngine.Rigidbody MainGameManager::rb
	Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * ___rb_31;
	// SoundPlaySystem MainGameManager::soundPlaySystem
	SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * ___soundPlaySystem_32;
	// System.Single MainGameManager::soundEffectVolume
	float ___soundEffectVolume_33;
	// System.Single MainGameManager::backgroundSoundVolume
	float ___backgroundSoundVolume_34;

public:
	inline static int32_t get_offset_of_player_4() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___player_4)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_player_4() const { return ___player_4; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_player_4() { return &___player_4; }
	inline void set_player_4(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___player_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___player_4), (void*)value);
	}

	inline static int32_t get_offset_of_In_5() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___In_5)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_In_5() const { return ___In_5; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_In_5() { return &___In_5; }
	inline void set_In_5(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___In_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___In_5), (void*)value);
	}

	inline static int32_t get_offset_of_Seki_6() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___Seki_6)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_Seki_6() const { return ___Seki_6; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_Seki_6() { return &___Seki_6; }
	inline void set_Seki_6(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___Seki_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Seki_6), (void*)value);
	}

	inline static int32_t get_offset_of_wall_7() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___wall_7)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_wall_7() const { return ___wall_7; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_wall_7() { return &___wall_7; }
	inline void set_wall_7(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___wall_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___wall_7), (void*)value);
	}

	inline static int32_t get_offset_of_goal_8() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___goal_8)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_goal_8() const { return ___goal_8; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_goal_8() { return &___goal_8; }
	inline void set_goal_8(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___goal_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___goal_8), (void*)value);
	}

	inline static int32_t get_offset_of_clearCanvasGroup_9() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___clearCanvasGroup_9)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_clearCanvasGroup_9() const { return ___clearCanvasGroup_9; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_clearCanvasGroup_9() { return &___clearCanvasGroup_9; }
	inline void set_clearCanvasGroup_9(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___clearCanvasGroup_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___clearCanvasGroup_9), (void*)value);
	}

	inline static int32_t get_offset_of_btn_nextStage_10() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___btn_nextStage_10)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_btn_nextStage_10() const { return ___btn_nextStage_10; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_btn_nextStage_10() { return &___btn_nextStage_10; }
	inline void set_btn_nextStage_10(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___btn_nextStage_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___btn_nextStage_10), (void*)value);
	}

	inline static int32_t get_offset_of_btn_retry_11() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___btn_retry_11)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_btn_retry_11() const { return ___btn_retry_11; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_btn_retry_11() { return &___btn_retry_11; }
	inline void set_btn_retry_11(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___btn_retry_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___btn_retry_11), (void*)value);
	}

	inline static int32_t get_offset_of_btn_resume_12() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___btn_resume_12)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_btn_resume_12() const { return ___btn_resume_12; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_btn_resume_12() { return &___btn_resume_12; }
	inline void set_btn_resume_12(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___btn_resume_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___btn_resume_12), (void*)value);
	}

	inline static int32_t get_offset_of_btn_setting_13() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___btn_setting_13)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_btn_setting_13() const { return ___btn_setting_13; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_btn_setting_13() { return &___btn_setting_13; }
	inline void set_btn_setting_13(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___btn_setting_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___btn_setting_13), (void*)value);
	}

	inline static int32_t get_offset_of_toggle_autoRetry_14() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___toggle_autoRetry_14)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_toggle_autoRetry_14() const { return ___toggle_autoRetry_14; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_toggle_autoRetry_14() { return &___toggle_autoRetry_14; }
	inline void set_toggle_autoRetry_14(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___toggle_autoRetry_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___toggle_autoRetry_14), (void*)value);
	}

	inline static int32_t get_offset_of_ug_15() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___ug_15)); }
	inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * get_ug_15() const { return ___ug_15; }
	inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 ** get_address_of_ug_15() { return &___ug_15; }
	inline void set_ug_15(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * value)
	{
		___ug_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ug_15), (void*)value);
	}

	inline static int32_t get_offset_of_autoRetry_16() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___autoRetry_16)); }
	inline bool get_autoRetry_16() const { return ___autoRetry_16; }
	inline bool* get_address_of_autoRetry_16() { return &___autoRetry_16; }
	inline void set_autoRetry_16(bool value)
	{
		___autoRetry_16 = value;
	}

	inline static int32_t get_offset_of_isPausing_17() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___isPausing_17)); }
	inline bool get_isPausing_17() const { return ___isPausing_17; }
	inline bool* get_address_of_isPausing_17() { return &___isPausing_17; }
	inline void set_isPausing_17(bool value)
	{
		___isPausing_17 = value;
	}

	inline static int32_t get_offset_of_Label_20() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___Label_20)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_Label_20() const { return ___Label_20; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_Label_20() { return &___Label_20; }
	inline void set_Label_20(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___Label_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Label_20), (void*)value);
	}

	inline static int32_t get_offset_of_timeLabel_21() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___timeLabel_21)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_timeLabel_21() const { return ___timeLabel_21; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_timeLabel_21() { return &___timeLabel_21; }
	inline void set_timeLabel_21(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___timeLabel_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___timeLabel_21), (void*)value);
	}

	inline static int32_t get_offset_of_stageLabel_22() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___stageLabel_22)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_stageLabel_22() const { return ___stageLabel_22; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_stageLabel_22() { return &___stageLabel_22; }
	inline void set_stageLabel_22(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___stageLabel_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___stageLabel_22), (void*)value);
	}

	inline static int32_t get_offset_of_rtaResultLabel_23() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___rtaResultLabel_23)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_rtaResultLabel_23() const { return ___rtaResultLabel_23; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_rtaResultLabel_23() { return &___rtaResultLabel_23; }
	inline void set_rtaResultLabel_23(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___rtaResultLabel_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rtaResultLabel_23), (void*)value);
	}

	inline static int32_t get_offset_of_challengeLabel_24() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___challengeLabel_24)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_challengeLabel_24() const { return ___challengeLabel_24; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_challengeLabel_24() { return &___challengeLabel_24; }
	inline void set_challengeLabel_24(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___challengeLabel_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___challengeLabel_24), (void*)value);
	}

	inline static int32_t get_offset_of_temp_25() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___temp_25)); }
	inline String_t* get_temp_25() const { return ___temp_25; }
	inline String_t** get_address_of_temp_25() { return &___temp_25; }
	inline void set_temp_25(String_t* value)
	{
		___temp_25 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___temp_25), (void*)value);
	}

	inline static int32_t get_offset_of_dat_26() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___dat_26)); }
	inline datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * get_dat_26() const { return ___dat_26; }
	inline datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 ** get_address_of_dat_26() { return &___dat_26; }
	inline void set_dat_26(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * value)
	{
		___dat_26 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___dat_26), (void*)value);
	}

	inline static int32_t get_offset_of_tr_27() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___tr_27)); }
	inline TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * get_tr_27() const { return ___tr_27; }
	inline TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 ** get_address_of_tr_27() { return &___tr_27; }
	inline void set_tr_27(TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * value)
	{
		___tr_27 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___tr_27), (void*)value);
	}

	inline static int32_t get_offset_of_sdata_28() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___sdata_28)); }
	inline stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  get_sdata_28() const { return ___sdata_28; }
	inline stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * get_address_of_sdata_28() { return &___sdata_28; }
	inline void set_sdata_28(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  value)
	{
		___sdata_28 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_28))->___inPoss_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_28))->___sekiPoss_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_28))->___wallPoss_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_28))->___wallSizes_6), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_t_29() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___t_29)); }
	inline float get_t_29() const { return ___t_29; }
	inline float* get_address_of_t_29() { return &___t_29; }
	inline void set_t_29(float value)
	{
		___t_29 = value;
	}

	inline static int32_t get_offset_of_playerVel_30() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___playerVel_30)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_playerVel_30() const { return ___playerVel_30; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_playerVel_30() { return &___playerVel_30; }
	inline void set_playerVel_30(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___playerVel_30 = value;
	}

	inline static int32_t get_offset_of_rb_31() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___rb_31)); }
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * get_rb_31() const { return ___rb_31; }
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A ** get_address_of_rb_31() { return &___rb_31; }
	inline void set_rb_31(Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * value)
	{
		___rb_31 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rb_31), (void*)value);
	}

	inline static int32_t get_offset_of_soundPlaySystem_32() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___soundPlaySystem_32)); }
	inline SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * get_soundPlaySystem_32() const { return ___soundPlaySystem_32; }
	inline SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E ** get_address_of_soundPlaySystem_32() { return &___soundPlaySystem_32; }
	inline void set_soundPlaySystem_32(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * value)
	{
		___soundPlaySystem_32 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundPlaySystem_32), (void*)value);
	}

	inline static int32_t get_offset_of_soundEffectVolume_33() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___soundEffectVolume_33)); }
	inline float get_soundEffectVolume_33() const { return ___soundEffectVolume_33; }
	inline float* get_address_of_soundEffectVolume_33() { return &___soundEffectVolume_33; }
	inline void set_soundEffectVolume_33(float value)
	{
		___soundEffectVolume_33 = value;
	}

	inline static int32_t get_offset_of_backgroundSoundVolume_34() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4, ___backgroundSoundVolume_34)); }
	inline float get_backgroundSoundVolume_34() const { return ___backgroundSoundVolume_34; }
	inline float* get_address_of_backgroundSoundVolume_34() { return &___backgroundSoundVolume_34; }
	inline void set_backgroundSoundVolume_34(float value)
	{
		___backgroundSoundVolume_34 = value;
	}
};

struct MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields
{
public:
	// System.Boolean MainGameManager::rta
	bool ___rta_18;
	// System.Int32 MainGameManager::MAX_STAGE_NUM
	int32_t ___MAX_STAGE_NUM_19;

public:
	inline static int32_t get_offset_of_rta_18() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields, ___rta_18)); }
	inline bool get_rta_18() const { return ___rta_18; }
	inline bool* get_address_of_rta_18() { return &___rta_18; }
	inline void set_rta_18(bool value)
	{
		___rta_18 = value;
	}

	inline static int32_t get_offset_of_MAX_STAGE_NUM_19() { return static_cast<int32_t>(offsetof(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields, ___MAX_STAGE_NUM_19)); }
	inline int32_t get_MAX_STAGE_NUM_19() const { return ___MAX_STAGE_NUM_19; }
	inline int32_t* get_address_of_MAX_STAGE_NUM_19() { return &___MAX_STAGE_NUM_19; }
	inline void set_MAX_STAGE_NUM_19(int32_t value)
	{
		___MAX_STAGE_NUM_19 = value;
	}
};


// MusicManager
struct MusicManager_tFC710AB7CA46AF229C4B937E8F9E0119AE59182D  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// PlayerManager
struct PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Boolean PlayerManager::isCleared
	bool ___isCleared_4;
	// System.Boolean PlayerManager::isFailed
	bool ___isFailed_5;
	// UnityEngine.GameObject PlayerManager::Manager
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___Manager_6;
	// MainGameManager PlayerManager::mgManager
	MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * ___mgManager_7;
	// UnityEngine.Rigidbody PlayerManager::rb
	Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * ___rb_8;
	// UnityEngine.TrailRenderer PlayerManager::tr
	TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * ___tr_9;
	// stageData PlayerManager::sdata
	stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  ___sdata_10;
	// datas PlayerManager::dat
	datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * ___dat_11;
	// UniversalGravity PlayerManager::ug
	UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * ___ug_12;
	// UnityEngine.UI.Text PlayerManager::debugLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___debugLabel_13;
	// Sinus PlayerManager::sinus
	Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * ___sinus_14;
	// UnityEngine.GameObject[] PlayerManager::forceSpheres
	GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* ___forceSpheres_15;
	// SoundPlaySystem PlayerManager::soundPlaySystem
	SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * ___soundPlaySystem_16;
	// System.Boolean PlayerManager::hitClear
	bool ___hitClear_17;
	// System.Boolean PlayerManager::hitFail
	bool ___hitFail_18;
	// System.Boolean PlayerManager::hitWall
	bool ___hitWall_19;
	// System.Boolean PlayerManager::challengeFlag1
	bool ___challengeFlag1_20;
	// System.Int32 PlayerManager::clickCount
	int32_t ___clickCount_21;
	// System.Single PlayerManager::t
	float ___t_22;
	// UnityEngine.Vector3 PlayerManager::pos
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___pos_23;

public:
	inline static int32_t get_offset_of_isCleared_4() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___isCleared_4)); }
	inline bool get_isCleared_4() const { return ___isCleared_4; }
	inline bool* get_address_of_isCleared_4() { return &___isCleared_4; }
	inline void set_isCleared_4(bool value)
	{
		___isCleared_4 = value;
	}

	inline static int32_t get_offset_of_isFailed_5() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___isFailed_5)); }
	inline bool get_isFailed_5() const { return ___isFailed_5; }
	inline bool* get_address_of_isFailed_5() { return &___isFailed_5; }
	inline void set_isFailed_5(bool value)
	{
		___isFailed_5 = value;
	}

	inline static int32_t get_offset_of_Manager_6() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___Manager_6)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_Manager_6() const { return ___Manager_6; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_Manager_6() { return &___Manager_6; }
	inline void set_Manager_6(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___Manager_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Manager_6), (void*)value);
	}

	inline static int32_t get_offset_of_mgManager_7() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___mgManager_7)); }
	inline MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * get_mgManager_7() const { return ___mgManager_7; }
	inline MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 ** get_address_of_mgManager_7() { return &___mgManager_7; }
	inline void set_mgManager_7(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * value)
	{
		___mgManager_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___mgManager_7), (void*)value);
	}

	inline static int32_t get_offset_of_rb_8() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___rb_8)); }
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * get_rb_8() const { return ___rb_8; }
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A ** get_address_of_rb_8() { return &___rb_8; }
	inline void set_rb_8(Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * value)
	{
		___rb_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rb_8), (void*)value);
	}

	inline static int32_t get_offset_of_tr_9() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___tr_9)); }
	inline TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * get_tr_9() const { return ___tr_9; }
	inline TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 ** get_address_of_tr_9() { return &___tr_9; }
	inline void set_tr_9(TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * value)
	{
		___tr_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___tr_9), (void*)value);
	}

	inline static int32_t get_offset_of_sdata_10() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___sdata_10)); }
	inline stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  get_sdata_10() const { return ___sdata_10; }
	inline stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * get_address_of_sdata_10() { return &___sdata_10; }
	inline void set_sdata_10(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  value)
	{
		___sdata_10 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_10))->___inPoss_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_10))->___sekiPoss_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_10))->___wallPoss_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___sdata_10))->___wallSizes_6), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_dat_11() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___dat_11)); }
	inline datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * get_dat_11() const { return ___dat_11; }
	inline datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 ** get_address_of_dat_11() { return &___dat_11; }
	inline void set_dat_11(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * value)
	{
		___dat_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___dat_11), (void*)value);
	}

	inline static int32_t get_offset_of_ug_12() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___ug_12)); }
	inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * get_ug_12() const { return ___ug_12; }
	inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 ** get_address_of_ug_12() { return &___ug_12; }
	inline void set_ug_12(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * value)
	{
		___ug_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ug_12), (void*)value);
	}

	inline static int32_t get_offset_of_debugLabel_13() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___debugLabel_13)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_debugLabel_13() const { return ___debugLabel_13; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_debugLabel_13() { return &___debugLabel_13; }
	inline void set_debugLabel_13(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___debugLabel_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___debugLabel_13), (void*)value);
	}

	inline static int32_t get_offset_of_sinus_14() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___sinus_14)); }
	inline Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * get_sinus_14() const { return ___sinus_14; }
	inline Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 ** get_address_of_sinus_14() { return &___sinus_14; }
	inline void set_sinus_14(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * value)
	{
		___sinus_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___sinus_14), (void*)value);
	}

	inline static int32_t get_offset_of_forceSpheres_15() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___forceSpheres_15)); }
	inline GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* get_forceSpheres_15() const { return ___forceSpheres_15; }
	inline GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642** get_address_of_forceSpheres_15() { return &___forceSpheres_15; }
	inline void set_forceSpheres_15(GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* value)
	{
		___forceSpheres_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___forceSpheres_15), (void*)value);
	}

	inline static int32_t get_offset_of_soundPlaySystem_16() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___soundPlaySystem_16)); }
	inline SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * get_soundPlaySystem_16() const { return ___soundPlaySystem_16; }
	inline SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E ** get_address_of_soundPlaySystem_16() { return &___soundPlaySystem_16; }
	inline void set_soundPlaySystem_16(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * value)
	{
		___soundPlaySystem_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundPlaySystem_16), (void*)value);
	}

	inline static int32_t get_offset_of_hitClear_17() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___hitClear_17)); }
	inline bool get_hitClear_17() const { return ___hitClear_17; }
	inline bool* get_address_of_hitClear_17() { return &___hitClear_17; }
	inline void set_hitClear_17(bool value)
	{
		___hitClear_17 = value;
	}

	inline static int32_t get_offset_of_hitFail_18() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___hitFail_18)); }
	inline bool get_hitFail_18() const { return ___hitFail_18; }
	inline bool* get_address_of_hitFail_18() { return &___hitFail_18; }
	inline void set_hitFail_18(bool value)
	{
		___hitFail_18 = value;
	}

	inline static int32_t get_offset_of_hitWall_19() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___hitWall_19)); }
	inline bool get_hitWall_19() const { return ___hitWall_19; }
	inline bool* get_address_of_hitWall_19() { return &___hitWall_19; }
	inline void set_hitWall_19(bool value)
	{
		___hitWall_19 = value;
	}

	inline static int32_t get_offset_of_challengeFlag1_20() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___challengeFlag1_20)); }
	inline bool get_challengeFlag1_20() const { return ___challengeFlag1_20; }
	inline bool* get_address_of_challengeFlag1_20() { return &___challengeFlag1_20; }
	inline void set_challengeFlag1_20(bool value)
	{
		___challengeFlag1_20 = value;
	}

	inline static int32_t get_offset_of_clickCount_21() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___clickCount_21)); }
	inline int32_t get_clickCount_21() const { return ___clickCount_21; }
	inline int32_t* get_address_of_clickCount_21() { return &___clickCount_21; }
	inline void set_clickCount_21(int32_t value)
	{
		___clickCount_21 = value;
	}

	inline static int32_t get_offset_of_t_22() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___t_22)); }
	inline float get_t_22() const { return ___t_22; }
	inline float* get_address_of_t_22() { return &___t_22; }
	inline void set_t_22(float value)
	{
		___t_22 = value;
	}

	inline static int32_t get_offset_of_pos_23() { return static_cast<int32_t>(offsetof(PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48, ___pos_23)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_pos_23() const { return ___pos_23; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_pos_23() { return &___pos_23; }
	inline void set_pos_23(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___pos_23 = value;
	}
};


// Sinus
struct Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Single Sinus::frequency
	float ___frequency_4;
	// System.Single Sinus::overtonesRange
	float ___overtonesRange_5;
	// System.Single Sinus::freqRandRange
	float ___freqRandRange_6;
	// System.Single Sinus::randomFreq
	float ___randomFreq_7;
	// System.Single Sinus::gain
	float ___gain_8;
	// System.Single Sinus::increment
	float ___increment_9;
	// System.Single Sinus::phase
	float ___phase_10;
	// System.Single Sinus::sampleFreq
	float ___sampleFreq_11;

public:
	inline static int32_t get_offset_of_frequency_4() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___frequency_4)); }
	inline float get_frequency_4() const { return ___frequency_4; }
	inline float* get_address_of_frequency_4() { return &___frequency_4; }
	inline void set_frequency_4(float value)
	{
		___frequency_4 = value;
	}

	inline static int32_t get_offset_of_overtonesRange_5() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___overtonesRange_5)); }
	inline float get_overtonesRange_5() const { return ___overtonesRange_5; }
	inline float* get_address_of_overtonesRange_5() { return &___overtonesRange_5; }
	inline void set_overtonesRange_5(float value)
	{
		___overtonesRange_5 = value;
	}

	inline static int32_t get_offset_of_freqRandRange_6() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___freqRandRange_6)); }
	inline float get_freqRandRange_6() const { return ___freqRandRange_6; }
	inline float* get_address_of_freqRandRange_6() { return &___freqRandRange_6; }
	inline void set_freqRandRange_6(float value)
	{
		___freqRandRange_6 = value;
	}

	inline static int32_t get_offset_of_randomFreq_7() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___randomFreq_7)); }
	inline float get_randomFreq_7() const { return ___randomFreq_7; }
	inline float* get_address_of_randomFreq_7() { return &___randomFreq_7; }
	inline void set_randomFreq_7(float value)
	{
		___randomFreq_7 = value;
	}

	inline static int32_t get_offset_of_gain_8() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___gain_8)); }
	inline float get_gain_8() const { return ___gain_8; }
	inline float* get_address_of_gain_8() { return &___gain_8; }
	inline void set_gain_8(float value)
	{
		___gain_8 = value;
	}

	inline static int32_t get_offset_of_increment_9() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___increment_9)); }
	inline float get_increment_9() const { return ___increment_9; }
	inline float* get_address_of_increment_9() { return &___increment_9; }
	inline void set_increment_9(float value)
	{
		___increment_9 = value;
	}

	inline static int32_t get_offset_of_phase_10() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___phase_10)); }
	inline float get_phase_10() const { return ___phase_10; }
	inline float* get_address_of_phase_10() { return &___phase_10; }
	inline void set_phase_10(float value)
	{
		___phase_10 = value;
	}

	inline static int32_t get_offset_of_sampleFreq_11() { return static_cast<int32_t>(offsetof(Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5, ___sampleFreq_11)); }
	inline float get_sampleFreq_11() const { return ___sampleFreq_11; }
	inline float* get_address_of_sampleFreq_11() { return &___sampleFreq_11; }
	inline void set_sampleFreq_11(float value)
	{
		___sampleFreq_11 = value;
	}
};


// SoundPlaySystem
struct SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.AudioClip SoundPlaySystem::soundEffect
	AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * ___soundEffect_4;
	// System.Boolean SoundPlaySystem::isReady
	bool ___isReady_5;
	// System.Single[] SoundPlaySystem::soundData
	SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* ___soundData_6;
	// System.Int32 SoundPlaySystem::count
	int32_t ___count_7;
	// System.Int32 SoundPlaySystem::sampleLength
	int32_t ___sampleLength_8;
	// System.Single SoundPlaySystem::gain
	float ___gain_9;

public:
	inline static int32_t get_offset_of_soundEffect_4() { return static_cast<int32_t>(offsetof(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E, ___soundEffect_4)); }
	inline AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * get_soundEffect_4() const { return ___soundEffect_4; }
	inline AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE ** get_address_of_soundEffect_4() { return &___soundEffect_4; }
	inline void set_soundEffect_4(AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * value)
	{
		___soundEffect_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundEffect_4), (void*)value);
	}

	inline static int32_t get_offset_of_isReady_5() { return static_cast<int32_t>(offsetof(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E, ___isReady_5)); }
	inline bool get_isReady_5() const { return ___isReady_5; }
	inline bool* get_address_of_isReady_5() { return &___isReady_5; }
	inline void set_isReady_5(bool value)
	{
		___isReady_5 = value;
	}

	inline static int32_t get_offset_of_soundData_6() { return static_cast<int32_t>(offsetof(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E, ___soundData_6)); }
	inline SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* get_soundData_6() const { return ___soundData_6; }
	inline SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA** get_address_of_soundData_6() { return &___soundData_6; }
	inline void set_soundData_6(SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* value)
	{
		___soundData_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundData_6), (void*)value);
	}

	inline static int32_t get_offset_of_count_7() { return static_cast<int32_t>(offsetof(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E, ___count_7)); }
	inline int32_t get_count_7() const { return ___count_7; }
	inline int32_t* get_address_of_count_7() { return &___count_7; }
	inline void set_count_7(int32_t value)
	{
		___count_7 = value;
	}

	inline static int32_t get_offset_of_sampleLength_8() { return static_cast<int32_t>(offsetof(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E, ___sampleLength_8)); }
	inline int32_t get_sampleLength_8() const { return ___sampleLength_8; }
	inline int32_t* get_address_of_sampleLength_8() { return &___sampleLength_8; }
	inline void set_sampleLength_8(int32_t value)
	{
		___sampleLength_8 = value;
	}

	inline static int32_t get_offset_of_gain_9() { return static_cast<int32_t>(offsetof(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E, ___gain_9)); }
	inline float get_gain_9() const { return ___gain_9; }
	inline float* get_address_of_gain_9() { return &___gain_9; }
	inline void set_gain_9(float value)
	{
		___gain_9 = value;
	}
};


// SoundSettingManager
struct SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.UI.Slider SoundSettingManager::soundEffectSlider
	Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * ___soundEffectSlider_4;
	// UnityEngine.UI.Slider SoundSettingManager::backgroundSoundSlider
	Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * ___backgroundSoundSlider_5;
	// UnityEngine.GameObject SoundSettingManager::SoundSettingGroup
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___SoundSettingGroup_6;

public:
	inline static int32_t get_offset_of_soundEffectSlider_4() { return static_cast<int32_t>(offsetof(SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12, ___soundEffectSlider_4)); }
	inline Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * get_soundEffectSlider_4() const { return ___soundEffectSlider_4; }
	inline Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A ** get_address_of_soundEffectSlider_4() { return &___soundEffectSlider_4; }
	inline void set_soundEffectSlider_4(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * value)
	{
		___soundEffectSlider_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundEffectSlider_4), (void*)value);
	}

	inline static int32_t get_offset_of_backgroundSoundSlider_5() { return static_cast<int32_t>(offsetof(SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12, ___backgroundSoundSlider_5)); }
	inline Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * get_backgroundSoundSlider_5() const { return ___backgroundSoundSlider_5; }
	inline Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A ** get_address_of_backgroundSoundSlider_5() { return &___backgroundSoundSlider_5; }
	inline void set_backgroundSoundSlider_5(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * value)
	{
		___backgroundSoundSlider_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___backgroundSoundSlider_5), (void*)value);
	}

	inline static int32_t get_offset_of_SoundSettingGroup_6() { return static_cast<int32_t>(offsetof(SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12, ___SoundSettingGroup_6)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_SoundSettingGroup_6() const { return ___SoundSettingGroup_6; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_SoundSettingGroup_6() { return &___SoundSettingGroup_6; }
	inline void set_SoundSettingGroup_6(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___SoundSettingGroup_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___SoundSettingGroup_6), (void*)value);
	}
};


// TitleManager
struct TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// MainGameManager TitleManager::mainGameManager
	MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * ___mainGameManager_4;
	// datas TitleManager::dat
	datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * ___dat_5;
	// UnityEngine.GameObject[] TitleManager::canvasGroup
	GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* ___canvasGroup_6;
	// UnityEngine.GameObject TitleManager::creditGroup
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___creditGroup_7;
	// UnityEngine.GameObject TitleManager::bgm
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___bgm_8;
	// System.Boolean TitleManager::canvasStatus
	bool ___canvasStatus_9;
	// System.Boolean TitleManager::isCredit
	bool ___isCredit_10;
	// UnityEngine.UI.Text TitleManager::rtaBestScoreLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___rtaBestScoreLabel_11;
	// UnityEngine.UI.Text TitleManager::challengeLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___challengeLabel_12;
	// UnityEngine.UI.Text TitleManager::completeLabel
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___completeLabel_13;
	// System.String[] TitleManager::challenges
	StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* ___challenges_14;
	// UnityEngine.GameObject TitleManager::obj_ChallengeToggle
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___obj_ChallengeToggle_15;
	// System.Int32 TitleManager::completeRate
	int32_t ___completeRate_16;
	// UniversalGravity TitleManager::ug
	UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * ___ug_17;
	// SoundPlaySystem TitleManager::soundPlaySystem
	SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * ___soundPlaySystem_18;

public:
	inline static int32_t get_offset_of_mainGameManager_4() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___mainGameManager_4)); }
	inline MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * get_mainGameManager_4() const { return ___mainGameManager_4; }
	inline MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 ** get_address_of_mainGameManager_4() { return &___mainGameManager_4; }
	inline void set_mainGameManager_4(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * value)
	{
		___mainGameManager_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___mainGameManager_4), (void*)value);
	}

	inline static int32_t get_offset_of_dat_5() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___dat_5)); }
	inline datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * get_dat_5() const { return ___dat_5; }
	inline datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 ** get_address_of_dat_5() { return &___dat_5; }
	inline void set_dat_5(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * value)
	{
		___dat_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___dat_5), (void*)value);
	}

	inline static int32_t get_offset_of_canvasGroup_6() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___canvasGroup_6)); }
	inline GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* get_canvasGroup_6() const { return ___canvasGroup_6; }
	inline GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642** get_address_of_canvasGroup_6() { return &___canvasGroup_6; }
	inline void set_canvasGroup_6(GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* value)
	{
		___canvasGroup_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___canvasGroup_6), (void*)value);
	}

	inline static int32_t get_offset_of_creditGroup_7() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___creditGroup_7)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_creditGroup_7() const { return ___creditGroup_7; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_creditGroup_7() { return &___creditGroup_7; }
	inline void set_creditGroup_7(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___creditGroup_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___creditGroup_7), (void*)value);
	}

	inline static int32_t get_offset_of_bgm_8() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___bgm_8)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_bgm_8() const { return ___bgm_8; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_bgm_8() { return &___bgm_8; }
	inline void set_bgm_8(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___bgm_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bgm_8), (void*)value);
	}

	inline static int32_t get_offset_of_canvasStatus_9() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___canvasStatus_9)); }
	inline bool get_canvasStatus_9() const { return ___canvasStatus_9; }
	inline bool* get_address_of_canvasStatus_9() { return &___canvasStatus_9; }
	inline void set_canvasStatus_9(bool value)
	{
		___canvasStatus_9 = value;
	}

	inline static int32_t get_offset_of_isCredit_10() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___isCredit_10)); }
	inline bool get_isCredit_10() const { return ___isCredit_10; }
	inline bool* get_address_of_isCredit_10() { return &___isCredit_10; }
	inline void set_isCredit_10(bool value)
	{
		___isCredit_10 = value;
	}

	inline static int32_t get_offset_of_rtaBestScoreLabel_11() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___rtaBestScoreLabel_11)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_rtaBestScoreLabel_11() const { return ___rtaBestScoreLabel_11; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_rtaBestScoreLabel_11() { return &___rtaBestScoreLabel_11; }
	inline void set_rtaBestScoreLabel_11(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___rtaBestScoreLabel_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rtaBestScoreLabel_11), (void*)value);
	}

	inline static int32_t get_offset_of_challengeLabel_12() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___challengeLabel_12)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_challengeLabel_12() const { return ___challengeLabel_12; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_challengeLabel_12() { return &___challengeLabel_12; }
	inline void set_challengeLabel_12(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___challengeLabel_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___challengeLabel_12), (void*)value);
	}

	inline static int32_t get_offset_of_completeLabel_13() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___completeLabel_13)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_completeLabel_13() const { return ___completeLabel_13; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_completeLabel_13() { return &___completeLabel_13; }
	inline void set_completeLabel_13(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___completeLabel_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___completeLabel_13), (void*)value);
	}

	inline static int32_t get_offset_of_challenges_14() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___challenges_14)); }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* get_challenges_14() const { return ___challenges_14; }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A** get_address_of_challenges_14() { return &___challenges_14; }
	inline void set_challenges_14(StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* value)
	{
		___challenges_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___challenges_14), (void*)value);
	}

	inline static int32_t get_offset_of_obj_ChallengeToggle_15() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___obj_ChallengeToggle_15)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_obj_ChallengeToggle_15() const { return ___obj_ChallengeToggle_15; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_obj_ChallengeToggle_15() { return &___obj_ChallengeToggle_15; }
	inline void set_obj_ChallengeToggle_15(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___obj_ChallengeToggle_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___obj_ChallengeToggle_15), (void*)value);
	}

	inline static int32_t get_offset_of_completeRate_16() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___completeRate_16)); }
	inline int32_t get_completeRate_16() const { return ___completeRate_16; }
	inline int32_t* get_address_of_completeRate_16() { return &___completeRate_16; }
	inline void set_completeRate_16(int32_t value)
	{
		___completeRate_16 = value;
	}

	inline static int32_t get_offset_of_ug_17() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___ug_17)); }
	inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * get_ug_17() const { return ___ug_17; }
	inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 ** get_address_of_ug_17() { return &___ug_17; }
	inline void set_ug_17(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * value)
	{
		___ug_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ug_17), (void*)value);
	}

	inline static int32_t get_offset_of_soundPlaySystem_18() { return static_cast<int32_t>(offsetof(TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4, ___soundPlaySystem_18)); }
	inline SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * get_soundPlaySystem_18() const { return ___soundPlaySystem_18; }
	inline SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E ** get_address_of_soundPlaySystem_18() { return &___soundPlaySystem_18; }
	inline void set_soundPlaySystem_18(SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * value)
	{
		___soundPlaySystem_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundPlaySystem_18), (void*)value);
	}
};


// UnityEngine.EventSystems.UIBehaviour
struct UIBehaviour_tD1C6E2D542222546D68510ECE74036EFBC3C3B0E  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// UniversalGravity
struct UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Single UniversalGravity::G
	float ___G_4;
	// UnityEngine.GameObject[] UniversalGravity::AstroObjs
	GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* ___AstroObjs_5;
	// UnityEngine.Rigidbody[] UniversalGravity::rbs
	RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* ___rbs_6;
	// UnityEngine.Rigidbody UniversalGravity::rb
	Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * ___rb_7;
	// System.Int32 UniversalGravity::count
	int32_t ___count_8;
	// UnityEngine.Vector3 UniversalGravity::F
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___F_9;
	// System.Boolean UniversalGravity::forceMode
	bool ___forceMode_10;
	// UnityEngine.Color UniversalGravity::In
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___In_11;
	// UnityEngine.Color UniversalGravity::Seki
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___Seki_12;

public:
	inline static int32_t get_offset_of_G_4() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___G_4)); }
	inline float get_G_4() const { return ___G_4; }
	inline float* get_address_of_G_4() { return &___G_4; }
	inline void set_G_4(float value)
	{
		___G_4 = value;
	}

	inline static int32_t get_offset_of_AstroObjs_5() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___AstroObjs_5)); }
	inline GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* get_AstroObjs_5() const { return ___AstroObjs_5; }
	inline GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642** get_address_of_AstroObjs_5() { return &___AstroObjs_5; }
	inline void set_AstroObjs_5(GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* value)
	{
		___AstroObjs_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___AstroObjs_5), (void*)value);
	}

	inline static int32_t get_offset_of_rbs_6() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___rbs_6)); }
	inline RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* get_rbs_6() const { return ___rbs_6; }
	inline RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B** get_address_of_rbs_6() { return &___rbs_6; }
	inline void set_rbs_6(RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* value)
	{
		___rbs_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rbs_6), (void*)value);
	}

	inline static int32_t get_offset_of_rb_7() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___rb_7)); }
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * get_rb_7() const { return ___rb_7; }
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A ** get_address_of_rb_7() { return &___rb_7; }
	inline void set_rb_7(Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * value)
	{
		___rb_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rb_7), (void*)value);
	}

	inline static int32_t get_offset_of_count_8() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___count_8)); }
	inline int32_t get_count_8() const { return ___count_8; }
	inline int32_t* get_address_of_count_8() { return &___count_8; }
	inline void set_count_8(int32_t value)
	{
		___count_8 = value;
	}

	inline static int32_t get_offset_of_F_9() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___F_9)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_F_9() const { return ___F_9; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_F_9() { return &___F_9; }
	inline void set_F_9(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___F_9 = value;
	}

	inline static int32_t get_offset_of_forceMode_10() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___forceMode_10)); }
	inline bool get_forceMode_10() const { return ___forceMode_10; }
	inline bool* get_address_of_forceMode_10() { return &___forceMode_10; }
	inline void set_forceMode_10(bool value)
	{
		___forceMode_10 = value;
	}

	inline static int32_t get_offset_of_In_11() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___In_11)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_In_11() const { return ___In_11; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_In_11() { return &___In_11; }
	inline void set_In_11(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___In_11 = value;
	}

	inline static int32_t get_offset_of_Seki_12() { return static_cast<int32_t>(offsetof(UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9, ___Seki_12)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_Seki_12() const { return ___Seki_12; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_Seki_12() { return &___Seki_12; }
	inline void set_Seki_12(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___Seki_12 = value;
	}
};


// UnityEngine.EventSystems.EventSystem
struct EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C  : public UIBehaviour_tD1C6E2D542222546D68510ECE74036EFBC3C3B0E
{
public:
	// System.Collections.Generic.List`1<UnityEngine.EventSystems.BaseInputModule> UnityEngine.EventSystems.EventSystem::m_SystemInputModules
	List_1_t39946D94B66FAE9B0DED5D3A84AD116AF9DDDCC1 * ___m_SystemInputModules_4;
	// UnityEngine.EventSystems.BaseInputModule UnityEngine.EventSystems.EventSystem::m_CurrentInputModule
	BaseInputModule_t395DEB45C225A941B2C831CBDB000A23E5899924 * ___m_CurrentInputModule_5;
	// UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::m_FirstSelected
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_FirstSelected_7;
	// System.Boolean UnityEngine.EventSystems.EventSystem::m_sendNavigationEvents
	bool ___m_sendNavigationEvents_8;
	// System.Int32 UnityEngine.EventSystems.EventSystem::m_DragThreshold
	int32_t ___m_DragThreshold_9;
	// UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::m_CurrentSelected
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_CurrentSelected_10;
	// System.Boolean UnityEngine.EventSystems.EventSystem::m_HasFocus
	bool ___m_HasFocus_11;
	// System.Boolean UnityEngine.EventSystems.EventSystem::m_SelectionGuard
	bool ___m_SelectionGuard_12;
	// UnityEngine.EventSystems.BaseEventData UnityEngine.EventSystems.EventSystem::m_DummyData
	BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E * ___m_DummyData_13;

public:
	inline static int32_t get_offset_of_m_SystemInputModules_4() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_SystemInputModules_4)); }
	inline List_1_t39946D94B66FAE9B0DED5D3A84AD116AF9DDDCC1 * get_m_SystemInputModules_4() const { return ___m_SystemInputModules_4; }
	inline List_1_t39946D94B66FAE9B0DED5D3A84AD116AF9DDDCC1 ** get_address_of_m_SystemInputModules_4() { return &___m_SystemInputModules_4; }
	inline void set_m_SystemInputModules_4(List_1_t39946D94B66FAE9B0DED5D3A84AD116AF9DDDCC1 * value)
	{
		___m_SystemInputModules_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_SystemInputModules_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_CurrentInputModule_5() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_CurrentInputModule_5)); }
	inline BaseInputModule_t395DEB45C225A941B2C831CBDB000A23E5899924 * get_m_CurrentInputModule_5() const { return ___m_CurrentInputModule_5; }
	inline BaseInputModule_t395DEB45C225A941B2C831CBDB000A23E5899924 ** get_address_of_m_CurrentInputModule_5() { return &___m_CurrentInputModule_5; }
	inline void set_m_CurrentInputModule_5(BaseInputModule_t395DEB45C225A941B2C831CBDB000A23E5899924 * value)
	{
		___m_CurrentInputModule_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CurrentInputModule_5), (void*)value);
	}

	inline static int32_t get_offset_of_m_FirstSelected_7() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_FirstSelected_7)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_FirstSelected_7() const { return ___m_FirstSelected_7; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_FirstSelected_7() { return &___m_FirstSelected_7; }
	inline void set_m_FirstSelected_7(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_FirstSelected_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FirstSelected_7), (void*)value);
	}

	inline static int32_t get_offset_of_m_sendNavigationEvents_8() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_sendNavigationEvents_8)); }
	inline bool get_m_sendNavigationEvents_8() const { return ___m_sendNavigationEvents_8; }
	inline bool* get_address_of_m_sendNavigationEvents_8() { return &___m_sendNavigationEvents_8; }
	inline void set_m_sendNavigationEvents_8(bool value)
	{
		___m_sendNavigationEvents_8 = value;
	}

	inline static int32_t get_offset_of_m_DragThreshold_9() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_DragThreshold_9)); }
	inline int32_t get_m_DragThreshold_9() const { return ___m_DragThreshold_9; }
	inline int32_t* get_address_of_m_DragThreshold_9() { return &___m_DragThreshold_9; }
	inline void set_m_DragThreshold_9(int32_t value)
	{
		___m_DragThreshold_9 = value;
	}

	inline static int32_t get_offset_of_m_CurrentSelected_10() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_CurrentSelected_10)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_CurrentSelected_10() const { return ___m_CurrentSelected_10; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_CurrentSelected_10() { return &___m_CurrentSelected_10; }
	inline void set_m_CurrentSelected_10(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_CurrentSelected_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CurrentSelected_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_HasFocus_11() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_HasFocus_11)); }
	inline bool get_m_HasFocus_11() const { return ___m_HasFocus_11; }
	inline bool* get_address_of_m_HasFocus_11() { return &___m_HasFocus_11; }
	inline void set_m_HasFocus_11(bool value)
	{
		___m_HasFocus_11 = value;
	}

	inline static int32_t get_offset_of_m_SelectionGuard_12() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_SelectionGuard_12)); }
	inline bool get_m_SelectionGuard_12() const { return ___m_SelectionGuard_12; }
	inline bool* get_address_of_m_SelectionGuard_12() { return &___m_SelectionGuard_12; }
	inline void set_m_SelectionGuard_12(bool value)
	{
		___m_SelectionGuard_12 = value;
	}

	inline static int32_t get_offset_of_m_DummyData_13() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C, ___m_DummyData_13)); }
	inline BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E * get_m_DummyData_13() const { return ___m_DummyData_13; }
	inline BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E ** get_address_of_m_DummyData_13() { return &___m_DummyData_13; }
	inline void set_m_DummyData_13(BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E * value)
	{
		___m_DummyData_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DummyData_13), (void*)value);
	}
};

struct EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C_StaticFields
{
public:
	// System.Collections.Generic.List`1<UnityEngine.EventSystems.EventSystem> UnityEngine.EventSystems.EventSystem::m_EventSystems
	List_1_tEF3D2378B547F18609950BEABF54AF34FBBC9733 * ___m_EventSystems_6;
	// System.Comparison`1<UnityEngine.EventSystems.RaycastResult> UnityEngine.EventSystems.EventSystem::s_RaycastComparer
	Comparison_1_t47C8B3739FFDD51D29B281A2FD2C36A57DDF9E38 * ___s_RaycastComparer_14;

public:
	inline static int32_t get_offset_of_m_EventSystems_6() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C_StaticFields, ___m_EventSystems_6)); }
	inline List_1_tEF3D2378B547F18609950BEABF54AF34FBBC9733 * get_m_EventSystems_6() const { return ___m_EventSystems_6; }
	inline List_1_tEF3D2378B547F18609950BEABF54AF34FBBC9733 ** get_address_of_m_EventSystems_6() { return &___m_EventSystems_6; }
	inline void set_m_EventSystems_6(List_1_tEF3D2378B547F18609950BEABF54AF34FBBC9733 * value)
	{
		___m_EventSystems_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_EventSystems_6), (void*)value);
	}

	inline static int32_t get_offset_of_s_RaycastComparer_14() { return static_cast<int32_t>(offsetof(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C_StaticFields, ___s_RaycastComparer_14)); }
	inline Comparison_1_t47C8B3739FFDD51D29B281A2FD2C36A57DDF9E38 * get_s_RaycastComparer_14() const { return ___s_RaycastComparer_14; }
	inline Comparison_1_t47C8B3739FFDD51D29B281A2FD2C36A57DDF9E38 ** get_address_of_s_RaycastComparer_14() { return &___s_RaycastComparer_14; }
	inline void set_s_RaycastComparer_14(Comparison_1_t47C8B3739FFDD51D29B281A2FD2C36A57DDF9E38 * value)
	{
		___s_RaycastComparer_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_RaycastComparer_14), (void*)value);
	}
};


// UnityEngine.UI.Graphic
struct Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24  : public UIBehaviour_tD1C6E2D542222546D68510ECE74036EFBC3C3B0E
{
public:
	// UnityEngine.Material UnityEngine.UI.Graphic::m_Material
	Material_t8927C00353A72755313F046D0CE85178AE8218EE * ___m_Material_6;
	// UnityEngine.Color UnityEngine.UI.Graphic::m_Color
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___m_Color_7;
	// System.Boolean UnityEngine.UI.Graphic::m_SkipLayoutUpdate
	bool ___m_SkipLayoutUpdate_8;
	// System.Boolean UnityEngine.UI.Graphic::m_SkipMaterialUpdate
	bool ___m_SkipMaterialUpdate_9;
	// System.Boolean UnityEngine.UI.Graphic::m_RaycastTarget
	bool ___m_RaycastTarget_10;
	// UnityEngine.Vector4 UnityEngine.UI.Graphic::m_RaycastPadding
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___m_RaycastPadding_11;
	// UnityEngine.RectTransform UnityEngine.UI.Graphic::m_RectTransform
	RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * ___m_RectTransform_12;
	// UnityEngine.CanvasRenderer UnityEngine.UI.Graphic::m_CanvasRenderer
	CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E * ___m_CanvasRenderer_13;
	// UnityEngine.Canvas UnityEngine.UI.Graphic::m_Canvas
	Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA * ___m_Canvas_14;
	// System.Boolean UnityEngine.UI.Graphic::m_VertsDirty
	bool ___m_VertsDirty_15;
	// System.Boolean UnityEngine.UI.Graphic::m_MaterialDirty
	bool ___m_MaterialDirty_16;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyLayoutCallback
	UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * ___m_OnDirtyLayoutCallback_17;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyVertsCallback
	UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * ___m_OnDirtyVertsCallback_18;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyMaterialCallback
	UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * ___m_OnDirtyMaterialCallback_19;
	// UnityEngine.Mesh UnityEngine.UI.Graphic::m_CachedMesh
	Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * ___m_CachedMesh_22;
	// UnityEngine.Vector2[] UnityEngine.UI.Graphic::m_CachedUvs
	Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA* ___m_CachedUvs_23;
	// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween> UnityEngine.UI.Graphic::m_ColorTweenRunner
	TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 * ___m_ColorTweenRunner_24;
	// System.Boolean UnityEngine.UI.Graphic::<useLegacyMeshGeneration>k__BackingField
	bool ___U3CuseLegacyMeshGenerationU3Ek__BackingField_25;

public:
	inline static int32_t get_offset_of_m_Material_6() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_Material_6)); }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE * get_m_Material_6() const { return ___m_Material_6; }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE ** get_address_of_m_Material_6() { return &___m_Material_6; }
	inline void set_m_Material_6(Material_t8927C00353A72755313F046D0CE85178AE8218EE * value)
	{
		___m_Material_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Material_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_Color_7() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_Color_7)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_m_Color_7() const { return ___m_Color_7; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_m_Color_7() { return &___m_Color_7; }
	inline void set_m_Color_7(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___m_Color_7 = value;
	}

	inline static int32_t get_offset_of_m_SkipLayoutUpdate_8() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_SkipLayoutUpdate_8)); }
	inline bool get_m_SkipLayoutUpdate_8() const { return ___m_SkipLayoutUpdate_8; }
	inline bool* get_address_of_m_SkipLayoutUpdate_8() { return &___m_SkipLayoutUpdate_8; }
	inline void set_m_SkipLayoutUpdate_8(bool value)
	{
		___m_SkipLayoutUpdate_8 = value;
	}

	inline static int32_t get_offset_of_m_SkipMaterialUpdate_9() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_SkipMaterialUpdate_9)); }
	inline bool get_m_SkipMaterialUpdate_9() const { return ___m_SkipMaterialUpdate_9; }
	inline bool* get_address_of_m_SkipMaterialUpdate_9() { return &___m_SkipMaterialUpdate_9; }
	inline void set_m_SkipMaterialUpdate_9(bool value)
	{
		___m_SkipMaterialUpdate_9 = value;
	}

	inline static int32_t get_offset_of_m_RaycastTarget_10() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_RaycastTarget_10)); }
	inline bool get_m_RaycastTarget_10() const { return ___m_RaycastTarget_10; }
	inline bool* get_address_of_m_RaycastTarget_10() { return &___m_RaycastTarget_10; }
	inline void set_m_RaycastTarget_10(bool value)
	{
		___m_RaycastTarget_10 = value;
	}

	inline static int32_t get_offset_of_m_RaycastPadding_11() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_RaycastPadding_11)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_m_RaycastPadding_11() const { return ___m_RaycastPadding_11; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_m_RaycastPadding_11() { return &___m_RaycastPadding_11; }
	inline void set_m_RaycastPadding_11(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___m_RaycastPadding_11 = value;
	}

	inline static int32_t get_offset_of_m_RectTransform_12() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_RectTransform_12)); }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * get_m_RectTransform_12() const { return ___m_RectTransform_12; }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 ** get_address_of_m_RectTransform_12() { return &___m_RectTransform_12; }
	inline void set_m_RectTransform_12(RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * value)
	{
		___m_RectTransform_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_RectTransform_12), (void*)value);
	}

	inline static int32_t get_offset_of_m_CanvasRenderer_13() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_CanvasRenderer_13)); }
	inline CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E * get_m_CanvasRenderer_13() const { return ___m_CanvasRenderer_13; }
	inline CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E ** get_address_of_m_CanvasRenderer_13() { return &___m_CanvasRenderer_13; }
	inline void set_m_CanvasRenderer_13(CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E * value)
	{
		___m_CanvasRenderer_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CanvasRenderer_13), (void*)value);
	}

	inline static int32_t get_offset_of_m_Canvas_14() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_Canvas_14)); }
	inline Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA * get_m_Canvas_14() const { return ___m_Canvas_14; }
	inline Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA ** get_address_of_m_Canvas_14() { return &___m_Canvas_14; }
	inline void set_m_Canvas_14(Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA * value)
	{
		___m_Canvas_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Canvas_14), (void*)value);
	}

	inline static int32_t get_offset_of_m_VertsDirty_15() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_VertsDirty_15)); }
	inline bool get_m_VertsDirty_15() const { return ___m_VertsDirty_15; }
	inline bool* get_address_of_m_VertsDirty_15() { return &___m_VertsDirty_15; }
	inline void set_m_VertsDirty_15(bool value)
	{
		___m_VertsDirty_15 = value;
	}

	inline static int32_t get_offset_of_m_MaterialDirty_16() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_MaterialDirty_16)); }
	inline bool get_m_MaterialDirty_16() const { return ___m_MaterialDirty_16; }
	inline bool* get_address_of_m_MaterialDirty_16() { return &___m_MaterialDirty_16; }
	inline void set_m_MaterialDirty_16(bool value)
	{
		___m_MaterialDirty_16 = value;
	}

	inline static int32_t get_offset_of_m_OnDirtyLayoutCallback_17() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_OnDirtyLayoutCallback_17)); }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * get_m_OnDirtyLayoutCallback_17() const { return ___m_OnDirtyLayoutCallback_17; }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 ** get_address_of_m_OnDirtyLayoutCallback_17() { return &___m_OnDirtyLayoutCallback_17; }
	inline void set_m_OnDirtyLayoutCallback_17(UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * value)
	{
		___m_OnDirtyLayoutCallback_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnDirtyLayoutCallback_17), (void*)value);
	}

	inline static int32_t get_offset_of_m_OnDirtyVertsCallback_18() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_OnDirtyVertsCallback_18)); }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * get_m_OnDirtyVertsCallback_18() const { return ___m_OnDirtyVertsCallback_18; }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 ** get_address_of_m_OnDirtyVertsCallback_18() { return &___m_OnDirtyVertsCallback_18; }
	inline void set_m_OnDirtyVertsCallback_18(UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * value)
	{
		___m_OnDirtyVertsCallback_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnDirtyVertsCallback_18), (void*)value);
	}

	inline static int32_t get_offset_of_m_OnDirtyMaterialCallback_19() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_OnDirtyMaterialCallback_19)); }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * get_m_OnDirtyMaterialCallback_19() const { return ___m_OnDirtyMaterialCallback_19; }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 ** get_address_of_m_OnDirtyMaterialCallback_19() { return &___m_OnDirtyMaterialCallback_19; }
	inline void set_m_OnDirtyMaterialCallback_19(UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * value)
	{
		___m_OnDirtyMaterialCallback_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnDirtyMaterialCallback_19), (void*)value);
	}

	inline static int32_t get_offset_of_m_CachedMesh_22() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_CachedMesh_22)); }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * get_m_CachedMesh_22() const { return ___m_CachedMesh_22; }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 ** get_address_of_m_CachedMesh_22() { return &___m_CachedMesh_22; }
	inline void set_m_CachedMesh_22(Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * value)
	{
		___m_CachedMesh_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CachedMesh_22), (void*)value);
	}

	inline static int32_t get_offset_of_m_CachedUvs_23() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_CachedUvs_23)); }
	inline Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA* get_m_CachedUvs_23() const { return ___m_CachedUvs_23; }
	inline Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA** get_address_of_m_CachedUvs_23() { return &___m_CachedUvs_23; }
	inline void set_m_CachedUvs_23(Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA* value)
	{
		___m_CachedUvs_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CachedUvs_23), (void*)value);
	}

	inline static int32_t get_offset_of_m_ColorTweenRunner_24() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_ColorTweenRunner_24)); }
	inline TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 * get_m_ColorTweenRunner_24() const { return ___m_ColorTweenRunner_24; }
	inline TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 ** get_address_of_m_ColorTweenRunner_24() { return &___m_ColorTweenRunner_24; }
	inline void set_m_ColorTweenRunner_24(TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 * value)
	{
		___m_ColorTweenRunner_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ColorTweenRunner_24), (void*)value);
	}

	inline static int32_t get_offset_of_U3CuseLegacyMeshGenerationU3Ek__BackingField_25() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___U3CuseLegacyMeshGenerationU3Ek__BackingField_25)); }
	inline bool get_U3CuseLegacyMeshGenerationU3Ek__BackingField_25() const { return ___U3CuseLegacyMeshGenerationU3Ek__BackingField_25; }
	inline bool* get_address_of_U3CuseLegacyMeshGenerationU3Ek__BackingField_25() { return &___U3CuseLegacyMeshGenerationU3Ek__BackingField_25; }
	inline void set_U3CuseLegacyMeshGenerationU3Ek__BackingField_25(bool value)
	{
		___U3CuseLegacyMeshGenerationU3Ek__BackingField_25 = value;
	}
};

struct Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields
{
public:
	// UnityEngine.Material UnityEngine.UI.Graphic::s_DefaultUI
	Material_t8927C00353A72755313F046D0CE85178AE8218EE * ___s_DefaultUI_4;
	// UnityEngine.Texture2D UnityEngine.UI.Graphic::s_WhiteTexture
	Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * ___s_WhiteTexture_5;
	// UnityEngine.Mesh UnityEngine.UI.Graphic::s_Mesh
	Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * ___s_Mesh_20;
	// UnityEngine.UI.VertexHelper UnityEngine.UI.Graphic::s_VertexHelper
	VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 * ___s_VertexHelper_21;

public:
	inline static int32_t get_offset_of_s_DefaultUI_4() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_DefaultUI_4)); }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE * get_s_DefaultUI_4() const { return ___s_DefaultUI_4; }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE ** get_address_of_s_DefaultUI_4() { return &___s_DefaultUI_4; }
	inline void set_s_DefaultUI_4(Material_t8927C00353A72755313F046D0CE85178AE8218EE * value)
	{
		___s_DefaultUI_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_DefaultUI_4), (void*)value);
	}

	inline static int32_t get_offset_of_s_WhiteTexture_5() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_WhiteTexture_5)); }
	inline Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * get_s_WhiteTexture_5() const { return ___s_WhiteTexture_5; }
	inline Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF ** get_address_of_s_WhiteTexture_5() { return &___s_WhiteTexture_5; }
	inline void set_s_WhiteTexture_5(Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * value)
	{
		___s_WhiteTexture_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_WhiteTexture_5), (void*)value);
	}

	inline static int32_t get_offset_of_s_Mesh_20() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_Mesh_20)); }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * get_s_Mesh_20() const { return ___s_Mesh_20; }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 ** get_address_of_s_Mesh_20() { return &___s_Mesh_20; }
	inline void set_s_Mesh_20(Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * value)
	{
		___s_Mesh_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Mesh_20), (void*)value);
	}

	inline static int32_t get_offset_of_s_VertexHelper_21() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_VertexHelper_21)); }
	inline VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 * get_s_VertexHelper_21() const { return ___s_VertexHelper_21; }
	inline VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 ** get_address_of_s_VertexHelper_21() { return &___s_VertexHelper_21; }
	inline void set_s_VertexHelper_21(VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 * value)
	{
		___s_VertexHelper_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_VertexHelper_21), (void*)value);
	}
};


// UnityEngine.UI.Selectable
struct Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD  : public UIBehaviour_tD1C6E2D542222546D68510ECE74036EFBC3C3B0E
{
public:
	// System.Boolean UnityEngine.UI.Selectable::m_EnableCalled
	bool ___m_EnableCalled_6;
	// UnityEngine.UI.Navigation UnityEngine.UI.Selectable::m_Navigation
	Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A  ___m_Navigation_7;
	// UnityEngine.UI.Selectable/Transition UnityEngine.UI.Selectable::m_Transition
	int32_t ___m_Transition_8;
	// UnityEngine.UI.ColorBlock UnityEngine.UI.Selectable::m_Colors
	ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955  ___m_Colors_9;
	// UnityEngine.UI.SpriteState UnityEngine.UI.Selectable::m_SpriteState
	SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E  ___m_SpriteState_10;
	// UnityEngine.UI.AnimationTriggers UnityEngine.UI.Selectable::m_AnimationTriggers
	AnimationTriggers_tF38CA7FA631709E096B57D732668D86081F44C11 * ___m_AnimationTriggers_11;
	// System.Boolean UnityEngine.UI.Selectable::m_Interactable
	bool ___m_Interactable_12;
	// UnityEngine.UI.Graphic UnityEngine.UI.Selectable::m_TargetGraphic
	Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___m_TargetGraphic_13;
	// System.Boolean UnityEngine.UI.Selectable::m_GroupsAllowInteraction
	bool ___m_GroupsAllowInteraction_14;
	// System.Int32 UnityEngine.UI.Selectable::m_CurrentIndex
	int32_t ___m_CurrentIndex_15;
	// System.Boolean UnityEngine.UI.Selectable::<isPointerInside>k__BackingField
	bool ___U3CisPointerInsideU3Ek__BackingField_16;
	// System.Boolean UnityEngine.UI.Selectable::<isPointerDown>k__BackingField
	bool ___U3CisPointerDownU3Ek__BackingField_17;
	// System.Boolean UnityEngine.UI.Selectable::<hasSelection>k__BackingField
	bool ___U3ChasSelectionU3Ek__BackingField_18;
	// System.Collections.Generic.List`1<UnityEngine.CanvasGroup> UnityEngine.UI.Selectable::m_CanvasGroupCache
	List_1_t34AA4AF4E7352129CA58045901530E41445AC16D * ___m_CanvasGroupCache_19;

public:
	inline static int32_t get_offset_of_m_EnableCalled_6() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_EnableCalled_6)); }
	inline bool get_m_EnableCalled_6() const { return ___m_EnableCalled_6; }
	inline bool* get_address_of_m_EnableCalled_6() { return &___m_EnableCalled_6; }
	inline void set_m_EnableCalled_6(bool value)
	{
		___m_EnableCalled_6 = value;
	}

	inline static int32_t get_offset_of_m_Navigation_7() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_Navigation_7)); }
	inline Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A  get_m_Navigation_7() const { return ___m_Navigation_7; }
	inline Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A * get_address_of_m_Navigation_7() { return &___m_Navigation_7; }
	inline void set_m_Navigation_7(Navigation_t1CF0FFB22C0357CD64714FB7A40A275F899D363A  value)
	{
		___m_Navigation_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Navigation_7))->___m_SelectOnUp_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Navigation_7))->___m_SelectOnDown_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Navigation_7))->___m_SelectOnLeft_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Navigation_7))->___m_SelectOnRight_5), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_Transition_8() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_Transition_8)); }
	inline int32_t get_m_Transition_8() const { return ___m_Transition_8; }
	inline int32_t* get_address_of_m_Transition_8() { return &___m_Transition_8; }
	inline void set_m_Transition_8(int32_t value)
	{
		___m_Transition_8 = value;
	}

	inline static int32_t get_offset_of_m_Colors_9() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_Colors_9)); }
	inline ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955  get_m_Colors_9() const { return ___m_Colors_9; }
	inline ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955 * get_address_of_m_Colors_9() { return &___m_Colors_9; }
	inline void set_m_Colors_9(ColorBlock_t04DFBB97B4772D2E00FD17ED2E3E6590E6916955  value)
	{
		___m_Colors_9 = value;
	}

	inline static int32_t get_offset_of_m_SpriteState_10() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_SpriteState_10)); }
	inline SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E  get_m_SpriteState_10() const { return ___m_SpriteState_10; }
	inline SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E * get_address_of_m_SpriteState_10() { return &___m_SpriteState_10; }
	inline void set_m_SpriteState_10(SpriteState_t9024961148433175CE2F3D9E8E9239A8B1CAB15E  value)
	{
		___m_SpriteState_10 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_SpriteState_10))->___m_HighlightedSprite_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_SpriteState_10))->___m_PressedSprite_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_SpriteState_10))->___m_SelectedSprite_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_SpriteState_10))->___m_DisabledSprite_3), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_AnimationTriggers_11() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_AnimationTriggers_11)); }
	inline AnimationTriggers_tF38CA7FA631709E096B57D732668D86081F44C11 * get_m_AnimationTriggers_11() const { return ___m_AnimationTriggers_11; }
	inline AnimationTriggers_tF38CA7FA631709E096B57D732668D86081F44C11 ** get_address_of_m_AnimationTriggers_11() { return &___m_AnimationTriggers_11; }
	inline void set_m_AnimationTriggers_11(AnimationTriggers_tF38CA7FA631709E096B57D732668D86081F44C11 * value)
	{
		___m_AnimationTriggers_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_AnimationTriggers_11), (void*)value);
	}

	inline static int32_t get_offset_of_m_Interactable_12() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_Interactable_12)); }
	inline bool get_m_Interactable_12() const { return ___m_Interactable_12; }
	inline bool* get_address_of_m_Interactable_12() { return &___m_Interactable_12; }
	inline void set_m_Interactable_12(bool value)
	{
		___m_Interactable_12 = value;
	}

	inline static int32_t get_offset_of_m_TargetGraphic_13() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_TargetGraphic_13)); }
	inline Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * get_m_TargetGraphic_13() const { return ___m_TargetGraphic_13; }
	inline Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 ** get_address_of_m_TargetGraphic_13() { return &___m_TargetGraphic_13; }
	inline void set_m_TargetGraphic_13(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * value)
	{
		___m_TargetGraphic_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_TargetGraphic_13), (void*)value);
	}

	inline static int32_t get_offset_of_m_GroupsAllowInteraction_14() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_GroupsAllowInteraction_14)); }
	inline bool get_m_GroupsAllowInteraction_14() const { return ___m_GroupsAllowInteraction_14; }
	inline bool* get_address_of_m_GroupsAllowInteraction_14() { return &___m_GroupsAllowInteraction_14; }
	inline void set_m_GroupsAllowInteraction_14(bool value)
	{
		___m_GroupsAllowInteraction_14 = value;
	}

	inline static int32_t get_offset_of_m_CurrentIndex_15() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_CurrentIndex_15)); }
	inline int32_t get_m_CurrentIndex_15() const { return ___m_CurrentIndex_15; }
	inline int32_t* get_address_of_m_CurrentIndex_15() { return &___m_CurrentIndex_15; }
	inline void set_m_CurrentIndex_15(int32_t value)
	{
		___m_CurrentIndex_15 = value;
	}

	inline static int32_t get_offset_of_U3CisPointerInsideU3Ek__BackingField_16() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___U3CisPointerInsideU3Ek__BackingField_16)); }
	inline bool get_U3CisPointerInsideU3Ek__BackingField_16() const { return ___U3CisPointerInsideU3Ek__BackingField_16; }
	inline bool* get_address_of_U3CisPointerInsideU3Ek__BackingField_16() { return &___U3CisPointerInsideU3Ek__BackingField_16; }
	inline void set_U3CisPointerInsideU3Ek__BackingField_16(bool value)
	{
		___U3CisPointerInsideU3Ek__BackingField_16 = value;
	}

	inline static int32_t get_offset_of_U3CisPointerDownU3Ek__BackingField_17() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___U3CisPointerDownU3Ek__BackingField_17)); }
	inline bool get_U3CisPointerDownU3Ek__BackingField_17() const { return ___U3CisPointerDownU3Ek__BackingField_17; }
	inline bool* get_address_of_U3CisPointerDownU3Ek__BackingField_17() { return &___U3CisPointerDownU3Ek__BackingField_17; }
	inline void set_U3CisPointerDownU3Ek__BackingField_17(bool value)
	{
		___U3CisPointerDownU3Ek__BackingField_17 = value;
	}

	inline static int32_t get_offset_of_U3ChasSelectionU3Ek__BackingField_18() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___U3ChasSelectionU3Ek__BackingField_18)); }
	inline bool get_U3ChasSelectionU3Ek__BackingField_18() const { return ___U3ChasSelectionU3Ek__BackingField_18; }
	inline bool* get_address_of_U3ChasSelectionU3Ek__BackingField_18() { return &___U3ChasSelectionU3Ek__BackingField_18; }
	inline void set_U3ChasSelectionU3Ek__BackingField_18(bool value)
	{
		___U3ChasSelectionU3Ek__BackingField_18 = value;
	}

	inline static int32_t get_offset_of_m_CanvasGroupCache_19() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD, ___m_CanvasGroupCache_19)); }
	inline List_1_t34AA4AF4E7352129CA58045901530E41445AC16D * get_m_CanvasGroupCache_19() const { return ___m_CanvasGroupCache_19; }
	inline List_1_t34AA4AF4E7352129CA58045901530E41445AC16D ** get_address_of_m_CanvasGroupCache_19() { return &___m_CanvasGroupCache_19; }
	inline void set_m_CanvasGroupCache_19(List_1_t34AA4AF4E7352129CA58045901530E41445AC16D * value)
	{
		___m_CanvasGroupCache_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CanvasGroupCache_19), (void*)value);
	}
};

struct Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD_StaticFields
{
public:
	// UnityEngine.UI.Selectable[] UnityEngine.UI.Selectable::s_Selectables
	SelectableU5BU5D_tECF9F5BDBF0652A937D18F10C883EFDAE2E62535* ___s_Selectables_4;
	// System.Int32 UnityEngine.UI.Selectable::s_SelectableCount
	int32_t ___s_SelectableCount_5;

public:
	inline static int32_t get_offset_of_s_Selectables_4() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD_StaticFields, ___s_Selectables_4)); }
	inline SelectableU5BU5D_tECF9F5BDBF0652A937D18F10C883EFDAE2E62535* get_s_Selectables_4() const { return ___s_Selectables_4; }
	inline SelectableU5BU5D_tECF9F5BDBF0652A937D18F10C883EFDAE2E62535** get_address_of_s_Selectables_4() { return &___s_Selectables_4; }
	inline void set_s_Selectables_4(SelectableU5BU5D_tECF9F5BDBF0652A937D18F10C883EFDAE2E62535* value)
	{
		___s_Selectables_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Selectables_4), (void*)value);
	}

	inline static int32_t get_offset_of_s_SelectableCount_5() { return static_cast<int32_t>(offsetof(Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD_StaticFields, ___s_SelectableCount_5)); }
	inline int32_t get_s_SelectableCount_5() const { return ___s_SelectableCount_5; }
	inline int32_t* get_address_of_s_SelectableCount_5() { return &___s_SelectableCount_5; }
	inline void set_s_SelectableCount_5(int32_t value)
	{
		___s_SelectableCount_5 = value;
	}
};


// UnityEngine.UI.Button
struct Button_tA893FC15AB26E1439AC25BDCA7079530587BB65D  : public Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD
{
public:
	// UnityEngine.UI.Button/ButtonClickedEvent UnityEngine.UI.Button::m_OnClick
	ButtonClickedEvent_tE6D6D94ED8100451CF00D2BED1FB2253F37BB14F * ___m_OnClick_20;

public:
	inline static int32_t get_offset_of_m_OnClick_20() { return static_cast<int32_t>(offsetof(Button_tA893FC15AB26E1439AC25BDCA7079530587BB65D, ___m_OnClick_20)); }
	inline ButtonClickedEvent_tE6D6D94ED8100451CF00D2BED1FB2253F37BB14F * get_m_OnClick_20() const { return ___m_OnClick_20; }
	inline ButtonClickedEvent_tE6D6D94ED8100451CF00D2BED1FB2253F37BB14F ** get_address_of_m_OnClick_20() { return &___m_OnClick_20; }
	inline void set_m_OnClick_20(ButtonClickedEvent_tE6D6D94ED8100451CF00D2BED1FB2253F37BB14F * value)
	{
		___m_OnClick_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnClick_20), (void*)value);
	}
};


// UnityEngine.UI.MaskableGraphic
struct MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE  : public Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24
{
public:
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_ShouldRecalculateStencil
	bool ___m_ShouldRecalculateStencil_26;
	// UnityEngine.Material UnityEngine.UI.MaskableGraphic::m_MaskMaterial
	Material_t8927C00353A72755313F046D0CE85178AE8218EE * ___m_MaskMaterial_27;
	// UnityEngine.UI.RectMask2D UnityEngine.UI.MaskableGraphic::m_ParentMask
	RectMask2D_tD909811991B341D752E4C978C89EFB80FA7A2B15 * ___m_ParentMask_28;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_Maskable
	bool ___m_Maskable_29;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_IsMaskingGraphic
	bool ___m_IsMaskingGraphic_30;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_IncludeForMasking
	bool ___m_IncludeForMasking_31;
	// UnityEngine.UI.MaskableGraphic/CullStateChangedEvent UnityEngine.UI.MaskableGraphic::m_OnCullStateChanged
	CullStateChangedEvent_t9B69755DEBEF041C3CC15C3604610BDD72856BD4 * ___m_OnCullStateChanged_32;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_ShouldRecalculate
	bool ___m_ShouldRecalculate_33;
	// System.Int32 UnityEngine.UI.MaskableGraphic::m_StencilValue
	int32_t ___m_StencilValue_34;
	// UnityEngine.Vector3[] UnityEngine.UI.MaskableGraphic::m_Corners
	Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* ___m_Corners_35;

public:
	inline static int32_t get_offset_of_m_ShouldRecalculateStencil_26() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_ShouldRecalculateStencil_26)); }
	inline bool get_m_ShouldRecalculateStencil_26() const { return ___m_ShouldRecalculateStencil_26; }
	inline bool* get_address_of_m_ShouldRecalculateStencil_26() { return &___m_ShouldRecalculateStencil_26; }
	inline void set_m_ShouldRecalculateStencil_26(bool value)
	{
		___m_ShouldRecalculateStencil_26 = value;
	}

	inline static int32_t get_offset_of_m_MaskMaterial_27() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_MaskMaterial_27)); }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE * get_m_MaskMaterial_27() const { return ___m_MaskMaterial_27; }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE ** get_address_of_m_MaskMaterial_27() { return &___m_MaskMaterial_27; }
	inline void set_m_MaskMaterial_27(Material_t8927C00353A72755313F046D0CE85178AE8218EE * value)
	{
		___m_MaskMaterial_27 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_MaskMaterial_27), (void*)value);
	}

	inline static int32_t get_offset_of_m_ParentMask_28() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_ParentMask_28)); }
	inline RectMask2D_tD909811991B341D752E4C978C89EFB80FA7A2B15 * get_m_ParentMask_28() const { return ___m_ParentMask_28; }
	inline RectMask2D_tD909811991B341D752E4C978C89EFB80FA7A2B15 ** get_address_of_m_ParentMask_28() { return &___m_ParentMask_28; }
	inline void set_m_ParentMask_28(RectMask2D_tD909811991B341D752E4C978C89EFB80FA7A2B15 * value)
	{
		___m_ParentMask_28 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ParentMask_28), (void*)value);
	}

	inline static int32_t get_offset_of_m_Maskable_29() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_Maskable_29)); }
	inline bool get_m_Maskable_29() const { return ___m_Maskable_29; }
	inline bool* get_address_of_m_Maskable_29() { return &___m_Maskable_29; }
	inline void set_m_Maskable_29(bool value)
	{
		___m_Maskable_29 = value;
	}

	inline static int32_t get_offset_of_m_IsMaskingGraphic_30() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_IsMaskingGraphic_30)); }
	inline bool get_m_IsMaskingGraphic_30() const { return ___m_IsMaskingGraphic_30; }
	inline bool* get_address_of_m_IsMaskingGraphic_30() { return &___m_IsMaskingGraphic_30; }
	inline void set_m_IsMaskingGraphic_30(bool value)
	{
		___m_IsMaskingGraphic_30 = value;
	}

	inline static int32_t get_offset_of_m_IncludeForMasking_31() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_IncludeForMasking_31)); }
	inline bool get_m_IncludeForMasking_31() const { return ___m_IncludeForMasking_31; }
	inline bool* get_address_of_m_IncludeForMasking_31() { return &___m_IncludeForMasking_31; }
	inline void set_m_IncludeForMasking_31(bool value)
	{
		___m_IncludeForMasking_31 = value;
	}

	inline static int32_t get_offset_of_m_OnCullStateChanged_32() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_OnCullStateChanged_32)); }
	inline CullStateChangedEvent_t9B69755DEBEF041C3CC15C3604610BDD72856BD4 * get_m_OnCullStateChanged_32() const { return ___m_OnCullStateChanged_32; }
	inline CullStateChangedEvent_t9B69755DEBEF041C3CC15C3604610BDD72856BD4 ** get_address_of_m_OnCullStateChanged_32() { return &___m_OnCullStateChanged_32; }
	inline void set_m_OnCullStateChanged_32(CullStateChangedEvent_t9B69755DEBEF041C3CC15C3604610BDD72856BD4 * value)
	{
		___m_OnCullStateChanged_32 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnCullStateChanged_32), (void*)value);
	}

	inline static int32_t get_offset_of_m_ShouldRecalculate_33() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_ShouldRecalculate_33)); }
	inline bool get_m_ShouldRecalculate_33() const { return ___m_ShouldRecalculate_33; }
	inline bool* get_address_of_m_ShouldRecalculate_33() { return &___m_ShouldRecalculate_33; }
	inline void set_m_ShouldRecalculate_33(bool value)
	{
		___m_ShouldRecalculate_33 = value;
	}

	inline static int32_t get_offset_of_m_StencilValue_34() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_StencilValue_34)); }
	inline int32_t get_m_StencilValue_34() const { return ___m_StencilValue_34; }
	inline int32_t* get_address_of_m_StencilValue_34() { return &___m_StencilValue_34; }
	inline void set_m_StencilValue_34(int32_t value)
	{
		___m_StencilValue_34 = value;
	}

	inline static int32_t get_offset_of_m_Corners_35() { return static_cast<int32_t>(offsetof(MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE, ___m_Corners_35)); }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* get_m_Corners_35() const { return ___m_Corners_35; }
	inline Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4** get_address_of_m_Corners_35() { return &___m_Corners_35; }
	inline void set_m_Corners_35(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* value)
	{
		___m_Corners_35 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Corners_35), (void*)value);
	}
};


// UnityEngine.UI.Slider
struct Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A  : public Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD
{
public:
	// UnityEngine.RectTransform UnityEngine.UI.Slider::m_FillRect
	RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * ___m_FillRect_20;
	// UnityEngine.RectTransform UnityEngine.UI.Slider::m_HandleRect
	RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * ___m_HandleRect_21;
	// UnityEngine.UI.Slider/Direction UnityEngine.UI.Slider::m_Direction
	int32_t ___m_Direction_22;
	// System.Single UnityEngine.UI.Slider::m_MinValue
	float ___m_MinValue_23;
	// System.Single UnityEngine.UI.Slider::m_MaxValue
	float ___m_MaxValue_24;
	// System.Boolean UnityEngine.UI.Slider::m_WholeNumbers
	bool ___m_WholeNumbers_25;
	// System.Single UnityEngine.UI.Slider::m_Value
	float ___m_Value_26;
	// UnityEngine.UI.Slider/SliderEvent UnityEngine.UI.Slider::m_OnValueChanged
	SliderEvent_t312D89AE02E00DD965D68D6F7F813BDF455FD780 * ___m_OnValueChanged_27;
	// UnityEngine.UI.Image UnityEngine.UI.Slider::m_FillImage
	Image_t4021FF27176E44BFEDDCBE43C7FE6B713EC70D3C * ___m_FillImage_28;
	// UnityEngine.Transform UnityEngine.UI.Slider::m_FillTransform
	Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * ___m_FillTransform_29;
	// UnityEngine.RectTransform UnityEngine.UI.Slider::m_FillContainerRect
	RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * ___m_FillContainerRect_30;
	// UnityEngine.Transform UnityEngine.UI.Slider::m_HandleTransform
	Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * ___m_HandleTransform_31;
	// UnityEngine.RectTransform UnityEngine.UI.Slider::m_HandleContainerRect
	RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * ___m_HandleContainerRect_32;
	// UnityEngine.Vector2 UnityEngine.UI.Slider::m_Offset
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___m_Offset_33;
	// UnityEngine.DrivenRectTransformTracker UnityEngine.UI.Slider::m_Tracker
	DrivenRectTransformTracker_t7DAF937E47C63B899C7BA0E9B0F206AAB4D85AC2  ___m_Tracker_34;
	// System.Boolean UnityEngine.UI.Slider::m_DelayedUpdateVisuals
	bool ___m_DelayedUpdateVisuals_35;

public:
	inline static int32_t get_offset_of_m_FillRect_20() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_FillRect_20)); }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * get_m_FillRect_20() const { return ___m_FillRect_20; }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 ** get_address_of_m_FillRect_20() { return &___m_FillRect_20; }
	inline void set_m_FillRect_20(RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * value)
	{
		___m_FillRect_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FillRect_20), (void*)value);
	}

	inline static int32_t get_offset_of_m_HandleRect_21() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_HandleRect_21)); }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * get_m_HandleRect_21() const { return ___m_HandleRect_21; }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 ** get_address_of_m_HandleRect_21() { return &___m_HandleRect_21; }
	inline void set_m_HandleRect_21(RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * value)
	{
		___m_HandleRect_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_HandleRect_21), (void*)value);
	}

	inline static int32_t get_offset_of_m_Direction_22() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_Direction_22)); }
	inline int32_t get_m_Direction_22() const { return ___m_Direction_22; }
	inline int32_t* get_address_of_m_Direction_22() { return &___m_Direction_22; }
	inline void set_m_Direction_22(int32_t value)
	{
		___m_Direction_22 = value;
	}

	inline static int32_t get_offset_of_m_MinValue_23() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_MinValue_23)); }
	inline float get_m_MinValue_23() const { return ___m_MinValue_23; }
	inline float* get_address_of_m_MinValue_23() { return &___m_MinValue_23; }
	inline void set_m_MinValue_23(float value)
	{
		___m_MinValue_23 = value;
	}

	inline static int32_t get_offset_of_m_MaxValue_24() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_MaxValue_24)); }
	inline float get_m_MaxValue_24() const { return ___m_MaxValue_24; }
	inline float* get_address_of_m_MaxValue_24() { return &___m_MaxValue_24; }
	inline void set_m_MaxValue_24(float value)
	{
		___m_MaxValue_24 = value;
	}

	inline static int32_t get_offset_of_m_WholeNumbers_25() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_WholeNumbers_25)); }
	inline bool get_m_WholeNumbers_25() const { return ___m_WholeNumbers_25; }
	inline bool* get_address_of_m_WholeNumbers_25() { return &___m_WholeNumbers_25; }
	inline void set_m_WholeNumbers_25(bool value)
	{
		___m_WholeNumbers_25 = value;
	}

	inline static int32_t get_offset_of_m_Value_26() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_Value_26)); }
	inline float get_m_Value_26() const { return ___m_Value_26; }
	inline float* get_address_of_m_Value_26() { return &___m_Value_26; }
	inline void set_m_Value_26(float value)
	{
		___m_Value_26 = value;
	}

	inline static int32_t get_offset_of_m_OnValueChanged_27() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_OnValueChanged_27)); }
	inline SliderEvent_t312D89AE02E00DD965D68D6F7F813BDF455FD780 * get_m_OnValueChanged_27() const { return ___m_OnValueChanged_27; }
	inline SliderEvent_t312D89AE02E00DD965D68D6F7F813BDF455FD780 ** get_address_of_m_OnValueChanged_27() { return &___m_OnValueChanged_27; }
	inline void set_m_OnValueChanged_27(SliderEvent_t312D89AE02E00DD965D68D6F7F813BDF455FD780 * value)
	{
		___m_OnValueChanged_27 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnValueChanged_27), (void*)value);
	}

	inline static int32_t get_offset_of_m_FillImage_28() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_FillImage_28)); }
	inline Image_t4021FF27176E44BFEDDCBE43C7FE6B713EC70D3C * get_m_FillImage_28() const { return ___m_FillImage_28; }
	inline Image_t4021FF27176E44BFEDDCBE43C7FE6B713EC70D3C ** get_address_of_m_FillImage_28() { return &___m_FillImage_28; }
	inline void set_m_FillImage_28(Image_t4021FF27176E44BFEDDCBE43C7FE6B713EC70D3C * value)
	{
		___m_FillImage_28 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FillImage_28), (void*)value);
	}

	inline static int32_t get_offset_of_m_FillTransform_29() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_FillTransform_29)); }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * get_m_FillTransform_29() const { return ___m_FillTransform_29; }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 ** get_address_of_m_FillTransform_29() { return &___m_FillTransform_29; }
	inline void set_m_FillTransform_29(Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * value)
	{
		___m_FillTransform_29 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FillTransform_29), (void*)value);
	}

	inline static int32_t get_offset_of_m_FillContainerRect_30() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_FillContainerRect_30)); }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * get_m_FillContainerRect_30() const { return ___m_FillContainerRect_30; }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 ** get_address_of_m_FillContainerRect_30() { return &___m_FillContainerRect_30; }
	inline void set_m_FillContainerRect_30(RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * value)
	{
		___m_FillContainerRect_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FillContainerRect_30), (void*)value);
	}

	inline static int32_t get_offset_of_m_HandleTransform_31() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_HandleTransform_31)); }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * get_m_HandleTransform_31() const { return ___m_HandleTransform_31; }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 ** get_address_of_m_HandleTransform_31() { return &___m_HandleTransform_31; }
	inline void set_m_HandleTransform_31(Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * value)
	{
		___m_HandleTransform_31 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_HandleTransform_31), (void*)value);
	}

	inline static int32_t get_offset_of_m_HandleContainerRect_32() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_HandleContainerRect_32)); }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * get_m_HandleContainerRect_32() const { return ___m_HandleContainerRect_32; }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 ** get_address_of_m_HandleContainerRect_32() { return &___m_HandleContainerRect_32; }
	inline void set_m_HandleContainerRect_32(RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * value)
	{
		___m_HandleContainerRect_32 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_HandleContainerRect_32), (void*)value);
	}

	inline static int32_t get_offset_of_m_Offset_33() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_Offset_33)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_m_Offset_33() const { return ___m_Offset_33; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_m_Offset_33() { return &___m_Offset_33; }
	inline void set_m_Offset_33(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___m_Offset_33 = value;
	}

	inline static int32_t get_offset_of_m_Tracker_34() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_Tracker_34)); }
	inline DrivenRectTransformTracker_t7DAF937E47C63B899C7BA0E9B0F206AAB4D85AC2  get_m_Tracker_34() const { return ___m_Tracker_34; }
	inline DrivenRectTransformTracker_t7DAF937E47C63B899C7BA0E9B0F206AAB4D85AC2 * get_address_of_m_Tracker_34() { return &___m_Tracker_34; }
	inline void set_m_Tracker_34(DrivenRectTransformTracker_t7DAF937E47C63B899C7BA0E9B0F206AAB4D85AC2  value)
	{
		___m_Tracker_34 = value;
	}

	inline static int32_t get_offset_of_m_DelayedUpdateVisuals_35() { return static_cast<int32_t>(offsetof(Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A, ___m_DelayedUpdateVisuals_35)); }
	inline bool get_m_DelayedUpdateVisuals_35() const { return ___m_DelayedUpdateVisuals_35; }
	inline bool* get_address_of_m_DelayedUpdateVisuals_35() { return &___m_DelayedUpdateVisuals_35; }
	inline void set_m_DelayedUpdateVisuals_35(bool value)
	{
		___m_DelayedUpdateVisuals_35 = value;
	}
};


// UnityEngine.UI.Toggle
struct Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E  : public Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD
{
public:
	// UnityEngine.UI.Toggle/ToggleTransition UnityEngine.UI.Toggle::toggleTransition
	int32_t ___toggleTransition_20;
	// UnityEngine.UI.Graphic UnityEngine.UI.Toggle::graphic
	Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___graphic_21;
	// UnityEngine.UI.ToggleGroup UnityEngine.UI.Toggle::m_Group
	ToggleGroup_t12E1DFDEB3FFD979A20299EE42A94388AC619C95 * ___m_Group_22;
	// UnityEngine.UI.Toggle/ToggleEvent UnityEngine.UI.Toggle::onValueChanged
	ToggleEvent_t7B9EFE80B7D7F16F3E7B8FA75FEF45B00E0C0075 * ___onValueChanged_23;
	// System.Boolean UnityEngine.UI.Toggle::m_IsOn
	bool ___m_IsOn_24;

public:
	inline static int32_t get_offset_of_toggleTransition_20() { return static_cast<int32_t>(offsetof(Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E, ___toggleTransition_20)); }
	inline int32_t get_toggleTransition_20() const { return ___toggleTransition_20; }
	inline int32_t* get_address_of_toggleTransition_20() { return &___toggleTransition_20; }
	inline void set_toggleTransition_20(int32_t value)
	{
		___toggleTransition_20 = value;
	}

	inline static int32_t get_offset_of_graphic_21() { return static_cast<int32_t>(offsetof(Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E, ___graphic_21)); }
	inline Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * get_graphic_21() const { return ___graphic_21; }
	inline Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 ** get_address_of_graphic_21() { return &___graphic_21; }
	inline void set_graphic_21(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * value)
	{
		___graphic_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___graphic_21), (void*)value);
	}

	inline static int32_t get_offset_of_m_Group_22() { return static_cast<int32_t>(offsetof(Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E, ___m_Group_22)); }
	inline ToggleGroup_t12E1DFDEB3FFD979A20299EE42A94388AC619C95 * get_m_Group_22() const { return ___m_Group_22; }
	inline ToggleGroup_t12E1DFDEB3FFD979A20299EE42A94388AC619C95 ** get_address_of_m_Group_22() { return &___m_Group_22; }
	inline void set_m_Group_22(ToggleGroup_t12E1DFDEB3FFD979A20299EE42A94388AC619C95 * value)
	{
		___m_Group_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Group_22), (void*)value);
	}

	inline static int32_t get_offset_of_onValueChanged_23() { return static_cast<int32_t>(offsetof(Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E, ___onValueChanged_23)); }
	inline ToggleEvent_t7B9EFE80B7D7F16F3E7B8FA75FEF45B00E0C0075 * get_onValueChanged_23() const { return ___onValueChanged_23; }
	inline ToggleEvent_t7B9EFE80B7D7F16F3E7B8FA75FEF45B00E0C0075 ** get_address_of_onValueChanged_23() { return &___onValueChanged_23; }
	inline void set_onValueChanged_23(ToggleEvent_t7B9EFE80B7D7F16F3E7B8FA75FEF45B00E0C0075 * value)
	{
		___onValueChanged_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___onValueChanged_23), (void*)value);
	}

	inline static int32_t get_offset_of_m_IsOn_24() { return static_cast<int32_t>(offsetof(Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E, ___m_IsOn_24)); }
	inline bool get_m_IsOn_24() const { return ___m_IsOn_24; }
	inline bool* get_address_of_m_IsOn_24() { return &___m_IsOn_24; }
	inline void set_m_IsOn_24(bool value)
	{
		___m_IsOn_24 = value;
	}
};


// UnityEngine.UI.Text
struct Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1  : public MaskableGraphic_t0DB59E37E3C8AD2F5A4FB7FB091630CB21370CCE
{
public:
	// UnityEngine.UI.FontData UnityEngine.UI.Text::m_FontData
	FontData_t0F1E9B3ED8136CD40782AC9A6AFB69CAD127C738 * ___m_FontData_36;
	// System.String UnityEngine.UI.Text::m_Text
	String_t* ___m_Text_37;
	// UnityEngine.TextGenerator UnityEngine.UI.Text::m_TextCache
	TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 * ___m_TextCache_38;
	// UnityEngine.TextGenerator UnityEngine.UI.Text::m_TextCacheForLayout
	TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 * ___m_TextCacheForLayout_39;
	// System.Boolean UnityEngine.UI.Text::m_DisableFontTextureRebuiltCallback
	bool ___m_DisableFontTextureRebuiltCallback_41;
	// UnityEngine.UIVertex[] UnityEngine.UI.Text::m_TempVerts
	UIVertexU5BU5D_tE3D523C48DFEBC775876720DE2539A79FB7E5E5A* ___m_TempVerts_42;

public:
	inline static int32_t get_offset_of_m_FontData_36() { return static_cast<int32_t>(offsetof(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1, ___m_FontData_36)); }
	inline FontData_t0F1E9B3ED8136CD40782AC9A6AFB69CAD127C738 * get_m_FontData_36() const { return ___m_FontData_36; }
	inline FontData_t0F1E9B3ED8136CD40782AC9A6AFB69CAD127C738 ** get_address_of_m_FontData_36() { return &___m_FontData_36; }
	inline void set_m_FontData_36(FontData_t0F1E9B3ED8136CD40782AC9A6AFB69CAD127C738 * value)
	{
		___m_FontData_36 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FontData_36), (void*)value);
	}

	inline static int32_t get_offset_of_m_Text_37() { return static_cast<int32_t>(offsetof(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1, ___m_Text_37)); }
	inline String_t* get_m_Text_37() const { return ___m_Text_37; }
	inline String_t** get_address_of_m_Text_37() { return &___m_Text_37; }
	inline void set_m_Text_37(String_t* value)
	{
		___m_Text_37 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Text_37), (void*)value);
	}

	inline static int32_t get_offset_of_m_TextCache_38() { return static_cast<int32_t>(offsetof(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1, ___m_TextCache_38)); }
	inline TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 * get_m_TextCache_38() const { return ___m_TextCache_38; }
	inline TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 ** get_address_of_m_TextCache_38() { return &___m_TextCache_38; }
	inline void set_m_TextCache_38(TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 * value)
	{
		___m_TextCache_38 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_TextCache_38), (void*)value);
	}

	inline static int32_t get_offset_of_m_TextCacheForLayout_39() { return static_cast<int32_t>(offsetof(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1, ___m_TextCacheForLayout_39)); }
	inline TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 * get_m_TextCacheForLayout_39() const { return ___m_TextCacheForLayout_39; }
	inline TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 ** get_address_of_m_TextCacheForLayout_39() { return &___m_TextCacheForLayout_39; }
	inline void set_m_TextCacheForLayout_39(TextGenerator_t893F256D3587633108E00E5731CDC5A77AFF1B70 * value)
	{
		___m_TextCacheForLayout_39 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_TextCacheForLayout_39), (void*)value);
	}

	inline static int32_t get_offset_of_m_DisableFontTextureRebuiltCallback_41() { return static_cast<int32_t>(offsetof(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1, ___m_DisableFontTextureRebuiltCallback_41)); }
	inline bool get_m_DisableFontTextureRebuiltCallback_41() const { return ___m_DisableFontTextureRebuiltCallback_41; }
	inline bool* get_address_of_m_DisableFontTextureRebuiltCallback_41() { return &___m_DisableFontTextureRebuiltCallback_41; }
	inline void set_m_DisableFontTextureRebuiltCallback_41(bool value)
	{
		___m_DisableFontTextureRebuiltCallback_41 = value;
	}

	inline static int32_t get_offset_of_m_TempVerts_42() { return static_cast<int32_t>(offsetof(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1, ___m_TempVerts_42)); }
	inline UIVertexU5BU5D_tE3D523C48DFEBC775876720DE2539A79FB7E5E5A* get_m_TempVerts_42() const { return ___m_TempVerts_42; }
	inline UIVertexU5BU5D_tE3D523C48DFEBC775876720DE2539A79FB7E5E5A** get_address_of_m_TempVerts_42() { return &___m_TempVerts_42; }
	inline void set_m_TempVerts_42(UIVertexU5BU5D_tE3D523C48DFEBC775876720DE2539A79FB7E5E5A* value)
	{
		___m_TempVerts_42 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_TempVerts_42), (void*)value);
	}
};

struct Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1_StaticFields
{
public:
	// UnityEngine.Material UnityEngine.UI.Text::s_DefaultText
	Material_t8927C00353A72755313F046D0CE85178AE8218EE * ___s_DefaultText_40;

public:
	inline static int32_t get_offset_of_s_DefaultText_40() { return static_cast<int32_t>(offsetof(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1_StaticFields, ___s_DefaultText_40)); }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE * get_s_DefaultText_40() const { return ___s_DefaultText_40; }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE ** get_address_of_s_DefaultText_40() { return &___s_DefaultText_40; }
	inline void set_s_DefaultText_40(Material_t8927C00353A72755313F046D0CE85178AE8218EE * value)
	{
		___s_DefaultText_40 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_DefaultText_40), (void*)value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// UnityEngine.Vector3[]
struct Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  m_Items[1];

public:
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.GameObject[]
struct GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * m_Items[1];

public:
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.Single[]
struct SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) float m_Items[1];

public:
	inline float GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline float* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, float value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline float GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline float* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, float value)
	{
		m_Items[index] = value;
	}
};
// System.String[]
struct StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) String_t* m_Items[1];

public:
	inline String_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline String_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, String_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline String_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline String_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, String_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// UnityEngine.Rigidbody[]
struct RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * m_Items[1];

public:
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};


// !!0 UnityEngine.GameObject::GetComponent<System.Object>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method);
// !!0 UnityEngine.Resources::Load<System.Object>(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * Resources_Load_TisRuntimeObject_m39B6A35CFE684CD1FFF77873E20D7297B36A55E8_gshared (String_t* ___path0, const RuntimeMethod* method);
// !!0 UnityEngine.Object::Instantiate<System.Object>(!!0,UnityEngine.Vector3,UnityEngine.Quaternion)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * Object_Instantiate_TisRuntimeObject_mB05DEC51C29EF5BB8BD17D055E80217F11E571AA_gshared (RuntimeObject * ___original0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___position1, Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  ___rotation2, const RuntimeMethod* method);
// !!0 UnityEngine.Component::GetComponent<System.Object>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * Component_GetComponent_TisRuntimeObject_m69D9C576D6DD024C709E29EEADBC8041299A3AA7_gshared (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * __this, const RuntimeMethod* method);
// System.Void System.Array::Resize<System.Object>(!!0[]&,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Array_Resize_TisRuntimeObject_m6F70613DBB973872E27DFD9A42F7653C55337A64_gshared (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** ___array0, int32_t ___newSize1, const RuntimeMethod* method);

// System.Void datas::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void datas__ctor_mE6BBE9C089031DEEA352E2A6D402729C8D064E8D (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * __this, const RuntimeMethod* method);
// UnityEngine.SceneManagement.Scene UnityEngine.SceneManagement.SceneManager::GetActiveScene()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE  SceneManager_GetActiveScene_mB9A5037FFB576B2432D0BFEF6A161B7C4C1921A4 (const RuntimeMethod* method);
// System.String UnityEngine.SceneManagement.Scene::get_name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Scene_get_name_m38F195D7CA6417FED310C23E4D8E86150C7835B8 (Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE * __this, const RuntimeMethod* method);
// System.Boolean System.String::op_Equality(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB (String_t* ___a0, String_t* ___b1, const RuntimeMethod* method);
// System.Void MainGameManager::generateStage()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_generateStage_mACCE2CAB40727A6ECDFC550150C699C036FEEB97 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.GameObject::SetActive(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void System.IO.StreamReader::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * __this, String_t* ___path0, const RuntimeMethod* method);
// System.Int32 System.String::IndexOf(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454 (String_t* __this, String_t* ___value0, const RuntimeMethod* method);
// System.String System.String::Substring(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B (String_t* __this, int32_t ___startIndex0, int32_t ___length1, const RuntimeMethod* method);
// System.Int32 System.Convert::ToInt32(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Convert_ToInt32_mA1C10AB2A7C95E9DCAC473D1D88C74D60FA240ED (String_t* ___value0, const RuntimeMethod* method);
// System.Boolean System.Convert::ToBoolean(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Convert_ToBoolean_m85FE22B779E69576B3251DEC1E27BC8004485288 (int32_t ___value0, const RuntimeMethod* method);
// !!0 UnityEngine.GameObject::GetComponent<UnityEngine.UI.Toggle>()
inline Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// System.Void UnityEngine.UI.Toggle::set_isOn(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Toggle_set_isOn_mB018B9F410D7236AAB71D6D1A5BACC64C891F507 (Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * __this, bool ___value0, const RuntimeMethod* method);
// !!0 UnityEngine.GameObject::GetComponent<UniversalGravity>()
inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// !!0 UnityEngine.GameObject::GetComponent<UnityEngine.TrailRenderer>()
inline TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * GameObject_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m6BF02D14A2BF23863B8F688EEA112E78DD7B4AB8 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// !!0 UnityEngine.GameObject::GetComponent<UnityEngine.Rigidbody>()
inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// UnityEngine.GameObject UnityEngine.GameObject::Find(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B (String_t* ___name0, const RuntimeMethod* method);
// !!0 UnityEngine.GameObject::GetComponent<SoundPlaySystem>()
inline SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// System.Single UnityEngine.Time::get_deltaTime()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Time_get_deltaTime_mCC15F147DA67F38C74CE408FB5D7FF4A87DA2290 (const RuntimeMethod* method);
// System.String System.Single::ToString(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Single_ToString_m15F10F2AFF80750906CEFCFB456EBA84F9D2E8D7 (float* __this, String_t* ___format0, const RuntimeMethod* method);
// System.String System.String::Concat(System.String,System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m89EAB4C6A96B0E5C3F87300D6BE78D386B9EFC44 (String_t* ___str00, String_t* ___str11, String_t* ___str22, const RuntimeMethod* method);
// System.Boolean UnityEngine.Input::GetKeyDown(UnityEngine.KeyCode)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Input_GetKeyDown_m476116696E71771641BBECBAB1A4C55E69018220 (int32_t ___key0, const RuntimeMethod* method);
// System.Void MainGameManager::loadSelf()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_loadSelf_mCAD29627F78B89D8EFB412D3B4A796EAC7DECB79 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method);
// UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.EventSystem::get_current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * EventSystem_get_current_m4B9C11F490297AE55428038DACD240596D6CE5F2 (const RuntimeMethod* method);
// System.Boolean UnityEngine.EventSystems.EventSystem::IsPointerOverGameObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool EventSystem_IsPointerOverGameObject_m49888E0F63763086DCD74D5A6C5C5705A96F88EB (EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.Input::GetMouseButtonDown(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Input_GetMouseButtonDown_m466D81FDCC87C9CB07557B39DCB435EB691F1EF3 (int32_t ___button0, const RuntimeMethod* method);
// !!0 UnityEngine.Resources::Load<UnityEngine.AudioClip>(System.String)
inline AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1 (String_t* ___path0, const RuntimeMethod* method)
{
	return ((  AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * (*) (String_t*, const RuntimeMethod*))Resources_Load_TisRuntimeObject_m39B6A35CFE684CD1FFF77873E20D7297B36A55E8_gshared)(___path0, method);
}
// System.Void SoundPlaySystem::SetSoundData(UnityEngine.AudioClip)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundPlaySystem_SetSoundData_mC95E81C797E4E7D7210309AE5D3B8687EAB0BB9A (SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * __this, AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * ___audioClip0, const RuntimeMethod* method);
// System.Void UniversalGravity::changeMode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4 (UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * __this, const RuntimeMethod* method);
// System.Void MainGameManager::switchPause()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_switchPause_mA34A3C637F6A5919EA14A8F79321BE4A8C277CAE (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method);
// System.String System.Int32::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Int32_ToString_m340C0A14D16799421EFDF8A81C8A16FA76D48411 (int32_t* __this, const RuntimeMethod* method);
// System.String System.String::Concat(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m4B4AB72618348C5DFBFBA8DED84B9E2EBDB55E1B (String_t* ___str00, String_t* ___str11, const RuntimeMethod* method);
// stageData datas::getStageData(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  datas_getStageData_m0D19D87CDF47A697BFB2A35294B70E4B221DEA2F (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * __this, int32_t ___n0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Object::op_Equality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Equality_mEE9EC7EB5C7DC3E95B94AB904E1986FC4D566D54 (Object_tF2F3778131EFF286AF62B7B013A170F95A91571A * ___x0, Object_tF2F3778131EFF286AF62B7B013A170F95A91571A * ___y1, const RuntimeMethod* method);
// UnityEngine.Quaternion UnityEngine.Quaternion::get_identity()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  Quaternion_get_identity_mF2E565DBCE793A1AE6208056D42CA7C59D83A702 (const RuntimeMethod* method);
// !!0 UnityEngine.Object::Instantiate<UnityEngine.GameObject>(!!0,UnityEngine.Vector3,UnityEngine.Quaternion)
inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___original0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___position1, Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  ___rotation2, const RuntimeMethod* method)
{
	return ((  GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E , Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4 , const RuntimeMethod*))Object_Instantiate_TisRuntimeObject_mB05DEC51C29EF5BB8BD17D055E80217F11E571AA_gshared)(___original0, ___position1, ___rotation2, method);
}
// UnityEngine.Transform UnityEngine.GameObject::get_transform()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * GameObject_get_transform_m16A80BB92B6C8C5AB696E447014D45EDF1E4DE34 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Transform::set_localScale(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Transform_set_localScale_mF4D1611E48D1BA7566A1E166DC2DACF3ADD8BA3A (Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * __this, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___value0, const RuntimeMethod* method);
// System.Void datas::goStage(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void datas_goStage_m25C4F57045373560EC4458957FEF4E28A2E43D09 (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * __this, int32_t ___n0, const RuntimeMethod* method);
// System.Void UnityEngine.SceneManagement.SceneManager::LoadScene(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SceneManager_LoadScene_m7DAF30213E99396ECBDB1BD40CC34CCF36902092 (String_t* ___sceneName0, const RuntimeMethod* method);
// !!0 UnityEngine.GameObject::GetComponent<PlayerManager>()
inline PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * GameObject_GetComponent_TisPlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48_m9D6451632C23946A0F702FE50879B5BF75CEF829 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// System.Void PlayerManager::loadStage(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_loadStage_mEA31662275CFD57A213EA40C1DDD20599709CC00 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, int32_t ___i0, const RuntimeMethod* method);
// System.Void UnityEngine.Rigidbody::set_isKinematic(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Rigidbody_set_isKinematic_mCF74D680205544826F2DE2CAB929C9F25409A311 (Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * __this, bool ___value0, const RuntimeMethod* method);
// System.Int32 System.String::IndexOf(System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0 (String_t* __this, String_t* ___value0, int32_t ___startIndex1, const RuntimeMethod* method);
// System.Void System.Text.StringBuilder::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77 (StringBuilder_t * __this, String_t* ___value0, const RuntimeMethod* method);
// System.Boolean System.String::Equals(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_Equals_m8A062B96B61A7D652E7D73C9B3E904F6B0E5F41D (String_t* __this, String_t* ___value0, const RuntimeMethod* method);
// System.Single System.Single::Parse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Single_Parse_mA1B20E6E0AAD67F60707D81E82667D2D4B274D6F (String_t* ___s0, const RuntimeMethod* method);
// System.Text.StringBuilder System.Text.StringBuilder::Remove(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StringBuilder_t * StringBuilder_Remove_m6ABF9CF3D10160EB52E0768262A9B179F987571E (StringBuilder_t * __this, int32_t ___startIndex0, int32_t ___length1, const RuntimeMethod* method);
// System.Text.StringBuilder System.Text.StringBuilder::Insert(System.Int32,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StringBuilder_t * StringBuilder_Insert_m2B101CF8B6D47CFC7602CBABC101569E513D234F (StringBuilder_t * __this, int32_t ___index0, String_t* ___value1, const RuntimeMethod* method);
// System.Text.Encoding System.Text.Encoding::get_UTF8()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * Encoding_get_UTF8_mC877FB3137BBD566AEE7B15F9BF61DC4EF8F5E5E (const RuntimeMethod* method);
// System.Void System.IO.StreamWriter::.ctor(System.String,System.Boolean,System.Text.Encoding)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StreamWriter__ctor_m8E689BB489D6CA87348E79EBF05BA4E3F6D4B9A4 (StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * __this, String_t* ___path0, bool ___append1, Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___encoding2, const RuntimeMethod* method);
// System.Void UnityEngine.MonoBehaviour::Invoke(System.String,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour_Invoke_m4AAB759653B1C6FB0653527F4DDC72D1E9162CC4 (MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A * __this, String_t* ___methodName0, float ___time1, const RuntimeMethod* method);
// System.Boolean UnityEngine.UI.Toggle::get_isOn()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Toggle_get_isOn_m2B1F3640101A6FCDA6B5AF27924FFD10E3A89A6C_inline (Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * __this, const RuntimeMethod* method);
// System.Int32 System.Convert::ToInt32(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Convert_ToInt32_m3B3C332A65A7F38D6DDF1A1D0ED511C701F67CD3 (bool ___value0, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Rigidbody::get_velocity()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Rigidbody_get_velocity_mCFB033F3BD14C2BA68E797DFA4950F9307EC8E2C (Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Rigidbody::set_velocity(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Rigidbody_set_velocity_m8DC0988916EB38DFD7D4584830B41D79140BF18D (Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * __this, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.MonoBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED (MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A * __this, const RuntimeMethod* method);
// UnityEngine.GameObject UnityEngine.Component::get_gameObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * Component_get_gameObject_m55DC35B149AFB9157582755383BA954655FE0C5B (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Object::DontDestroyOnLoad(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object_DontDestroyOnLoad_m03007A68ABBA4CCD8C27B944964983395E7640F9 (Object_tF2F3778131EFF286AF62B7B013A170F95A91571A * ___target0, const RuntimeMethod* method);
// !!0 UnityEngine.GameObject::GetComponent<MainGameManager>()
inline MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// !!0 UnityEngine.Component::GetComponent<UnityEngine.Rigidbody>()
inline Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * __this, const RuntimeMethod* method)
{
	return ((  Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * (*) (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 *, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m69D9C576D6DD024C709E29EEADBC8041299A3AA7_gshared)(__this, method);
}
// !!0 UnityEngine.Component::GetComponent<UnityEngine.TrailRenderer>()
inline TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * Component_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m3BF8F0D99AB14A2C6D2C3DCC33AC2AFAC49B29D1 (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * __this, const RuntimeMethod* method)
{
	return ((  TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * (*) (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 *, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m69D9C576D6DD024C709E29EEADBC8041299A3AA7_gshared)(__this, method);
}
// !!0 UnityEngine.Component::GetComponent<UniversalGravity>()
inline UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * Component_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m7F9CE8DE7ACB08AC5198A03E9B4A1B64CAD17A4F (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * __this, const RuntimeMethod* method)
{
	return ((  UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * (*) (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 *, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m69D9C576D6DD024C709E29EEADBC8041299A3AA7_gshared)(__this, method);
}
// System.Void PlayerManager::resetChallengeFlags()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_resetChallengeFlags_m4CA13CBC872BF5439D424C23371D097C883D2986 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, const RuntimeMethod* method);
// !!0 UnityEngine.GameObject::GetComponent<Sinus>()
inline Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// UnityEngine.GameObject[] UnityEngine.GameObject::FindGameObjectsWithTag(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* GameObject_FindGameObjectsWithTag_m0948320611DC82590D59A36D1C57155B1B6CE186 (String_t* ___tag0, const RuntimeMethod* method);
// System.Void PlayerManager::challengeManager(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_challengeManager_m3B695215655DAF690D60D26DFD87A05C36635652 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, int32_t ___i0, const RuntimeMethod* method);
// UnityEngine.Transform UnityEngine.Component::get_transform()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * Component_get_transform_mE8496EBC45BEB1BADB5F314960F1DF1C952FA11F (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * __this, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Transform::get_position()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Transform_get_position_m40A8A9895568D56FFC687B57F30E8D53CB5EA341 (Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * __this, const RuntimeMethod* method);
// System.Single UnityEngine.Vector3::Distance(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Vector3_Distance_mB648A79E4A1BAAFBF7B029644638C0D715480677 (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___b1, const RuntimeMethod* method);
// System.Single UnityEngine.Vector3::get_magnitude()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Vector3_get_magnitude_mDDD40612220D8104E77E993E18A101A69A944991 (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * __this, const RuntimeMethod* method);
// UnityEngine.GameObject UnityEngine.Collision::get_gameObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * Collision_get_gameObject_m5682F872FD28419AA36F0651CE8B19825A21859D (Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0 * __this, const RuntimeMethod* method);
// System.String UnityEngine.GameObject::get_tag()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* GameObject_get_tag_mC21F33D368C18A631040F2887036C678B96ABC33 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Rigidbody::set_constraints(UnityEngine.RigidbodyConstraints)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Rigidbody_set_constraints_mA76F562D16D3BE8889E095D0309C8FE38DA914F1 (Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void MainGameManager::setCanvesActive(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_setCanvesActive_mB2D2B2AEB306B5063502C824E457620DEEEACDA9 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, bool ___isCleared0, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Vector3::get_zero()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6 (const RuntimeMethod* method);
// System.Void UnityEngine.Transform::set_position(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Transform_set_position_mB169E52D57EEAC1E3F22C5395968714E4F00AC91 (Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * __this, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.Object::Destroy(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object_Destroy_m3EEDB6ECD49A541EC826EA8E1C8B599F7AF67D30 (Object_tF2F3778131EFF286AF62B7B013A170F95A91571A * ___obj0, const RuntimeMethod* method);
// System.Void UniversalGravity::GetAstroObjs()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UniversalGravity_GetAstroObjs_mAC081AB221E0E3D34E9633FE0E4A8002ADF22EAA (UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TrailRenderer::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TrailRenderer_Clear_mF9AAA91E20A28ECE700EA2B3D2605F0D9C294663 (TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * __this, const RuntimeMethod* method);
// System.Void PlayerManager::savechallenge(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, int32_t ___i0, const RuntimeMethod* method);
// System.Int32 UnityEngine.Mathf::RoundToInt(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mathf_RoundToInt_m56850BDF60FF9E3441CE57E5EFEFEF36EDCDE6DD (float ___f0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Vector3::op_Equality(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Vector3_op_Equality_m8A98C7F38641110A2F90445EF8E98ECE14B08296 (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___lhs0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___rhs1, const RuntimeMethod* method);
// System.Void UnityEngine.Debug::Log(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_Log_mC26E5AD0D8D156C7FFD173AA15827F69225E9DB8 (RuntimeObject * ___message0, const RuntimeMethod* method);
// System.Single UnityEngine.Time::get_timeSinceLevelLoad()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Time_get_timeSinceLevelLoad_m47A90DE6CB3A3180D64F0049290BC72C186FC7FB (const RuntimeMethod* method);
// System.Single UnityEngine.Mathf::PerlinNoise(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Mathf_PerlinNoise_mBCF172821FEB8FAD7E7CF7F7982018846E702519 (float ___x0, float ___y1, const RuntimeMethod* method);
// System.Int32 UnityEngine.AudioClip::get_samples()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AudioClip_get_samples_m741BFBA562FBFDBE67AFE98A38B1B4A871D2D567 (AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.AudioClip::get_channels()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AudioClip_get_channels_m7592B378317BFA41DF2228636124E4DD5B86D3B8 (AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.AudioClip::GetData(System.Single[],System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AudioClip_GetData_m2D7410645789EBED93CAA8146D271C79156E2CB0 (AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * __this, SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* ___data0, int32_t ___offsetSamples1, const RuntimeMethod* method);
// System.Int32 System.String::get_Length()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m129FC0ADA02FECBED3C0B1A809AE84A5AEE1CF09_inline (String_t* __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.GameObject::get_activeSelf()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GameObject_get_activeSelf_m4865097C24FB29F3C31F5C30619AF242297F23EE (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method);
// System.String System.Single::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Single_ToString_m80E7ABED4F4D73F2BE19DDB80D3D92FCD8DFA010 (float* __this, const RuntimeMethod* method);
// System.Void TitleManager::checkData()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_checkData_m02820912FEEAD00B0B83CBFD98B4F0B1114AC945 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method);
// !!0 UnityEngine.Component::GetComponent<MainGameManager>()
inline MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * Component_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF0ABC826AA3E324A387AE7C6716E2776405AC583 (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 * __this, const RuntimeMethod* method)
{
	return ((  MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * (*) (Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684 *, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m69D9C576D6DD024C709E29EEADBC8041299A3AA7_gshared)(__this, method);
}
// !!0 UnityEngine.GameObject::GetComponent<UnityEngine.UI.Button>()
inline Button_tA893FC15AB26E1439AC25BDCA7079530587BB65D * GameObject_GetComponent_TisButton_tA893FC15AB26E1439AC25BDCA7079530587BB65D_mC89B59084AF54D6861DE55F9F1FC4226E4F616A8 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  Button_tA893FC15AB26E1439AC25BDCA7079530587BB65D * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// System.Void UnityEngine.UI.Selectable::set_interactable(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Selectable_set_interactable_mE6F57D33A9E0484377174D0F490C4372BF7F0D40 (Selectable_t34088A3677CC9D344F81B0D91999D8C5963D7DBD * __this, bool ___value0, const RuntimeMethod* method);
// System.Boolean System.IO.Directory::Exists(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Directory_Exists_m17E38B91F6D9A0064D614FF2237BBFC0127468FE (String_t* ___path0, const RuntimeMethod* method);
// System.IO.DirectoryInfo System.IO.Directory::CreateDirectory(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DirectoryInfo_t4EF3610F45F0D234800D01ADA8F3F476AE0CF5CD * Directory_CreateDirectory_m38040338519C48CE52137CC146372A153D5C6A7A (String_t* ___path0, const RuntimeMethod* method);
// System.Boolean System.IO.File::Exists(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool File_Exists_mDAEBF2732BC830270FD98346F069B04E97BB1D5B (String_t* ___path0, const RuntimeMethod* method);
// System.Void System.IO.File::WriteAllText(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void File_WriteAllText_mA0528ED8C0C9B94864772B9036FC4B206682EE9C (String_t* ___path0, String_t* ___contents1, const RuntimeMethod* method);
// System.Void UnityEngine.Color32::.ctor(System.Byte,System.Byte,System.Byte,System.Byte)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Color32__ctor_m9D07EC69256BB7ED2784E543848DE7B8484A5C94 (Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D * __this, uint8_t ___r0, uint8_t ___g1, uint8_t ___b2, uint8_t ___a3, const RuntimeMethod* method);
// UnityEngine.Color UnityEngine.Color32::op_Implicit(UnityEngine.Color32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  Color32_op_Implicit_m63F14F1A14B1A9A3EE4D154413EE229D3E001623 (Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D  ___c0, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Vector3::op_Subtraction(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Subtraction_m2725C96965D5C0B1F9715797E51762B13A5FED58_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___b1, const RuntimeMethod* method);
// System.String UnityEngine.Object::get_name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB (Object_tF2F3778131EFF286AF62B7B013A170F95A91571A * __this, const RuntimeMethod* method);
// System.Boolean System.String::Contains(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A (String_t* __this, String_t* ___value0, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Vector3::get_normalized()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_get_normalized_m2FA6DF38F97BDA4CCBDAE12B9FE913A241DAC8D5 (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * __this, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Vector3::op_Multiply(UnityEngine.Vector3,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, float ___d1, const RuntimeMethod* method);
// System.Single UnityEngine.Rigidbody::get_mass()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223 (Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * __this, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Vector3::op_Division(UnityEngine.Vector3,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Division_mE5ACBFB168FED529587457A83BA98B7DB32E2A05_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, float ___d1, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Vector3::op_Addition(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Addition_mEE4F672B923CCB184C39AABCA33443DB218E50E0_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___b1, const RuntimeMethod* method);
// System.Void UnityEngine.Rigidbody::AddForce(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Rigidbody_AddForce_mDFB0D57C25682B826999B0074F5C0FD399C6401D (Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * __this, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___force0, const RuntimeMethod* method);
// System.Void System.Array::Resize<UnityEngine.Rigidbody>(!!0[]&,System.Int32)
inline void Array_Resize_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m5F039C66CEB5890529B35E8E0EF57322FD099EF9 (RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B** ___array0, int32_t ___newSize1, const RuntimeMethod* method)
{
	((  void (*) (RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B**, int32_t, const RuntimeMethod*))Array_Resize_TisRuntimeObject_m6F70613DBB973872E27DFD9A42F7653C55337A64_gshared)(___array0, ___newSize1, method);
}
// !!0 UnityEngine.GameObject::GetComponent<UnityEngine.Renderer>()
inline Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C * GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466 (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * __this, const RuntimeMethod* method)
{
	return ((  Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C * (*) (GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_mCE43118393A796C759AC5D43257AB2330881767D_gshared)(__this, method);
}
// UnityEngine.Material UnityEngine.Renderer::get_material()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Material_t8927C00353A72755313F046D0CE85178AE8218EE * Renderer_get_material_mE6B01125502D08EE0D6DFE2EAEC064AD9BB31804 (Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Material::set_color(UnityEngine.Color)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Material_set_color_mC3C88E2389B7132EBF3EB0D1F040545176B795C0 (Material_t8927C00353A72755313F046D0CE85178AE8218EE * __this, Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method);
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405 (RuntimeObject * __this, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void MainGameManager::Start()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_Start_m2F565E036D5616568F5DD11B6EF25E8D06D729FA (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m6BF02D14A2BF23863B8F688EEA112E78DD7B4AB8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9FCD15851E70A26784E98AFC64621C56BC0BBFD0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE  V_0;
	memset((&V_0), 0, sizeof(V_0));
	String_t* V_1 = NULL;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		// dat = new datas();
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_0 = (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 *)il2cpp_codegen_object_new(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		datas__ctor_mE6BBE9C089031DEEA352E2A6D402729C8D064E8D(L_0, /*hidden argument*/NULL);
		__this->set_dat_26(L_0);
		// t = 0;
		__this->set_t_29((0.0f));
		// isPausing = false;
		__this->set_isPausing_17((bool)0);
		// if (SceneManager.GetActiveScene().name == "Main")
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE  L_1;
		L_1 = SceneManager_GetActiveScene_mB9A5037FFB576B2432D0BFEF6A161B7C4C1921A4(/*hidden argument*/NULL);
		V_0 = L_1;
		String_t* L_2;
		L_2 = Scene_get_name_m38F195D7CA6417FED310C23E4D8E86150C7835B8((Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE *)(&V_0), /*hidden argument*/NULL);
		bool L_3;
		L_3 = String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB(L_2, _stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_00a6;
		}
	}
	{
		// generateStage();
		MainGameManager_generateStage_mACCE2CAB40727A6ECDFC550150C699C036FEEB97(__this, /*hidden argument*/NULL);
		// if (rta)
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		bool L_4 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_rta_18();
		if (!L_4)
		{
			goto IL_0051;
		}
	}
	{
		// toggle_autoRetry.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_5 = __this->get_toggle_autoRetry_14();
		NullCheck(L_5);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_5, (bool)0, /*hidden argument*/NULL);
		// }
		goto IL_00a6;
	}

IL_0051:
	{
		// StreamReader sr = new StreamReader("Save/data.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_6 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_6, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		// string saveData = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_7 = L_6;
		NullCheck(L_7);
		String_t* L_8;
		L_8 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_7);
		V_1 = L_8;
		// sr.Close();
		NullCheck(L_7);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_7);
		// int idx = saveData.IndexOf("AutoRetry") + 10; //インデックス+文字数+1
		String_t* L_9 = V_1;
		NullCheck(L_9);
		int32_t L_10;
		L_10 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_9, _stringLiteral9FCD15851E70A26784E98AFC64621C56BC0BBFD0, /*hidden argument*/NULL);
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_10, (int32_t)((int32_t)10)));
		// int temp = Convert.ToInt32(saveData.Substring(idx, 1));
		String_t* L_11 = V_1;
		int32_t L_12 = V_2;
		NullCheck(L_11);
		String_t* L_13;
		L_13 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_11, L_12, 1, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		int32_t L_14;
		L_14 = Convert_ToInt32_mA1C10AB2A7C95E9DCAC473D1D88C74D60FA240ED(L_13, /*hidden argument*/NULL);
		V_3 = L_14;
		// autoRetry = Convert.ToBoolean(temp);
		int32_t L_15 = V_3;
		bool L_16;
		L_16 = Convert_ToBoolean_m85FE22B779E69576B3251DEC1E27BC8004485288(L_15, /*hidden argument*/NULL);
		__this->set_autoRetry_16(L_16);
		// toggle_autoRetry.GetComponent<Toggle>().isOn = autoRetry;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_17 = __this->get_toggle_autoRetry_14();
		NullCheck(L_17);
		Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * L_18;
		L_18 = GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49(L_17, /*hidden argument*/GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49_RuntimeMethod_var);
		bool L_19 = __this->get_autoRetry_16();
		NullCheck(L_18);
		Toggle_set_isOn_mB018B9F410D7236AAB71D6D1A5BACC64C891F507(L_18, L_19, /*hidden argument*/NULL);
	}

IL_00a6:
	{
		// ug = player.GetComponent<UniversalGravity>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_20 = __this->get_player_4();
		NullCheck(L_20);
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_21;
		L_21 = GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810(L_20, /*hidden argument*/GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810_RuntimeMethod_var);
		__this->set_ug_15(L_21);
		// tr = player.GetComponent<TrailRenderer>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_22 = __this->get_player_4();
		NullCheck(L_22);
		TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * L_23;
		L_23 = GameObject_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m6BF02D14A2BF23863B8F688EEA112E78DD7B4AB8(L_22, /*hidden argument*/GameObject_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m6BF02D14A2BF23863B8F688EEA112E78DD7B4AB8_RuntimeMethod_var);
		__this->set_tr_27(L_23);
		// rb = player.GetComponent<Rigidbody>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_24 = __this->get_player_4();
		NullCheck(L_24);
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_25;
		L_25 = GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354(L_24, /*hidden argument*/GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354_RuntimeMethod_var);
		__this->set_rb_31(L_25);
		// soundPlaySystem = GameObject.Find("Main Camera").GetComponent<SoundPlaySystem>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_26;
		L_26 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_26);
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_27;
		L_27 = GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F(L_26, /*hidden argument*/GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		__this->set_soundPlaySystem_32(L_27);
		// }
		return;
	}
}
// System.Void MainGameManager::Update()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_Update_mADE244B8A04904537378FCB5A02B12BE123FB327 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2B86D66477376A42A49B3CD3983CF53BEF4E55A0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9B469AD8D3831F081E8E4B97777919CC5F65D853);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralD131397F1FB7BFF3B5A8A63CC32384739F6D42AC);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDAFC4BB68B649F31995F74799A69A3414294F814);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (rta && !isPausing)
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		bool L_0 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_rta_18();
		if (!L_0)
		{
			goto IL_004b;
		}
	}
	{
		bool L_1 = __this->get_isPausing_17();
		if (L_1)
		{
			goto IL_004b;
		}
	}
	{
		// t += Time.deltaTime;
		float L_2 = __this->get_t_29();
		float L_3;
		L_3 = Time_get_deltaTime_mCC15F147DA67F38C74CE408FB5D7FF4A87DA2290(/*hidden argument*/NULL);
		__this->set_t_29(((float)il2cpp_codegen_add((float)L_2, (float)L_3)));
		// timeLabel.text = "経過時間:" + t.ToString("f3") + "秒";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_4 = __this->get_timeLabel_21();
		float* L_5 = __this->get_address_of_t_29();
		String_t* L_6;
		L_6 = Single_ToString_m15F10F2AFF80750906CEFCFB456EBA84F9D2E8D7((float*)L_5, _stringLiteralD131397F1FB7BFF3B5A8A63CC32384739F6D42AC, /*hidden argument*/NULL);
		String_t* L_7;
		L_7 = String_Concat_m89EAB4C6A96B0E5C3F87300D6BE78D386B9EFC44(_stringLiteralDAFC4BB68B649F31995F74799A69A3414294F814, L_6, _stringLiteral2B86D66477376A42A49B3CD3983CF53BEF4E55A0, /*hidden argument*/NULL);
		NullCheck(L_4);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_4, L_7);
	}

IL_004b:
	{
		// if (Input.GetKeyDown(KeyCode.Space)) loadSelf();
		bool L_8;
		L_8 = Input_GetKeyDown_m476116696E71771641BBECBAB1A4C55E69018220(((int32_t)32), /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_005a;
		}
	}
	{
		// if (Input.GetKeyDown(KeyCode.Space)) loadSelf();
		MainGameManager_loadSelf_mCAD29627F78B89D8EFB412D3B4A796EAC7DECB79(__this, /*hidden argument*/NULL);
	}

IL_005a:
	{
		// if (EventSystem.current.IsPointerOverGameObject()) return; //uGUIのボタンを押したときに画面クリックを無視する
		IL2CPP_RUNTIME_CLASS_INIT(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C_il2cpp_TypeInfo_var);
		EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * L_9;
		L_9 = EventSystem_get_current_m4B9C11F490297AE55428038DACD240596D6CE5F2(/*hidden argument*/NULL);
		NullCheck(L_9);
		bool L_10;
		L_10 = EventSystem_IsPointerOverGameObject_m49888E0F63763086DCD74D5A6C5C5705A96F88EB(L_9, /*hidden argument*/NULL);
		if (!L_10)
		{
			goto IL_0067;
		}
	}
	{
		// if (EventSystem.current.IsPointerOverGameObject()) return; //uGUIのボタンを押したときに画面クリックを無視する
		return;
	}

IL_0067:
	{
		// if (Input.GetMouseButtonDown(0) && !isPausing)
		bool L_11;
		L_11 = Input_GetMouseButtonDown_m466D81FDCC87C9CB07557B39DCB435EB691F1EF3(0, /*hidden argument*/NULL);
		if (!L_11)
		{
			goto IL_0097;
		}
	}
	{
		bool L_12 = __this->get_isPausing_17();
		if (L_12)
		{
			goto IL_0097;
		}
	}
	{
		// soundPlaySystem.SetSoundData(Resources.Load<AudioClip>("Sounds/correct"));
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_13 = __this->get_soundPlaySystem_32();
		AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * L_14;
		L_14 = Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1(_stringLiteral9B469AD8D3831F081E8E4B97777919CC5F65D853, /*hidden argument*/Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1_RuntimeMethod_var);
		NullCheck(L_13);
		SoundPlaySystem_SetSoundData_mC95E81C797E4E7D7210309AE5D3B8687EAB0BB9A(L_13, L_14, /*hidden argument*/NULL);
		// ug.changeMode();
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_15 = __this->get_ug_15();
		NullCheck(L_15);
		UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4(L_15, /*hidden argument*/NULL);
	}

IL_0097:
	{
		// if (Input.GetKeyDown(KeyCode.Escape)) switchPause();
		bool L_16;
		L_16 = Input_GetKeyDown_m476116696E71771641BBECBAB1A4C55E69018220(((int32_t)27), /*hidden argument*/NULL);
		if (!L_16)
		{
			goto IL_00a6;
		}
	}
	{
		// if (Input.GetKeyDown(KeyCode.Escape)) switchPause();
		MainGameManager_switchPause_mA34A3C637F6A5919EA14A8F79321BE4A8C277CAE(__this, /*hidden argument*/NULL);
	}

IL_00a6:
	{
		// }
		return;
	}
}
// System.Void MainGameManager::generateStage()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_generateStage_mACCE2CAB40727A6ECDFC550150C699C036FEEB97 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2F0971EEB34F669DA121AFE1DB3967AE709E3CE6);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral6016AF1CE72794A6C2FF2B0D3605A9649CE69719);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		// stageLabel.text = "STAGE:" + (datas.currentStageNum + 1).ToString();
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_0 = __this->get_stageLabel_22();
		int32_t L_1 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)1));
		String_t* L_2;
		L_2 = Int32_ToString_m340C0A14D16799421EFDF8A81C8A16FA76D48411((int32_t*)(&V_0), /*hidden argument*/NULL);
		String_t* L_3;
		L_3 = String_Concat_m4B4AB72618348C5DFBFBA8DED84B9E2EBDB55E1B(_stringLiteral2F0971EEB34F669DA121AFE1DB3967AE709E3CE6, L_2, /*hidden argument*/NULL);
		NullCheck(L_0);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_0, L_3);
		// sdata = dat.getStageData(datas.currentStageNum);
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_4 = __this->get_dat_26();
		int32_t L_5 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		NullCheck(L_4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_6;
		L_6 = datas_getStageData_m0D19D87CDF47A697BFB2A35294B70E4B221DEA2F(L_4, L_5, /*hidden argument*/NULL);
		__this->set_sdata_28(L_6);
		// if (GameObject.Find("Player(Clone)") == null)
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_7;
		L_7 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteral6016AF1CE72794A6C2FF2B0D3605A9649CE69719, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		bool L_8;
		L_8 = Object_op_Equality_mEE9EC7EB5C7DC3E95B94AB904E1986FC4D566D54(L_7, (Object_tF2F3778131EFF286AF62B7B013A170F95A91571A *)NULL, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_006d;
		}
	}
	{
		// player = Instantiate(player, sdata.playerPos, Quaternion.identity);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_9 = __this->get_player_4();
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_10 = __this->get_address_of_sdata_28();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_11 = L_10->get_playerPos_0();
		Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  L_12;
		L_12 = Quaternion_get_identity_mF2E565DBCE793A1AE6208056D42CA7C59D83A702(/*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_13;
		L_13 = Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B(L_9, L_11, L_12, /*hidden argument*/Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B_RuntimeMethod_var);
		__this->set_player_4(L_13);
	}

IL_006d:
	{
		// for (int i = 0; i < sdata.inPoss.Length; i++)
		V_1 = 0;
		goto IL_0097;
	}

IL_0071:
	{
		// Instantiate(In, sdata.inPoss[i], Quaternion.identity);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_14 = __this->get_In_5();
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_15 = __this->get_address_of_sdata_28();
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_16 = L_15->get_inPoss_1();
		int32_t L_17 = V_1;
		NullCheck(L_16);
		int32_t L_18 = L_17;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_19 = (L_16)->GetAt(static_cast<il2cpp_array_size_t>(L_18));
		Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  L_20;
		L_20 = Quaternion_get_identity_mF2E565DBCE793A1AE6208056D42CA7C59D83A702(/*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_21;
		L_21 = Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B(L_14, L_19, L_20, /*hidden argument*/Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B_RuntimeMethod_var);
		// for (int i = 0; i < sdata.inPoss.Length; i++)
		int32_t L_22 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_22, (int32_t)1));
	}

IL_0097:
	{
		// for (int i = 0; i < sdata.inPoss.Length; i++)
		int32_t L_23 = V_1;
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_24 = __this->get_address_of_sdata_28();
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_25 = L_24->get_inPoss_1();
		NullCheck(L_25);
		if ((((int32_t)L_23) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_25)->max_length))))))
		{
			goto IL_0071;
		}
	}
	{
		// for (int i = 0; i < sdata.sekiPoss.Length; i++)
		V_2 = 0;
		goto IL_00d1;
	}

IL_00ab:
	{
		// Instantiate(Seki, sdata.sekiPoss[i], Quaternion.identity);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_26 = __this->get_Seki_6();
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_27 = __this->get_address_of_sdata_28();
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_28 = L_27->get_sekiPoss_2();
		int32_t L_29 = V_2;
		NullCheck(L_28);
		int32_t L_30 = L_29;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_31 = (L_28)->GetAt(static_cast<il2cpp_array_size_t>(L_30));
		Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  L_32;
		L_32 = Quaternion_get_identity_mF2E565DBCE793A1AE6208056D42CA7C59D83A702(/*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_33;
		L_33 = Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B(L_26, L_31, L_32, /*hidden argument*/Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B_RuntimeMethod_var);
		// for (int i = 0; i < sdata.sekiPoss.Length; i++)
		int32_t L_34 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_34, (int32_t)1));
	}

IL_00d1:
	{
		// for (int i = 0; i < sdata.sekiPoss.Length; i++)
		int32_t L_35 = V_2;
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_36 = __this->get_address_of_sdata_28();
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_37 = L_36->get_sekiPoss_2();
		NullCheck(L_37);
		if ((((int32_t)L_35) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_37)->max_length))))))
		{
			goto IL_00ab;
		}
	}
	{
		// GameObject _goal = Instantiate(goal, sdata.goalPos, Quaternion.identity);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_38 = __this->get_goal_8();
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_39 = __this->get_address_of_sdata_28();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_40 = L_39->get_goalPos_3();
		Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  L_41;
		L_41 = Quaternion_get_identity_mF2E565DBCE793A1AE6208056D42CA7C59D83A702(/*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_42;
		L_42 = Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B(L_38, L_40, L_41, /*hidden argument*/Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B_RuntimeMethod_var);
		// _goal.transform.localScale = sdata.goalSize;
		NullCheck(L_42);
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_43;
		L_43 = GameObject_get_transform_m16A80BB92B6C8C5AB696E447014D45EDF1E4DE34(L_42, /*hidden argument*/NULL);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_44 = __this->get_address_of_sdata_28();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_45 = L_44->get_goalSize_4();
		NullCheck(L_43);
		Transform_set_localScale_mF4D1611E48D1BA7566A1E166DC2DACF3ADD8BA3A(L_43, L_45, /*hidden argument*/NULL);
		// for (int i = 0; i < sdata.wallPoss.Length; i++)
		V_3 = 0;
		goto IL_0155;
	}

IL_0115:
	{
		// _wall = Instantiate(wall, sdata.wallPoss[i], Quaternion.identity);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_46 = __this->get_wall_7();
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_47 = __this->get_address_of_sdata_28();
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_48 = L_47->get_wallPoss_5();
		int32_t L_49 = V_3;
		NullCheck(L_48);
		int32_t L_50 = L_49;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_51 = (L_48)->GetAt(static_cast<il2cpp_array_size_t>(L_50));
		Quaternion_t6D28618CF65156D4A0AD747370DDFD0C514A31B4  L_52;
		L_52 = Quaternion_get_identity_mF2E565DBCE793A1AE6208056D42CA7C59D83A702(/*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_53;
		L_53 = Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B(L_46, L_51, L_52, /*hidden argument*/Object_Instantiate_TisGameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319_m81B599A0051F8F4543E5C73A11585E96E940943B_RuntimeMethod_var);
		// _wall.transform.localScale = sdata.wallSizes[i];
		NullCheck(L_53);
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_54;
		L_54 = GameObject_get_transform_m16A80BB92B6C8C5AB696E447014D45EDF1E4DE34(L_53, /*hidden argument*/NULL);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_55 = __this->get_address_of_sdata_28();
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_56 = L_55->get_wallSizes_6();
		int32_t L_57 = V_3;
		NullCheck(L_56);
		int32_t L_58 = L_57;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_59 = (L_56)->GetAt(static_cast<il2cpp_array_size_t>(L_58));
		NullCheck(L_54);
		Transform_set_localScale_mF4D1611E48D1BA7566A1E166DC2DACF3ADD8BA3A(L_54, L_59, /*hidden argument*/NULL);
		// for (int i = 0; i < sdata.wallPoss.Length; i++)
		int32_t L_60 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_60, (int32_t)1));
	}

IL_0155:
	{
		// for (int i = 0; i < sdata.wallPoss.Length; i++)
		int32_t L_61 = V_3;
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_62 = __this->get_address_of_sdata_28();
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_63 = L_62->get_wallPoss_5();
		NullCheck(L_63);
		if ((((int32_t)L_61) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_63)->max_length))))))
		{
			goto IL_0115;
		}
	}
	{
		// }
		return;
	}
}
// System.Void MainGameManager::goNextStage()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_goNextStage_m941FBAEA01264E29001D851839F02FE02665DA7E (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// dat.goStage(datas.currentStageNum + 1);
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_0 = __this->get_dat_26();
		int32_t L_1 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		NullCheck(L_0);
		datas_goStage_m25C4F57045373560EC4458957FEF4E28A2E43D09(L_0, ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)1)), /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void MainGameManager::goTitle()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_goTitle_m8B8D5AC60CC176DDCC99E736E9AED3C6746DDBAD (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral40E83ACCE0D042A519B971EC5FA530E519DEAD8E);
		s_Il2CppMethodInitialized = true;
	}
	{
		// SceneManager.LoadScene("Title");
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		SceneManager_LoadScene_m7DAF30213E99396ECBDB1BD40CC34CCF36902092(_stringLiteral40E83ACCE0D042A519B971EC5FA530E519DEAD8E, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void MainGameManager::loadSelf()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_loadSelf_mCAD29627F78B89D8EFB412D3B4A796EAC7DECB79 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisPlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48_m9D6451632C23946A0F702FE50879B5BF75CEF829_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (rta)
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		bool L_0 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_rta_18();
		if (!L_0)
		{
			goto IL_0018;
		}
	}
	{
		// datas.currentStageNum = 0;
		((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->set_currentStageNum_0(0);
		// SceneManager.LoadScene("Main");
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		SceneManager_LoadScene_m7DAF30213E99396ECBDB1BD40CC34CCF36902092(_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D, /*hidden argument*/NULL);
		// }
		return;
	}

IL_0018:
	{
		// clearCanvasGroup.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1 = __this->get_clearCanvasGroup_9();
		NullCheck(L_1);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_1, (bool)0, /*hidden argument*/NULL);
		// player.GetComponent<PlayerManager>().loadStage(datas.currentStageNum);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_2 = __this->get_player_4();
		NullCheck(L_2);
		PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * L_3;
		L_3 = GameObject_GetComponent_TisPlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48_m9D6451632C23946A0F702FE50879B5BF75CEF829(L_2, /*hidden argument*/GameObject_GetComponent_TisPlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48_m9D6451632C23946A0F702FE50879B5BF75CEF829_RuntimeMethod_var);
		int32_t L_4 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		NullCheck(L_3);
		PlayerManager_loadStage_mEA31662275CFD57A213EA40C1DDD20599709CC00(L_3, L_4, /*hidden argument*/NULL);
		// ug.forceMode = true;
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_5 = __this->get_ug_15();
		NullCheck(L_5);
		L_5->set_forceMode_10((bool)1);
		// ug.changeMode();
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_6 = __this->get_ug_15();
		NullCheck(L_6);
		UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4(L_6, /*hidden argument*/NULL);
		// btn_nextStage.SetActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_7 = __this->get_btn_nextStage_10();
		NullCheck(L_7);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_7, (bool)1, /*hidden argument*/NULL);
		// btn_retry.SetActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_8 = __this->get_btn_retry_11();
		NullCheck(L_8);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_8, (bool)1, /*hidden argument*/NULL);
		// isPausing = false;
		__this->set_isPausing_17((bool)0);
		// rb.isKinematic = false;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_9 = __this->get_rb_31();
		NullCheck(L_9);
		Rigidbody_set_isKinematic_mCF74D680205544826F2DE2CAB929C9F25409A311(L_9, (bool)0, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void MainGameManager::setCanvesActive(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_setCanvesActive_mB2D2B2AEB306B5063502C824E457620DEEEACDA9 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, bool ___isCleared0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringBuilder_t_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral28A00C6C2538607194DCD2548EF0DFB07D324A14);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2B86D66477376A42A49B3CD3983CF53BEF4E55A0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral420E59722344B7BBF7D2AD7BAADC29DE98149298);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral892E1AB895E27AFF8AB5474D79F8D5C76BE64F01);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralB20BB0B2D8D418EF3CDB10A09869E584A012E8CE);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralC8EA0F7A3B3C7A6868670228490AEA985E92164D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralD131397F1FB7BFF3B5A8A63CC32384739F6D42AC);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	String_t* V_1 = NULL;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	StringBuilder_t * V_4 = NULL;
	String_t* V_5 = NULL;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	StringBuilder_t * V_8 = NULL;
	int32_t V_9 = 0;
	{
		// if (rta) //RTAモードでこの関数が呼ばれるとき、必ず最終ステージをクリアしている
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		bool L_0 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_rta_18();
		if (!L_0)
		{
			goto IL_012a;
		}
	}
	{
		// float score = t;
		float L_1 = __this->get_t_29();
		V_0 = L_1;
		// rtaResultLabel.text = "時間:" + score.ToString("f3") + "秒";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_2 = __this->get_rtaResultLabel_23();
		String_t* L_3;
		L_3 = Single_ToString_m15F10F2AFF80750906CEFCFB456EBA84F9D2E8D7((float*)(&V_0), _stringLiteralD131397F1FB7BFF3B5A8A63CC32384739F6D42AC, /*hidden argument*/NULL);
		String_t* L_4;
		L_4 = String_Concat_m89EAB4C6A96B0E5C3F87300D6BE78D386B9EFC44(_stringLiteralC8EA0F7A3B3C7A6868670228490AEA985E92164D, L_3, _stringLiteral2B86D66477376A42A49B3CD3983CF53BEF4E55A0, /*hidden argument*/NULL);
		NullCheck(L_2);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_2, L_4);
		// clearCanvasGroup.SetActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_5 = __this->get_clearCanvasGroup_9();
		NullCheck(L_5);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_5, (bool)1, /*hidden argument*/NULL);
		// StreamReader sr = new StreamReader("Save/data.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_6 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_6, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		// string saveData = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_7 = L_6;
		NullCheck(L_7);
		String_t* L_8;
		L_8 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_7);
		V_1 = L_8;
		// sr.Close();
		NullCheck(L_7);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_7);
		// int idx = saveData.IndexOf(":"); //最初のコロンの位置(AutoRetryの後)
		String_t* L_9 = V_1;
		NullCheck(L_9);
		int32_t L_10;
		L_10 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_9, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, /*hidden argument*/NULL);
		V_2 = L_10;
		// idx = saveData.IndexOf(":", idx + 1); //2番目のコロンの位置(ReachedStageの後)
		String_t* L_11 = V_1;
		int32_t L_12 = V_2;
		NullCheck(L_11);
		int32_t L_13;
		L_13 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_11, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, ((int32_t)il2cpp_codegen_add((int32_t)L_12, (int32_t)1)), /*hidden argument*/NULL);
		V_2 = L_13;
		// idx = saveData.IndexOf(":", idx + 1); //3番目のコロンの位置(RTAの後)
		String_t* L_14 = V_1;
		int32_t L_15 = V_2;
		NullCheck(L_14);
		int32_t L_16;
		L_16 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_14, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, ((int32_t)il2cpp_codegen_add((int32_t)L_15, (int32_t)1)), /*hidden argument*/NULL);
		V_2 = L_16;
		// idx++; //コロンが含まれてしまうため
		int32_t L_17 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_17, (int32_t)1));
		// int subidx = saveData.IndexOf(";"); //最初のセミコロンの位置（AutoRetryの後）
		String_t* L_18 = V_1;
		NullCheck(L_18);
		int32_t L_19;
		L_19 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_18, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, /*hidden argument*/NULL);
		V_3 = L_19;
		// subidx = saveData.IndexOf(";", subidx + 1); //2番目のセミコロンの位置（ReachedStageの後）
		String_t* L_20 = V_1;
		int32_t L_21 = V_3;
		NullCheck(L_20);
		int32_t L_22;
		L_22 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_20, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, ((int32_t)il2cpp_codegen_add((int32_t)L_21, (int32_t)1)), /*hidden argument*/NULL);
		V_3 = L_22;
		// subidx = saveData.IndexOf(";", subidx + 1); //3番目のセミコロンの位置（RTAの後）
		String_t* L_23 = V_1;
		int32_t L_24 = V_3;
		NullCheck(L_23);
		int32_t L_25;
		L_25 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_23, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, ((int32_t)il2cpp_codegen_add((int32_t)L_24, (int32_t)1)), /*hidden argument*/NULL);
		V_3 = L_25;
		// StringBuilder sb = new StringBuilder(saveData);
		String_t* L_26 = V_1;
		StringBuilder_t * L_27 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77(L_27, L_26, /*hidden argument*/NULL);
		V_4 = L_27;
		// if (saveData.Substring(idx, subidx - idx).Equals("N/A") || score <= float.Parse(saveData.Substring(idx, subidx - idx)))
		String_t* L_28 = V_1;
		int32_t L_29 = V_2;
		int32_t L_30 = V_3;
		int32_t L_31 = V_2;
		NullCheck(L_28);
		String_t* L_32;
		L_32 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_28, L_29, ((int32_t)il2cpp_codegen_subtract((int32_t)L_30, (int32_t)L_31)), /*hidden argument*/NULL);
		NullCheck(L_32);
		bool L_33;
		L_33 = String_Equals_m8A062B96B61A7D652E7D73C9B3E904F6B0E5F41D(L_32, _stringLiteral28A00C6C2538607194DCD2548EF0DFB07D324A14, /*hidden argument*/NULL);
		if (L_33)
		{
			goto IL_00e4;
		}
	}
	{
		float L_34 = V_0;
		String_t* L_35 = V_1;
		int32_t L_36 = V_2;
		int32_t L_37 = V_3;
		int32_t L_38 = V_2;
		NullCheck(L_35);
		String_t* L_39;
		L_39 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_35, L_36, ((int32_t)il2cpp_codegen_subtract((int32_t)L_37, (int32_t)L_38)), /*hidden argument*/NULL);
		float L_40;
		L_40 = Single_Parse_mA1B20E6E0AAD67F60707D81E82667D2D4B274D6F(L_39, /*hidden argument*/NULL);
		if ((!(((float)L_34) <= ((float)L_40))))
		{
			goto IL_02b1;
		}
	}

IL_00e4:
	{
		// sb.Remove(idx, subidx - idx);
		StringBuilder_t * L_41 = V_4;
		int32_t L_42 = V_2;
		int32_t L_43 = V_3;
		int32_t L_44 = V_2;
		NullCheck(L_41);
		StringBuilder_t * L_45;
		L_45 = StringBuilder_Remove_m6ABF9CF3D10160EB52E0768262A9B179F987571E(L_41, L_42, ((int32_t)il2cpp_codegen_subtract((int32_t)L_43, (int32_t)L_44)), /*hidden argument*/NULL);
		// sb.Insert(idx, score.ToString("f3"));
		StringBuilder_t * L_46 = V_4;
		int32_t L_47 = V_2;
		String_t* L_48;
		L_48 = Single_ToString_m15F10F2AFF80750906CEFCFB456EBA84F9D2E8D7((float*)(&V_0), _stringLiteralD131397F1FB7BFF3B5A8A63CC32384739F6D42AC, /*hidden argument*/NULL);
		NullCheck(L_46);
		StringBuilder_t * L_49;
		L_49 = StringBuilder_Insert_m2B101CF8B6D47CFC7602CBABC101569E513D234F(L_46, L_47, L_48, /*hidden argument*/NULL);
		// saveData = sb.ToString();
		StringBuilder_t * L_50 = V_4;
		NullCheck(L_50);
		String_t* L_51;
		L_51 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_50);
		V_1 = L_51;
		// StreamWriter sw = new StreamWriter("Save/data.txt", false, Encoding.UTF8);
		Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * L_52;
		L_52 = Encoding_get_UTF8_mC877FB3137BBD566AEE7B15F9BF61DC4EF8F5E5E(/*hidden argument*/NULL);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_53 = (StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 *)il2cpp_codegen_object_new(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		StreamWriter__ctor_m8E689BB489D6CA87348E79EBF05BA4E3F6D4B9A4(L_53, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, (bool)0, L_52, /*hidden argument*/NULL);
		// sw.Write(saveData);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_54 = L_53;
		String_t* L_55 = V_1;
		NullCheck(L_54);
		VirtActionInvoker1< String_t* >::Invoke(14 /* System.Void System.IO.TextWriter::Write(System.String) */, L_54, L_55);
		// sw.Close();
		NullCheck(L_54);
		VirtActionInvoker0::Invoke(8 /* System.Void System.IO.TextWriter::Close() */, L_54);
		// }
		return;
	}

IL_012a:
	{
		// else if (isCleared)
		bool L_56 = ___isCleared0;
		if (!L_56)
		{
			goto IL_024c;
		}
	}
	{
		// Label.text = "成功";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_57 = __this->get_Label_20();
		NullCheck(L_57);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_57, _stringLiteral892E1AB895E27AFF8AB5474D79F8D5C76BE64F01);
		// if (datas.currentStageNum == MAX_STAGE_NUM)
		int32_t L_58 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		int32_t L_59 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_MAX_STAGE_NUM_19();
		if ((!(((uint32_t)L_58) == ((uint32_t)L_59))))
		{
			goto IL_0158;
		}
	}
	{
		// btn_nextStage.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_60 = __this->get_btn_nextStage_10();
		NullCheck(L_60);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_60, (bool)0, /*hidden argument*/NULL);
	}

IL_0158:
	{
		// btn_setting.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_61 = __this->get_btn_setting_13();
		NullCheck(L_61);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_61, (bool)0, /*hidden argument*/NULL);
		// StreamReader sr = new StreamReader("Save/data.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_62 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_62, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		// string saveData = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_63 = L_62;
		NullCheck(L_63);
		String_t* L_64;
		L_64 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_63);
		V_5 = L_64;
		// sr.Close();
		NullCheck(L_63);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_63);
		// int idx = saveData.IndexOf(":"); //最初のコロンの位置(AutoRetryの後)
		String_t* L_65 = V_5;
		NullCheck(L_65);
		int32_t L_66;
		L_66 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_65, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, /*hidden argument*/NULL);
		V_6 = L_66;
		// idx = saveData.IndexOf(":", idx + 1); //2番目のコロンの位置(ReachedStageの後)
		String_t* L_67 = V_5;
		int32_t L_68 = V_6;
		NullCheck(L_67);
		int32_t L_69;
		L_69 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_67, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, ((int32_t)il2cpp_codegen_add((int32_t)L_68, (int32_t)1)), /*hidden argument*/NULL);
		V_6 = L_69;
		// idx++; //コロンが含まれてしまうため
		int32_t L_70 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_add((int32_t)L_70, (int32_t)1));
		// int subidx = saveData.IndexOf(";"); //最初のセミコロンの位置（AutoRetryの後）
		String_t* L_71 = V_5;
		NullCheck(L_71);
		int32_t L_72;
		L_72 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_71, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, /*hidden argument*/NULL);
		V_7 = L_72;
		// subidx = saveData.IndexOf(";", subidx + 1); //2番目のセミコロンの位置（ReachedStageの後）
		String_t* L_73 = V_5;
		int32_t L_74 = V_7;
		NullCheck(L_73);
		int32_t L_75;
		L_75 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_73, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, ((int32_t)il2cpp_codegen_add((int32_t)L_74, (int32_t)1)), /*hidden argument*/NULL);
		V_7 = L_75;
		// StringBuilder sb = new StringBuilder(saveData);
		String_t* L_76 = V_5;
		StringBuilder_t * L_77 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77(L_77, L_76, /*hidden argument*/NULL);
		V_8 = L_77;
		// if (datas.currentStageNum >= Convert.ToInt32(saveData.Substring(idx, subidx - idx)) && datas.currentStageNum <= MAX_STAGE_NUM)
		int32_t L_78 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		String_t* L_79 = V_5;
		int32_t L_80 = V_6;
		int32_t L_81 = V_7;
		int32_t L_82 = V_6;
		NullCheck(L_79);
		String_t* L_83;
		L_83 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_79, L_80, ((int32_t)il2cpp_codegen_subtract((int32_t)L_81, (int32_t)L_82)), /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		int32_t L_84;
		L_84 = Convert_ToInt32_mA1C10AB2A7C95E9DCAC473D1D88C74D60FA240ED(L_83, /*hidden argument*/NULL);
		if ((((int32_t)L_78) < ((int32_t)L_84)))
		{
			goto IL_023f;
		}
	}
	{
		int32_t L_85 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		int32_t L_86 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_MAX_STAGE_NUM_19();
		if ((((int32_t)L_85) > ((int32_t)L_86)))
		{
			goto IL_023f;
		}
	}
	{
		// sb.Remove(idx, subidx - idx);
		StringBuilder_t * L_87 = V_8;
		int32_t L_88 = V_6;
		int32_t L_89 = V_7;
		int32_t L_90 = V_6;
		NullCheck(L_87);
		StringBuilder_t * L_91;
		L_91 = StringBuilder_Remove_m6ABF9CF3D10160EB52E0768262A9B179F987571E(L_87, L_88, ((int32_t)il2cpp_codegen_subtract((int32_t)L_89, (int32_t)L_90)), /*hidden argument*/NULL);
		// sb.Insert(idx, (datas.currentStageNum + 1).ToString());
		StringBuilder_t * L_92 = V_8;
		int32_t L_93 = V_6;
		int32_t L_94 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		V_9 = ((int32_t)il2cpp_codegen_add((int32_t)L_94, (int32_t)1));
		String_t* L_95;
		L_95 = Int32_ToString_m340C0A14D16799421EFDF8A81C8A16FA76D48411((int32_t*)(&V_9), /*hidden argument*/NULL);
		NullCheck(L_92);
		StringBuilder_t * L_96;
		L_96 = StringBuilder_Insert_m2B101CF8B6D47CFC7602CBABC101569E513D234F(L_92, L_93, L_95, /*hidden argument*/NULL);
		// saveData = sb.ToString();
		StringBuilder_t * L_97 = V_8;
		NullCheck(L_97);
		String_t* L_98;
		L_98 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_97);
		V_5 = L_98;
		// StreamWriter sw = new StreamWriter("Save/data.txt", false, Encoding.UTF8);
		Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * L_99;
		L_99 = Encoding_get_UTF8_mC877FB3137BBD566AEE7B15F9BF61DC4EF8F5E5E(/*hidden argument*/NULL);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_100 = (StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 *)il2cpp_codegen_object_new(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		StreamWriter__ctor_m8E689BB489D6CA87348E79EBF05BA4E3F6D4B9A4(L_100, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, (bool)0, L_99, /*hidden argument*/NULL);
		// sw.Write(saveData);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_101 = L_100;
		String_t* L_102 = V_5;
		NullCheck(L_101);
		VirtActionInvoker1< String_t* >::Invoke(14 /* System.Void System.IO.TextWriter::Write(System.String) */, L_101, L_102);
		// sw.Close();
		NullCheck(L_101);
		VirtActionInvoker0::Invoke(8 /* System.Void System.IO.TextWriter::Close() */, L_101);
	}

IL_023f:
	{
		// clearCanvasGroup.SetActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_103 = __this->get_clearCanvasGroup_9();
		NullCheck(L_103);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_103, (bool)1, /*hidden argument*/NULL);
		// }
		return;
	}

IL_024c:
	{
		// if (autoRetry)
		bool L_104 = __this->get_autoRetry_16();
		if (!L_104)
		{
			goto IL_0265;
		}
	}
	{
		// Invoke("loadSelf", 0.26f);
		MonoBehaviour_Invoke_m4AAB759653B1C6FB0653527F4DDC72D1E9162CC4(__this, _stringLiteral420E59722344B7BBF7D2AD7BAADC29DE98149298, (0.25999999f), /*hidden argument*/NULL);
		// }
		return;
	}

IL_0265:
	{
		// Label.text = "失敗";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_105 = __this->get_Label_20();
		NullCheck(L_105);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_105, _stringLiteralB20BB0B2D8D418EF3CDB10A09869E584A012E8CE);
		// btn_resume.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_106 = __this->get_btn_resume_12();
		NullCheck(L_106);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_106, (bool)0, /*hidden argument*/NULL);
		// toggle_autoRetry.SetActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_107 = __this->get_toggle_autoRetry_14();
		NullCheck(L_107);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_107, (bool)1, /*hidden argument*/NULL);
		// btn_nextStage.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_108 = __this->get_btn_nextStage_10();
		NullCheck(L_108);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_108, (bool)0, /*hidden argument*/NULL);
		// btn_setting.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_109 = __this->get_btn_setting_13();
		NullCheck(L_109);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_109, (bool)0, /*hidden argument*/NULL);
		// clearCanvasGroup.SetActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_110 = __this->get_clearCanvasGroup_9();
		NullCheck(L_110);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_110, (bool)1, /*hidden argument*/NULL);
	}

IL_02b1:
	{
		// }
		return;
	}
}
// System.Void MainGameManager::switchAutoRetry()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_switchAutoRetry_m09C893F433E0685D31857B5B53A57B2EC22FFA3E (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringBuilder_t_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9FCD15851E70A26784E98AFC64621C56BC0BBFD0);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		// autoRetry = toggle_autoRetry.GetComponent<Toggle>().isOn;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = __this->get_toggle_autoRetry_14();
		NullCheck(L_0);
		Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * L_1;
		L_1 = GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49(L_0, /*hidden argument*/GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49_RuntimeMethod_var);
		NullCheck(L_1);
		bool L_2;
		L_2 = Toggle_get_isOn_m2B1F3640101A6FCDA6B5AF27924FFD10E3A89A6C_inline(L_1, /*hidden argument*/NULL);
		__this->set_autoRetry_16(L_2);
		// StreamReader sr = new StreamReader("Save/data.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_3 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_3, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		// string saveData = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_4 = L_3;
		NullCheck(L_4);
		String_t* L_5;
		L_5 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_4);
		V_0 = L_5;
		// sr.Close();
		NullCheck(L_4);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_4);
		// int idx = saveData.IndexOf("AutoRetry") + 10;
		String_t* L_6 = V_0;
		NullCheck(L_6);
		int32_t L_7;
		L_7 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_6, _stringLiteral9FCD15851E70A26784E98AFC64621C56BC0BBFD0, /*hidden argument*/NULL);
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_7, (int32_t)((int32_t)10)));
		// StringBuilder sb = new StringBuilder(saveData);
		String_t* L_8 = V_0;
		StringBuilder_t * L_9 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77(L_9, L_8, /*hidden argument*/NULL);
		// sb.Remove(idx, 1);
		StringBuilder_t * L_10 = L_9;
		int32_t L_11 = V_1;
		NullCheck(L_10);
		StringBuilder_t * L_12;
		L_12 = StringBuilder_Remove_m6ABF9CF3D10160EB52E0768262A9B179F987571E(L_10, L_11, 1, /*hidden argument*/NULL);
		// sb.Insert(idx, Convert.ToInt32(autoRetry).ToString());
		StringBuilder_t * L_13 = L_10;
		int32_t L_14 = V_1;
		bool L_15 = __this->get_autoRetry_16();
		IL2CPP_RUNTIME_CLASS_INIT(Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		int32_t L_16;
		L_16 = Convert_ToInt32_m3B3C332A65A7F38D6DDF1A1D0ED511C701F67CD3(L_15, /*hidden argument*/NULL);
		V_2 = L_16;
		String_t* L_17;
		L_17 = Int32_ToString_m340C0A14D16799421EFDF8A81C8A16FA76D48411((int32_t*)(&V_2), /*hidden argument*/NULL);
		NullCheck(L_13);
		StringBuilder_t * L_18;
		L_18 = StringBuilder_Insert_m2B101CF8B6D47CFC7602CBABC101569E513D234F(L_13, L_14, L_17, /*hidden argument*/NULL);
		// saveData = sb.ToString();
		NullCheck(L_13);
		String_t* L_19;
		L_19 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_13);
		V_0 = L_19;
		// StreamWriter sw = new StreamWriter("Save/data.txt", false, Encoding.UTF8);
		Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * L_20;
		L_20 = Encoding_get_UTF8_mC877FB3137BBD566AEE7B15F9BF61DC4EF8F5E5E(/*hidden argument*/NULL);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_21 = (StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 *)il2cpp_codegen_object_new(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		StreamWriter__ctor_m8E689BB489D6CA87348E79EBF05BA4E3F6D4B9A4(L_21, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, (bool)0, L_20, /*hidden argument*/NULL);
		// sw.Write(saveData);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_22 = L_21;
		String_t* L_23 = V_0;
		NullCheck(L_22);
		VirtActionInvoker1< String_t* >::Invoke(14 /* System.Void System.IO.TextWriter::Write(System.String) */, L_22, L_23);
		// sw.Close();
		NullCheck(L_22);
		VirtActionInvoker0::Invoke(8 /* System.Void System.IO.TextWriter::Close() */, L_22);
		// }
		return;
	}
}
// System.Void MainGameManager::switchPause()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager_switchPause_mA34A3C637F6A5919EA14A8F79321BE4A8C277CAE (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralB60DAB3032F143FD7C8052FD9EA179FE7A4F18BB);
		s_Il2CppMethodInitialized = true;
	}
	{
		// btn_nextStage.SetActive(isPausing);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = __this->get_btn_nextStage_10();
		bool L_1 = __this->get_isPausing_17();
		NullCheck(L_0);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_0, L_1, /*hidden argument*/NULL);
		// isPausing = !isPausing;
		bool L_2 = __this->get_isPausing_17();
		__this->set_isPausing_17((bool)((((int32_t)L_2) == ((int32_t)0))? 1 : 0));
		// Label.text = "停止中";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_3 = __this->get_Label_20();
		NullCheck(L_3);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_3, _stringLiteralB60DAB3032F143FD7C8052FD9EA179FE7A4F18BB);
		// btn_resume.SetActive(isPausing);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_4 = __this->get_btn_resume_12();
		bool L_5 = __this->get_isPausing_17();
		NullCheck(L_4);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_4, L_5, /*hidden argument*/NULL);
		// btn_setting.SetActive(isPausing);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_6 = __this->get_btn_setting_13();
		bool L_7 = __this->get_isPausing_17();
		NullCheck(L_6);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_6, L_7, /*hidden argument*/NULL);
		// clearCanvasGroup.SetActive(isPausing);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_8 = __this->get_clearCanvasGroup_9();
		bool L_9 = __this->get_isPausing_17();
		NullCheck(L_8);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_8, L_9, /*hidden argument*/NULL);
		// if (isPausing)
		bool L_10 = __this->get_isPausing_17();
		if (!L_10)
		{
			goto IL_0089;
		}
	}
	{
		// playerVel = rb.velocity;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_11 = __this->get_rb_31();
		NullCheck(L_11);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_12;
		L_12 = Rigidbody_get_velocity_mCFB033F3BD14C2BA68E797DFA4950F9307EC8E2C(L_11, /*hidden argument*/NULL);
		__this->set_playerVel_30(L_12);
		// rb.isKinematic = true;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_13 = __this->get_rb_31();
		NullCheck(L_13);
		Rigidbody_set_isKinematic_mCF74D680205544826F2DE2CAB929C9F25409A311(L_13, (bool)1, /*hidden argument*/NULL);
		// }
		return;
	}

IL_0089:
	{
		// rb.isKinematic = false;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_14 = __this->get_rb_31();
		NullCheck(L_14);
		Rigidbody_set_isKinematic_mCF74D680205544826F2DE2CAB929C9F25409A311(L_14, (bool)0, /*hidden argument*/NULL);
		// rb.velocity = playerVel;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_15 = __this->get_rb_31();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_16 = __this->get_playerVel_30();
		NullCheck(L_15);
		Rigidbody_set_velocity_m8DC0988916EB38DFD7D4584830B41D79140BF18D(L_15, L_16, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void MainGameManager::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager__ctor_mD5EF849C53422DCB7971DD3CA76A5360BAE6D648 (MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void MainGameManager::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainGameManager__cctor_m48B9999F35461BE7E81987118B877D20775F25E9 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public static int MAX_STAGE_NUM = 19;
		((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->set_MAX_STAGE_NUM_19(((int32_t)19));
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void MusicManager::Start()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MusicManager_Start_m1F72199B30EAA11A29F14D822F58533A045DEE6C (MusicManager_tFC710AB7CA46AF229C4B937E8F9E0119AE59182D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// DontDestroyOnLoad(gameObject);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0;
		L_0 = Component_get_gameObject_m55DC35B149AFB9157582755383BA954655FE0C5B(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		Object_DontDestroyOnLoad_m03007A68ABBA4CCD8C27B944964983395E7640F9(L_0, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void MusicManager::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MusicManager__ctor_m94AF2B626CF1C068F5FA6D685B09D615BC0558F1 (MusicManager_tFC710AB7CA46AF229C4B937E8F9E0119AE59182D * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void PlayerManager::Start()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_Start_mA587FD881326FC1FBCEE2699E54A8A0ACCF83455 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m3BF8F0D99AB14A2C6D2C3DCC33AC2AFAC49B29D1_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m7F9CE8DE7ACB08AC5198A03E9B4A1B64CAD17A4F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7831B7715AA09703BEA6DAB66D910E60EB689C3F);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// Manager = GameObject.Find("Manager");
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0;
		L_0 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteral7831B7715AA09703BEA6DAB66D910E60EB689C3F, /*hidden argument*/NULL);
		__this->set_Manager_6(L_0);
		// isCleared = false;
		__this->set_isCleared_4((bool)0);
		// isFailed = false;
		__this->set_isFailed_5((bool)0);
		// mgManager = Manager.GetComponent<MainGameManager>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1 = __this->get_Manager_6();
		NullCheck(L_1);
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_2;
		L_2 = GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0(L_1, /*hidden argument*/GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0_RuntimeMethod_var);
		__this->set_mgManager_7(L_2);
		// rb = GetComponent<Rigidbody>();
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_3;
		L_3 = Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE(__this, /*hidden argument*/Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE_RuntimeMethod_var);
		__this->set_rb_8(L_3);
		// tr = GetComponent<TrailRenderer>();
		TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * L_4;
		L_4 = Component_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m3BF8F0D99AB14A2C6D2C3DCC33AC2AFAC49B29D1(__this, /*hidden argument*/Component_GetComponent_TisTrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01_m3BF8F0D99AB14A2C6D2C3DCC33AC2AFAC49B29D1_RuntimeMethod_var);
		__this->set_tr_9(L_4);
		// ug = GetComponent<UniversalGravity>();
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_5;
		L_5 = Component_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m7F9CE8DE7ACB08AC5198A03E9B4A1B64CAD17A4F(__this, /*hidden argument*/Component_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m7F9CE8DE7ACB08AC5198A03E9B4A1B64CAD17A4F_RuntimeMethod_var);
		__this->set_ug_12(L_5);
		// dat = new datas();
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_6 = (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 *)il2cpp_codegen_object_new(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		datas__ctor_mE6BBE9C089031DEEA352E2A6D402729C8D064E8D(L_6, /*hidden argument*/NULL);
		__this->set_dat_11(L_6);
		// resetChallengeFlags();
		PlayerManager_resetChallengeFlags_m4CA13CBC872BF5439D424C23371D097C883D2986(__this, /*hidden argument*/NULL);
		// sinus = GameObject.Find("Main Camera").GetComponent<Sinus>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_7;
		L_7 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_7);
		Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * L_8;
		L_8 = GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C(L_7, /*hidden argument*/GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C_RuntimeMethod_var);
		__this->set_sinus_14(L_8);
		// forceSpheres = GameObject.FindGameObjectsWithTag("ForceSphere");
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_9;
		L_9 = GameObject_FindGameObjectsWithTag_m0948320611DC82590D59A36D1C57155B1B6CE186(_stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1, /*hidden argument*/NULL);
		__this->set_forceSpheres_15(L_9);
		// soundPlaySystem = GameObject.Find("Main Camera").GetComponent<SoundPlaySystem>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_10;
		L_10 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_10);
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_11;
		L_11 = GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F(L_10, /*hidden argument*/GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		__this->set_soundPlaySystem_16(L_11);
		// }
		return;
	}
}
// System.Void PlayerManager::Update()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_Update_mA0EE0A117D34258508935E958CF715FD930D066A (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	float V_1 = 0.0f;
	GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* V_2 = NULL;
	int32_t V_3 = 0;
	float V_4 = 0.0f;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  V_5;
	memset((&V_5), 0, sizeof(V_5));
	{
		// if (Input.GetMouseButtonDown(0) && !mgManager.isPausing) clickCount++;
		bool L_0;
		L_0 = Input_GetMouseButtonDown_m466D81FDCC87C9CB07557B39DCB435EB691F1EF3(0, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0023;
		}
	}
	{
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_1 = __this->get_mgManager_7();
		NullCheck(L_1);
		bool L_2 = L_1->get_isPausing_17();
		if (L_2)
		{
			goto IL_0023;
		}
	}
	{
		// if (Input.GetMouseButtonDown(0) && !mgManager.isPausing) clickCount++;
		int32_t L_3 = __this->get_clickCount_21();
		__this->set_clickCount_21(((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)1)));
	}

IL_0023:
	{
		// challengeManager(datas.currentStageNum);
		int32_t L_4 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		PlayerManager_challengeManager_m3B695215655DAF690D60D26DFD87A05C36635652(__this, L_4, /*hidden argument*/NULL);
		// pos = transform.position;
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_5;
		L_5 = Component_get_transform_mE8496EBC45BEB1BADB5F314960F1DF1C952FA11F(__this, /*hidden argument*/NULL);
		NullCheck(L_5);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_6;
		L_6 = Transform_get_position_m40A8A9895568D56FFC687B57F30E8D53CB5EA341(L_5, /*hidden argument*/NULL);
		__this->set_pos_23(L_6);
		// if (!mgManager.isPausing) t += Time.deltaTime;
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_7 = __this->get_mgManager_7();
		NullCheck(L_7);
		bool L_8 = L_7->get_isPausing_17();
		if (L_8)
		{
			goto IL_005e;
		}
	}
	{
		// if (!mgManager.isPausing) t += Time.deltaTime;
		float L_9 = __this->get_t_22();
		float L_10;
		L_10 = Time_get_deltaTime_mCC15F147DA67F38C74CE408FB5D7FF4A87DA2290(/*hidden argument*/NULL);
		__this->set_t_22(((float)il2cpp_codegen_add((float)L_9, (float)L_10)));
	}

IL_005e:
	{
		// int closeSphereCount = 0; //範囲内にある球の数
		V_0 = 0;
		// float closestDistance = 100; //最も近い球との最短距離
		V_1 = (100.0f);
		// foreach (GameObject obj in forceSpheres)
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_11 = __this->get_forceSpheres_15();
		V_2 = L_11;
		V_3 = 0;
		goto IL_00a9;
	}

IL_0071:
	{
		// foreach (GameObject obj in forceSpheres)
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_12 = V_2;
		int32_t L_13 = V_3;
		NullCheck(L_12);
		int32_t L_14 = L_13;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_15 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		// float dist = Vector3.Distance(obj.transform.position, transform.position);
		NullCheck(L_15);
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_16;
		L_16 = GameObject_get_transform_m16A80BB92B6C8C5AB696E447014D45EDF1E4DE34(L_15, /*hidden argument*/NULL);
		NullCheck(L_16);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_17;
		L_17 = Transform_get_position_m40A8A9895568D56FFC687B57F30E8D53CB5EA341(L_16, /*hidden argument*/NULL);
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_18;
		L_18 = Component_get_transform_mE8496EBC45BEB1BADB5F314960F1DF1C952FA11F(__this, /*hidden argument*/NULL);
		NullCheck(L_18);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_19;
		L_19 = Transform_get_position_m40A8A9895568D56FFC687B57F30E8D53CB5EA341(L_18, /*hidden argument*/NULL);
		float L_20;
		L_20 = Vector3_Distance_mB648A79E4A1BAAFBF7B029644638C0D715480677(L_17, L_19, /*hidden argument*/NULL);
		V_4 = L_20;
		// if (dist < 6) closeSphereCount++;
		float L_21 = V_4;
		if ((!(((float)L_21) < ((float)(6.0f)))))
		{
			goto IL_009d;
		}
	}
	{
		// if (dist < 6) closeSphereCount++;
		int32_t L_22 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_22, (int32_t)1));
	}

IL_009d:
	{
		// if (dist < closestDistance) closestDistance = dist;
		float L_23 = V_4;
		float L_24 = V_1;
		if ((!(((float)L_23) < ((float)L_24))))
		{
			goto IL_00a5;
		}
	}
	{
		// if (dist < closestDistance) closestDistance = dist;
		float L_25 = V_4;
		V_1 = L_25;
	}

IL_00a5:
	{
		int32_t L_26 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_26, (int32_t)1));
	}

IL_00a9:
	{
		// foreach (GameObject obj in forceSpheres)
		int32_t L_27 = V_3;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_28 = V_2;
		NullCheck(L_28);
		if ((((int32_t)L_27) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_28)->max_length))))))
		{
			goto IL_0071;
		}
	}
	{
		// if (closeSphereCount == 0) sinus.overtonesRange = 1;
		int32_t L_29 = V_0;
		if (L_29)
		{
			goto IL_00c4;
		}
	}
	{
		// if (closeSphereCount == 0) sinus.overtonesRange = 1;
		Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * L_30 = __this->get_sinus_14();
		NullCheck(L_30);
		L_30->set_overtonesRange_5((1.0f));
		goto IL_00d1;
	}

IL_00c4:
	{
		// else sinus.overtonesRange = closeSphereCount;
		Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * L_31 = __this->get_sinus_14();
		int32_t L_32 = V_0;
		NullCheck(L_31);
		L_31->set_overtonesRange_5(((float)((float)L_32)));
	}

IL_00d1:
	{
		// if (rb.velocity.magnitude < 0.01f) sinus.frequency = 0;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_33 = __this->get_rb_8();
		NullCheck(L_33);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_34;
		L_34 = Rigidbody_get_velocity_mCFB033F3BD14C2BA68E797DFA4950F9307EC8E2C(L_33, /*hidden argument*/NULL);
		V_5 = L_34;
		float L_35;
		L_35 = Vector3_get_magnitude_mDDD40612220D8104E77E993E18A101A69A944991((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_5), /*hidden argument*/NULL);
		if ((!(((float)L_35) < ((float)(0.00999999978f)))))
		{
			goto IL_00fd;
		}
	}
	{
		// if (rb.velocity.magnitude < 0.01f) sinus.frequency = 0;
		Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * L_36 = __this->get_sinus_14();
		NullCheck(L_36);
		L_36->set_frequency_4((0.0f));
		return;
	}

IL_00fd:
	{
		// else sinus.frequency = rb.velocity.magnitude * 200 + 20;
		Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * L_37 = __this->get_sinus_14();
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_38 = __this->get_rb_8();
		NullCheck(L_38);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_39;
		L_39 = Rigidbody_get_velocity_mCFB033F3BD14C2BA68E797DFA4950F9307EC8E2C(L_38, /*hidden argument*/NULL);
		V_5 = L_39;
		float L_40;
		L_40 = Vector3_get_magnitude_mDDD40612220D8104E77E993E18A101A69A944991((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_5), /*hidden argument*/NULL);
		NullCheck(L_37);
		L_37->set_frequency_4(((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)L_40, (float)(200.0f))), (float)(20.0f))));
		// }
		return;
	}
}
// System.Void PlayerManager::OnCollisionEnter(UnityEngine.Collision)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_OnCollisionEnter_m36092D4986E0F456A95F641B33AC6D57790331D0 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0 * ___collisionInfo0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral27F8F1C579FF819E3522ABC61DA3B4E399DCF184);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral751ED465D17C903AD85E4E0D66A7122959CA8A62);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7649AEE062EE200D5810926162F39A75BCEE5287);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralFCD384615BA1CF7639363F707CDE70D1A4DFDA91);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// if (collisionInfo.gameObject.tag == "ForceSphere" && !isCleared)
		Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0 * L_0 = ___collisionInfo0;
		NullCheck(L_0);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1;
		L_1 = Collision_get_gameObject_m5682F872FD28419AA36F0651CE8B19825A21859D(L_0, /*hidden argument*/NULL);
		NullCheck(L_1);
		String_t* L_2;
		L_2 = GameObject_get_tag_mC21F33D368C18A631040F2887036C678B96ABC33(L_1, /*hidden argument*/NULL);
		bool L_3;
		L_3 = String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB(L_2, _stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_00e6;
		}
	}
	{
		bool L_4 = __this->get_isCleared_4();
		if (L_4)
		{
			goto IL_00e6;
		}
	}
	{
		// soundPlaySystem.SetSoundData(Resources.Load<AudioClip>("Sounds/incorrect"));
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_5 = __this->get_soundPlaySystem_16();
		AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * L_6;
		L_6 = Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1(_stringLiteral27F8F1C579FF819E3522ABC61DA3B4E399DCF184, /*hidden argument*/Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1_RuntimeMethod_var);
		NullCheck(L_5);
		SoundPlaySystem_SetSoundData_mC95E81C797E4E7D7210309AE5D3B8687EAB0BB9A(L_5, L_6, /*hidden argument*/NULL);
		// hitFail = true;
		__this->set_hitFail_18((bool)1);
		// challengeManager(datas.currentStageNum);
		int32_t L_7 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		PlayerManager_challengeManager_m3B695215655DAF690D60D26DFD87A05C36635652(__this, L_7, /*hidden argument*/NULL);
		// if (MainGameManager.rta || mgManager.autoRetry)
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		bool L_8 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_rta_18();
		if (L_8)
		{
			goto IL_0060;
		}
	}
	{
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_9 = __this->get_mgManager_7();
		NullCheck(L_9);
		bool L_10 = L_9->get_autoRetry_16();
		if (!L_10)
		{
			goto IL_0083;
		}
	}

IL_0060:
	{
		// ug.forceMode = true;
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_11 = __this->get_ug_12();
		NullCheck(L_11);
		L_11->set_forceMode_10((bool)1);
		// ug.changeMode();
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_12 = __this->get_ug_12();
		NullCheck(L_12);
		UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4(L_12, /*hidden argument*/NULL);
		// loadStage(datas.currentStageNum);
		int32_t L_13 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		PlayerManager_loadStage_mEA31662275CFD57A213EA40C1DDD20599709CC00(__this, L_13, /*hidden argument*/NULL);
		// return;
		return;
	}

IL_0083:
	{
		// if (SceneManager.GetActiveScene().name == "StageTest")
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE  L_14;
		L_14 = SceneManager_GetActiveScene_mB9A5037FFB576B2432D0BFEF6A161B7C4C1921A4(/*hidden argument*/NULL);
		V_0 = L_14;
		String_t* L_15;
		L_15 = Scene_get_name_m38F195D7CA6417FED310C23E4D8E86150C7835B8((Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE *)(&V_0), /*hidden argument*/NULL);
		bool L_16;
		L_16 = String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB(L_15, _stringLiteralFCD384615BA1CF7639363F707CDE70D1A4DFDA91, /*hidden argument*/NULL);
		if (!L_16)
		{
			goto IL_00a8;
		}
	}
	{
		// SceneManager.LoadScene("StageTest");
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		SceneManager_LoadScene_m7DAF30213E99396ECBDB1BD40CC34CCF36902092(_stringLiteralFCD384615BA1CF7639363F707CDE70D1A4DFDA91, /*hidden argument*/NULL);
		// }
		goto IL_00df;
	}

IL_00a8:
	{
		// else if (SceneManager.GetActiveScene().name == "Main")
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE  L_17;
		L_17 = SceneManager_GetActiveScene_mB9A5037FFB576B2432D0BFEF6A161B7C4C1921A4(/*hidden argument*/NULL);
		V_0 = L_17;
		String_t* L_18;
		L_18 = Scene_get_name_m38F195D7CA6417FED310C23E4D8E86150C7835B8((Scene_t5495AD2FDC587DB2E94D9BDE2B85868BFB9A92EE *)(&V_0), /*hidden argument*/NULL);
		bool L_19;
		L_19 = String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB(L_18, _stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D, /*hidden argument*/NULL);
		if (!L_19)
		{
			goto IL_00df;
		}
	}
	{
		// rb.constraints = RigidbodyConstraints.FreezeAll;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_20 = __this->get_rb_8();
		NullCheck(L_20);
		Rigidbody_set_constraints_mA76F562D16D3BE8889E095D0309C8FE38DA914F1(L_20, ((int32_t)126), /*hidden argument*/NULL);
		// Manager.GetComponent<MainGameManager>().setCanvesActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_21 = __this->get_Manager_6();
		NullCheck(L_21);
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_22;
		L_22 = GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0(L_21, /*hidden argument*/GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0_RuntimeMethod_var);
		NullCheck(L_22);
		MainGameManager_setCanvesActive_mB2D2B2AEB306B5063502C824E457620DEEEACDA9(L_22, (bool)0, /*hidden argument*/NULL);
	}

IL_00df:
	{
		// isFailed = true;
		__this->set_isFailed_5((bool)1);
	}

IL_00e6:
	{
		// if ((collisionInfo.gameObject.tag == "Wall" || collisionInfo.gameObject.tag == "BorderWall") && !isCleared) hitWall = true;
		Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0 * L_23 = ___collisionInfo0;
		NullCheck(L_23);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_24;
		L_24 = Collision_get_gameObject_m5682F872FD28419AA36F0651CE8B19825A21859D(L_23, /*hidden argument*/NULL);
		NullCheck(L_24);
		String_t* L_25;
		L_25 = GameObject_get_tag_mC21F33D368C18A631040F2887036C678B96ABC33(L_24, /*hidden argument*/NULL);
		bool L_26;
		L_26 = String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB(L_25, _stringLiteral7649AEE062EE200D5810926162F39A75BCEE5287, /*hidden argument*/NULL);
		if (L_26)
		{
			goto IL_0114;
		}
	}
	{
		Collision_tDC11F9B3834FD25DEB8C7DD1C51B635D240BBBF0 * L_27 = ___collisionInfo0;
		NullCheck(L_27);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_28;
		L_28 = Collision_get_gameObject_m5682F872FD28419AA36F0651CE8B19825A21859D(L_27, /*hidden argument*/NULL);
		NullCheck(L_28);
		String_t* L_29;
		L_29 = GameObject_get_tag_mC21F33D368C18A631040F2887036C678B96ABC33(L_28, /*hidden argument*/NULL);
		bool L_30;
		L_30 = String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB(L_29, _stringLiteral751ED465D17C903AD85E4E0D66A7122959CA8A62, /*hidden argument*/NULL);
		if (!L_30)
		{
			goto IL_0123;
		}
	}

IL_0114:
	{
		bool L_31 = __this->get_isCleared_4();
		if (L_31)
		{
			goto IL_0123;
		}
	}
	{
		// if ((collisionInfo.gameObject.tag == "Wall" || collisionInfo.gameObject.tag == "BorderWall") && !isCleared) hitWall = true;
		__this->set_hitWall_19((bool)1);
	}

IL_0123:
	{
		// }
		return;
	}
}
// System.Void PlayerManager::OnTriggerEnter(UnityEngine.Collider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_OnTriggerEnter_m63B072A77CF38CDCCD90C4C5D59DC443B79F917C (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 * ___other0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral43D9F7275E270582D83C15A95CEE78A24DFA363A);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (other.gameObject.tag == "Goal" && !isCleared && !isFailed)
		Collider_t5E81E43C2ECA0209A7C4528E84A632712D192B02 * L_0 = ___other0;
		NullCheck(L_0);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1;
		L_1 = Component_get_gameObject_m55DC35B149AFB9157582755383BA954655FE0C5B(L_0, /*hidden argument*/NULL);
		NullCheck(L_1);
		String_t* L_2;
		L_2 = GameObject_get_tag_mC21F33D368C18A631040F2887036C678B96ABC33(L_1, /*hidden argument*/NULL);
		bool L_3;
		L_3 = String_op_Equality_m2B91EE68355F142F67095973D32EB5828B7B73CB(L_2, _stringLiteral43D9F7275E270582D83C15A95CEE78A24DFA363A, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_005c;
		}
	}
	{
		bool L_4 = __this->get_isCleared_4();
		if (L_4)
		{
			goto IL_005c;
		}
	}
	{
		bool L_5 = __this->get_isFailed_5();
		if (L_5)
		{
			goto IL_005c;
		}
	}
	{
		// if (MainGameManager.rta)
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		bool L_6 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_rta_18();
		if (!L_6)
		{
			goto IL_003d;
		}
	}
	{
		// loadStage(datas.currentStageNum + 1);
		int32_t L_7 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		PlayerManager_loadStage_mEA31662275CFD57A213EA40C1DDD20599709CC00(__this, ((int32_t)il2cpp_codegen_add((int32_t)L_7, (int32_t)1)), /*hidden argument*/NULL);
		// }
		goto IL_0055;
	}

IL_003d:
	{
		// Manager.GetComponent<MainGameManager>().setCanvesActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_8 = __this->get_Manager_6();
		NullCheck(L_8);
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_9;
		L_9 = GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0(L_8, /*hidden argument*/GameObject_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF25FFE09EC8E2CE80D7BD1637C9F256A929491F0_RuntimeMethod_var);
		NullCheck(L_9);
		MainGameManager_setCanvesActive_mB2D2B2AEB306B5063502C824E457620DEEEACDA9(L_9, (bool)1, /*hidden argument*/NULL);
		// isCleared = true;
		__this->set_isCleared_4((bool)1);
	}

IL_0055:
	{
		// hitClear = true;
		__this->set_hitClear_17((bool)1);
	}

IL_005c:
	{
		// }
		return;
	}
}
// System.Void PlayerManager::LoadMainScene()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_LoadMainScene_mD99CF480981DE75C61B5E0ECDB28DB5D02207D05 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D);
		s_Il2CppMethodInitialized = true;
	}
	{
		// SceneManager.LoadScene("Main");
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		SceneManager_LoadScene_m7DAF30213E99396ECBDB1BD40CC34CCF36902092(_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void PlayerManager::loadStage(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_loadStage_mEA31662275CFD57A213EA40C1DDD20599709CC00 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, int32_t ___i0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral181EA86C68EBB2997047E26C99EDFF7B17E18DBB);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7649AEE062EE200D5810926162F39A75BCEE5287);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* V_0 = NULL;
	GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* V_1 = NULL;
	int32_t V_2 = 0;
	{
		// isFailed = false;
		__this->set_isFailed_5((bool)0);
		// isCleared = false;
		__this->set_isCleared_4((bool)0);
		// resetChallengeFlags();
		PlayerManager_resetChallengeFlags_m4CA13CBC872BF5439D424C23371D097C883D2986(__this, /*hidden argument*/NULL);
		// if (i <= MainGameManager.MAX_STAGE_NUM)
		int32_t L_0 = ___i0;
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		int32_t L_1 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_MAX_STAGE_NUM_19();
		if ((((int32_t)L_0) > ((int32_t)L_1)))
		{
			goto IL_00ee;
		}
	}
	{
		// rb.velocity = Vector3.zero;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_2 = __this->get_rb_8();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_3;
		L_3 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		NullCheck(L_2);
		Rigidbody_set_velocity_m8DC0988916EB38DFD7D4584830B41D79140BF18D(L_2, L_3, /*hidden argument*/NULL);
		// sdata = dat.getStageData(i);
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_4 = __this->get_dat_11();
		int32_t L_5 = ___i0;
		NullCheck(L_4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_6;
		L_6 = datas_getStageData_m0D19D87CDF47A697BFB2A35294B70E4B221DEA2F(L_4, L_5, /*hidden argument*/NULL);
		__this->set_sdata_10(L_6);
		// transform.position = sdata.playerPos;
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_7;
		L_7 = Component_get_transform_mE8496EBC45BEB1BADB5F314960F1DF1C952FA11F(__this, /*hidden argument*/NULL);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 * L_8 = __this->get_address_of_sdata_10();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_9 = L_8->get_playerPos_0();
		NullCheck(L_7);
		Transform_set_position_mB169E52D57EEAC1E3F22C5395968714E4F00AC91(L_7, L_9, /*hidden argument*/NULL);
		// rb.constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotation;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_10 = __this->get_rb_8();
		NullCheck(L_10);
		Rigidbody_set_constraints_mA76F562D16D3BE8889E095D0309C8FE38DA914F1(L_10, ((int32_t)116), /*hidden argument*/NULL);
		// if (i != datas.currentStageNum)
		int32_t L_11 = ___i0;
		int32_t L_12 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		if ((((int32_t)L_11) == ((int32_t)L_12)))
		{
			goto IL_00e2;
		}
	}
	{
		// datas.currentStageNum++;
		int32_t L_13 = ((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->get_currentStageNum_0();
		((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->set_currentStageNum_0(((int32_t)il2cpp_codegen_add((int32_t)L_13, (int32_t)1)));
		// GameObject[] fieldObj1 = GameObject.FindGameObjectsWithTag("ForceSphere");
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_14;
		L_14 = GameObject_FindGameObjectsWithTag_m0948320611DC82590D59A36D1C57155B1B6CE186(_stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1, /*hidden argument*/NULL);
		// GameObject[] fieldObj2 = GameObject.FindGameObjectsWithTag("Wall");
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_15;
		L_15 = GameObject_FindGameObjectsWithTag_m0948320611DC82590D59A36D1C57155B1B6CE186(_stringLiteral7649AEE062EE200D5810926162F39A75BCEE5287, /*hidden argument*/NULL);
		V_0 = L_15;
		// foreach (GameObject obj in fieldObj1)
		V_1 = L_14;
		V_2 = 0;
		goto IL_009f;
	}

IL_0092:
	{
		// foreach (GameObject obj in fieldObj1)
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_16 = V_1;
		int32_t L_17 = V_2;
		NullCheck(L_16);
		int32_t L_18 = L_17;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_19 = (L_16)->GetAt(static_cast<il2cpp_array_size_t>(L_18));
		// obj.SetActive(false);
		NullCheck(L_19);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_19, (bool)0, /*hidden argument*/NULL);
		int32_t L_20 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_20, (int32_t)1));
	}

IL_009f:
	{
		// foreach (GameObject obj in fieldObj1)
		int32_t L_21 = V_2;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_22 = V_1;
		NullCheck(L_22);
		if ((((int32_t)L_21) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_22)->max_length))))))
		{
			goto IL_0092;
		}
	}
	{
		// foreach (GameObject obj in fieldObj2)
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_23 = V_0;
		V_1 = L_23;
		V_2 = 0;
		goto IL_00b7;
	}

IL_00ab:
	{
		// foreach (GameObject obj in fieldObj2)
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_24 = V_1;
		int32_t L_25 = V_2;
		NullCheck(L_24);
		int32_t L_26 = L_25;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_27 = (L_24)->GetAt(static_cast<il2cpp_array_size_t>(L_26));
		// Destroy(obj);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		Object_Destroy_m3EEDB6ECD49A541EC826EA8E1C8B599F7AF67D30(L_27, /*hidden argument*/NULL);
		int32_t L_28 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_28, (int32_t)1));
	}

IL_00b7:
	{
		// foreach (GameObject obj in fieldObj2)
		int32_t L_29 = V_2;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_30 = V_1;
		NullCheck(L_30);
		if ((((int32_t)L_29) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_30)->max_length))))))
		{
			goto IL_00ab;
		}
	}
	{
		// Destroy(GameObject.Find("Goal(Clone)"));
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_31;
		L_31 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteral181EA86C68EBB2997047E26C99EDFF7B17E18DBB, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_il2cpp_TypeInfo_var);
		Object_Destroy_m3EEDB6ECD49A541EC826EA8E1C8B599F7AF67D30(L_31, /*hidden argument*/NULL);
		// mgManager.generateStage();
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_32 = __this->get_mgManager_7();
		NullCheck(L_32);
		MainGameManager_generateStage_mACCE2CAB40727A6ECDFC550150C699C036FEEB97(L_32, /*hidden argument*/NULL);
		// ug.GetAstroObjs();
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_33 = __this->get_ug_12();
		NullCheck(L_33);
		UniversalGravity_GetAstroObjs_mAC081AB221E0E3D34E9633FE0E4A8002ADF22EAA(L_33, /*hidden argument*/NULL);
	}

IL_00e2:
	{
		// tr.Clear();
		TrailRenderer_t219A9B1F6C4B984AE4BEEC40F90665D122056A01 * L_34 = __this->get_tr_9();
		NullCheck(L_34);
		TrailRenderer_Clear_mF9AAA91E20A28ECE700EA2B3D2605F0D9C294663(L_34, /*hidden argument*/NULL);
		// }
		return;
	}

IL_00ee:
	{
		// isCleared = true;
		__this->set_isCleared_4((bool)1);
		// mgManager.setCanvesActive(true);
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_35 = __this->get_mgManager_7();
		NullCheck(L_35);
		MainGameManager_setCanvesActive_mB2D2B2AEB306B5063502C824E457620DEEEACDA9(L_35, (bool)1, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void PlayerManager::challengeManager(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_challengeManager_m3B695215655DAF690D60D26DFD87A05C36635652 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, int32_t ___i0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Debug_tEB68BCBEB8EFD60F8043C67146DC05E7F50F374B_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral32FD1C2CD95565F20E77CF2BAF251A2BBE2177E4);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		int32_t L_0 = ___i0;
		switch (L_0)
		{
			case 0:
			{
				goto IL_005b;
			}
			case 1:
			{
				goto IL_009a;
			}
			case 2:
			{
				goto IL_00b9;
			}
			case 3:
			{
				goto IL_00f4;
			}
			case 4:
			{
				goto IL_0113;
			}
			case 5:
			{
				goto IL_0132;
			}
			case 6:
			{
				goto IL_0151;
			}
			case 7:
			{
				goto IL_0174;
			}
			case 8:
			{
				goto IL_0192;
			}
			case 9:
			{
				goto IL_01b1;
			}
			case 10:
			{
				goto IL_020c;
			}
			case 11:
			{
				goto IL_022f;
			}
			case 12:
			{
				goto IL_028f;
			}
			case 13:
			{
				goto IL_02ae;
			}
			case 14:
			{
				goto IL_02f7;
			}
			case 15:
			{
				goto IL_032e;
			}
			case 16:
			{
				goto IL_0392;
			}
			case 17:
			{
				goto IL_03b1;
			}
			case 18:
			{
				goto IL_03d4;
			}
			case 19:
			{
				goto IL_040b;
			}
		}
	}
	{
		goto IL_0465;
	}

IL_005b:
	{
		// if (rb.velocity.magnitude >= 8) challengeFlag1 = true;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_1 = __this->get_rb_8();
		NullCheck(L_1);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_2;
		L_2 = Rigidbody_get_velocity_mCFB033F3BD14C2BA68E797DFA4950F9307EC8E2C(L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		float L_3;
		L_3 = Vector3_get_magnitude_mDDD40612220D8104E77E993E18A101A69A944991((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_0), /*hidden argument*/NULL);
		if ((!(((float)L_3) >= ((float)(8.0f)))))
		{
			goto IL_007c;
		}
	}
	{
		// if (rb.velocity.magnitude >= 8) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_007c:
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		bool L_4 = __this->get_challengeFlag1_20();
		if (!L_4)
		{
			goto IL_046f;
		}
	}
	{
		bool L_5 = __this->get_hitClear_17();
		if (!L_5)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		int32_t L_6 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_6, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_009a:
	{
		// if (clickCount >= 2 && hitClear) savechallenge(i);
		int32_t L_7 = __this->get_clickCount_21();
		if ((((int32_t)L_7) < ((int32_t)2)))
		{
			goto IL_046f;
		}
	}
	{
		bool L_8 = __this->get_hitClear_17();
		if (!L_8)
		{
			goto IL_046f;
		}
	}
	{
		// if (clickCount >= 2 && hitClear) savechallenge(i);
		int32_t L_9 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_9, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_00b9:
	{
		// if (t <= 1 && clickCount >= 1) challengeFlag1 = true;
		float L_10 = __this->get_t_22();
		if ((!(((float)L_10) <= ((float)(1.0f)))))
		{
			goto IL_00d6;
		}
	}
	{
		int32_t L_11 = __this->get_clickCount_21();
		if ((((int32_t)L_11) < ((int32_t)1)))
		{
			goto IL_00d6;
		}
	}
	{
		// if (t <= 1 && clickCount >= 1) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_00d6:
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		bool L_12 = __this->get_challengeFlag1_20();
		if (!L_12)
		{
			goto IL_046f;
		}
	}
	{
		bool L_13 = __this->get_hitClear_17();
		if (!L_13)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		int32_t L_14 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_14, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_00f4:
	{
		// if (clickCount == 1 && hitClear) savechallenge(i);
		int32_t L_15 = __this->get_clickCount_21();
		if ((!(((uint32_t)L_15) == ((uint32_t)1))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_16 = __this->get_hitClear_17();
		if (!L_16)
		{
			goto IL_046f;
		}
	}
	{
		// if (clickCount == 1 && hitClear) savechallenge(i);
		int32_t L_17 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_17, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_0113:
	{
		// if (clickCount == 1 && hitClear) savechallenge(i);
		int32_t L_18 = __this->get_clickCount_21();
		if ((!(((uint32_t)L_18) == ((uint32_t)1))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_19 = __this->get_hitClear_17();
		if (!L_19)
		{
			goto IL_046f;
		}
	}
	{
		// if (clickCount == 1 && hitClear) savechallenge(i);
		int32_t L_20 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_20, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_0132:
	{
		// if (clickCount == 2 && hitClear) savechallenge(i);
		int32_t L_21 = __this->get_clickCount_21();
		if ((!(((uint32_t)L_21) == ((uint32_t)2))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_22 = __this->get_hitClear_17();
		if (!L_22)
		{
			goto IL_046f;
		}
	}
	{
		// if (clickCount == 2 && hitClear) savechallenge(i);
		int32_t L_23 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_23, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_0151:
	{
		// if (t <= 5 && hitClear) savechallenge(i);
		float L_24 = __this->get_t_22();
		if ((!(((float)L_24) <= ((float)(5.0f)))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_25 = __this->get_hitClear_17();
		if (!L_25)
		{
			goto IL_046f;
		}
	}
	{
		// if (t <= 5 && hitClear) savechallenge(i);
		int32_t L_26 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_26, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_0174:
	{
		// if (!hitWall && hitClear) savechallenge(i);
		bool L_27 = __this->get_hitWall_19();
		if (L_27)
		{
			goto IL_046f;
		}
	}
	{
		bool L_28 = __this->get_hitClear_17();
		if (!L_28)
		{
			goto IL_046f;
		}
	}
	{
		// if (!hitWall && hitClear) savechallenge(i);
		int32_t L_29 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_29, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_0192:
	{
		// if (clickCount == 3 && hitClear) savechallenge(i);
		int32_t L_30 = __this->get_clickCount_21();
		if ((!(((uint32_t)L_30) == ((uint32_t)3))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_31 = __this->get_hitClear_17();
		if (!L_31)
		{
			goto IL_046f;
		}
	}
	{
		// if (clickCount == 3 && hitClear) savechallenge(i);
		int32_t L_32 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_32, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_01b1:
	{
		// if (pos.x <= -3 && pos.z >= 6 && pos.z <= 10) challengeFlag1 = true;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_33 = __this->get_address_of_pos_23();
		float L_34 = L_33->get_x_2();
		if ((!(((float)L_34) <= ((float)(-3.0f)))))
		{
			goto IL_01ee;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_35 = __this->get_address_of_pos_23();
		float L_36 = L_35->get_z_4();
		if ((!(((float)L_36) >= ((float)(6.0f)))))
		{
			goto IL_01ee;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_37 = __this->get_address_of_pos_23();
		float L_38 = L_37->get_z_4();
		if ((!(((float)L_38) <= ((float)(10.0f)))))
		{
			goto IL_01ee;
		}
	}
	{
		// if (pos.x <= -3 && pos.z >= 6 && pos.z <= 10) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_01ee:
	{
		// if (challengeFlag1 && hitFail) savechallenge(i);
		bool L_39 = __this->get_challengeFlag1_20();
		if (!L_39)
		{
			goto IL_046f;
		}
	}
	{
		bool L_40 = __this->get_hitFail_18();
		if (!L_40)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitFail) savechallenge(i);
		int32_t L_41 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_41, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_020c:
	{
		// if (t <= 30 && hitClear) savechallenge(i);
		float L_42 = __this->get_t_22();
		if ((!(((float)L_42) <= ((float)(30.0f)))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_43 = __this->get_hitClear_17();
		if (!L_43)
		{
			goto IL_046f;
		}
	}
	{
		// if (t <= 30 && hitClear) savechallenge(i);
		int32_t L_44 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_44, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_022f:
	{
		// if (pos.x >= -7 && pos.x <= -6 && Mathf.Abs(pos.z) <= 0.5f) challengeFlag1 = true;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_45 = __this->get_address_of_pos_23();
		float L_46 = L_45->get_x_2();
		if ((!(((float)L_46) >= ((float)(-7.0f)))))
		{
			goto IL_0271;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_47 = __this->get_address_of_pos_23();
		float L_48 = L_47->get_x_2();
		if ((!(((float)L_48) <= ((float)(-6.0f)))))
		{
			goto IL_0271;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_49 = __this->get_address_of_pos_23();
		float L_50 = L_49->get_z_4();
		float L_51;
		L_51 = fabsf(L_50);
		if ((!(((float)L_51) <= ((float)(0.5f)))))
		{
			goto IL_0271;
		}
	}
	{
		// if (pos.x >= -7 && pos.x <= -6 && Mathf.Abs(pos.z) <= 0.5f) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_0271:
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		bool L_52 = __this->get_challengeFlag1_20();
		if (!L_52)
		{
			goto IL_046f;
		}
	}
	{
		bool L_53 = __this->get_hitClear_17();
		if (!L_53)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		int32_t L_54 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_54, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_028f:
	{
		// if (clickCount == 2 && hitClear) savechallenge(i);
		int32_t L_55 = __this->get_clickCount_21();
		if ((!(((uint32_t)L_55) == ((uint32_t)2))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_56 = __this->get_hitClear_17();
		if (!L_56)
		{
			goto IL_046f;
		}
	}
	{
		// if (clickCount == 2 && hitClear) savechallenge(i);
		int32_t L_57 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_57, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_02ae:
	{
		// if (pos.x <= -6 && pos.z >= 6) challengeFlag1 = true;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_58 = __this->get_address_of_pos_23();
		float L_59 = L_58->get_x_2();
		if ((!(((float)L_59) <= ((float)(-6.0f)))))
		{
			goto IL_02d9;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_60 = __this->get_address_of_pos_23();
		float L_61 = L_60->get_z_4();
		if ((!(((float)L_61) >= ((float)(6.0f)))))
		{
			goto IL_02d9;
		}
	}
	{
		// if (pos.x <= -6 && pos.z >= 6) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_02d9:
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		bool L_62 = __this->get_challengeFlag1_20();
		if (!L_62)
		{
			goto IL_046f;
		}
	}
	{
		bool L_63 = __this->get_hitClear_17();
		if (!L_63)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		int32_t L_64 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_64, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_02f7:
	{
		// if (pos.x <= -4) challengeFlag1 = true;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_65 = __this->get_address_of_pos_23();
		float L_66 = L_65->get_x_2();
		if ((!(((float)L_66) <= ((float)(-4.0f)))))
		{
			goto IL_0310;
		}
	}
	{
		// if (pos.x <= -4) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_0310:
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		bool L_67 = __this->get_challengeFlag1_20();
		if (!L_67)
		{
			goto IL_046f;
		}
	}
	{
		bool L_68 = __this->get_hitClear_17();
		if (!L_68)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		int32_t L_69 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_69, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_032e:
	{
		// if (Mathf.RoundToInt(pos.x) == 9 && Mathf.RoundToInt(pos.z) == -9 && rb.velocity == Vector3.zero) challengeFlag1 = true;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_70 = __this->get_address_of_pos_23();
		float L_71 = L_70->get_x_2();
		int32_t L_72;
		L_72 = Mathf_RoundToInt_m56850BDF60FF9E3441CE57E5EFEFEF36EDCDE6DD(L_71, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_72) == ((uint32_t)((int32_t)9)))))
		{
			goto IL_0374;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_73 = __this->get_address_of_pos_23();
		float L_74 = L_73->get_z_4();
		int32_t L_75;
		L_75 = Mathf_RoundToInt_m56850BDF60FF9E3441CE57E5EFEFEF36EDCDE6DD(L_74, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_75) == ((uint32_t)((int32_t)-9)))))
		{
			goto IL_0374;
		}
	}
	{
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_76 = __this->get_rb_8();
		NullCheck(L_76);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_77;
		L_77 = Rigidbody_get_velocity_mCFB033F3BD14C2BA68E797DFA4950F9307EC8E2C(L_76, /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_78;
		L_78 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		bool L_79;
		L_79 = Vector3_op_Equality_m8A98C7F38641110A2F90445EF8E98ECE14B08296(L_77, L_78, /*hidden argument*/NULL);
		if (!L_79)
		{
			goto IL_0374;
		}
	}
	{
		// if (Mathf.RoundToInt(pos.x) == 9 && Mathf.RoundToInt(pos.z) == -9 && rb.velocity == Vector3.zero) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_0374:
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		bool L_80 = __this->get_challengeFlag1_20();
		if (!L_80)
		{
			goto IL_046f;
		}
	}
	{
		bool L_81 = __this->get_hitClear_17();
		if (!L_81)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		int32_t L_82 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_82, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_0392:
	{
		// if (clickCount == 1 && hitClear) savechallenge(i);
		int32_t L_83 = __this->get_clickCount_21();
		if ((!(((uint32_t)L_83) == ((uint32_t)1))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_84 = __this->get_hitClear_17();
		if (!L_84)
		{
			goto IL_046f;
		}
	}
	{
		// if (clickCount == 1 && hitClear) savechallenge(i);
		int32_t L_85 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_85, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_03b1:
	{
		// if (t <= 16 && hitClear) savechallenge(i);
		float L_86 = __this->get_t_22();
		if ((!(((float)L_86) <= ((float)(16.0f)))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_87 = __this->get_hitClear_17();
		if (!L_87)
		{
			goto IL_046f;
		}
	}
	{
		// if (t <= 16 && hitClear) savechallenge(i);
		int32_t L_88 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_88, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_03d4:
	{
		// if (pos.x >= 0 && pos.z >= 0 && hitFail) savechallenge(i);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_89 = __this->get_address_of_pos_23();
		float L_90 = L_89->get_x_2();
		if ((!(((float)L_90) >= ((float)(0.0f)))))
		{
			goto IL_046f;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_91 = __this->get_address_of_pos_23();
		float L_92 = L_91->get_z_4();
		if ((!(((float)L_92) >= ((float)(0.0f)))))
		{
			goto IL_046f;
		}
	}
	{
		bool L_93 = __this->get_hitFail_18();
		if (!L_93)
		{
			goto IL_046f;
		}
	}
	{
		// if (pos.x >= 0 && pos.z >= 0 && hitFail) savechallenge(i);
		int32_t L_94 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_94, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_040b:
	{
		// if (Mathf.Abs(pos.x) <= 1 && pos.z <= -2 && pos.z >= -6) challengeFlag1 = true;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_95 = __this->get_address_of_pos_23();
		float L_96 = L_95->get_x_2();
		float L_97;
		L_97 = fabsf(L_96);
		if ((!(((float)L_97) <= ((float)(1.0f)))))
		{
			goto IL_044d;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_98 = __this->get_address_of_pos_23();
		float L_99 = L_98->get_z_4();
		if ((!(((float)L_99) <= ((float)(-2.0f)))))
		{
			goto IL_044d;
		}
	}
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * L_100 = __this->get_address_of_pos_23();
		float L_101 = L_100->get_z_4();
		if ((!(((float)L_101) >= ((float)(-6.0f)))))
		{
			goto IL_044d;
		}
	}
	{
		// if (Mathf.Abs(pos.x) <= 1 && pos.z <= -2 && pos.z >= -6) challengeFlag1 = true;
		__this->set_challengeFlag1_20((bool)1);
	}

IL_044d:
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		bool L_102 = __this->get_challengeFlag1_20();
		if (!L_102)
		{
			goto IL_046f;
		}
	}
	{
		bool L_103 = __this->get_hitClear_17();
		if (!L_103)
		{
			goto IL_046f;
		}
	}
	{
		// if (challengeFlag1 && hitClear) savechallenge(i);
		int32_t L_104 = ___i0;
		PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC(__this, L_104, /*hidden argument*/NULL);
		// break;
		return;
	}

IL_0465:
	{
		// Debug.Log("Challenge Error!");
		IL2CPP_RUNTIME_CLASS_INIT(Debug_tEB68BCBEB8EFD60F8043C67146DC05E7F50F374B_il2cpp_TypeInfo_var);
		Debug_Log_mC26E5AD0D8D156C7FFD173AA15827F69225E9DB8(_stringLiteral32FD1C2CD95565F20E77CF2BAF251A2BBE2177E4, /*hidden argument*/NULL);
	}

IL_046f:
	{
		// }
		return;
	}
}
// System.Void PlayerManager::savechallenge(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_savechallenge_m49F8EEDE9BD32B27C4D30C3766F14F7C588BD5CC (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, int32_t ___i0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringBuilder_t_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE91FE173F59B063D620A934CE1A010F2B114C1F3);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		// StreamReader sr = new StreamReader("Save/data.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_0 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_0, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		// string saveData = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_1 = L_0;
		NullCheck(L_1);
		String_t* L_2;
		L_2 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_1);
		V_0 = L_2;
		// sr.Close();
		NullCheck(L_1);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_1);
		// int idx = 0;
		V_1 = 0;
		// int subidx = 0;
		V_2 = 0;
		// for (int j = 0; j < 4 + i; j++)
		V_3 = 0;
		goto IL_0040;
	}

IL_001e:
	{
		// idx = saveData.IndexOf(":", idx + 1);
		String_t* L_3 = V_0;
		int32_t L_4 = V_1;
		NullCheck(L_3);
		int32_t L_5;
		L_5 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_3, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)1)), /*hidden argument*/NULL);
		V_1 = L_5;
		// subidx = saveData.IndexOf(";", subidx + 1);
		String_t* L_6 = V_0;
		int32_t L_7 = V_2;
		NullCheck(L_6);
		int32_t L_8;
		L_8 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_6, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, ((int32_t)il2cpp_codegen_add((int32_t)L_7, (int32_t)1)), /*hidden argument*/NULL);
		V_2 = L_8;
		// for (int j = 0; j < 4 + i; j++)
		int32_t L_9 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_9, (int32_t)1));
	}

IL_0040:
	{
		// for (int j = 0; j < 4 + i; j++)
		int32_t L_10 = V_3;
		int32_t L_11 = ___i0;
		if ((((int32_t)L_10) < ((int32_t)((int32_t)il2cpp_codegen_add((int32_t)4, (int32_t)L_11)))))
		{
			goto IL_001e;
		}
	}
	{
		// idx++; //コロンが含まれてしまうため
		int32_t L_12 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_12, (int32_t)1));
		// StringBuilder sb = new StringBuilder(saveData);
		String_t* L_13 = V_0;
		StringBuilder_t * L_14 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77(L_14, L_13, /*hidden argument*/NULL);
		// sb.Remove(idx, subidx - idx);
		StringBuilder_t * L_15 = L_14;
		int32_t L_16 = V_1;
		int32_t L_17 = V_2;
		int32_t L_18 = V_1;
		NullCheck(L_15);
		StringBuilder_t * L_19;
		L_19 = StringBuilder_Remove_m6ABF9CF3D10160EB52E0768262A9B179F987571E(L_15, L_16, ((int32_t)il2cpp_codegen_subtract((int32_t)L_17, (int32_t)L_18)), /*hidden argument*/NULL);
		// sb.Insert(idx, "1");
		StringBuilder_t * L_20 = L_15;
		int32_t L_21 = V_1;
		NullCheck(L_20);
		StringBuilder_t * L_22;
		L_22 = StringBuilder_Insert_m2B101CF8B6D47CFC7602CBABC101569E513D234F(L_20, L_21, _stringLiteralE91FE173F59B063D620A934CE1A010F2B114C1F3, /*hidden argument*/NULL);
		// saveData = sb.ToString();
		NullCheck(L_20);
		String_t* L_23;
		L_23 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_20);
		V_0 = L_23;
		// StreamWriter sw = new StreamWriter("Save/data.txt", false, Encoding.UTF8);
		Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * L_24;
		L_24 = Encoding_get_UTF8_mC877FB3137BBD566AEE7B15F9BF61DC4EF8F5E5E(/*hidden argument*/NULL);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_25 = (StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 *)il2cpp_codegen_object_new(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		StreamWriter__ctor_m8E689BB489D6CA87348E79EBF05BA4E3F6D4B9A4(L_25, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, (bool)0, L_24, /*hidden argument*/NULL);
		// sw.Write(saveData);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_26 = L_25;
		String_t* L_27 = V_0;
		NullCheck(L_26);
		VirtActionInvoker1< String_t* >::Invoke(14 /* System.Void System.IO.TextWriter::Write(System.String) */, L_26, L_27);
		// sw.Close();
		NullCheck(L_26);
		VirtActionInvoker0::Invoke(8 /* System.Void System.IO.TextWriter::Close() */, L_26);
		// }
		return;
	}
}
// System.Void PlayerManager::resetChallengeFlags()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager_resetChallengeFlags_m4CA13CBC872BF5439D424C23371D097C883D2986 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, const RuntimeMethod* method)
{
	{
		// hitClear = false;
		__this->set_hitClear_17((bool)0);
		// hitFail = false;
		__this->set_hitFail_18((bool)0);
		// hitWall = false;
		__this->set_hitWall_19((bool)0);
		// challengeFlag1 = false;
		__this->set_challengeFlag1_20((bool)0);
		// clickCount = 0;
		__this->set_clickCount_21(0);
		// t = 0;
		__this->set_t_22((0.0f));
		// }
		return;
	}
}
// System.Void PlayerManager::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerManager__ctor_m4C7CA12A8243D6CA73C1EA65B361E7B717070471 (PlayerManager_tA626E96D79E0168DAC909A130EC9A26A533AAD48 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Sinus::Update()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Sinus_Update_m300775C3067A37B6178D41E1CBC37AC943A6596C (Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * __this, const RuntimeMethod* method)
{
	{
		// randomFreq = Mathf.PerlinNoise(0, Time.timeSinceLevelLoad) * freqRandRange;
		float L_0;
		L_0 = Time_get_timeSinceLevelLoad_m47A90DE6CB3A3180D64F0049290BC72C186FC7FB(/*hidden argument*/NULL);
		float L_1;
		L_1 = Mathf_PerlinNoise_mBCF172821FEB8FAD7E7CF7F7982018846E702519((0.0f), L_0, /*hidden argument*/NULL);
		float L_2 = __this->get_freqRandRange_6();
		__this->set_randomFreq_7(((float)il2cpp_codegen_multiply((float)L_1, (float)L_2)));
		// }
		return;
	}
}
// System.Void Sinus::OnAudioFilterRead(System.Single[],System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Sinus_OnAudioFilterRead_mE68358DF4BDC9EDD2579CC6F47CE390CC83561C3 (Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * __this, SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* ___data0, int32_t ___channels1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		// increment = frequency * 2 * Mathf.PI / sampleFreq;
		float L_0 = __this->get_frequency_4();
		float L_1 = __this->get_sampleFreq_11();
		__this->set_increment_9(((float)((float)((float)il2cpp_codegen_multiply((float)((float)il2cpp_codegen_multiply((float)L_0, (float)(2.0f))), (float)(3.14159274f)))/(float)L_1)));
		// float max = 0; //最大振幅
		V_0 = (0.0f);
		// for (int i = 0; i < data.Length; i += channels)
		V_1 = 0;
		goto IL_00bd;
	}

IL_002c:
	{
		// phase += increment;
		float L_2 = __this->get_phase_10();
		float L_3 = __this->get_increment_9();
		__this->set_phase_10(((float)il2cpp_codegen_add((float)L_2, (float)L_3)));
		// data[i] = 0;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_4 = ___data0;
		int32_t L_5 = V_1;
		NullCheck(L_4);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(L_5), (float)(0.0f));
		// for (int j = 1; j <= overtonesRange; j++)
		V_2 = 1;
		goto IL_007c;
	}

IL_004b:
	{
		// data[i] += (float)(gain * Math.Sin(phase * j + randomFreq)) / (float)j; //振幅が周波数に反比例する倍音を足す //音割れ防止処理が必要
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_6 = ___data0;
		int32_t L_7 = V_1;
		NullCheck(L_6);
		float* L_8 = ((L_6)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_7)));
		float L_9 = *((float*)L_8);
		float L_10 = __this->get_gain_8();
		float L_11 = __this->get_phase_10();
		int32_t L_12 = V_2;
		float L_13 = __this->get_randomFreq_7();
		IL2CPP_RUNTIME_CLASS_INIT(Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		double L_14;
		L_14 = sin(((double)((double)((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)L_11, (float)((float)((float)L_12)))), (float)L_13)))));
		int32_t L_15 = V_2;
		*((float*)L_8) = (float)((float)il2cpp_codegen_add((float)L_9, (float)((float)((float)((float)((float)((double)il2cpp_codegen_multiply((double)((double)((double)L_10)), (double)L_14))))/(float)((float)((float)L_15))))));
		// for (int j = 1; j <= overtonesRange; j++)
		int32_t L_16 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_16, (int32_t)1));
	}

IL_007c:
	{
		// for (int j = 1; j <= overtonesRange; j++)
		int32_t L_17 = V_2;
		float L_18 = __this->get_overtonesRange_5();
		if ((((float)((float)((float)L_17))) <= ((float)L_18)))
		{
			goto IL_004b;
		}
	}
	{
		// if (max < data[i]) max = data[i];
		float L_19 = V_0;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_20 = ___data0;
		int32_t L_21 = V_1;
		NullCheck(L_20);
		int32_t L_22 = L_21;
		float L_23 = (L_20)->GetAt(static_cast<il2cpp_array_size_t>(L_22));
		if ((!(((float)L_19) < ((float)L_23))))
		{
			goto IL_0090;
		}
	}
	{
		// if (max < data[i]) max = data[i];
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_24 = ___data0;
		int32_t L_25 = V_1;
		NullCheck(L_24);
		int32_t L_26 = L_25;
		float L_27 = (L_24)->GetAt(static_cast<il2cpp_array_size_t>(L_26));
		V_0 = L_27;
	}

IL_0090:
	{
		// if (channels == 2)
		int32_t L_28 = ___channels1;
		if ((!(((uint32_t)L_28) == ((uint32_t)2))))
		{
			goto IL_009c;
		}
	}
	{
		// data[i + 1] = data[i];
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_29 = ___data0;
		int32_t L_30 = V_1;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_31 = ___data0;
		int32_t L_32 = V_1;
		NullCheck(L_31);
		int32_t L_33 = L_32;
		float L_34 = (L_31)->GetAt(static_cast<il2cpp_array_size_t>(L_33));
		NullCheck(L_29);
		(L_29)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add((int32_t)L_30, (int32_t)1))), (float)L_34);
	}

IL_009c:
	{
		// if (phase > 2 * Math.PI)
		float L_35 = __this->get_phase_10();
		if ((!(((double)((double)((double)L_35))) > ((double)(6.2831853071795862)))))
		{
			goto IL_00b9;
		}
	}
	{
		// phase = 0;
		__this->set_phase_10((0.0f));
	}

IL_00b9:
	{
		// for (int i = 0; i < data.Length; i += channels)
		int32_t L_36 = V_1;
		int32_t L_37 = ___channels1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_36, (int32_t)L_37));
	}

IL_00bd:
	{
		// for (int i = 0; i < data.Length; i += channels)
		int32_t L_38 = V_1;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_39 = ___data0;
		NullCheck(L_39);
		if ((((int32_t)L_38) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_39)->max_length))))))
		{
			goto IL_002c;
		}
	}
	{
		// if (max > 1) for (int i = 0; i < data.Length; i++) data[i] /= max;
		float L_40 = V_0;
		if ((!(((float)L_40) > ((float)(1.0f)))))
		{
			goto IL_00e8;
		}
	}
	{
		// if (max > 1) for (int i = 0; i < data.Length; i++) data[i] /= max;
		V_3 = 0;
		goto IL_00e2;
	}

IL_00d2:
	{
		// if (max > 1) for (int i = 0; i < data.Length; i++) data[i] /= max;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_41 = ___data0;
		int32_t L_42 = V_3;
		NullCheck(L_41);
		float* L_43 = ((L_41)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_42)));
		float L_44 = *((float*)L_43);
		float L_45 = V_0;
		*((float*)L_43) = (float)((float)((float)L_44/(float)L_45));
		// if (max > 1) for (int i = 0; i < data.Length; i++) data[i] /= max;
		int32_t L_46 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_46, (int32_t)1));
	}

IL_00e2:
	{
		// if (max > 1) for (int i = 0; i < data.Length; i++) data[i] /= max;
		int32_t L_47 = V_3;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_48 = ___data0;
		NullCheck(L_48);
		if ((((int32_t)L_47) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_48)->max_length))))))
		{
			goto IL_00d2;
		}
	}

IL_00e8:
	{
		// }
		return;
	}
}
// System.Void Sinus::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Sinus__ctor_m1BC3745EA32E5938E775EC28811534DC44D6B752 (Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * __this, const RuntimeMethod* method)
{
	{
		// public float frequency = 440, overtonesRange = 1;
		__this->set_frequency_4((440.0f));
		// public float frequency = 440, overtonesRange = 1;
		__this->set_overtonesRange_5((1.0f));
		// [Range(0, 1)] public float gain = 0.2f;
		__this->set_gain_8((0.200000003f));
		// float sampleFreq = 44100;
		__this->set_sampleFreq_11((44100.0f));
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void SoundPlaySystem::SetSoundData(UnityEngine.AudioClip)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundPlaySystem_SetSoundData_mC95E81C797E4E7D7210309AE5D3B8687EAB0BB9A (SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * __this, AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * ___audioClip0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// soundEffect = audioClip;
		AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * L_0 = ___audioClip0;
		__this->set_soundEffect_4(L_0);
		// sampleLength = soundEffect.samples * soundEffect.channels;
		AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * L_1 = __this->get_soundEffect_4();
		NullCheck(L_1);
		int32_t L_2;
		L_2 = AudioClip_get_samples_m741BFBA562FBFDBE67AFE98A38B1B4A871D2D567(L_1, /*hidden argument*/NULL);
		AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * L_3 = __this->get_soundEffect_4();
		NullCheck(L_3);
		int32_t L_4;
		L_4 = AudioClip_get_channels_m7592B378317BFA41DF2228636124E4DD5B86D3B8(L_3, /*hidden argument*/NULL);
		__this->set_sampleLength_8(((int32_t)il2cpp_codegen_multiply((int32_t)L_2, (int32_t)L_4)));
		// soundData = new float[sampleLength];
		int32_t L_5 = __this->get_sampleLength_8();
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_6 = (SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA*)(SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA*)SZArrayNew(SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA_il2cpp_TypeInfo_var, (uint32_t)L_5);
		__this->set_soundData_6(L_6);
		// soundEffect.GetData(soundData, 0);
		AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * L_7 = __this->get_soundEffect_4();
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_8 = __this->get_soundData_6();
		NullCheck(L_7);
		bool L_9;
		L_9 = AudioClip_GetData_m2D7410645789EBED93CAA8146D271C79156E2CB0(L_7, L_8, 0, /*hidden argument*/NULL);
		// isReady = true;
		__this->set_isReady_5((bool)1);
		// }
		return;
	}
}
// System.Void SoundPlaySystem::OnAudioFilterRead(System.Single[],System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundPlaySystem_OnAudioFilterRead_m061FC034774FEA48CA4A5DAC3308E1F48AA240F4 (SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * __this, SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* ___data0, int32_t ___channels1, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		// if (!isReady) return;
		bool L_0 = __this->get_isReady_5();
		if (L_0)
		{
			goto IL_0009;
		}
	}
	{
		// if (!isReady) return;
		return;
	}

IL_0009:
	{
		// for (int i = 0; i < data.Length; i += channels)
		V_0 = 0;
		goto IL_006c;
	}

IL_000d:
	{
		// if (count >= sampleLength)
		int32_t L_1 = __this->get_count_7();
		int32_t L_2 = __this->get_sampleLength_8();
		if ((((int32_t)L_1) < ((int32_t)L_2)))
		{
			goto IL_0029;
		}
	}
	{
		// isReady = false;
		__this->set_isReady_5((bool)0);
		// count = 0;
		__this->set_count_7(0);
	}

IL_0029:
	{
		// if (count < sampleLength) data[i] = gain * soundData[count];
		int32_t L_3 = __this->get_count_7();
		int32_t L_4 = __this->get_sampleLength_8();
		if ((((int32_t)L_3) >= ((int32_t)L_4)))
		{
			goto IL_004e;
		}
	}
	{
		// if (count < sampleLength) data[i] = gain * soundData[count];
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_5 = ___data0;
		int32_t L_6 = V_0;
		float L_7 = __this->get_gain_9();
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_8 = __this->get_soundData_6();
		int32_t L_9 = __this->get_count_7();
		NullCheck(L_8);
		int32_t L_10 = L_9;
		float L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		NullCheck(L_5);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(L_6), (float)((float)il2cpp_codegen_multiply((float)L_7, (float)L_11)));
	}

IL_004e:
	{
		// if (channels == 2) data[i + 1] = data[i];
		int32_t L_12 = ___channels1;
		if ((!(((uint32_t)L_12) == ((uint32_t)2))))
		{
			goto IL_005a;
		}
	}
	{
		// if (channels == 2) data[i + 1] = data[i];
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_13 = ___data0;
		int32_t L_14 = V_0;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_15 = ___data0;
		int32_t L_16 = V_0;
		NullCheck(L_15);
		int32_t L_17 = L_16;
		float L_18 = (L_15)->GetAt(static_cast<il2cpp_array_size_t>(L_17));
		NullCheck(L_13);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add((int32_t)L_14, (int32_t)1))), (float)L_18);
	}

IL_005a:
	{
		// count++;
		int32_t L_19 = __this->get_count_7();
		__this->set_count_7(((int32_t)il2cpp_codegen_add((int32_t)L_19, (int32_t)1)));
		// for (int i = 0; i < data.Length; i += channels)
		int32_t L_20 = V_0;
		int32_t L_21 = ___channels1;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_20, (int32_t)L_21));
	}

IL_006c:
	{
		// for (int i = 0; i < data.Length; i += channels)
		int32_t L_22 = V_0;
		SingleU5BU5D_t47E8DBF5B597C122478D1FFBD9DD57399A0650FA* L_23 = ___data0;
		NullCheck(L_23);
		if ((((int32_t)L_22) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_23)->max_length))))))
		{
			goto IL_000d;
		}
	}
	{
		// }
		return;
	}
}
// System.Void SoundPlaySystem::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundPlaySystem__ctor_m6D117931BD6F4A62D1218EBC1E6B103FE6B269FA (SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * __this, const RuntimeMethod* method)
{
	{
		// [Range(0, 1)] public float gain = 0.5f;
		__this->set_gain_9((0.5f));
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void SoundSettingManager::Start()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundSettingManager_Start_mF0B4919F9BC3631E3D1D19AEE8627041A9C27592 (SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	{
		// StreamReader sr = new StreamReader("Save/soundsetting.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_0 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_0, _stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0, /*hidden argument*/NULL);
		// string data = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_1 = L_0;
		NullCheck(L_1);
		String_t* L_2;
		L_2 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_1);
		V_0 = L_2;
		// sr.Close();
		NullCheck(L_1);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_1);
		// int idx = data.IndexOf(":");
		String_t* L_3 = V_0;
		NullCheck(L_3);
		int32_t L_4;
		L_4 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_3, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, /*hidden argument*/NULL);
		V_1 = L_4;
		// soundEffectSlider.value = float.Parse(data.Substring(0, idx));
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_5 = __this->get_soundEffectSlider_4();
		String_t* L_6 = V_0;
		int32_t L_7 = V_1;
		NullCheck(L_6);
		String_t* L_8;
		L_8 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_6, 0, L_7, /*hidden argument*/NULL);
		float L_9;
		L_9 = Single_Parse_mA1B20E6E0AAD67F60707D81E82667D2D4B274D6F(L_8, /*hidden argument*/NULL);
		NullCheck(L_5);
		VirtActionInvoker1< float >::Invoke(47 /* System.Void UnityEngine.UI.Slider::set_value(System.Single) */, L_5, L_9);
		// backgroundSoundSlider.value = float.Parse(data.Substring(idx + 1, data.Length - idx - 1));
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_10 = __this->get_backgroundSoundSlider_5();
		String_t* L_11 = V_0;
		int32_t L_12 = V_1;
		String_t* L_13 = V_0;
		NullCheck(L_13);
		int32_t L_14;
		L_14 = String_get_Length_m129FC0ADA02FECBED3C0B1A809AE84A5AEE1CF09_inline(L_13, /*hidden argument*/NULL);
		int32_t L_15 = V_1;
		NullCheck(L_11);
		String_t* L_16;
		L_16 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_11, ((int32_t)il2cpp_codegen_add((int32_t)L_12, (int32_t)1)), ((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_14, (int32_t)L_15)), (int32_t)1)), /*hidden argument*/NULL);
		float L_17;
		L_17 = Single_Parse_mA1B20E6E0AAD67F60707D81E82667D2D4B274D6F(L_16, /*hidden argument*/NULL);
		NullCheck(L_10);
		VirtActionInvoker1< float >::Invoke(47 /* System.Void UnityEngine.UI.Slider::set_value(System.Single) */, L_10, L_17);
		// GameObject.Find("Main Camera").GetComponent<SoundPlaySystem>().gain = soundEffectSlider.value;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_18;
		L_18 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_18);
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_19;
		L_19 = GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F(L_18, /*hidden argument*/GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_20 = __this->get_soundEffectSlider_4();
		NullCheck(L_20);
		float L_21;
		L_21 = VirtFuncInvoker0< float >::Invoke(46 /* System.Single UnityEngine.UI.Slider::get_value() */, L_20);
		NullCheck(L_19);
		L_19->set_gain_9(L_21);
		// GameObject.Find("Main Camera").GetComponent<Sinus>().gain = backgroundSoundSlider.value;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_22;
		L_22 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_22);
		Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * L_23;
		L_23 = GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C(L_22, /*hidden argument*/GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C_RuntimeMethod_var);
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_24 = __this->get_backgroundSoundSlider_5();
		NullCheck(L_24);
		float L_25;
		L_25 = VirtFuncInvoker0< float >::Invoke(46 /* System.Single UnityEngine.UI.Slider::get_value() */, L_24);
		NullCheck(L_23);
		L_23->set_gain_8(L_25);
		// }
		return;
	}
}
// System.Void SoundSettingManager::SwitchSetting()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundSettingManager_SwitchSetting_mFAE5529A141B1DB639333B99B6E70D8FE0AF9A68 (SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12 * __this, const RuntimeMethod* method)
{
	{
		// SoundSettingGroup.SetActive(!SoundSettingGroup.activeSelf);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = __this->get_SoundSettingGroup_6();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1 = __this->get_SoundSettingGroup_6();
		NullCheck(L_1);
		bool L_2;
		L_2 = GameObject_get_activeSelf_m4865097C24FB29F3C31F5C30619AF242297F23EE(L_1, /*hidden argument*/NULL);
		NullCheck(L_0);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_0, (bool)((((int32_t)L_2) == ((int32_t)0))? 1 : 0), /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void SoundSettingManager::ChangeSoundVolume()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundSettingManager_ChangeSoundVolume_mFC169E6974C7D9D7084966E72D51C50C772E209A (SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	{
		// GameObject.Find("Main Camera").GetComponent<SoundPlaySystem>().gain = soundEffectSlider.value;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0;
		L_0 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_0);
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_1;
		L_1 = GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F(L_0, /*hidden argument*/GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_2 = __this->get_soundEffectSlider_4();
		NullCheck(L_2);
		float L_3;
		L_3 = VirtFuncInvoker0< float >::Invoke(46 /* System.Single UnityEngine.UI.Slider::get_value() */, L_2);
		NullCheck(L_1);
		L_1->set_gain_9(L_3);
		// GameObject.Find("Main Camera").GetComponent<Sinus>().gain = backgroundSoundSlider.value;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_4;
		L_4 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_4);
		Sinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5 * L_5;
		L_5 = GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C(L_4, /*hidden argument*/GameObject_GetComponent_TisSinus_tD747327E50B0D34D609A4FB78E0440105C0D49A5_mED71D856ED1935764EBBFF6655CB78CDBC1ABF7C_RuntimeMethod_var);
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_6 = __this->get_backgroundSoundSlider_5();
		NullCheck(L_6);
		float L_7;
		L_7 = VirtFuncInvoker0< float >::Invoke(46 /* System.Single UnityEngine.UI.Slider::get_value() */, L_6);
		NullCheck(L_5);
		L_5->set_gain_8(L_7);
		// StreamWriter sw = new StreamWriter("Save/soundsetting.txt", false, Encoding.UTF8);
		Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * L_8;
		L_8 = Encoding_get_UTF8_mC877FB3137BBD566AEE7B15F9BF61DC4EF8F5E5E(/*hidden argument*/NULL);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_9 = (StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 *)il2cpp_codegen_object_new(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		StreamWriter__ctor_m8E689BB489D6CA87348E79EBF05BA4E3F6D4B9A4(L_9, _stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0, (bool)0, L_8, /*hidden argument*/NULL);
		// sw.Write(soundEffectSlider.value + ":" + backgroundSoundSlider.value);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_10 = L_9;
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_11 = __this->get_soundEffectSlider_4();
		NullCheck(L_11);
		float L_12;
		L_12 = VirtFuncInvoker0< float >::Invoke(46 /* System.Single UnityEngine.UI.Slider::get_value() */, L_11);
		V_0 = L_12;
		String_t* L_13;
		L_13 = Single_ToString_m80E7ABED4F4D73F2BE19DDB80D3D92FCD8DFA010((float*)(&V_0), /*hidden argument*/NULL);
		Slider_tBF39A11CC24CBD3F8BD728982ACAEAE43989B51A * L_14 = __this->get_backgroundSoundSlider_5();
		NullCheck(L_14);
		float L_15;
		L_15 = VirtFuncInvoker0< float >::Invoke(46 /* System.Single UnityEngine.UI.Slider::get_value() */, L_14);
		V_0 = L_15;
		String_t* L_16;
		L_16 = Single_ToString_m80E7ABED4F4D73F2BE19DDB80D3D92FCD8DFA010((float*)(&V_0), /*hidden argument*/NULL);
		String_t* L_17;
		L_17 = String_Concat_m89EAB4C6A96B0E5C3F87300D6BE78D386B9EFC44(L_13, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, L_16, /*hidden argument*/NULL);
		NullCheck(L_10);
		VirtActionInvoker1< String_t* >::Invoke(14 /* System.Void System.IO.TextWriter::Write(System.String) */, L_10, L_17);
		// sw.Close();
		NullCheck(L_10);
		VirtActionInvoker0::Invoke(8 /* System.Void System.IO.TextWriter::Close() */, L_10);
		// }
		return;
	}
}
// System.Void SoundSettingManager::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SoundSettingManager__ctor_mDE9BF93657572442CE4ED24BFEE306F8118BE54B (SoundSettingManager_t8084329666507B2B752ABF63D9C0696FDEF6DC12 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void TitleManager::Awake()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_Awake_mF129104373A2C819440233C959692D0AE46284B9 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	{
		// checkData();
		TitleManager_checkData_m02820912FEEAD00B0B83CBFD98B4F0B1114AC945(__this, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void TitleManager::Start()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_Start_mB1BDED26067331336418D8C8F760161E62F96224 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF0ABC826AA3E324A387AE7C6716E2776405AC583_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisButton_tA893FC15AB26E1439AC25BDCA7079530587BB65D_mC89B59084AF54D6861DE55F9F1FC4226E4F616A8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringBuilder_t_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral0375962E83E838E0A86F6EB54ECAD5AD338AF627);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral095F11D31FCE39BCB9C4F377E423D637323A437F);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral097BDACD66FAD850156FED9F725F9CC4873080ED);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral09BC0067B93715551994AF937074AACB2BC46F45);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral18DFC76CE558A95E4B965CF15DB25F8772BAD6BE);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral1AE3DFDF095F1A9D00C82F9DE68A906D657A1BA5);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2B86D66477376A42A49B3CD3983CF53BEF4E55A0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral458F0853AD35AB3C88EE592FD6A04E76A9C9C22A);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral6BA2B8FA5CFC29F65A5DDF3DDB50406BF7EF826A);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7374AAEDBB17A9B4E1F4E7C44C8B168FF56495B3);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7D0383344321A8EB9F670DF59AB1502AE480A331);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral81C6B56546B7CAF0C90DC134E1582EEDDD65C2F2);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral920ABEDD47410DA9C7554955C460817D580178ED);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9CB11ACA5A88BD2B601F12BC6D2090EB273F7DAB);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralA251A204B5A2874A8CD540A624F660C7638CA9F5);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralA461C945895BA5F3EBE497F50FE9845AAA6F3782);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralAC0D425DEDD91FCD849100926AE866C23736FB5A);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralCAF8804297181FF007CA835529DD4477CFD94A70);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralD9AB4BD1D01DB5E2C32CFA950256355AA98BEE29);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE070A0F7AE650838CAC9FB9703A37D7A8775247C);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE146753D0BD9B838630EAF1D9A8B7E8385F405AC);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralEA138C6D14D8FDCE6394BF7F95D836B105671B79);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	{
		// mainGameManager = GetComponent<MainGameManager>();
		MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4 * L_0;
		L_0 = Component_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF0ABC826AA3E324A387AE7C6716E2776405AC583(__this, /*hidden argument*/Component_GetComponent_TisMainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_mF0ABC826AA3E324A387AE7C6716E2776405AC583_RuntimeMethod_var);
		__this->set_mainGameManager_4(L_0);
		// ug = GameObject.Find("Player").GetComponent<UniversalGravity>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1;
		L_1 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralCAF8804297181FF007CA835529DD4477CFD94A70, /*hidden argument*/NULL);
		NullCheck(L_1);
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_2;
		L_2 = GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810(L_1, /*hidden argument*/GameObject_GetComponent_TisUniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9_m10221C7DA4B0DC83C8706852CFB0426E6AE42810_RuntimeMethod_var);
		__this->set_ug_17(L_2);
		// soundPlaySystem = GameObject.Find("Main Camera").GetComponent<SoundPlaySystem>();
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_3;
		L_3 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(_stringLiteralDA7E8B88100AA34B19982A11B0554BAF879AFF81, /*hidden argument*/NULL);
		NullCheck(L_3);
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_4;
		L_4 = GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F(L_3, /*hidden argument*/GameObject_GetComponent_TisSoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E_m94FE8778ABE1A00CF54635EAA61C67254806271F_RuntimeMethod_var);
		__this->set_soundPlaySystem_18(L_4);
		// StreamReader sr = new StreamReader("Save/data.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_5 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_5, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		// string saveData = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_6 = L_5;
		NullCheck(L_6);
		String_t* L_7;
		L_7 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_6);
		V_0 = L_7;
		// sr.Close();
		NullCheck(L_6);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_6);
		// int idx = saveData.IndexOf(":"); //最初のコロンの位置(AutoRetryの後)
		String_t* L_8 = V_0;
		NullCheck(L_8);
		int32_t L_9;
		L_9 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_8, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, /*hidden argument*/NULL);
		V_1 = L_9;
		// idx = saveData.IndexOf(":", idx + 1); //最初のコロンの位置(ReachedStageの後)
		String_t* L_10 = V_0;
		int32_t L_11 = V_1;
		NullCheck(L_10);
		int32_t L_12;
		L_12 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_10, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, ((int32_t)il2cpp_codegen_add((int32_t)L_11, (int32_t)1)), /*hidden argument*/NULL);
		V_1 = L_12;
		// idx++; //コロンが含まれてしまうため
		int32_t L_13 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_13, (int32_t)1));
		// int subidx = saveData.IndexOf(";"); //2番目のセミコロンの位置（AutoRetryの後）
		String_t* L_14 = V_0;
		NullCheck(L_14);
		int32_t L_15;
		L_15 = String_IndexOf_m90616B2D8ACC645F389750FAE4F9A75BC5D82454(L_14, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, /*hidden argument*/NULL);
		V_2 = L_15;
		// subidx = saveData.IndexOf(";", subidx + 1); //2番目のセミコロンの位置（ReachedStageの後）
		String_t* L_16 = V_0;
		int32_t L_17 = V_2;
		NullCheck(L_16);
		int32_t L_18;
		L_18 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_16, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, ((int32_t)il2cpp_codegen_add((int32_t)L_17, (int32_t)1)), /*hidden argument*/NULL);
		V_2 = L_18;
		// StringBuilder sb = new StringBuilder(saveData);
		String_t* L_19 = V_0;
		StringBuilder_t * L_20 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77(L_20, L_19, /*hidden argument*/NULL);
		// int reachedStageNum = Convert.ToInt32(saveData.Substring(idx, subidx - idx));
		String_t* L_21 = V_0;
		int32_t L_22 = V_1;
		int32_t L_23 = V_2;
		int32_t L_24 = V_1;
		NullCheck(L_21);
		String_t* L_25;
		L_25 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_21, L_22, ((int32_t)il2cpp_codegen_subtract((int32_t)L_23, (int32_t)L_24)), /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		int32_t L_26;
		L_26 = Convert_ToInt32_mA1C10AB2A7C95E9DCAC473D1D88C74D60FA240ED(L_25, /*hidden argument*/NULL);
		V_3 = L_26;
		// idx = saveData.IndexOf(":", idx); //3番目のコロンの位置（RTAの後）
		String_t* L_27 = V_0;
		int32_t L_28 = V_1;
		NullCheck(L_27);
		int32_t L_29;
		L_29 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_27, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, L_28, /*hidden argument*/NULL);
		V_1 = L_29;
		// idx++; //コロンが含まれてしまうため
		int32_t L_30 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_30, (int32_t)1));
		// subidx = saveData.IndexOf(";", subidx + 1); //3番目のセミコロンの位置（RTAの後）
		String_t* L_31 = V_0;
		int32_t L_32 = V_2;
		NullCheck(L_31);
		int32_t L_33;
		L_33 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_31, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, ((int32_t)il2cpp_codegen_add((int32_t)L_32, (int32_t)1)), /*hidden argument*/NULL);
		V_2 = L_33;
		// completeRate = reachedStageNum;
		int32_t L_34 = V_3;
		__this->set_completeRate_16(L_34);
		// for (int i = 0; i <= reachedStageNum; i++)
		V_4 = 0;
		goto IL_0101;
	}

IL_00c9:
	{
		// if (i != MainGameManager.MAX_STAGE_NUM + 1) GameObject.Find("Stage_" + (i + 1).ToString()).GetComponent<Button>().interactable = true;
		int32_t L_35 = V_4;
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		int32_t L_36 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_MAX_STAGE_NUM_19();
		if ((((int32_t)L_35) == ((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_36, (int32_t)1)))))
		{
			goto IL_00fb;
		}
	}
	{
		// if (i != MainGameManager.MAX_STAGE_NUM + 1) GameObject.Find("Stage_" + (i + 1).ToString()).GetComponent<Button>().interactable = true;
		int32_t L_37 = V_4;
		V_5 = ((int32_t)il2cpp_codegen_add((int32_t)L_37, (int32_t)1));
		String_t* L_38;
		L_38 = Int32_ToString_m340C0A14D16799421EFDF8A81C8A16FA76D48411((int32_t*)(&V_5), /*hidden argument*/NULL);
		String_t* L_39;
		L_39 = String_Concat_m4B4AB72618348C5DFBFBA8DED84B9E2EBDB55E1B(_stringLiteralEA138C6D14D8FDCE6394BF7F95D836B105671B79, L_38, /*hidden argument*/NULL);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_40;
		L_40 = GameObject_Find_m20157C941F1A9DA0E33E0ACA1324FAA41C2B199B(L_39, /*hidden argument*/NULL);
		NullCheck(L_40);
		Button_tA893FC15AB26E1439AC25BDCA7079530587BB65D * L_41;
		L_41 = GameObject_GetComponent_TisButton_tA893FC15AB26E1439AC25BDCA7079530587BB65D_mC89B59084AF54D6861DE55F9F1FC4226E4F616A8(L_40, /*hidden argument*/GameObject_GetComponent_TisButton_tA893FC15AB26E1439AC25BDCA7079530587BB65D_mC89B59084AF54D6861DE55F9F1FC4226E4F616A8_RuntimeMethod_var);
		NullCheck(L_41);
		Selectable_set_interactable_mE6F57D33A9E0484377174D0F490C4372BF7F0D40(L_41, (bool)1, /*hidden argument*/NULL);
	}

IL_00fb:
	{
		// for (int i = 0; i <= reachedStageNum; i++)
		int32_t L_42 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add((int32_t)L_42, (int32_t)1));
	}

IL_0101:
	{
		// for (int i = 0; i <= reachedStageNum; i++)
		int32_t L_43 = V_4;
		int32_t L_44 = V_3;
		if ((((int32_t)L_43) <= ((int32_t)L_44)))
		{
			goto IL_00c9;
		}
	}
	{
		// rtaBestScoreLabel.text = "スピードラン最速記録:" + saveData.Substring(idx, subidx - idx) + "秒";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_45 = __this->get_rtaBestScoreLabel_11();
		String_t* L_46 = V_0;
		int32_t L_47 = V_1;
		int32_t L_48 = V_2;
		int32_t L_49 = V_1;
		NullCheck(L_46);
		String_t* L_50;
		L_50 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_46, L_47, ((int32_t)il2cpp_codegen_subtract((int32_t)L_48, (int32_t)L_49)), /*hidden argument*/NULL);
		String_t* L_51;
		L_51 = String_Concat_m89EAB4C6A96B0E5C3F87300D6BE78D386B9EFC44(_stringLiteral6BA2B8FA5CFC29F65A5DDF3DDB50406BF7EF826A, L_50, _stringLiteral2B86D66477376A42A49B3CD3983CF53BEF4E55A0, /*hidden argument*/NULL);
		NullCheck(L_45);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_45, L_51);
		// for (int i = 0; i <= MainGameManager.MAX_STAGE_NUM; i++)
		V_6 = 0;
		goto IL_0173;
	}

IL_012f:
	{
		// idx = saveData.IndexOf(":", idx + 1);
		String_t* L_52 = V_0;
		int32_t L_53 = V_1;
		NullCheck(L_52);
		int32_t L_54;
		L_54 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_52, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, ((int32_t)il2cpp_codegen_add((int32_t)L_53, (int32_t)1)), /*hidden argument*/NULL);
		V_1 = L_54;
		// idx++;
		int32_t L_55 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_55, (int32_t)1));
		// subidx = saveData.IndexOf(";", subidx + 1);
		String_t* L_56 = V_0;
		int32_t L_57 = V_2;
		NullCheck(L_56);
		int32_t L_58;
		L_58 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_56, _stringLiteral951CCB49640C8F9E81FB4E0D82730321F4E15BB3, ((int32_t)il2cpp_codegen_add((int32_t)L_57, (int32_t)1)), /*hidden argument*/NULL);
		V_2 = L_58;
		// completeRate += Convert.ToInt32(saveData.Substring(idx, subidx - idx));
		int32_t L_59 = __this->get_completeRate_16();
		String_t* L_60 = V_0;
		int32_t L_61 = V_1;
		int32_t L_62 = V_2;
		int32_t L_63 = V_1;
		NullCheck(L_60);
		String_t* L_64;
		L_64 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_60, L_61, ((int32_t)il2cpp_codegen_subtract((int32_t)L_62, (int32_t)L_63)), /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		int32_t L_65;
		L_65 = Convert_ToInt32_mA1C10AB2A7C95E9DCAC473D1D88C74D60FA240ED(L_64, /*hidden argument*/NULL);
		__this->set_completeRate_16(((int32_t)il2cpp_codegen_add((int32_t)L_59, (int32_t)L_65)));
		// for (int i = 0; i <= MainGameManager.MAX_STAGE_NUM; i++)
		int32_t L_66 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_add((int32_t)L_66, (int32_t)1));
	}

IL_0173:
	{
		// for (int i = 0; i <= MainGameManager.MAX_STAGE_NUM; i++)
		int32_t L_67 = V_6;
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		int32_t L_68 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_MAX_STAGE_NUM_19();
		if ((((int32_t)L_67) <= ((int32_t)L_68)))
		{
			goto IL_012f;
		}
	}
	{
		// completeLabel.text = "達成率:" + completeRate.ToString() + "/40";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_69 = __this->get_completeLabel_13();
		int32_t* L_70 = __this->get_address_of_completeRate_16();
		String_t* L_71;
		L_71 = Int32_ToString_m340C0A14D16799421EFDF8A81C8A16FA76D48411((int32_t*)L_70, /*hidden argument*/NULL);
		String_t* L_72;
		L_72 = String_Concat_m89EAB4C6A96B0E5C3F87300D6BE78D386B9EFC44(_stringLiteralA461C945895BA5F3EBE497F50FE9845AAA6F3782, L_71, _stringLiteral1AE3DFDF095F1A9D00C82F9DE68A906D657A1BA5, /*hidden argument*/NULL);
		NullCheck(L_69);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_69, L_72);
		// dat = new datas();
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_73 = (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 *)il2cpp_codegen_object_new(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		datas__ctor_mE6BBE9C089031DEEA352E2A6D402729C8D064E8D(L_73, /*hidden argument*/NULL);
		__this->set_dat_5(L_73);
		// canvasStatus = false;
		__this->set_canvasStatus_9((bool)0);
		// canvasGroup[0].SetActive(true);
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_74 = __this->get_canvasGroup_6();
		NullCheck(L_74);
		int32_t L_75 = 0;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_76 = (L_74)->GetAt(static_cast<il2cpp_array_size_t>(L_75));
		NullCheck(L_76);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_76, (bool)1, /*hidden argument*/NULL);
		// canvasGroup[1].SetActive(false);
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_77 = __this->get_canvasGroup_6();
		NullCheck(L_77);
		int32_t L_78 = 1;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_79 = (L_77)->GetAt(static_cast<il2cpp_array_size_t>(L_78));
		NullCheck(L_79);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_79, (bool)0, /*hidden argument*/NULL);
		// isCredit = false;
		__this->set_isCredit_10((bool)0);
		// creditGroup.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_80 = __this->get_creditGroup_7();
		NullCheck(L_80);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_80, (bool)0, /*hidden argument*/NULL);
		// MainGameManager.rta = false;
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->set_rta_18((bool)0);
		// challenges[0] = "最大速さ8以上を出して成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_81 = __this->get_challenges_14();
		NullCheck(L_81);
		ArrayElementTypeCheck (L_81, _stringLiteral9CB11ACA5A88BD2B601F12BC6D2090EB273F7DAB);
		(L_81)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral9CB11ACA5A88BD2B601F12BC6D2090EB273F7DAB);
		// challenges[1] = "2回以上の操作で成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_82 = __this->get_challenges_14();
		NullCheck(L_82);
		ArrayElementTypeCheck (L_82, _stringLiteral458F0853AD35AB3C88EE592FD6A04E76A9C9C22A);
		(L_82)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral458F0853AD35AB3C88EE592FD6A04E76A9C9C22A);
		// challenges[2] = "開始1秒以内に1回以上操作して成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_83 = __this->get_challenges_14();
		NullCheck(L_83);
		ArrayElementTypeCheck (L_83, _stringLiteral095F11D31FCE39BCB9C4F377E423D637323A437F);
		(L_83)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral095F11D31FCE39BCB9C4F377E423D637323A437F);
		// challenges[3] = "1回の操作で成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_84 = __this->get_challenges_14();
		NullCheck(L_84);
		ArrayElementTypeCheck (L_84, _stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA);
		(L_84)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)_stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA);
		// challenges[4] = "1回の操作で成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_85 = __this->get_challenges_14();
		NullCheck(L_85);
		ArrayElementTypeCheck (L_85, _stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA);
		(L_85)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA);
		// challenges[5] = "2回の操作で成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_86 = __this->get_challenges_14();
		NullCheck(L_86);
		ArrayElementTypeCheck (L_86, _stringLiteralAC0D425DEDD91FCD849100926AE866C23736FB5A);
		(L_86)->SetAt(static_cast<il2cpp_array_size_t>(5), (String_t*)_stringLiteralAC0D425DEDD91FCD849100926AE866C23736FB5A);
		// challenges[6] = "5秒以内に成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_87 = __this->get_challenges_14();
		NullCheck(L_87);
		ArrayElementTypeCheck (L_87, _stringLiteral0375962E83E838E0A86F6EB54ECAD5AD338AF627);
		(L_87)->SetAt(static_cast<il2cpp_array_size_t>(6), (String_t*)_stringLiteral0375962E83E838E0A86F6EB54ECAD5AD338AF627);
		// challenges[7] = "壁に当たらずに成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_88 = __this->get_challenges_14();
		NullCheck(L_88);
		ArrayElementTypeCheck (L_88, _stringLiteralD9AB4BD1D01DB5E2C32CFA950256355AA98BEE29);
		(L_88)->SetAt(static_cast<il2cpp_array_size_t>(7), (String_t*)_stringLiteralD9AB4BD1D01DB5E2C32CFA950256355AA98BEE29);
		// challenges[8] = "3回の操作で成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_89 = __this->get_challenges_14();
		NullCheck(L_89);
		ArrayElementTypeCheck (L_89, _stringLiteral920ABEDD47410DA9C7554955C460817D580178ED);
		(L_89)->SetAt(static_cast<il2cpp_array_size_t>(8), (String_t*)_stringLiteral920ABEDD47410DA9C7554955C460817D580178ED);
		// challenges[9] = "ゴールまで近づき、失敗する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_90 = __this->get_challenges_14();
		NullCheck(L_90);
		ArrayElementTypeCheck (L_90, _stringLiteral7374AAEDBB17A9B4E1F4E7C44C8B168FF56495B3);
		(L_90)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)9)), (String_t*)_stringLiteral7374AAEDBB17A9B4E1F4E7C44C8B168FF56495B3);
		// challenges[10] = "30秒以内に成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_91 = __this->get_challenges_14();
		NullCheck(L_91);
		ArrayElementTypeCheck (L_91, _stringLiteralE070A0F7AE650838CAC9FB9703A37D7A8775247C);
		(L_91)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)10)), (String_t*)_stringLiteralE070A0F7AE650838CAC9FB9703A37D7A8775247C);
		// challenges[11] = "左側の狭い道を通り、成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_92 = __this->get_challenges_14();
		NullCheck(L_92);
		ArrayElementTypeCheck (L_92, _stringLiteralA251A204B5A2874A8CD540A624F660C7638CA9F5);
		(L_92)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)11)), (String_t*)_stringLiteralA251A204B5A2874A8CD540A624F660C7638CA9F5);
		// challenges[12] = "2回の操作で成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_93 = __this->get_challenges_14();
		NullCheck(L_93);
		ArrayElementTypeCheck (L_93, _stringLiteralAC0D425DEDD91FCD849100926AE866C23736FB5A);
		(L_93)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)12)), (String_t*)_stringLiteralAC0D425DEDD91FCD849100926AE866C23736FB5A);
		// challenges[13] = "左上の球の傍を通り、成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_94 = __this->get_challenges_14();
		NullCheck(L_94);
		ArrayElementTypeCheck (L_94, _stringLiteral7D0383344321A8EB9F670DF59AB1502AE480A331);
		(L_94)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)13)), (String_t*)_stringLiteral7D0383344321A8EB9F670DF59AB1502AE480A331);
		// challenges[14] = "左側に出て、その後成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_95 = __this->get_challenges_14();
		NullCheck(L_95);
		ArrayElementTypeCheck (L_95, _stringLiteralE146753D0BD9B838630EAF1D9A8B7E8385F405AC);
		(L_95)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)14)), (String_t*)_stringLiteralE146753D0BD9B838630EAF1D9A8B7E8385F405AC);
		// challenges[15] = "右下の端で一時停止し、成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_96 = __this->get_challenges_14();
		NullCheck(L_96);
		ArrayElementTypeCheck (L_96, _stringLiteral81C6B56546B7CAF0C90DC134E1582EEDDD65C2F2);
		(L_96)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)15)), (String_t*)_stringLiteral81C6B56546B7CAF0C90DC134E1582EEDDD65C2F2);
		// challenges[16] = "1回の操作で成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_97 = __this->get_challenges_14();
		NullCheck(L_97);
		ArrayElementTypeCheck (L_97, _stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA);
		(L_97)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)16)), (String_t*)_stringLiteral0772B9D281FF8F6E5F83A8A96DAF30ED490D90DA);
		// challenges[17] = "16秒以内に成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_98 = __this->get_challenges_14();
		NullCheck(L_98);
		ArrayElementTypeCheck (L_98, _stringLiteral09BC0067B93715551994AF937074AACB2BC46F45);
		(L_98)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)17)), (String_t*)_stringLiteral09BC0067B93715551994AF937074AACB2BC46F45);
		// challenges[18] = "右上の部分で失敗する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_99 = __this->get_challenges_14();
		NullCheck(L_99);
		ArrayElementTypeCheck (L_99, _stringLiteral097BDACD66FAD850156FED9F725F9CC4873080ED);
		(L_99)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)18)), (String_t*)_stringLiteral097BDACD66FAD850156FED9F725F9CC4873080ED);
		// challenges[19] = "ゴールの下を通り、成功する";
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_100 = __this->get_challenges_14();
		NullCheck(L_100);
		ArrayElementTypeCheck (L_100, _stringLiteral18DFC76CE558A95E4B965CF15DB25F8772BAD6BE);
		(L_100)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)19)), (String_t*)_stringLiteral18DFC76CE558A95E4B965CF15DB25F8772BAD6BE);
		// }
		return;
	}
}
// System.Void TitleManager::Update()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_Update_m3D4B2483A33278FCFEB981AA66D621FDF1A652C7 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9B469AD8D3831F081E8E4B97777919CC5F65D853);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (Input.GetMouseButtonDown(0))
		bool L_0;
		L_0 = Input_GetMouseButtonDown_m466D81FDCC87C9CB07557B39DCB435EB691F1EF3(0, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0028;
		}
	}
	{
		// soundPlaySystem.SetSoundData(Resources.Load<AudioClip>("Sounds/correct"));
		SoundPlaySystem_t5F8071C71C869BB9E0793009A287F4325B08BB7E * L_1 = __this->get_soundPlaySystem_18();
		AudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE * L_2;
		L_2 = Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1(_stringLiteral9B469AD8D3831F081E8E4B97777919CC5F65D853, /*hidden argument*/Resources_Load_TisAudioClip_t16D2E573E7CC1C5118D8EE0F0692D46866A1C0EE_m6BF04F0FBDDD2978D86924C75AC86AF2B7273EA1_RuntimeMethod_var);
		NullCheck(L_1);
		SoundPlaySystem_SetSoundData_mC95E81C797E4E7D7210309AE5D3B8687EAB0BB9A(L_1, L_2, /*hidden argument*/NULL);
		// ug.changeMode();
		UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * L_3 = __this->get_ug_17();
		NullCheck(L_3);
		UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4(L_3, /*hidden argument*/NULL);
	}

IL_0028:
	{
		// }
		return;
	}
}
// System.Void TitleManager::onStageSelected(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_onStageSelected_m6A34F2AC410BA4F9EE6E0863D88DECA94A0C8BCD (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, int32_t ___n0, const RuntimeMethod* method)
{
	{
		// dat.goStage(n);
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_0 = __this->get_dat_5();
		int32_t L_1 = ___n0;
		NullCheck(L_0);
		datas_goStage_m25C4F57045373560EC4458957FEF4E28A2E43D09(L_0, L_1, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void TitleManager::checkData()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_checkData_m02820912FEEAD00B0B83CBFD98B4F0B1114AC945 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2FC0DC959FF52C9FB2EAD49C873F17BD1F1D0689);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral53EF8123784329433012CFAFBE65A775DA74906E);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral591B0174416DB6050EA3BA13A1D32B8C6FE72F0C);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralCE863626383155D02291456632E72C0FBEC22C3C);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709);
		s_Il2CppMethodInitialized = true;
	}
	StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * V_0 = NULL;
	int32_t V_1 = 0;
	{
		// if (!Directory.Exists("Save")) Directory.CreateDirectory("Save");
		bool L_0;
		L_0 = Directory_Exists_m17E38B91F6D9A0064D614FF2237BBFC0127468FE(_stringLiteralCE863626383155D02291456632E72C0FBEC22C3C, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		// if (!Directory.Exists("Save")) Directory.CreateDirectory("Save");
		DirectoryInfo_t4EF3610F45F0D234800D01ADA8F3F476AE0CF5CD * L_1;
		L_1 = Directory_CreateDirectory_m38040338519C48CE52137CC146372A153D5C6A7A(_stringLiteralCE863626383155D02291456632E72C0FBEC22C3C, /*hidden argument*/NULL);
	}

IL_0017:
	{
		// if (!System.IO.File.Exists("Save/data.txt"))
		bool L_2;
		L_2 = File_Exists_mDAEBF2732BC830270FD98346F069B04E97BB1D5B(_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		if (L_2)
		{
			goto IL_007b;
		}
	}
	{
		// File.WriteAllText("Save/data.txt", "AutoRetry:0;\nReachedStage:0;\nRTA:N/A;");
		File_WriteAllText_mA0528ED8C0C9B94864772B9036FC4B206682EE9C(_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, _stringLiteral591B0174416DB6050EA3BA13A1D32B8C6FE72F0C, /*hidden argument*/NULL);
		// StreamWriter sw = new StreamWriter("Save/data.txt", true, Encoding.UTF8);
		Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * L_3;
		L_3 = Encoding_get_UTF8_mC877FB3137BBD566AEE7B15F9BF61DC4EF8F5E5E(/*hidden argument*/NULL);
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_4 = (StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 *)il2cpp_codegen_object_new(StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6_il2cpp_TypeInfo_var);
		StreamWriter__ctor_m8E689BB489D6CA87348E79EBF05BA4E3F6D4B9A4(L_4, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, (bool)1, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		// sw.WriteLine("");
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_5 = V_0;
		NullCheck(L_5);
		VirtActionInvoker1< String_t* >::Invoke(18 /* System.Void System.IO.TextWriter::WriteLine(System.String) */, L_5, _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709);
		// for (int i = 0; i <= MainGameManager.MAX_STAGE_NUM; i++)
		V_1 = 0;
		goto IL_006d;
	}

IL_0052:
	{
		// sw.WriteLine(i.ToString() + ":0;");
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_6 = V_0;
		String_t* L_7;
		L_7 = Int32_ToString_m340C0A14D16799421EFDF8A81C8A16FA76D48411((int32_t*)(&V_1), /*hidden argument*/NULL);
		String_t* L_8;
		L_8 = String_Concat_m4B4AB72618348C5DFBFBA8DED84B9E2EBDB55E1B(L_7, _stringLiteral53EF8123784329433012CFAFBE65A775DA74906E, /*hidden argument*/NULL);
		NullCheck(L_6);
		VirtActionInvoker1< String_t* >::Invoke(18 /* System.Void System.IO.TextWriter::WriteLine(System.String) */, L_6, L_8);
		// for (int i = 0; i <= MainGameManager.MAX_STAGE_NUM; i++)
		int32_t L_9 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_9, (int32_t)1));
	}

IL_006d:
	{
		// for (int i = 0; i <= MainGameManager.MAX_STAGE_NUM; i++)
		int32_t L_10 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		int32_t L_11 = ((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->get_MAX_STAGE_NUM_19();
		if ((((int32_t)L_10) <= ((int32_t)L_11)))
		{
			goto IL_0052;
		}
	}
	{
		// sw.Close();
		StreamWriter_t3E267B7F3C9522AF936C26ABF158398BB779FAF6 * L_12 = V_0;
		NullCheck(L_12);
		VirtActionInvoker0::Invoke(8 /* System.Void System.IO.TextWriter::Close() */, L_12);
	}

IL_007b:
	{
		// if (!System.IO.File.Exists("Save/soundsetting.txt")) File.WriteAllText("Save/soundsetting.txt", "0.5:0.2");
		bool L_13;
		L_13 = File_Exists_mDAEBF2732BC830270FD98346F069B04E97BB1D5B(_stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0, /*hidden argument*/NULL);
		if (L_13)
		{
			goto IL_0096;
		}
	}
	{
		// if (!System.IO.File.Exists("Save/soundsetting.txt")) File.WriteAllText("Save/soundsetting.txt", "0.5:0.2");
		File_WriteAllText_mA0528ED8C0C9B94864772B9036FC4B206682EE9C(_stringLiteral30B657D660F915954F735E751A0DC3A6466E59A0, _stringLiteral2FC0DC959FF52C9FB2EAD49C873F17BD1F1D0689, /*hidden argument*/NULL);
	}

IL_0096:
	{
		// }
		return;
	}
}
// System.Void TitleManager::setRTA()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_setRTA_mD882541C9B3BFE96F02EAE79F49263D1BE606367 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// dat.goStage(0);
		datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * L_0 = __this->get_dat_5();
		NullCheck(L_0);
		datas_goStage_m25C4F57045373560EC4458957FEF4E28A2E43D09(L_0, 0, /*hidden argument*/NULL);
		// MainGameManager.rta = true;
		IL2CPP_RUNTIME_CLASS_INIT(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var);
		((MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_StaticFields*)il2cpp_codegen_static_fields_for(MainGameManager_t95006EEF82DE2E7E9A13EF3F82D9A5F2D005B6D4_il2cpp_TypeInfo_var))->set_rta_18((bool)1);
		// }
		return;
	}
}
// System.Void TitleManager::switchCanvas()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_switchCanvas_mCBA6B182DE57659C28603C9CE8EF0EC04173A883 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// canvasGroup[Convert.ToInt32(canvasStatus)].SetActive(false);
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_0 = __this->get_canvasGroup_6();
		bool L_1 = __this->get_canvasStatus_9();
		IL2CPP_RUNTIME_CLASS_INIT(Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		int32_t L_2;
		L_2 = Convert_ToInt32_m3B3C332A65A7F38D6DDF1A1D0ED511C701F67CD3(L_1, /*hidden argument*/NULL);
		NullCheck(L_0);
		int32_t L_3 = L_2;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_4 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		NullCheck(L_4);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_4, (bool)0, /*hidden argument*/NULL);
		// canvasGroup[Convert.ToInt32(!canvasStatus)].SetActive(true);
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_5 = __this->get_canvasGroup_6();
		bool L_6 = __this->get_canvasStatus_9();
		int32_t L_7;
		L_7 = Convert_ToInt32_m3B3C332A65A7F38D6DDF1A1D0ED511C701F67CD3((bool)((((int32_t)L_6) == ((int32_t)0))? 1 : 0), /*hidden argument*/NULL);
		NullCheck(L_5);
		int32_t L_8 = L_7;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_9 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		NullCheck(L_9);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_9, (bool)1, /*hidden argument*/NULL);
		// canvasStatus = !canvasStatus;
		bool L_10 = __this->get_canvasStatus_9();
		__this->set_canvasStatus_9((bool)((((int32_t)L_10) == ((int32_t)0))? 1 : 0));
		// }
		return;
	}
}
// System.Void TitleManager::setChallengeLabel(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_setChallengeLabel_m4BB922BE830CBA6E275AC7449A2DD0454A91D5CD (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, int32_t ___i0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		// StreamReader sr = new StreamReader("Save/data.txt");
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_0 = (StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 *)il2cpp_codegen_object_new(StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3_il2cpp_TypeInfo_var);
		StreamReader__ctor_m1F07D64A9881F3A6B755881210B4E88F8E63849B(L_0, _stringLiteral98FD6090DE846F2223AC98675CA4283BFA9A2F5D, /*hidden argument*/NULL);
		// string saveData = sr.ReadToEnd();
		StreamReader_tA857ACC7ABF9AA4638E1291E6D2539C14D2963D3 * L_1 = L_0;
		NullCheck(L_1);
		String_t* L_2;
		L_2 = VirtFuncInvoker0< String_t* >::Invoke(12 /* System.String System.IO.TextReader::ReadToEnd() */, L_1);
		V_0 = L_2;
		// sr.Close();
		NullCheck(L_1);
		VirtActionInvoker0::Invoke(7 /* System.Void System.IO.TextReader::Close() */, L_1);
		// int idx = 0;
		V_1 = 0;
		// for (int j = 0; j < 4 + i; j++)
		V_2 = 0;
		goto IL_002f;
	}

IL_001c:
	{
		// idx = saveData.IndexOf(":", idx + 1);
		String_t* L_3 = V_0;
		int32_t L_4 = V_1;
		NullCheck(L_3);
		int32_t L_5;
		L_5 = String_IndexOf_m9037DBF7895B78147B9F5931DA0AA9D2CBD8C3F0(L_3, _stringLiteral876C4B39B6E4D0187090400768899C71D99DE90D, ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)1)), /*hidden argument*/NULL);
		V_1 = L_5;
		// for (int j = 0; j < 4 + i; j++)
		int32_t L_6 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_6, (int32_t)1));
	}

IL_002f:
	{
		// for (int j = 0; j < 4 + i; j++)
		int32_t L_7 = V_2;
		int32_t L_8 = ___i0;
		if ((((int32_t)L_7) < ((int32_t)((int32_t)il2cpp_codegen_add((int32_t)4, (int32_t)L_8)))))
		{
			goto IL_001c;
		}
	}
	{
		// idx++; //コロンが含まれてしまうため
		int32_t L_9 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_9, (int32_t)1));
		// obj_ChallengeToggle.GetComponent<Toggle>().isOn = Convert.ToBoolean(Convert.ToInt32(saveData.Substring(idx, 1)));
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_10 = __this->get_obj_ChallengeToggle_15();
		NullCheck(L_10);
		Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * L_11;
		L_11 = GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49(L_10, /*hidden argument*/GameObject_GetComponent_TisToggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E_m34CD4077023A1701311E3E7D5B0A9E6EE1979A49_RuntimeMethod_var);
		String_t* L_12 = V_0;
		int32_t L_13 = V_1;
		NullCheck(L_12);
		String_t* L_14;
		L_14 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_12, L_13, 1, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_tDA947A979C1DAB4F09C461FAFD94FE194743A671_il2cpp_TypeInfo_var);
		int32_t L_15;
		L_15 = Convert_ToInt32_mA1C10AB2A7C95E9DCAC473D1D88C74D60FA240ED(L_14, /*hidden argument*/NULL);
		bool L_16;
		L_16 = Convert_ToBoolean_m85FE22B779E69576B3251DEC1E27BC8004485288(L_15, /*hidden argument*/NULL);
		NullCheck(L_11);
		Toggle_set_isOn_mB018B9F410D7236AAB71D6D1A5BACC64C891F507(L_11, L_16, /*hidden argument*/NULL);
		// obj_ChallengeToggle.SetActive(true);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_17 = __this->get_obj_ChallengeToggle_15();
		NullCheck(L_17);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_17, (bool)1, /*hidden argument*/NULL);
		// challengeLabel.text = challenges[i];
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_18 = __this->get_challengeLabel_12();
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_19 = __this->get_challenges_14();
		int32_t L_20 = ___i0;
		NullCheck(L_19);
		int32_t L_21 = L_20;
		String_t* L_22 = (L_19)->GetAt(static_cast<il2cpp_array_size_t>(L_21));
		NullCheck(L_18);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_18, L_22);
		// }
		return;
	}
}
// System.Void TitleManager::clearChallengeLabel()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_clearChallengeLabel_m2535E499AD7E402F0D39BA01D9831CB05C10773E (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709);
		s_Il2CppMethodInitialized = true;
	}
	{
		// challengeLabel.text = "";
		Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * L_0 = __this->get_challengeLabel_12();
		NullCheck(L_0);
		VirtActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_0, _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709);
		// obj_ChallengeToggle.SetActive(false);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1 = __this->get_obj_ChallengeToggle_15();
		NullCheck(L_1);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_1, (bool)0, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void TitleManager::switchCredit()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager_switchCredit_m0B27C6EE30E7F4BF36C236C6E40E983D70542B40 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	{
		// isCredit = !isCredit;
		bool L_0 = __this->get_isCredit_10();
		__this->set_isCredit_10((bool)((((int32_t)L_0) == ((int32_t)0))? 1 : 0));
		// creditGroup.SetActive(isCredit);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_1 = __this->get_creditGroup_7();
		bool L_2 = __this->get_isCredit_10();
		NullCheck(L_1);
		GameObject_SetActive_mCF1EEF2A314F3AE85DA581FF52EB06ACEF2FFF86(L_1, L_2, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void TitleManager::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TitleManager__ctor_m0D14731249E3B6D0846A587A421CAE4FAD2056D0 (TitleManager_tD5DD684FA380D9524ED08D1A131C3241E4B8DFC4 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// [SerializeField] GameObject[] canvasGroup = new GameObject[2];
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_0 = (GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642*)(GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642*)SZArrayNew(GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642_il2cpp_TypeInfo_var, (uint32_t)2);
		__this->set_canvasGroup_6(L_0);
		// string[] challenges = new string[20];
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_1 = (StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A*)(StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A*)SZArrayNew(StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A_il2cpp_TypeInfo_var, (uint32_t)((int32_t)20));
		__this->set_challenges_14(L_1);
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UniversalGravity::Start()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UniversalGravity_Start_m335253E1A5593A42D276E963A17437DAC7312B10 (UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * __this, const RuntimeMethod* method)
{
	{
		// GetAstroObjs();
		UniversalGravity_GetAstroObjs_mAC081AB221E0E3D34E9633FE0E4A8002ADF22EAA(__this, /*hidden argument*/NULL);
		// G = 30f;
		__this->set_G_4((30.0f));
		// In = new Color32(255, 40, 0, 255);
		Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D  L_0;
		memset((&L_0), 0, sizeof(L_0));
		Color32__ctor_m9D07EC69256BB7ED2784E543848DE7B8484A5C94((&L_0), (uint8_t)((int32_t)255), (uint8_t)((int32_t)40), (uint8_t)0, (uint8_t)((int32_t)255), /*hidden argument*/NULL);
		Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  L_1;
		L_1 = Color32_op_Implicit_m63F14F1A14B1A9A3EE4D154413EE229D3E001623(L_0, /*hidden argument*/NULL);
		__this->set_In_11(L_1);
		// Seki = new Color32(0, 255, 0, 255);
		Color32_tDB54A78627878A7D2DE42BB028D64306A18E858D  L_2;
		memset((&L_2), 0, sizeof(L_2));
		Color32__ctor_m9D07EC69256BB7ED2784E543848DE7B8484A5C94((&L_2), (uint8_t)0, (uint8_t)((int32_t)255), (uint8_t)0, (uint8_t)((int32_t)255), /*hidden argument*/NULL);
		Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  L_3;
		L_3 = Color32_op_Implicit_m63F14F1A14B1A9A3EE4D154413EE229D3E001623(L_2, /*hidden argument*/NULL);
		__this->set_Seki_12(L_3);
		// forceMode = true;
		__this->set_forceMode_10((bool)1);
		// changeMode();
		UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4(__this, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void UniversalGravity::FixedUpdate()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UniversalGravity_FixedUpdate_mE3584B3DB200CB655417B33AD139D51CC56213FB (UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2342ED095E8746444A44CFCD5D8ACA13F0E7EEF8);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral8BB6FD18AC8C106620676F49BEB172C77C1549CA);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  V_1;
	memset((&V_1), 0, sizeof(V_1));
	float V_2 = 0.0f;
	{
		// F = Vector3.zero;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0;
		L_0 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		__this->set_F_9(L_0);
		// for (int i = 0; i < count; i++)
		V_0 = 0;
		goto IL_01ee;
	}

IL_0012:
	{
		// Vector3 rVec = AstroObjs[i].transform.position - transform.position;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_1 = __this->get_AstroObjs_5();
		int32_t L_2 = V_0;
		NullCheck(L_1);
		int32_t L_3 = L_2;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		NullCheck(L_4);
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_5;
		L_5 = GameObject_get_transform_m16A80BB92B6C8C5AB696E447014D45EDF1E4DE34(L_4, /*hidden argument*/NULL);
		NullCheck(L_5);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_6;
		L_6 = Transform_get_position_m40A8A9895568D56FFC687B57F30E8D53CB5EA341(L_5, /*hidden argument*/NULL);
		Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * L_7;
		L_7 = Component_get_transform_mE8496EBC45BEB1BADB5F314960F1DF1C952FA11F(__this, /*hidden argument*/NULL);
		NullCheck(L_7);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_8;
		L_8 = Transform_get_position_m40A8A9895568D56FFC687B57F30E8D53CB5EA341(L_7, /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_9;
		L_9 = Vector3_op_Subtraction_m2725C96965D5C0B1F9715797E51762B13A5FED58_inline(L_6, L_8, /*hidden argument*/NULL);
		V_1 = L_9;
		// float r = rVec.magnitude;
		float L_10;
		L_10 = Vector3_get_magnitude_mDDD40612220D8104E77E993E18A101A69A944991((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_1), /*hidden argument*/NULL);
		V_2 = L_10;
		// if (!forceMode)
		bool L_11 = __this->get_forceMode_10();
		if (L_11)
		{
			goto IL_0119;
		}
	}
	{
		// if (AstroObjs[i].name.Contains("In"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_12 = __this->get_AstroObjs_5();
		int32_t L_13 = V_0;
		NullCheck(L_12);
		int32_t L_14 = L_13;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_15 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		NullCheck(L_15);
		String_t* L_16;
		L_16 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_15, /*hidden argument*/NULL);
		NullCheck(L_16);
		bool L_17;
		L_17 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_16, _stringLiteral2342ED095E8746444A44CFCD5D8ACA13F0E7EEF8, /*hidden argument*/NULL);
		if (!L_17)
		{
			goto IL_00af;
		}
	}
	{
		// F += rVec.normalized * G * (rbs[i].mass * rb.mass) / (r * r);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_18 = __this->get_F_9();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_19;
		L_19 = Vector3_get_normalized_m2FA6DF38F97BDA4CCBDAE12B9FE913A241DAC8D5((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_1), /*hidden argument*/NULL);
		float L_20 = __this->get_G_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_21;
		L_21 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_19, L_20, /*hidden argument*/NULL);
		RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* L_22 = __this->get_rbs_6();
		int32_t L_23 = V_0;
		NullCheck(L_22);
		int32_t L_24 = L_23;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_25 = (L_22)->GetAt(static_cast<il2cpp_array_size_t>(L_24));
		NullCheck(L_25);
		float L_26;
		L_26 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_25, /*hidden argument*/NULL);
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_27 = __this->get_rb_7();
		NullCheck(L_27);
		float L_28;
		L_28 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_27, /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_29;
		L_29 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_21, ((float)il2cpp_codegen_multiply((float)L_26, (float)L_28)), /*hidden argument*/NULL);
		float L_30 = V_2;
		float L_31 = V_2;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_32;
		L_32 = Vector3_op_Division_mE5ACBFB168FED529587457A83BA98B7DB32E2A05_inline(L_29, ((float)il2cpp_codegen_multiply((float)L_30, (float)L_31)), /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_33;
		L_33 = Vector3_op_Addition_mEE4F672B923CCB184C39AABCA33443DB218E50E0_inline(L_18, L_32, /*hidden argument*/NULL);
		__this->set_F_9(L_33);
		// }
		goto IL_01ea;
	}

IL_00af:
	{
		// else if (AstroObjs[i].name.Contains("Seki"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_34 = __this->get_AstroObjs_5();
		int32_t L_35 = V_0;
		NullCheck(L_34);
		int32_t L_36 = L_35;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_37 = (L_34)->GetAt(static_cast<il2cpp_array_size_t>(L_36));
		NullCheck(L_37);
		String_t* L_38;
		L_38 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_37, /*hidden argument*/NULL);
		NullCheck(L_38);
		bool L_39;
		L_39 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_38, _stringLiteral8BB6FD18AC8C106620676F49BEB172C77C1549CA, /*hidden argument*/NULL);
		if (!L_39)
		{
			goto IL_01ea;
		}
	}
	{
		// F -= rVec.normalized * G * (rbs[i].mass * rb.mass) / (r * r);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_40 = __this->get_F_9();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_41;
		L_41 = Vector3_get_normalized_m2FA6DF38F97BDA4CCBDAE12B9FE913A241DAC8D5((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_1), /*hidden argument*/NULL);
		float L_42 = __this->get_G_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_43;
		L_43 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_41, L_42, /*hidden argument*/NULL);
		RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* L_44 = __this->get_rbs_6();
		int32_t L_45 = V_0;
		NullCheck(L_44);
		int32_t L_46 = L_45;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_47 = (L_44)->GetAt(static_cast<il2cpp_array_size_t>(L_46));
		NullCheck(L_47);
		float L_48;
		L_48 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_47, /*hidden argument*/NULL);
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_49 = __this->get_rb_7();
		NullCheck(L_49);
		float L_50;
		L_50 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_49, /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_51;
		L_51 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_43, ((float)il2cpp_codegen_multiply((float)L_48, (float)L_50)), /*hidden argument*/NULL);
		float L_52 = V_2;
		float L_53 = V_2;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_54;
		L_54 = Vector3_op_Division_mE5ACBFB168FED529587457A83BA98B7DB32E2A05_inline(L_51, ((float)il2cpp_codegen_multiply((float)L_52, (float)L_53)), /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_55;
		L_55 = Vector3_op_Subtraction_m2725C96965D5C0B1F9715797E51762B13A5FED58_inline(L_40, L_54, /*hidden argument*/NULL);
		__this->set_F_9(L_55);
		// }
		goto IL_01ea;
	}

IL_0119:
	{
		// else if (forceMode)
		bool L_56 = __this->get_forceMode_10();
		if (!L_56)
		{
			goto IL_01ea;
		}
	}
	{
		// if (AstroObjs[i].name.Contains("In"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_57 = __this->get_AstroObjs_5();
		int32_t L_58 = V_0;
		NullCheck(L_57);
		int32_t L_59 = L_58;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_60 = (L_57)->GetAt(static_cast<il2cpp_array_size_t>(L_59));
		NullCheck(L_60);
		String_t* L_61;
		L_61 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_60, /*hidden argument*/NULL);
		NullCheck(L_61);
		bool L_62;
		L_62 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_61, _stringLiteral2342ED095E8746444A44CFCD5D8ACA13F0E7EEF8, /*hidden argument*/NULL);
		if (!L_62)
		{
			goto IL_0188;
		}
	}
	{
		// F -= rVec.normalized * G * (rbs[i].mass * rb.mass) / (r * r);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_63 = __this->get_F_9();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_64;
		L_64 = Vector3_get_normalized_m2FA6DF38F97BDA4CCBDAE12B9FE913A241DAC8D5((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_1), /*hidden argument*/NULL);
		float L_65 = __this->get_G_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_66;
		L_66 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_64, L_65, /*hidden argument*/NULL);
		RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* L_67 = __this->get_rbs_6();
		int32_t L_68 = V_0;
		NullCheck(L_67);
		int32_t L_69 = L_68;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_70 = (L_67)->GetAt(static_cast<il2cpp_array_size_t>(L_69));
		NullCheck(L_70);
		float L_71;
		L_71 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_70, /*hidden argument*/NULL);
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_72 = __this->get_rb_7();
		NullCheck(L_72);
		float L_73;
		L_73 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_72, /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_74;
		L_74 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_66, ((float)il2cpp_codegen_multiply((float)L_71, (float)L_73)), /*hidden argument*/NULL);
		float L_75 = V_2;
		float L_76 = V_2;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_77;
		L_77 = Vector3_op_Division_mE5ACBFB168FED529587457A83BA98B7DB32E2A05_inline(L_74, ((float)il2cpp_codegen_multiply((float)L_75, (float)L_76)), /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_78;
		L_78 = Vector3_op_Subtraction_m2725C96965D5C0B1F9715797E51762B13A5FED58_inline(L_63, L_77, /*hidden argument*/NULL);
		__this->set_F_9(L_78);
		// }
		goto IL_01ea;
	}

IL_0188:
	{
		// else if (AstroObjs[i].name.Contains("Seki"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_79 = __this->get_AstroObjs_5();
		int32_t L_80 = V_0;
		NullCheck(L_79);
		int32_t L_81 = L_80;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_82 = (L_79)->GetAt(static_cast<il2cpp_array_size_t>(L_81));
		NullCheck(L_82);
		String_t* L_83;
		L_83 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_82, /*hidden argument*/NULL);
		NullCheck(L_83);
		bool L_84;
		L_84 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_83, _stringLiteral8BB6FD18AC8C106620676F49BEB172C77C1549CA, /*hidden argument*/NULL);
		if (!L_84)
		{
			goto IL_01ea;
		}
	}
	{
		// F += rVec.normalized * G * (rbs[i].mass * rb.mass) / (r * r);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_85 = __this->get_F_9();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_86;
		L_86 = Vector3_get_normalized_m2FA6DF38F97BDA4CCBDAE12B9FE913A241DAC8D5((Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E *)(&V_1), /*hidden argument*/NULL);
		float L_87 = __this->get_G_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_88;
		L_88 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_86, L_87, /*hidden argument*/NULL);
		RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* L_89 = __this->get_rbs_6();
		int32_t L_90 = V_0;
		NullCheck(L_89);
		int32_t L_91 = L_90;
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_92 = (L_89)->GetAt(static_cast<il2cpp_array_size_t>(L_91));
		NullCheck(L_92);
		float L_93;
		L_93 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_92, /*hidden argument*/NULL);
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_94 = __this->get_rb_7();
		NullCheck(L_94);
		float L_95;
		L_95 = Rigidbody_get_mass_mB7B19406DAC6336A8244E98BE271BDA8B5C26223(L_94, /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_96;
		L_96 = Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline(L_88, ((float)il2cpp_codegen_multiply((float)L_93, (float)L_95)), /*hidden argument*/NULL);
		float L_97 = V_2;
		float L_98 = V_2;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_99;
		L_99 = Vector3_op_Division_mE5ACBFB168FED529587457A83BA98B7DB32E2A05_inline(L_96, ((float)il2cpp_codegen_multiply((float)L_97, (float)L_98)), /*hidden argument*/NULL);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_100;
		L_100 = Vector3_op_Addition_mEE4F672B923CCB184C39AABCA33443DB218E50E0_inline(L_85, L_99, /*hidden argument*/NULL);
		__this->set_F_9(L_100);
	}

IL_01ea:
	{
		// for (int i = 0; i < count; i++)
		int32_t L_101 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_101, (int32_t)1));
	}

IL_01ee:
	{
		// for (int i = 0; i < count; i++)
		int32_t L_102 = V_0;
		int32_t L_103 = __this->get_count_8();
		if ((((int32_t)L_102) < ((int32_t)L_103)))
		{
			goto IL_0012;
		}
	}
	{
		// rb.AddForce(F);
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_104 = __this->get_rb_7();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_105 = __this->get_F_9();
		NullCheck(L_104);
		Rigidbody_AddForce_mDFB0D57C25682B826999B0074F5C0FD399C6401D(L_104, L_105, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void UniversalGravity::GetAstroObjs()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UniversalGravity_GetAstroObjs_mAC081AB221E0E3D34E9633FE0E4A8002ADF22EAA (UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Array_Resize_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m5F039C66CEB5890529B35E8E0EF57322FD099EF9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (forceMode)
		bool L_0 = __this->get_forceMode_10();
		if (!L_0)
		{
			goto IL_000e;
		}
	}
	{
		// changeMode();
		UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4(__this, /*hidden argument*/NULL);
	}

IL_000e:
	{
		// AstroObjs = GameObject.FindGameObjectsWithTag("ForceSphere");
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_1;
		L_1 = GameObject_FindGameObjectsWithTag_m0948320611DC82590D59A36D1C57155B1B6CE186(_stringLiteral93B866A270CA6ACD4ACBA9651FBC8DDA2E925CD1, /*hidden argument*/NULL);
		__this->set_AstroObjs_5(L_1);
		// count = AstroObjs.Length;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_2 = __this->get_AstroObjs_5();
		NullCheck(L_2);
		__this->set_count_8(((int32_t)((int32_t)(((RuntimeArray*)L_2)->max_length))));
		// Array.Resize(ref rbs, count);
		RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B** L_3 = __this->get_address_of_rbs_6();
		int32_t L_4 = __this->get_count_8();
		Array_Resize_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m5F039C66CEB5890529B35E8E0EF57322FD099EF9((RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B**)L_3, L_4, /*hidden argument*/Array_Resize_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m5F039C66CEB5890529B35E8E0EF57322FD099EF9_RuntimeMethod_var);
		// rb = GetComponent<Rigidbody>();
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_5;
		L_5 = Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE(__this, /*hidden argument*/Component_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_m9DC24AA806B0B65E917751F7A3AFDB58861157CE_RuntimeMethod_var);
		__this->set_rb_7(L_5);
		// for (int i = 0; i < count; i++)
		V_0 = 0;
		goto IL_0066;
	}

IL_004d:
	{
		// rbs[i] = AstroObjs[i].GetComponent<Rigidbody>();
		RigidbodyU5BU5D_t9749C1DC39BC78A57D2239B2EF18DA9E31C2844B* L_6 = __this->get_rbs_6();
		int32_t L_7 = V_0;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_8 = __this->get_AstroObjs_5();
		int32_t L_9 = V_0;
		NullCheck(L_8);
		int32_t L_10 = L_9;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		NullCheck(L_11);
		Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A * L_12;
		L_12 = GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354(L_11, /*hidden argument*/GameObject_GetComponent_TisRigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A_mA1779277BB07CE3D2CB8E340CEA85C40C6B52354_RuntimeMethod_var);
		NullCheck(L_6);
		ArrayElementTypeCheck (L_6, L_12);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_7), (Rigidbody_t101F2E2F9F16E765A77429B2DE4527D2047A887A *)L_12);
		// for (int i = 0; i < count; i++)
		int32_t L_13 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_13, (int32_t)1));
	}

IL_0066:
	{
		// for (int i = 0; i < count; i++)
		int32_t L_14 = V_0;
		int32_t L_15 = __this->get_count_8();
		if ((((int32_t)L_14) < ((int32_t)L_15)))
		{
			goto IL_004d;
		}
	}
	{
		// }
		return;
	}
}
// System.Void UniversalGravity::changeMode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UniversalGravity_changeMode_m7C6D5446C42BC2E260E4F98FB747C6F711FF27F4 (UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2342ED095E8746444A44CFCD5D8ACA13F0E7EEF8);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral8BB6FD18AC8C106620676F49BEB172C77C1549CA);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// forceMode = !forceMode;
		bool L_0 = __this->get_forceMode_10();
		__this->set_forceMode_10((bool)((((int32_t)L_0) == ((int32_t)0))? 1 : 0));
		// for (int i = 0; i < count; i++)
		V_0 = 0;
		goto IL_010e;
	}

IL_0016:
	{
		// if (!forceMode)
		bool L_1 = __this->get_forceMode_10();
		if (L_1)
		{
			goto IL_0094;
		}
	}
	{
		// if (AstroObjs[i].name.Contains("In"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_2 = __this->get_AstroObjs_5();
		int32_t L_3 = V_0;
		NullCheck(L_2);
		int32_t L_4 = L_3;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		NullCheck(L_5);
		String_t* L_6;
		L_6 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_5, /*hidden argument*/NULL);
		NullCheck(L_6);
		bool L_7;
		L_7 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_6, _stringLiteral2342ED095E8746444A44CFCD5D8ACA13F0E7EEF8, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0059;
		}
	}
	{
		// AstroObjs[i].GetComponent<Renderer>().material.color = In;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_8 = __this->get_AstroObjs_5();
		int32_t L_9 = V_0;
		NullCheck(L_8);
		int32_t L_10 = L_9;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		NullCheck(L_11);
		Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C * L_12;
		L_12 = GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466(L_11, /*hidden argument*/GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466_RuntimeMethod_var);
		NullCheck(L_12);
		Material_t8927C00353A72755313F046D0CE85178AE8218EE * L_13;
		L_13 = Renderer_get_material_mE6B01125502D08EE0D6DFE2EAEC064AD9BB31804(L_12, /*hidden argument*/NULL);
		Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  L_14 = __this->get_In_11();
		NullCheck(L_13);
		Material_set_color_mC3C88E2389B7132EBF3EB0D1F040545176B795C0(L_13, L_14, /*hidden argument*/NULL);
		// }
		goto IL_010a;
	}

IL_0059:
	{
		// else if (AstroObjs[i].name.Contains("Seki"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_15 = __this->get_AstroObjs_5();
		int32_t L_16 = V_0;
		NullCheck(L_15);
		int32_t L_17 = L_16;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_18 = (L_15)->GetAt(static_cast<il2cpp_array_size_t>(L_17));
		NullCheck(L_18);
		String_t* L_19;
		L_19 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_18, /*hidden argument*/NULL);
		NullCheck(L_19);
		bool L_20;
		L_20 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_19, _stringLiteral8BB6FD18AC8C106620676F49BEB172C77C1549CA, /*hidden argument*/NULL);
		if (!L_20)
		{
			goto IL_010a;
		}
	}
	{
		// AstroObjs[i].GetComponent<Renderer>().material.color = Seki;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_21 = __this->get_AstroObjs_5();
		int32_t L_22 = V_0;
		NullCheck(L_21);
		int32_t L_23 = L_22;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_24 = (L_21)->GetAt(static_cast<il2cpp_array_size_t>(L_23));
		NullCheck(L_24);
		Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C * L_25;
		L_25 = GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466(L_24, /*hidden argument*/GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466_RuntimeMethod_var);
		NullCheck(L_25);
		Material_t8927C00353A72755313F046D0CE85178AE8218EE * L_26;
		L_26 = Renderer_get_material_mE6B01125502D08EE0D6DFE2EAEC064AD9BB31804(L_25, /*hidden argument*/NULL);
		Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  L_27 = __this->get_Seki_12();
		NullCheck(L_26);
		Material_set_color_mC3C88E2389B7132EBF3EB0D1F040545176B795C0(L_26, L_27, /*hidden argument*/NULL);
		// }
		goto IL_010a;
	}

IL_0094:
	{
		// else if (forceMode)
		bool L_28 = __this->get_forceMode_10();
		if (!L_28)
		{
			goto IL_010a;
		}
	}
	{
		// if (AstroObjs[i].name.Contains("In"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_29 = __this->get_AstroObjs_5();
		int32_t L_30 = V_0;
		NullCheck(L_29);
		int32_t L_31 = L_30;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_32 = (L_29)->GetAt(static_cast<il2cpp_array_size_t>(L_31));
		NullCheck(L_32);
		String_t* L_33;
		L_33 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_32, /*hidden argument*/NULL);
		NullCheck(L_33);
		bool L_34;
		L_34 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_33, _stringLiteral2342ED095E8746444A44CFCD5D8ACA13F0E7EEF8, /*hidden argument*/NULL);
		if (!L_34)
		{
			goto IL_00d4;
		}
	}
	{
		// AstroObjs[i].GetComponent<Renderer>().material.color = Seki;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_35 = __this->get_AstroObjs_5();
		int32_t L_36 = V_0;
		NullCheck(L_35);
		int32_t L_37 = L_36;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_38 = (L_35)->GetAt(static_cast<il2cpp_array_size_t>(L_37));
		NullCheck(L_38);
		Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C * L_39;
		L_39 = GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466(L_38, /*hidden argument*/GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466_RuntimeMethod_var);
		NullCheck(L_39);
		Material_t8927C00353A72755313F046D0CE85178AE8218EE * L_40;
		L_40 = Renderer_get_material_mE6B01125502D08EE0D6DFE2EAEC064AD9BB31804(L_39, /*hidden argument*/NULL);
		Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  L_41 = __this->get_Seki_12();
		NullCheck(L_40);
		Material_set_color_mC3C88E2389B7132EBF3EB0D1F040545176B795C0(L_40, L_41, /*hidden argument*/NULL);
		// }
		goto IL_010a;
	}

IL_00d4:
	{
		// else if (AstroObjs[i].name.Contains("Seki"))
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_42 = __this->get_AstroObjs_5();
		int32_t L_43 = V_0;
		NullCheck(L_42);
		int32_t L_44 = L_43;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_45 = (L_42)->GetAt(static_cast<il2cpp_array_size_t>(L_44));
		NullCheck(L_45);
		String_t* L_46;
		L_46 = Object_get_name_m0C7BC870ED2F0DC5A2FB09628136CD7D1CB82CFB(L_45, /*hidden argument*/NULL);
		NullCheck(L_46);
		bool L_47;
		L_47 = String_Contains_mA26BDCCE8F191E8965EB8EEFC18BB4D0F85A075A(L_46, _stringLiteral8BB6FD18AC8C106620676F49BEB172C77C1549CA, /*hidden argument*/NULL);
		if (!L_47)
		{
			goto IL_010a;
		}
	}
	{
		// AstroObjs[i].GetComponent<Renderer>().material.color = In;
		GameObjectU5BU5D_tA88FC1A1FC9D4D73D0B3984D4B0ECE88F4C47642* L_48 = __this->get_AstroObjs_5();
		int32_t L_49 = V_0;
		NullCheck(L_48);
		int32_t L_50 = L_49;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_51 = (L_48)->GetAt(static_cast<il2cpp_array_size_t>(L_50));
		NullCheck(L_51);
		Renderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C * L_52;
		L_52 = GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466(L_51, /*hidden argument*/GameObject_GetComponent_TisRenderer_t58147AB5B00224FE1460FD47542DC0DA7EC9378C_mD787758BED3337F182C18CC67C516C2A11B55466_RuntimeMethod_var);
		NullCheck(L_52);
		Material_t8927C00353A72755313F046D0CE85178AE8218EE * L_53;
		L_53 = Renderer_get_material_mE6B01125502D08EE0D6DFE2EAEC064AD9BB31804(L_52, /*hidden argument*/NULL);
		Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  L_54 = __this->get_In_11();
		NullCheck(L_53);
		Material_set_color_mC3C88E2389B7132EBF3EB0D1F040545176B795C0(L_53, L_54, /*hidden argument*/NULL);
	}

IL_010a:
	{
		// for (int i = 0; i < count; i++)
		int32_t L_55 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_55, (int32_t)1));
	}

IL_010e:
	{
		// for (int i = 0; i < count; i++)
		int32_t L_56 = V_0;
		int32_t L_57 = __this->get_count_8();
		if ((((int32_t)L_56) < ((int32_t)L_57)))
		{
			goto IL_0016;
		}
	}
	{
		// }
		return;
	}
}
// System.Void UniversalGravity::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UniversalGravity__ctor_mCB784BD312F5B3C9907DFAF1543DBDF7C640910D (UniversalGravity_tCD58616B1D9E57ADE90E65D002E8C1D6C33976C9 * __this, const RuntimeMethod* method)
{
	{
		// public float G = 150f;
		__this->set_G_4((150.0f));
		// Vector3 F = Vector3.zero;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0;
		L_0 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		__this->set_F_9(L_0);
		MonoBehaviour__ctor_mC0995D847F6A95B1A553652636C38A2AA8B13BED(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// stageData datas::getStageData(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  datas_getStageData_m0D19D87CDF47A697BFB2A35294B70E4B221DEA2F (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * __this, int32_t ___n0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		// stageData data = new stageData();
		il2cpp_codegen_initobj((&V_0), sizeof(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512 ));
		int32_t L_0 = ___n0;
		switch (L_0)
		{
			case 0:
			{
				goto IL_0063;
			}
			case 1:
			{
				goto IL_016d;
			}
			case 2:
			{
				goto IL_0245;
			}
			case 3:
			{
				goto IL_034f;
			}
			case 4:
			{
				goto IL_0459;
			}
			case 5:
			{
				goto IL_0563;
			}
			case 6:
			{
				goto IL_066d;
			}
			case 7:
			{
				goto IL_0757;
			}
			case 8:
			{
				goto IL_0b33;
			}
			case 9:
			{
				goto IL_0c0e;
			}
			case 10:
			{
				goto IL_0d18;
			}
			case 11:
			{
				goto IL_0f22;
			}
			case 12:
			{
				goto IL_1140;
			}
			case 13:
			{
				goto IL_144c;
			}
			case 14:
			{
				goto IL_16a7;
			}
			case 15:
			{
				goto IL_18b1;
			}
			case 16:
			{
				goto IL_1aec;
			}
			case 17:
			{
				goto IL_1dd1;
			}
			case 18:
			{
				goto IL_205b;
			}
			case 19:
			{
				goto IL_2398;
			}
		}
	}
	{
		goto IL_26b0;
	}

IL_0063:
	{
		// data.playerPos = new Vector3(2, 0, 0);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_1;
		memset((&L_1), 0, sizeof(L_1));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_1), (2.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_1);
		// data.inPoss = new Vector3[3];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_2 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)3);
		(&V_0)->set_inPoss_1(L_2);
		// data.inPoss[0] = new Vector3(-8, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_3 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_4 = L_3.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_5;
		memset((&L_5), 0, sizeof(L_5));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_5), (-8.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_4);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_5);
		// data.inPoss[1] = new Vector3(-8, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_6 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_7 = L_6.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_8;
		memset((&L_8), 0, sizeof(L_8));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_8), (-8.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_7);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_8);
		// data.inPoss[2] = new Vector3(-8, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_9 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_10 = L_9.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_11;
		memset((&L_11), 0, sizeof(L_11));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_11), (-8.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_10);
		(L_10)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_11);
		// data.sekiPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_12 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_sekiPoss_2(L_12);
		// data.sekiPoss[0] = new Vector3(8, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_13 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_14 = L_13.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_15;
		memset((&L_15), 0, sizeof(L_15));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_15), (8.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_14);
		(L_14)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_15);
		// data.goalPos = new Vector3(6, 0, 0);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_16;
		memset((&L_16), 0, sizeof(L_16));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_16), (6.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_16);
		// data.goalSize = new Vector3(2, 1, 4);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_17;
		memset((&L_17), 0, sizeof(L_17));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_17), (2.0f), (1.0f), (4.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_17);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_18 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_18);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_19 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_19);
		// break;
		goto IL_26b0;
	}

IL_016d:
	{
		// data.playerPos = new Vector3(9, 0, -7);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_20;
		memset((&L_20), 0, sizeof(L_20));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_20), (9.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_20);
		// data.inPoss = new Vector3[17];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_21 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)17));
		(&V_0)->set_inPoss_1(L_21);
		// for (int i = 0; i < 17; i++)
		V_1 = 0;
		goto IL_01be;
	}

IL_019a:
	{
		// data.inPoss[i] = new Vector3(-8, 0, i - 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_22 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_23 = L_22.get_inPoss_1();
		int32_t L_24 = V_1;
		int32_t L_25 = V_1;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_26;
		memset((&L_26), 0, sizeof(L_26));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_26), (-8.0f), (0.0f), ((float)((float)((int32_t)il2cpp_codegen_subtract((int32_t)L_25, (int32_t)((int32_t)9))))), /*hidden argument*/NULL);
		NullCheck(L_23);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(L_24), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_26);
		// for (int i = 0; i < 17; i++)
		int32_t L_27 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_27, (int32_t)1));
	}

IL_01be:
	{
		// for (int i = 0; i < 17; i++)
		int32_t L_28 = V_1;
		if ((((int32_t)L_28) < ((int32_t)((int32_t)17))))
		{
			goto IL_019a;
		}
	}
	{
		// data.sekiPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_29 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_sekiPoss_2(L_29);
		// data.sekiPoss[0] = new Vector3(9, 0, -9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_30 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_31 = L_30.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_32;
		memset((&L_32), 0, sizeof(L_32));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_32), (9.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		NullCheck(L_31);
		(L_31)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_32);
		// data.goalPos = new Vector3(-9, 0, 0);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_33;
		memset((&L_33), 0, sizeof(L_33));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_33), (-9.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_33);
		// data.goalSize = new Vector3(1, 1, 19);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_34;
		memset((&L_34), 0, sizeof(L_34));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_34), (1.0f), (1.0f), (19.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_34);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_35 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_35);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_36 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_36);
		// break;
		goto IL_26b0;
	}

IL_0245:
	{
		// data.playerPos = new Vector3(8, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_37;
		memset((&L_37), 0, sizeof(L_37));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_37), (8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_37);
		// data.inPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_38 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_inPoss_1(L_38);
		// data.inPoss[0] = new Vector3(2, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_39 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_40 = L_39.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_41;
		memset((&L_41), 0, sizeof(L_41));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_41), (2.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_40);
		(L_40)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_41);
		// data.sekiPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_42 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_sekiPoss_2(L_42);
		// data.sekiPoss[0] = new Vector3(9, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_43 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_44 = L_43.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_45;
		memset((&L_45), 0, sizeof(L_45));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_45), (9.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_44);
		(L_44)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_45);
		// data.goalPos = new Vector3(0, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_46;
		memset((&L_46), 0, sizeof(L_46));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_46), (0.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_46);
		// data.goalSize = new Vector3(5, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_47;
		memset((&L_47), 0, sizeof(L_47));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_47), (5.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_47);
		// data.wallPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_48 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_wallPoss_5(L_48);
		// data.wallPoss[0] = new Vector3(5, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_49 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_50 = L_49.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_51;
		memset((&L_51), 0, sizeof(L_51));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_51), (5.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_50);
		(L_50)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_51);
		// data.wallSizes = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_52 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_wallSizes_6(L_52);
		// data.wallSizes[0] = new Vector3(0.5f, 0.1f, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_53 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_54 = L_53.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_55;
		memset((&L_55), 0, sizeof(L_55));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_55), (0.5f), (0.100000001f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_54);
		(L_54)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_55);
		// break;
		goto IL_26b0;
	}

IL_034f:
	{
		// data.playerPos = new Vector3(-8, 0, -7);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_56;
		memset((&L_56), 0, sizeof(L_56));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_56), (-8.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_56);
		// data.inPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_57 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_inPoss_1(L_57);
		// data.inPoss[0] = new Vector3(-5, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_58 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_59 = L_58.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_60;
		memset((&L_60), 0, sizeof(L_60));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_60), (-5.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_59);
		(L_59)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_60);
		// data.inPoss[1] = new Vector3(2, 0, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_61 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_62 = L_61.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_63;
		memset((&L_63), 0, sizeof(L_63));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_63), (2.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_62);
		(L_62)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_63);
		// data.sekiPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_64 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_sekiPoss_2(L_64);
		// data.sekiPoss[0] = new Vector3(-9, 0, -9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_65 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_66 = L_65.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_67;
		memset((&L_67), 0, sizeof(L_67));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_67), (-9.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		NullCheck(L_66);
		(L_66)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_67);
		// data.sekiPoss[1] = new Vector3(-5, 0, -9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_68 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_69 = L_68.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_70;
		memset((&L_70), 0, sizeof(L_70));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_70), (-5.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		NullCheck(L_69);
		(L_69)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_70);
		// data.goalPos = new Vector3(8, 0, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_71;
		memset((&L_71), 0, sizeof(L_71));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_71), (8.0f), (0.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_71);
		// data.goalSize = new Vector3(3, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_72;
		memset((&L_72), 0, sizeof(L_72));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_72), (3.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_72);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_73 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_73);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_74 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_74);
		// break;
		goto IL_26b0;
	}

IL_0459:
	{
		// data.playerPos = new Vector3(0, 0, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_75;
		memset((&L_75), 0, sizeof(L_75));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_75), (0.0f), (0.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_75);
		// data.inPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_76 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_inPoss_1(L_76);
		// data.inPoss[0] = new Vector3(0, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_77 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_78 = L_77.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_79;
		memset((&L_79), 0, sizeof(L_79));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_79), (0.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_78);
		(L_78)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_79);
		// data.inPoss[1] = new Vector3(-7, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_80 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_81 = L_80.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_82;
		memset((&L_82), 0, sizeof(L_82));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_82), (-7.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_81);
		(L_81)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_82);
		// data.sekiPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_83 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_sekiPoss_2(L_83);
		// data.sekiPoss[0] = new Vector3(6, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_84 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_85 = L_84.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_86;
		memset((&L_86), 0, sizeof(L_86));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_86), (6.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_85);
		(L_85)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_86);
		// data.sekiPoss[1] = new Vector3(-6, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_87 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_88 = L_87.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_89;
		memset((&L_89), 0, sizeof(L_89));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_89), (-6.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_88);
		(L_88)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_89);
		// data.goalPos = new Vector3(7.5f, 0, -7.5f);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_90;
		memset((&L_90), 0, sizeof(L_90));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_90), (7.5f), (0.0f), (-7.5f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_90);
		// data.goalSize = new Vector3(4, 1, 4);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_91;
		memset((&L_91), 0, sizeof(L_91));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_91), (4.0f), (1.0f), (4.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_91);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_92 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_92);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_93 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_93);
		// break;
		goto IL_26b0;
	}

IL_0563:
	{
		// data.playerPos = new Vector3(0, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_94;
		memset((&L_94), 0, sizeof(L_94));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_94), (0.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_94);
		// data.inPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_95 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_inPoss_1(L_95);
		// data.inPoss[0] = new Vector3(6, 0, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_96 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_97 = L_96.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_98;
		memset((&L_98), 0, sizeof(L_98));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_98), (6.0f), (0.0f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_97);
		(L_97)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_98);
		// data.inPoss[1] = new Vector3(6, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_99 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_100 = L_99.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_101;
		memset((&L_101), 0, sizeof(L_101));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_101), (6.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_100);
		(L_100)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_101);
		// data.sekiPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_102 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_sekiPoss_2(L_102);
		// data.sekiPoss[0] = new Vector3(-6, 0, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_103 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_104 = L_103.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_105;
		memset((&L_105), 0, sizeof(L_105));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_105), (-6.0f), (0.0f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_104);
		(L_104)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_105);
		// data.sekiPoss[1] = new Vector3(-6, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_106 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_107 = L_106.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_108;
		memset((&L_108), 0, sizeof(L_108));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_108), (-6.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_107);
		(L_107)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_108);
		// data.goalPos = new Vector3(0, 0, -8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_109;
		memset((&L_109), 0, sizeof(L_109));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_109), (0.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_109);
		// data.goalSize = new Vector3(19, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_110;
		memset((&L_110), 0, sizeof(L_110));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_110), (19.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_110);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_111 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_111);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_112 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_112);
		// break;
		goto IL_26b0;
	}

IL_066d:
	{
		// data.playerPos = new Vector3(8, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_113;
		memset((&L_113), 0, sizeof(L_113));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_113), (8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_113);
		// data.inPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_114 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_inPoss_1(L_114);
		// data.inPoss[0] = new Vector3(2, 0, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_115 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_116 = L_115.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_117;
		memset((&L_117), 0, sizeof(L_117));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_117), (2.0f), (0.0f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_116);
		(L_116)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_117);
		// data.inPoss[1] = new Vector3(6, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_118 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_119 = L_118.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_120;
		memset((&L_120), 0, sizeof(L_120));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_120), (6.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_119);
		(L_119)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_120);
		// data.sekiPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_121 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_sekiPoss_2(L_121);
		// data.sekiPoss[0] = new Vector3(9, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_122 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_123 = L_122.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_124;
		memset((&L_124), 0, sizeof(L_124));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_124), (9.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_123);
		(L_123)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_124);
		// data.goalPos = new Vector3(6, 0, -4);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_125;
		memset((&L_125), 0, sizeof(L_125));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_125), (6.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_125);
		// data.goalSize = new Vector3(1, 1, 7);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_126;
		memset((&L_126), 0, sizeof(L_126));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_126), (1.0f), (1.0f), (7.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_126);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_127 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_127);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_128 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_128);
		// break;
		goto IL_26b0;
	}

IL_0757:
	{
		// data.playerPos = new Vector3(8, 0, -1);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_129;
		memset((&L_129), 0, sizeof(L_129));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_129), (8.0f), (0.0f), (-1.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_129);
		// data.inPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_130 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_inPoss_1(L_130);
		// data.sekiPoss = new Vector3[26];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_131 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)26));
		(&V_0)->set_sekiPoss_2(L_131);
		// data.sekiPoss[0] = new Vector3(2, 0, -9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_132 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_133 = L_132.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_134;
		memset((&L_134), 0, sizeof(L_134));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_134), (2.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		NullCheck(L_133);
		(L_133)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_134);
		// data.sekiPoss[1] = new Vector3(3, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_135 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_136 = L_135.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_137;
		memset((&L_137), 0, sizeof(L_137));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_137), (3.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_136);
		(L_136)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_137);
		// data.sekiPoss[2] = new Vector3(4, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_138 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_139 = L_138.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_140;
		memset((&L_140), 0, sizeof(L_140));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_140), (4.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_139);
		(L_139)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_140);
		// data.sekiPoss[3] = new Vector3(5, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_141 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_142 = L_141.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_143;
		memset((&L_143), 0, sizeof(L_143));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_143), (5.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_142);
		(L_142)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_143);
		// data.sekiPoss[4] = new Vector3(6, 0, -5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_144 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_145 = L_144.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_146;
		memset((&L_146), 0, sizeof(L_146));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_146), (6.0f), (0.0f), (-5.0f), /*hidden argument*/NULL);
		NullCheck(L_145);
		(L_145)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_146);
		// data.sekiPoss[5] = new Vector3(7, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_147 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_148 = L_147.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_149;
		memset((&L_149), 0, sizeof(L_149));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_149), (7.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_148);
		(L_148)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_149);
		// data.sekiPoss[6] = new Vector3(8, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_150 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_151 = L_150.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_152;
		memset((&L_152), 0, sizeof(L_152));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_152), (8.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_151);
		(L_151)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_152);
		// data.sekiPoss[7] = new Vector3(9, 0, -2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_153 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_154 = L_153.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_155;
		memset((&L_155), 0, sizeof(L_155));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_155), (9.0f), (0.0f), (-2.0f), /*hidden argument*/NULL);
		NullCheck(L_154);
		(L_154)->SetAt(static_cast<il2cpp_array_size_t>(7), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_155);
		// data.sekiPoss[8] = new Vector3(-2, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_156 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_157 = L_156.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_158;
		memset((&L_158), 0, sizeof(L_158));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_158), (-2.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_157);
		(L_157)->SetAt(static_cast<il2cpp_array_size_t>(8), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_158);
		// data.sekiPoss[9] = new Vector3(-3, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_159 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_160 = L_159.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_161;
		memset((&L_161), 0, sizeof(L_161));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_161), (-3.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_160);
		(L_160)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)9)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_161);
		// data.sekiPoss[10] = new Vector3(-4, 0, 7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_162 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_163 = L_162.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_164;
		memset((&L_164), 0, sizeof(L_164));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_164), (-4.0f), (0.0f), (7.0f), /*hidden argument*/NULL);
		NullCheck(L_163);
		(L_163)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)10)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_164);
		// data.sekiPoss[11] = new Vector3(-5, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_165 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_166 = L_165.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_167;
		memset((&L_167), 0, sizeof(L_167));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_167), (-5.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_166);
		(L_166)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)11)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_167);
		// data.sekiPoss[12] = new Vector3(-6, 0, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_168 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_169 = L_168.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_170;
		memset((&L_170), 0, sizeof(L_170));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_170), (-6.0f), (0.0f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_169);
		(L_169)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)12)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_170);
		// data.sekiPoss[13] = new Vector3(-7, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_171 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_172 = L_171.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_173;
		memset((&L_173), 0, sizeof(L_173));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_173), (-7.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_172);
		(L_172)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)13)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_173);
		// data.sekiPoss[14] = new Vector3(-8, 0, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_174 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_175 = L_174.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_176;
		memset((&L_176), 0, sizeof(L_176));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_176), (-8.0f), (0.0f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_175);
		(L_175)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)14)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_176);
		// data.sekiPoss[15] = new Vector3(-9, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_177 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_178 = L_177.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_179;
		memset((&L_179), 0, sizeof(L_179));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_179), (-9.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_178);
		(L_178)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)15)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_179);
		// data.sekiPoss[16] = new Vector3(-8, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_180 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_181 = L_180.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_182;
		memset((&L_182), 0, sizeof(L_182));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_182), (-8.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_181);
		(L_181)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)16)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_182);
		// data.sekiPoss[17] = new Vector3(-7, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_183 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_184 = L_183.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_185;
		memset((&L_185), 0, sizeof(L_185));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_185), (-7.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_184);
		(L_184)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)17)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_185);
		// data.sekiPoss[18] = new Vector3(-6, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_186 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_187 = L_186.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_188;
		memset((&L_188), 0, sizeof(L_188));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_188), (-6.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_187);
		(L_187)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)18)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_188);
		// data.sekiPoss[19] = new Vector3(-5, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_189 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_190 = L_189.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_191;
		memset((&L_191), 0, sizeof(L_191));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_191), (-5.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_190);
		(L_190)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)19)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_191);
		// data.sekiPoss[20] = new Vector3(-4, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_192 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_193 = L_192.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_194;
		memset((&L_194), 0, sizeof(L_194));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_194), (-4.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_193);
		(L_193)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)20)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_194);
		// data.sekiPoss[21] = new Vector3(2, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_195 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_196 = L_195.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_197;
		memset((&L_197), 0, sizeof(L_197));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_197), (2.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_196);
		(L_196)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)21)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_197);
		// data.sekiPoss[22] = new Vector3(2, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_198 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_199 = L_198.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_200;
		memset((&L_200), 0, sizeof(L_200));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_200), (2.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_199);
		(L_199)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)22)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_200);
		// data.sekiPoss[23] = new Vector3(2, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_201 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_202 = L_201.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_203;
		memset((&L_203), 0, sizeof(L_203));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_203), (2.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_202);
		(L_202)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)23)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_203);
		// data.sekiPoss[24] = new Vector3(2, 0, -5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_204 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_205 = L_204.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_206;
		memset((&L_206), 0, sizeof(L_206));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_206), (2.0f), (0.0f), (-5.0f), /*hidden argument*/NULL);
		NullCheck(L_205);
		(L_205)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)24)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_206);
		// data.sekiPoss[25] = new Vector3(2, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_207 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_208 = L_207.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_209;
		memset((&L_209), 0, sizeof(L_209));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_209), (2.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_208);
		(L_208)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)25)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_209);
		// data.goalPos = new Vector3(-7, 0, -7);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_210;
		memset((&L_210), 0, sizeof(L_210));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_210), (-7.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_210);
		// data.goalSize = new Vector3(5, 1, 5);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_211;
		memset((&L_211), 0, sizeof(L_211));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_211), (5.0f), (1.0f), (5.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_211);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_212 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_212);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_213 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_213);
		// break;
		goto IL_26b0;
	}

IL_0b33:
	{
		// data.playerPos = new Vector3(-8, 0, -8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_214;
		memset((&L_214), 0, sizeof(L_214));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_214), (-8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_214);
		// data.inPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_215 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_inPoss_1(L_215);
		// data.inPoss[0] = new Vector3(4, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_216 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_217 = L_216.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_218;
		memset((&L_218), 0, sizeof(L_218));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_218), (4.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_217);
		(L_217)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_218);
		// data.sekiPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_219 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_sekiPoss_2(L_219);
		// data.sekiPoss[0] = new Vector3(-2, 0, -2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_220 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_221 = L_220.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_222;
		memset((&L_222), 0, sizeof(L_222));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_222), (-2.0f), (0.0f), (-2.0f), /*hidden argument*/NULL);
		NullCheck(L_221);
		(L_221)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_222);
		// data.sekiPoss[1] = new Vector3(-1, 0, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_223 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_224 = L_223.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_225;
		memset((&L_225), 0, sizeof(L_225));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_225), (-1.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_224);
		(L_224)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_225);
		// data.goalPos = Vector3.zero;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_226;
		L_226 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_226);
		// data.goalSize = new Vector3(1, 1, 1);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_227;
		memset((&L_227), 0, sizeof(L_227));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_227), (1.0f), (1.0f), (1.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_227);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_228 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_228);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_229 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_229);
		// break;
		goto IL_26b0;
	}

IL_0c0e:
	{
		// data.playerPos = new Vector3(-8, 0, -8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_230;
		memset((&L_230), 0, sizeof(L_230));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_230), (-8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_230);
		// data.inPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_231 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_inPoss_1(L_231);
		// data.inPoss[0] = new Vector3(7, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_232 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_233 = L_232.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_234;
		memset((&L_234), 0, sizeof(L_234));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_234), (7.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_233);
		(L_233)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_234);
		// data.sekiPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_235 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_sekiPoss_2(L_235);
		// data.sekiPoss[0] = new Vector3(7, 0, 7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_236 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_237 = L_236.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_238;
		memset((&L_238), 0, sizeof(L_238));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_238), (7.0f), (0.0f), (7.0f), /*hidden argument*/NULL);
		NullCheck(L_237);
		(L_237)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_238);
		// data.goalPos = new Vector3(-8, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_239;
		memset((&L_239), 0, sizeof(L_239));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_239), (-8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_239);
		// data.goalSize = new Vector3(3, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_240;
		memset((&L_240), 0, sizeof(L_240));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_240), (3.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_240);
		// data.wallPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_241 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_wallPoss_5(L_241);
		// data.wallPoss[0] = new Vector3(-1, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_242 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_243 = L_242.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_244;
		memset((&L_244), 0, sizeof(L_244));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_244), (-1.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_243);
		(L_243)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_244);
		// data.wallSizes = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_245 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_wallSizes_6(L_245);
		// data.wallSizes[0] = new Vector3(17, 0.1f, 13);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_246 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_247 = L_246.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_248;
		memset((&L_248), 0, sizeof(L_248));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_248), (17.0f), (0.100000001f), (13.0f), /*hidden argument*/NULL);
		NullCheck(L_247);
		(L_247)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_248);
		// break;
		goto IL_26b0;
	}

IL_0d18:
	{
		// data.playerPos = new Vector3(-8, 0, -8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_249;
		memset((&L_249), 0, sizeof(L_249));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_249), (-8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_249);
		// data.inPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_250 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_inPoss_1(L_250);
		// data.inPoss[0] = new Vector3(6, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_251 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_252 = L_251.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_253;
		memset((&L_253), 0, sizeof(L_253));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_253), (6.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_252);
		(L_252)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_253);
		// data.sekiPoss = new Vector3[3];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_254 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)3);
		(&V_0)->set_sekiPoss_2(L_254);
		// data.sekiPoss[0] = new Vector3(-6, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_255 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_256 = L_255.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_257;
		memset((&L_257), 0, sizeof(L_257));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_257), (-6.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_256);
		(L_256)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_257);
		// data.sekiPoss[1] = new Vector3(-2, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_258 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_259 = L_258.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_260;
		memset((&L_260), 0, sizeof(L_260));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_260), (-2.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_259);
		(L_259)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_260);
		// data.sekiPoss[2] = new Vector3(2, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_261 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_262 = L_261.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_263;
		memset((&L_263), 0, sizeof(L_263));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_263), (2.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_262);
		(L_262)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_263);
		// data.goalPos = new Vector3(8, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_264;
		memset((&L_264), 0, sizeof(L_264));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_264), (8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_264);
		// data.goalSize = new Vector3(3, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_265;
		memset((&L_265), 0, sizeof(L_265));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_265), (3.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_265);
		// data.wallPoss = new Vector3[4];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_266 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)4);
		(&V_0)->set_wallPoss_5(L_266);
		// data.wallPoss[0] = new Vector3(-6, 0, -2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_267 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_268 = L_267.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_269;
		memset((&L_269), 0, sizeof(L_269));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_269), (-6.0f), (0.0f), (-2.0f), /*hidden argument*/NULL);
		NullCheck(L_268);
		(L_268)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_269);
		// data.wallPoss[1] = new Vector3(-2, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_270 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_271 = L_270.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_272;
		memset((&L_272), 0, sizeof(L_272));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_272), (-2.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_271);
		(L_271)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_272);
		// data.wallPoss[2] = new Vector3(2, 0, -2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_273 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_274 = L_273.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_275;
		memset((&L_275), 0, sizeof(L_275));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_275), (2.0f), (0.0f), (-2.0f), /*hidden argument*/NULL);
		NullCheck(L_274);
		(L_274)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_275);
		// data.wallPoss[3] = new Vector3(6, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_276 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_277 = L_276.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_278;
		memset((&L_278), 0, sizeof(L_278));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_278), (6.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_277);
		(L_277)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_278);
		// data.wallSizes = new Vector3[4];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_279 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)4);
		(&V_0)->set_wallSizes_6(L_279);
		// data.wallSizes[0] = new Vector3(1, 0.1f, 15);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_280 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_281 = L_280.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_282;
		memset((&L_282), 0, sizeof(L_282));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_282), (1.0f), (0.100000001f), (15.0f), /*hidden argument*/NULL);
		NullCheck(L_281);
		(L_281)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_282);
		// data.wallSizes[1] = new Vector3(1, 0.1f, 15);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_283 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_284 = L_283.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_285;
		memset((&L_285), 0, sizeof(L_285));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_285), (1.0f), (0.100000001f), (15.0f), /*hidden argument*/NULL);
		NullCheck(L_284);
		(L_284)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_285);
		// data.wallSizes[2] = new Vector3(1, 0.1f, 15);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_286 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_287 = L_286.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_288;
		memset((&L_288), 0, sizeof(L_288));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_288), (1.0f), (0.100000001f), (15.0f), /*hidden argument*/NULL);
		NullCheck(L_287);
		(L_287)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_288);
		// data.wallSizes[3] = new Vector3(1, 0.1f, 15);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_289 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_290 = L_289.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_291;
		memset((&L_291), 0, sizeof(L_291));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_291), (1.0f), (0.100000001f), (15.0f), /*hidden argument*/NULL);
		NullCheck(L_290);
		(L_290)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_291);
		// break;
		goto IL_26b0;
	}

IL_0f22:
	{
		// data.playerPos = new Vector3(-8, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_292;
		memset((&L_292), 0, sizeof(L_292));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_292), (-8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_292);
		// data.inPoss = new Vector3[11];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_293 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)11));
		(&V_0)->set_inPoss_1(L_293);
		// data.inPoss[0] = new Vector3(-9, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_294 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_295 = L_294.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_296;
		memset((&L_296), 0, sizeof(L_296));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_296), (-9.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_295);
		(L_295)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_296);
		// data.inPoss[1] = new Vector3(-8, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_297 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_298 = L_297.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_299;
		memset((&L_299), 0, sizeof(L_299));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_299), (-8.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_298);
		(L_298)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_299);
		// data.inPoss[2] = new Vector3(-5, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_300 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_301 = L_300.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_302;
		memset((&L_302), 0, sizeof(L_302));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_302), (-5.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_301);
		(L_301)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_302);
		// data.inPoss[3] = new Vector3(-4, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_303 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_304 = L_303.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_305;
		memset((&L_305), 0, sizeof(L_305));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_305), (-4.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_304);
		(L_304)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_305);
		// data.inPoss[4] = new Vector3(9, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_306 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_307 = L_306.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_308;
		memset((&L_308), 0, sizeof(L_308));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_308), (9.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_307);
		(L_307)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_308);
		// data.inPoss[5] = new Vector3(9, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_309 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_310 = L_309.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_311;
		memset((&L_311), 0, sizeof(L_311));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_311), (9.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_310);
		(L_310)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_311);
		// data.inPoss[6] = new Vector3(9, 0, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_312 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_313 = L_312.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_314;
		memset((&L_314), 0, sizeof(L_314));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_314), (9.0f), (0.0f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_313);
		(L_313)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_314);
		// data.inPoss[7] = new Vector3(9, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_315 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_316 = L_315.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_317;
		memset((&L_317), 0, sizeof(L_317));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_317), (9.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_316);
		(L_316)->SetAt(static_cast<il2cpp_array_size_t>(7), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_317);
		// data.inPoss[8] = new Vector3(9, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_318 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_319 = L_318.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_320;
		memset((&L_320), 0, sizeof(L_320));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_320), (9.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_319);
		(L_319)->SetAt(static_cast<il2cpp_array_size_t>(8), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_320);
		// data.inPoss[9] = new Vector3(9, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_321 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_322 = L_321.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_323;
		memset((&L_323), 0, sizeof(L_323));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_323), (9.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_322);
		(L_322)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)9)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_323);
		// data.inPoss[10] = new Vector3(9, 0, -9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_324 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_325 = L_324.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_326;
		memset((&L_326), 0, sizeof(L_326));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_326), (9.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		NullCheck(L_325);
		(L_325)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)10)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_326);
		// data.sekiPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_327 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_sekiPoss_2(L_327);
		// data.goalPos = new Vector3(-8, 0, -8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_328;
		memset((&L_328), 0, sizeof(L_328));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_328), (-8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_328);
		// data.goalSize = new Vector3(3, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_329;
		memset((&L_329), 0, sizeof(L_329));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_329), (3.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_329);
		// data.wallPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_330 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_wallPoss_5(L_330);
		// data.wallPoss[0] = Vector3.zero;
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_331 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_332 = L_331.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_333;
		L_333 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		NullCheck(L_332);
		(L_332)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_333);
		// data.wallSizes = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_334 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_wallSizes_6(L_334);
		// data.wallSizes[0] = new Vector3(7, 0.1f, 7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_335 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_336 = L_335.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_337;
		memset((&L_337), 0, sizeof(L_337));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_337), (7.0f), (0.100000001f), (7.0f), /*hidden argument*/NULL);
		NullCheck(L_336);
		(L_336)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_337);
		// break;
		goto IL_26b0;
	}

IL_1140:
	{
		// data.playerPos = new Vector3(8, 0, -8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_338;
		memset((&L_338), 0, sizeof(L_338));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_338), (8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_338);
		// data.inPoss = new Vector3[10];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_339 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)10));
		(&V_0)->set_inPoss_1(L_339);
		// data.inPoss[0] = new Vector3(-4, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_340 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_341 = L_340.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_342;
		memset((&L_342), 0, sizeof(L_342));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_342), (-4.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_341);
		(L_341)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_342);
		// data.inPoss[1] = new Vector3(-6, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_343 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_344 = L_343.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_345;
		memset((&L_345), 0, sizeof(L_345));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_345), (-6.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_344);
		(L_344)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_345);
		// data.inPoss[2] = new Vector3(-8, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_346 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_347 = L_346.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_348;
		memset((&L_348), 0, sizeof(L_348));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_348), (-8.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_347);
		(L_347)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_348);
		// data.inPoss[3] = new Vector3(-8, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_349 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_350 = L_349.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_351;
		memset((&L_351), 0, sizeof(L_351));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_351), (-8.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_350);
		(L_350)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_351);
		// data.inPoss[4] = new Vector3(-8, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_352 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_353 = L_352.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_354;
		memset((&L_354), 0, sizeof(L_354));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_354), (-8.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_353);
		(L_353)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_354);
		// data.inPoss[5] = new Vector3(-8, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_355 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_356 = L_355.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_357;
		memset((&L_357), 0, sizeof(L_357));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_357), (-8.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_356);
		(L_356)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_357);
		// data.inPoss[6] = new Vector3(-8, 0, -2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_358 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_359 = L_358.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_360;
		memset((&L_360), 0, sizeof(L_360));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_360), (-8.0f), (0.0f), (-2.0f), /*hidden argument*/NULL);
		NullCheck(L_359);
		(L_359)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_360);
		// data.inPoss[7] = new Vector3(-8, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_361 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_362 = L_361.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_363;
		memset((&L_363), 0, sizeof(L_363));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_363), (-8.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_362);
		(L_362)->SetAt(static_cast<il2cpp_array_size_t>(7), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_363);
		// data.inPoss[8] = new Vector3(-4, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_364 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_365 = L_364.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_366;
		memset((&L_366), 0, sizeof(L_366));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_366), (-4.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_365);
		(L_365)->SetAt(static_cast<il2cpp_array_size_t>(8), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_366);
		// data.inPoss[9] = new Vector3(3, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_367 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_368 = L_367.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_369;
		memset((&L_369), 0, sizeof(L_369));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_369), (3.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_368);
		(L_368)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)9)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_369);
		// data.sekiPoss = new Vector3[6];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_370 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)6);
		(&V_0)->set_sekiPoss_2(L_370);
		// data.sekiPoss[0] = new Vector3(-8, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_371 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_372 = L_371.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_373;
		memset((&L_373), 0, sizeof(L_373));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_373), (-8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_372);
		(L_372)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_373);
		// data.sekiPoss[1] = new Vector3(-6, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_374 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_375 = L_374.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_376;
		memset((&L_376), 0, sizeof(L_376));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_376), (-6.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_375);
		(L_375)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_376);
		// data.sekiPoss[2] = new Vector3(-4, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_377 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_378 = L_377.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_379;
		memset((&L_379), 0, sizeof(L_379));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_379), (-4.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_378);
		(L_378)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_379);
		// data.sekiPoss[3] = new Vector3(-1, 0, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_380 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_381 = L_380.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_382;
		memset((&L_382), 0, sizeof(L_382));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_382), (-1.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_381);
		(L_381)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_382);
		// data.sekiPoss[4] = new Vector3(0, 0, -5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_383 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_384 = L_383.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_385;
		memset((&L_385), 0, sizeof(L_385));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_385), (0.0f), (0.0f), (-5.0f), /*hidden argument*/NULL);
		NullCheck(L_384);
		(L_384)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_385);
		// data.sekiPoss[5] = new Vector3(5, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_386 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_387 = L_386.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_388;
		memset((&L_388), 0, sizeof(L_388));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_388), (5.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_387);
		(L_387)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_388);
		// data.goalPos = new Vector3(-4, 0, 0);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_389;
		memset((&L_389), 0, sizeof(L_389));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_389), (-4.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_389);
		// data.goalSize = new Vector3(3, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_390;
		memset((&L_390), 0, sizeof(L_390));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_390), (3.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_390);
		// data.wallPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_391 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_wallPoss_5(L_391);
		// data.wallPoss[0] = new Vector3(0, 0, 7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_392 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_393 = L_392.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_394;
		memset((&L_394), 0, sizeof(L_394));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_394), (0.0f), (0.0f), (7.0f), /*hidden argument*/NULL);
		NullCheck(L_393);
		(L_393)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_394);
		// data.wallPoss[1] = new Vector3(6, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_395 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_396 = L_395.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_397;
		memset((&L_397), 0, sizeof(L_397));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_397), (6.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_396);
		(L_396)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_397);
		// data.wallSizes = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_398 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_wallSizes_6(L_398);
		// data.wallSizes[0] = new Vector3(0.5f, 0.1f, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_399 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_400 = L_399.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_401;
		memset((&L_401), 0, sizeof(L_401));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_401), (0.5f), (0.100000001f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_400);
		(L_400)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_401);
		// data.wallSizes[1] = new Vector3(0.5f, 0.1f, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_402 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_403 = L_402.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_404;
		memset((&L_404), 0, sizeof(L_404));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_404), (0.5f), (0.100000001f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_403);
		(L_403)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_404);
		// break;
		goto IL_26b0;
	}

IL_144c:
	{
		// data.playerPos = new Vector3(8, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_405;
		memset((&L_405), 0, sizeof(L_405));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_405), (8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_405);
		// data.inPoss = new Vector3[5];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_406 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)5);
		(&V_0)->set_inPoss_1(L_406);
		// data.inPoss[0] = new Vector3(0, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_407 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_408 = L_407.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_409;
		memset((&L_409), 0, sizeof(L_409));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_409), (0.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_408);
		(L_408)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_409);
		// data.inPoss[1] = new Vector3(0, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_410 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_411 = L_410.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_412;
		memset((&L_412), 0, sizeof(L_412));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_412), (0.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_411);
		(L_411)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_412);
		// data.inPoss[2] = new Vector3(8, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_413 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_414 = L_413.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_415;
		memset((&L_415), 0, sizeof(L_415));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_415), (8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_414);
		(L_414)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_415);
		// data.inPoss[3] = new Vector3(-8, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_416 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_417 = L_416.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_418;
		memset((&L_418), 0, sizeof(L_418));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_418), (-8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_417);
		(L_417)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_418);
		// data.inPoss[4] = new Vector3(-8, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_419 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_420 = L_419.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_421;
		memset((&L_421), 0, sizeof(L_421));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_421), (-8.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_420);
		(L_420)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_421);
		// data.sekiPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_422 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_sekiPoss_2(L_422);
		// data.sekiPoss[0] = Vector3.zero;
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_423 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_424 = L_423.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_425;
		L_425 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		NullCheck(L_424);
		(L_424)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_425);
		// data.sekiPoss[1] = new Vector3(-8, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_426 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_427 = L_426.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_428;
		memset((&L_428), 0, sizeof(L_428));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_428), (-8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_427);
		(L_427)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_428);
		// data.goalPos = new Vector3(-4, 0, 0);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_429;
		memset((&L_429), 0, sizeof(L_429));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_429), (-4.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_429);
		// data.goalSize = new Vector3(3, 1, 5);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_430;
		memset((&L_430), 0, sizeof(L_430));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_430), (3.0f), (1.0f), (5.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_430);
		// data.wallPoss = new Vector3[4];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_431 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)4);
		(&V_0)->set_wallPoss_5(L_431);
		// data.wallPoss[0] = new Vector3(4, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_432 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_433 = L_432.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_434;
		memset((&L_434), 0, sizeof(L_434));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_434), (4.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_433);
		(L_433)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_434);
		// data.wallPoss[1] = new Vector3(4, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_435 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_436 = L_435.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_437;
		memset((&L_437), 0, sizeof(L_437));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_437), (4.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_436);
		(L_436)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_437);
		// data.wallPoss[2] = new Vector3(-4, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_438 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_439 = L_438.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_440;
		memset((&L_440), 0, sizeof(L_440));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_440), (-4.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_439);
		(L_439)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_440);
		// data.wallPoss[3] = new Vector3(-4, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_441 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_442 = L_441.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_443;
		memset((&L_443), 0, sizeof(L_443));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_443), (-4.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_442);
		(L_442)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_443);
		// data.wallSizes = new Vector3[4];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_444 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)4);
		(&V_0)->set_wallSizes_6(L_444);
		// data.wallSizes[0] = new Vector3(3, 0.1f, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_445 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_446 = L_445.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_447;
		memset((&L_447), 0, sizeof(L_447));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_447), (3.0f), (0.100000001f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_446);
		(L_446)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_447);
		// data.wallSizes[1] = new Vector3(3, 0.1f, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_448 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_449 = L_448.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_450;
		memset((&L_450), 0, sizeof(L_450));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_450), (3.0f), (0.100000001f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_449);
		(L_449)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_450);
		// data.wallSizes[2] = new Vector3(3, 0.1f, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_451 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_452 = L_451.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_453;
		memset((&L_453), 0, sizeof(L_453));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_453), (3.0f), (0.100000001f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_452);
		(L_452)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_453);
		// data.wallSizes[3] = new Vector3(3, 0.1f, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_454 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_455 = L_454.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_456;
		memset((&L_456), 0, sizeof(L_456));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_456), (3.0f), (0.100000001f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_455);
		(L_455)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_456);
		// break;
		goto IL_26b0;
	}

IL_16a7:
	{
		// data.playerPos = new Vector3(0, 0, 9);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_457;
		memset((&L_457), 0, sizeof(L_457));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_457), (0.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_457);
		// data.inPoss = new Vector3[6];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_458 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)6);
		(&V_0)->set_inPoss_1(L_458);
		// data.inPoss[0] = new Vector3(2, 0, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_459 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_460 = L_459.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_461;
		memset((&L_461), 0, sizeof(L_461));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_461), (2.0f), (0.0f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_460);
		(L_460)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_461);
		// data.inPoss[1] = new Vector3(-4, 0, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_462 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_463 = L_462.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_464;
		memset((&L_464), 0, sizeof(L_464));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_464), (-4.0f), (0.0f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_463);
		(L_463)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_464);
		// data.inPoss[2] = new Vector3(4, 0, -1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_465 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_466 = L_465.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_467;
		memset((&L_467), 0, sizeof(L_467));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_467), (4.0f), (0.0f), (-1.0f), /*hidden argument*/NULL);
		NullCheck(L_466);
		(L_466)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_467);
		// data.inPoss[3] = new Vector3(-2, 0, -1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_468 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_469 = L_468.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_470;
		memset((&L_470), 0, sizeof(L_470));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_470), (-2.0f), (0.0f), (-1.0f), /*hidden argument*/NULL);
		NullCheck(L_469);
		(L_469)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_470);
		// data.inPoss[4] = new Vector3(2, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_471 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_472 = L_471.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_473;
		memset((&L_473), 0, sizeof(L_473));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_473), (2.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_472);
		(L_472)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_473);
		// data.inPoss[5] = new Vector3(-2, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_474 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_475 = L_474.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_476;
		memset((&L_476), 0, sizeof(L_476));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_476), (-2.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_475);
		(L_475)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_476);
		// data.sekiPoss = new Vector3[6];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_477 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)6);
		(&V_0)->set_sekiPoss_2(L_477);
		// data.sekiPoss[0] = new Vector3(2, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_478 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_479 = L_478.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_480;
		memset((&L_480), 0, sizeof(L_480));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_480), (2.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_479);
		(L_479)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_480);
		// data.sekiPoss[1] = new Vector3(-2, 0, 8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_481 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_482 = L_481.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_483;
		memset((&L_483), 0, sizeof(L_483));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_483), (-2.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		NullCheck(L_482);
		(L_482)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_483);
		// data.sekiPoss[2] = new Vector3(4, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_484 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_485 = L_484.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_486;
		memset((&L_486), 0, sizeof(L_486));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_486), (4.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_485);
		(L_485)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_486);
		// data.sekiPoss[3] = new Vector3(-4, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_487 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_488 = L_487.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_489;
		memset((&L_489), 0, sizeof(L_489));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_489), (-4.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_488);
		(L_488)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_489);
		// data.sekiPoss[4] = new Vector3(4, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_490 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_491 = L_490.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_492;
		memset((&L_492), 0, sizeof(L_492));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_492), (4.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_491);
		(L_491)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_492);
		// data.sekiPoss[5] = new Vector3(-4, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_493 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_494 = L_493.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_495;
		memset((&L_495), 0, sizeof(L_495));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_495), (-4.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_494);
		(L_494)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_495);
		// data.goalPos = new Vector3(0, 0, -9);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_496;
		memset((&L_496), 0, sizeof(L_496));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_496), (0.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_496);
		// data.goalSize = new Vector3(19, 1, 1);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_497;
		memset((&L_497), 0, sizeof(L_497));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_497), (19.0f), (1.0f), (1.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_497);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_498 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_498);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_499 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_499);
		// break;
		goto IL_26b0;
	}

IL_18b1:
	{
		// data.playerPos = Vector3.zero;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_500;
		L_500 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_500);
		// data.inPoss = new Vector3[7];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_501 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)7);
		(&V_0)->set_inPoss_1(L_501);
		// data.inPoss[0] = new Vector3(9, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_502 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_503 = L_502.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_504;
		memset((&L_504), 0, sizeof(L_504));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_504), (9.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_503);
		(L_503)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_504);
		// data.inPoss[1] = new Vector3(-5, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_505 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_506 = L_505.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_507;
		memset((&L_507), 0, sizeof(L_507));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_507), (-5.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_506);
		(L_506)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_507);
		// data.inPoss[2] = new Vector3(6, 0, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_508 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_509 = L_508.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_510;
		memset((&L_510), 0, sizeof(L_510));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_510), (6.0f), (0.0f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_509);
		(L_509)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_510);
		// data.inPoss[3] = new Vector3(-3, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_511 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_512 = L_511.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_513;
		memset((&L_513), 0, sizeof(L_513));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_513), (-3.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_512);
		(L_512)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_513);
		// data.inPoss[4] = new Vector3(-6, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_514 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_515 = L_514.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_516;
		memset((&L_516), 0, sizeof(L_516));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_516), (-6.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_515);
		(L_515)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_516);
		// data.inPoss[5] = new Vector3(-1, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_517 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_518 = L_517.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_519;
		memset((&L_519), 0, sizeof(L_519));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_519), (-1.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_518);
		(L_518)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_519);
		// data.inPoss[6] = new Vector3(4, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_520 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_521 = L_520.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_522;
		memset((&L_522), 0, sizeof(L_522));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_522), (4.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_521);
		(L_521)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_522);
		// data.sekiPoss = new Vector3[7];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_523 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)7);
		(&V_0)->set_sekiPoss_2(L_523);
		// data.sekiPoss[0] = new Vector3(-7, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_524 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_525 = L_524.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_526;
		memset((&L_526), 0, sizeof(L_526));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_526), (-7.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_525);
		(L_525)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_526);
		// data.sekiPoss[1] = new Vector3(-3, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_527 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_528 = L_527.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_529;
		memset((&L_529), 0, sizeof(L_529));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_529), (-3.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_528);
		(L_528)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_529);
		// data.sekiPoss[2] = new Vector3(0, 0, 3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_530 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_531 = L_530.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_532;
		memset((&L_532), 0, sizeof(L_532));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_532), (0.0f), (0.0f), (3.0f), /*hidden argument*/NULL);
		NullCheck(L_531);
		(L_531)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_532);
		// data.sekiPoss[3] = new Vector3(8, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_533 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_534 = L_533.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_535;
		memset((&L_535), 0, sizeof(L_535));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_535), (8.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_534);
		(L_534)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_535);
		// data.sekiPoss[4] = new Vector3(-1, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_536 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_537 = L_536.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_538;
		memset((&L_538), 0, sizeof(L_538));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_538), (-1.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_537);
		(L_537)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_538);
		// data.sekiPoss[5] = new Vector3(-4, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_539 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_540 = L_539.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_541;
		memset((&L_541), 0, sizeof(L_541));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_541), (-4.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_540);
		(L_540)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_541);
		// data.sekiPoss[6] = new Vector3(-7, 0, -9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_542 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_543 = L_542.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_544;
		memset((&L_544), 0, sizeof(L_544));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_544), (-7.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		NullCheck(L_543);
		(L_543)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_544);
		// data.goalPos = new Vector3(2, 0, 6);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_545;
		memset((&L_545), 0, sizeof(L_545));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_545), (2.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_545);
		// data.goalSize = new Vector3(1, 1, 1);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_546;
		memset((&L_546), 0, sizeof(L_546));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_546), (1.0f), (1.0f), (1.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_546);
		// data.wallPoss = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_547 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallPoss_5(L_547);
		// data.wallSizes = new Vector3[0];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_548 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)0);
		(&V_0)->set_wallSizes_6(L_548);
		// break;
		goto IL_26b0;
	}

IL_1aec:
	{
		// data.playerPos = new Vector3(0, 0, 8.5f);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_549;
		memset((&L_549), 0, sizeof(L_549));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_549), (0.0f), (0.0f), (8.5f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_549);
		// data.inPoss = new Vector3[25];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_550 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)25));
		(&V_0)->set_inPoss_1(L_550);
		// data.sekiPoss = new Vector3[25];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_551 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)25));
		(&V_0)->set_sekiPoss_2(L_551);
		// for (int i = 0; i < 19; i++)
		V_2 = 0;
		goto IL_1b6b;
	}

IL_1b27:
	{
		// data.inPoss[i] = new Vector3(9, 0, i - 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_552 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_553 = L_552.get_inPoss_1();
		int32_t L_554 = V_2;
		int32_t L_555 = V_2;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_556;
		memset((&L_556), 0, sizeof(L_556));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_556), (9.0f), (0.0f), ((float)((float)((int32_t)il2cpp_codegen_subtract((int32_t)L_555, (int32_t)((int32_t)9))))), /*hidden argument*/NULL);
		NullCheck(L_553);
		(L_553)->SetAt(static_cast<il2cpp_array_size_t>(L_554), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_556);
		// data.sekiPoss[i] = new Vector3(-9, 0, i - 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_557 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_558 = L_557.get_sekiPoss_2();
		int32_t L_559 = V_2;
		int32_t L_560 = V_2;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_561;
		memset((&L_561), 0, sizeof(L_561));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_561), (-9.0f), (0.0f), ((float)((float)((int32_t)il2cpp_codegen_subtract((int32_t)L_560, (int32_t)((int32_t)9))))), /*hidden argument*/NULL);
		NullCheck(L_558);
		(L_558)->SetAt(static_cast<il2cpp_array_size_t>(L_559), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_561);
		// for (int i = 0; i < 19; i++)
		int32_t L_562 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_562, (int32_t)1));
	}

IL_1b6b:
	{
		// for (int i = 0; i < 19; i++)
		int32_t L_563 = V_2;
		if ((((int32_t)L_563) < ((int32_t)((int32_t)19))))
		{
			goto IL_1b27;
		}
	}
	{
		// data.inPoss[19] = new Vector3(-4, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_564 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_565 = L_564.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_566;
		memset((&L_566), 0, sizeof(L_566));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_566), (-4.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_565);
		(L_565)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)19)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_566);
		// data.inPoss[20] = new Vector3(4, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_567 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_568 = L_567.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_569;
		memset((&L_569), 0, sizeof(L_569));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_569), (4.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_568);
		(L_568)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)20)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_569);
		// data.inPoss[21] = new Vector3(4, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_570 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_571 = L_570.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_572;
		memset((&L_572), 0, sizeof(L_572));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_572), (4.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_571);
		(L_571)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)21)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_572);
		// data.inPoss[22] = new Vector3(-4, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_573 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_574 = L_573.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_575;
		memset((&L_575), 0, sizeof(L_575));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_575), (-4.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_574);
		(L_574)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)22)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_575);
		// data.inPoss[23] = new Vector3(-4, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_576 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_577 = L_576.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_578;
		memset((&L_578), 0, sizeof(L_578));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_578), (-4.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_577);
		(L_577)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)23)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_578);
		// data.inPoss[24] = new Vector3(0, 0, -4.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_579 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_580 = L_579.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_581;
		memset((&L_581), 0, sizeof(L_581));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_581), (0.0f), (0.0f), (-4.5f), /*hidden argument*/NULL);
		NullCheck(L_580);
		(L_580)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)24)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_581);
		// data.sekiPoss[19] = new Vector3(-4, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_582 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_583 = L_582.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_584;
		memset((&L_584), 0, sizeof(L_584));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_584), (-4.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_583);
		(L_583)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)19)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_584);
		// data.sekiPoss[20] = new Vector3(4, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_585 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_586 = L_585.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_587;
		memset((&L_587), 0, sizeof(L_587));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_587), (4.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_586);
		(L_586)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)20)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_587);
		// data.sekiPoss[21] = new Vector3(2, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_588 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_589 = L_588.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_590;
		memset((&L_590), 0, sizeof(L_590));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_590), (2.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_589);
		(L_589)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)21)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_590);
		// data.sekiPoss[22] = new Vector3(-2, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_591 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_592 = L_591.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_593;
		memset((&L_593), 0, sizeof(L_593));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_593), (-2.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_592);
		(L_592)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)22)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_593);
		// data.sekiPoss[23] = new Vector3(4, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_594 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_595 = L_594.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_596;
		memset((&L_596), 0, sizeof(L_596));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_596), (4.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_595);
		(L_595)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)23)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_596);
		// data.sekiPoss[24] = new Vector3(0, 0, -7.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_597 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_598 = L_597.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_599;
		memset((&L_599), 0, sizeof(L_599));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_599), (0.0f), (0.0f), (-7.5f), /*hidden argument*/NULL);
		NullCheck(L_598);
		(L_598)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)24)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_599);
		// data.goalPos = new Vector3(0, 0, -6);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_600;
		memset((&L_600), 0, sizeof(L_600));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_600), (0.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_600);
		// data.goalSize = new Vector3(1, 1, 1);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_601;
		memset((&L_601), 0, sizeof(L_601));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_601), (1.0f), (1.0f), (1.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_601);
		// data.wallPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_602 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_wallPoss_5(L_602);
		// data.wallPoss[0] = new Vector3(8.25f, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_603 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_604 = L_603.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_605;
		memset((&L_605), 0, sizeof(L_605));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_605), (8.25f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_604);
		(L_604)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_605);
		// data.wallPoss[1] = new Vector3(-8.25f, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_606 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_607 = L_606.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_608;
		memset((&L_608), 0, sizeof(L_608));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_608), (-8.25f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_607);
		(L_607)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_608);
		// data.wallSizes = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_609 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_wallSizes_6(L_609);
		// data.wallSizes[0] = new Vector3(0.5f, 0.1f, 19);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_610 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_611 = L_610.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_612;
		memset((&L_612), 0, sizeof(L_612));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_612), (0.5f), (0.100000001f), (19.0f), /*hidden argument*/NULL);
		NullCheck(L_611);
		(L_611)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_612);
		// data.wallSizes[1] = new Vector3(0.5f, 0.1f, 19);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_613 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_614 = L_613.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_615;
		memset((&L_615), 0, sizeof(L_615));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_615), (0.5f), (0.100000001f), (19.0f), /*hidden argument*/NULL);
		NullCheck(L_614);
		(L_614)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_615);
		// break;
		goto IL_26b0;
	}

IL_1dd1:
	{
		// data.playerPos = new Vector3(-8, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_616;
		memset((&L_616), 0, sizeof(L_616));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_616), (-8.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_616);
		// data.inPoss = new Vector3[6];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_617 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)6);
		(&V_0)->set_inPoss_1(L_617);
		// data.inPoss[0] = new Vector3(-1, 0, 6.25f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_618 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_619 = L_618.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_620;
		memset((&L_620), 0, sizeof(L_620));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_620), (-1.0f), (0.0f), (6.25f), /*hidden argument*/NULL);
		NullCheck(L_619);
		(L_619)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_620);
		// data.inPoss[1] = new Vector3(7, 0, 7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_621 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_622 = L_621.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_623;
		memset((&L_623), 0, sizeof(L_623));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_623), (7.0f), (0.0f), (7.0f), /*hidden argument*/NULL);
		NullCheck(L_622);
		(L_622)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_623);
		// data.inPoss[2] = new Vector3(-4, 0, 3.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_624 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_625 = L_624.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_626;
		memset((&L_626), 0, sizeof(L_626));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_626), (-4.0f), (0.0f), (3.5f), /*hidden argument*/NULL);
		NullCheck(L_625);
		(L_625)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_626);
		// data.inPoss[3] = new Vector3(6, 0, 2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_627 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_628 = L_627.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_629;
		memset((&L_629), 0, sizeof(L_629));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_629), (6.0f), (0.0f), (2.0f), /*hidden argument*/NULL);
		NullCheck(L_628);
		(L_628)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_629);
		// data.inPoss[4] = new Vector3(-1, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_630 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_631 = L_630.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_632;
		memset((&L_632), 0, sizeof(L_632));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_632), (-1.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_631);
		(L_631)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_632);
		// data.inPoss[5] = new Vector3(8, 0, -8);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_633 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_634 = L_633.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_635;
		memset((&L_635), 0, sizeof(L_635));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_635), (8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		NullCheck(L_634);
		(L_634)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_635);
		// data.sekiPoss = new Vector3[4];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_636 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)4);
		(&V_0)->set_sekiPoss_2(L_636);
		// data.sekiPoss[0] = new Vector3(2, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_637 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_638 = L_637.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_639;
		memset((&L_639), 0, sizeof(L_639));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_639), (2.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_638);
		(L_638)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_639);
		// data.sekiPoss[1] = new Vector3(-9, 0, 5.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_640 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_641 = L_640.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_642;
		memset((&L_642), 0, sizeof(L_642));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_642), (-9.0f), (0.0f), (5.5f), /*hidden argument*/NULL);
		NullCheck(L_641);
		(L_641)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_642);
		// data.sekiPoss[2] = new Vector3(-7.5f, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_643 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_644 = L_643.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_645;
		memset((&L_645), 0, sizeof(L_645));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_645), (-7.5f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_644);
		(L_644)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_645);
		// data.sekiPoss[3] = new Vector3(5, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_646 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_647 = L_646.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_648;
		memset((&L_648), 0, sizeof(L_648));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_648), (5.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_647);
		(L_647)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_648);
		// data.goalPos = new Vector3(-8, 0, -8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_649;
		memset((&L_649), 0, sizeof(L_649));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_649), (-8.0f), (0.0f), (-8.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_649);
		// data.goalSize = new Vector3(3, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_650;
		memset((&L_650), 0, sizeof(L_650));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_650), (3.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_650);
		// data.wallPoss = new Vector3[3];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_651 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)3);
		(&V_0)->set_wallPoss_5(L_651);
		// data.wallPoss[0] = new Vector3(-5.5f, 0, 6.25f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_652 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_653 = L_652.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_654;
		memset((&L_654), 0, sizeof(L_654));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_654), (-5.5f), (0.0f), (6.25f), /*hidden argument*/NULL);
		NullCheck(L_653);
		(L_653)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_654);
		// data.wallPoss[1] = new Vector3(-5.5f, 0, -6.25f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_655 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_656 = L_655.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_657;
		memset((&L_657), 0, sizeof(L_657));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_657), (-5.5f), (0.0f), (-6.25f), /*hidden argument*/NULL);
		NullCheck(L_656);
		(L_656)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_657);
		// data.wallPoss[2] = new Vector3(2, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_658 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_659 = L_658.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_660;
		memset((&L_660), 0, sizeof(L_660));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_660), (2.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_659);
		(L_659)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_660);
		// data.wallSizes = new Vector3[3];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_661 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)3);
		(&V_0)->set_wallSizes_6(L_661);
		// data.wallSizes[0] = new Vector3(8, 0.1f, 0.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_662 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_663 = L_662.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_664;
		memset((&L_664), 0, sizeof(L_664));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_664), (8.0f), (0.100000001f), (0.5f), /*hidden argument*/NULL);
		NullCheck(L_663);
		(L_663)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_664);
		// data.wallSizes[1] = new Vector3(8, 0.1f, 0.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_665 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_666 = L_665.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_667;
		memset((&L_667), 0, sizeof(L_667));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_667), (8.0f), (0.100000001f), (0.5f), /*hidden argument*/NULL);
		NullCheck(L_666);
		(L_666)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_667);
		// data.wallSizes[2] = new Vector3(15, 0.1f, 0.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_668 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_669 = L_668.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_670;
		memset((&L_670), 0, sizeof(L_670));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_670), (15.0f), (0.100000001f), (0.5f), /*hidden argument*/NULL);
		NullCheck(L_669);
		(L_669)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_670);
		// break;
		goto IL_26b0;
	}

IL_205b:
	{
		// data.playerPos = new Vector3(-2, 0, 7.75f);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_671;
		memset((&L_671), 0, sizeof(L_671));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_671), (-2.0f), (0.0f), (7.75f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_671);
		// data.inPoss = new Vector3[10];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_672 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)10));
		(&V_0)->set_inPoss_1(L_672);
		// data.inPoss[0] = new Vector3(-9, 0, 9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_673 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_674 = L_673.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_675;
		memset((&L_675), 0, sizeof(L_675));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_675), (-9.0f), (0.0f), (9.0f), /*hidden argument*/NULL);
		NullCheck(L_674);
		(L_674)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_675);
		// data.inPoss[1] = new Vector3(-6, 0, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_676 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_677 = L_676.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_678;
		memset((&L_678), 0, sizeof(L_678));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_678), (-6.0f), (0.0f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_677);
		(L_677)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_678);
		// data.inPoss[2] = new Vector3(-7, 0, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_679 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_680 = L_679.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_681;
		memset((&L_681), 0, sizeof(L_681));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_681), (-7.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_680);
		(L_680)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_681);
		// data.inPoss[3] = new Vector3(-2, 0, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_682 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_683 = L_682.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_684;
		memset((&L_684), 0, sizeof(L_684));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_684), (-2.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_683);
		(L_683)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_684);
		// data.inPoss[4] = new Vector3(-4, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_685 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_686 = L_685.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_687;
		memset((&L_687), 0, sizeof(L_687));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_687), (-4.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_686);
		(L_686)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_687);
		// data.inPoss[5] = new Vector3(-9, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_688 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_689 = L_688.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_690;
		memset((&L_690), 0, sizeof(L_690));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_690), (-9.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_689);
		(L_689)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_690);
		// data.inPoss[6] = new Vector3(1, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_691 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_692 = L_691.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_693;
		memset((&L_693), 0, sizeof(L_693));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_693), (1.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_692);
		(L_692)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_693);
		// data.inPoss[7] = new Vector3(3, 0, -3);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_694 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_695 = L_694.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_696;
		memset((&L_696), 0, sizeof(L_696));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_696), (3.0f), (0.0f), (-3.0f), /*hidden argument*/NULL);
		NullCheck(L_695);
		(L_695)->SetAt(static_cast<il2cpp_array_size_t>(7), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_696);
		// data.inPoss[8] = new Vector3(7, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_697 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_698 = L_697.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_699;
		memset((&L_699), 0, sizeof(L_699));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_699), (7.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_698);
		(L_698)->SetAt(static_cast<il2cpp_array_size_t>(8), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_699);
		// data.inPoss[9] = new Vector3(7, 0, -1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_700 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_701 = L_700.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_702;
		memset((&L_702), 0, sizeof(L_702));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_702), (7.0f), (0.0f), (-1.0f), /*hidden argument*/NULL);
		NullCheck(L_701);
		(L_701)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)9)), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_702);
		// data.sekiPoss = new Vector3[8];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_703 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)8);
		(&V_0)->set_sekiPoss_2(L_703);
		// data.sekiPoss[0] = new Vector3(-3, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_704 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_705 = L_704.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_706;
		memset((&L_706), 0, sizeof(L_706));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_706), (-3.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_705);
		(L_705)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_706);
		// data.sekiPoss[1] = new Vector3(-7, 0, -1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_707 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_708 = L_707.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_709;
		memset((&L_709), 0, sizeof(L_709));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_709), (-7.0f), (0.0f), (-1.0f), /*hidden argument*/NULL);
		NullCheck(L_708);
		(L_708)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_709);
		// data.sekiPoss[2] = new Vector3(-2, 0, -2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_710 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_711 = L_710.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_712;
		memset((&L_712), 0, sizeof(L_712));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_712), (-2.0f), (0.0f), (-2.0f), /*hidden argument*/NULL);
		NullCheck(L_711);
		(L_711)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_712);
		// data.sekiPoss[3] = new Vector3(-2, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_713 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_714 = L_713.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_715;
		memset((&L_715), 0, sizeof(L_715));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_715), (-2.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_714);
		(L_714)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_715);
		// data.sekiPoss[4] = new Vector3(-1, 0, -7);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_716 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_717 = L_716.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_718;
		memset((&L_718), 0, sizeof(L_718));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_718), (-1.0f), (0.0f), (-7.0f), /*hidden argument*/NULL);
		NullCheck(L_717);
		(L_717)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_718);
		// data.sekiPoss[5] = new Vector3(3, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_719 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_720 = L_719.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_721;
		memset((&L_721), 0, sizeof(L_721));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_721), (3.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_720);
		(L_720)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_721);
		// data.sekiPoss[6] = new Vector3(5, 0, -9);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_722 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_723 = L_722.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_724;
		memset((&L_724), 0, sizeof(L_724));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_724), (5.0f), (0.0f), (-9.0f), /*hidden argument*/NULL);
		NullCheck(L_723);
		(L_723)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_724);
		// data.sekiPoss[7] = new Vector3(7, 0, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_725 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_726 = L_725.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_727;
		memset((&L_727), 0, sizeof(L_727));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_727), (7.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_726);
		(L_726)->SetAt(static_cast<il2cpp_array_size_t>(7), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_727);
		// data.goalPos = new Vector3(2.25f, 0, 7.5f);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_728;
		memset((&L_728), 0, sizeof(L_728));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_728), (2.25f), (0.0f), (7.5f), /*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_728);
		// data.goalSize = new Vector3(4, 1, 4);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_729;
		memset((&L_729), 0, sizeof(L_729));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_729), (4.0f), (1.0f), (4.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_729);
		// data.wallPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_730 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_wallPoss_5(L_730);
		// data.wallPoss[0] = new Vector3(0, 0, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_731 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_732 = L_731.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_733;
		memset((&L_733), 0, sizeof(L_733));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_733), (0.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_732);
		(L_732)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_733);
		// data.wallPoss[1] = Vector3.zero;
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_734 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_735 = L_734.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_736;
		L_736 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		NullCheck(L_735);
		(L_735)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_736);
		// data.wallSizes = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_737 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_wallSizes_6(L_737);
		// data.wallSizes[0] = new Vector3(0.5f, 0.1f, 17);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_738 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_739 = L_738.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_740;
		memset((&L_740), 0, sizeof(L_740));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_740), (0.5f), (0.100000001f), (17.0f), /*hidden argument*/NULL);
		NullCheck(L_739);
		(L_739)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_740);
		// data.wallSizes[1] = new Vector3(15, 0.1f, 0.5f);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_741 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_742 = L_741.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_743;
		memset((&L_743), 0, sizeof(L_743));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_743), (15.0f), (0.100000001f), (0.5f), /*hidden argument*/NULL);
		NullCheck(L_742);
		(L_742)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_743);
		// break;
		goto IL_26b0;
	}

IL_2398:
	{
		// data.playerPos = new Vector3(0, 0, 8);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_744;
		memset((&L_744), 0, sizeof(L_744));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_744), (0.0f), (0.0f), (8.0f), /*hidden argument*/NULL);
		(&V_0)->set_playerPos_0(L_744);
		// data.inPoss = new Vector3[2];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_745 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)2);
		(&V_0)->set_inPoss_1(L_745);
		// data.inPoss[0] = new Vector3(9, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_746 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_747 = L_746.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_748;
		memset((&L_748), 0, sizeof(L_748));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_748), (9.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_747);
		(L_747)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_748);
		// data.inPoss[1] = new Vector3(0, 0, -5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_749 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_750 = L_749.get_inPoss_1();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_751;
		memset((&L_751), 0, sizeof(L_751));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_751), (0.0f), (0.0f), (-5.0f), /*hidden argument*/NULL);
		NullCheck(L_750);
		(L_750)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_751);
		// data.sekiPoss = new Vector3[1];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_752 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)1);
		(&V_0)->set_sekiPoss_2(L_752);
		// data.sekiPoss[0] = new Vector3(-9, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_753 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_754 = L_753.get_sekiPoss_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_755;
		memset((&L_755), 0, sizeof(L_755));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_755), (-9.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_754);
		(L_754)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_755);
		// data.goalPos = Vector3.zero;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_756;
		L_756 = Vector3_get_zero_m1A8F7993167785F750B6B01762D22C2597C84EF6(/*hidden argument*/NULL);
		(&V_0)->set_goalPos_3(L_756);
		// data.goalSize = new Vector3(3, 1, 3);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_757;
		memset((&L_757), 0, sizeof(L_757));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_757), (3.0f), (1.0f), (3.0f), /*hidden argument*/NULL);
		(&V_0)->set_goalSize_4(L_757);
		// data.wallPoss = new Vector3[9];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_758 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)9));
		(&V_0)->set_wallPoss_5(L_758);
		// data.wallPoss[0] = new Vector3(0, 0, -2);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_759 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_760 = L_759.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_761;
		memset((&L_761), 0, sizeof(L_761));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_761), (0.0f), (0.0f), (-2.0f), /*hidden argument*/NULL);
		NullCheck(L_760);
		(L_760)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_761);
		// data.wallPoss[1] = new Vector3(2, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_762 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_763 = L_762.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_764;
		memset((&L_764), 0, sizeof(L_764));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_764), (2.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_763);
		(L_763)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_764);
		// data.wallPoss[2] = new Vector3(-2, 0, 0);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_765 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_766 = L_765.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_767;
		memset((&L_767), 0, sizeof(L_767));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_767), (-2.0f), (0.0f), (0.0f), /*hidden argument*/NULL);
		NullCheck(L_766);
		(L_766)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_767);
		// data.wallPoss[3] = new Vector3(0, 0, 6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_768 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_769 = L_768.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_770;
		memset((&L_770), 0, sizeof(L_770));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_770), (0.0f), (0.0f), (6.0f), /*hidden argument*/NULL);
		NullCheck(L_769);
		(L_769)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_770);
		// data.wallPoss[4] = new Vector3(0, 0, -6);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_771 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_772 = L_771.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_773;
		memset((&L_773), 0, sizeof(L_773));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_773), (0.0f), (0.0f), (-6.0f), /*hidden argument*/NULL);
		NullCheck(L_772);
		(L_772)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_773);
		// data.wallPoss[5] = new Vector3(6, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_774 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_775 = L_774.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_776;
		memset((&L_776), 0, sizeof(L_776));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_776), (6.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_775);
		(L_775)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_776);
		// data.wallPoss[6] = new Vector3(6, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_777 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_778 = L_777.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_779;
		memset((&L_779), 0, sizeof(L_779));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_779), (6.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_778);
		(L_778)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_779);
		// data.wallPoss[7] = new Vector3(-6, 0, 4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_780 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_781 = L_780.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_782;
		memset((&L_782), 0, sizeof(L_782));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_782), (-6.0f), (0.0f), (4.0f), /*hidden argument*/NULL);
		NullCheck(L_781);
		(L_781)->SetAt(static_cast<il2cpp_array_size_t>(7), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_782);
		// data.wallPoss[8] = new Vector3(-6, 0, -4);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_783 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_784 = L_783.get_wallPoss_5();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_785;
		memset((&L_785), 0, sizeof(L_785));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_785), (-6.0f), (0.0f), (-4.0f), /*hidden argument*/NULL);
		NullCheck(L_784);
		(L_784)->SetAt(static_cast<il2cpp_array_size_t>(8), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_785);
		// data.wallSizes = new Vector3[9];
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_786 = (Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, (uint32_t)((int32_t)9));
		(&V_0)->set_wallSizes_6(L_786);
		// data.wallSizes[0] = new Vector3(3, 0.1f, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_787 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_788 = L_787.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_789;
		memset((&L_789), 0, sizeof(L_789));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_789), (3.0f), (0.100000001f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_788);
		(L_788)->SetAt(static_cast<il2cpp_array_size_t>(0), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_789);
		// data.wallSizes[1] = new Vector3(1, 0.1f, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_790 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_791 = L_790.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_792;
		memset((&L_792), 0, sizeof(L_792));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_792), (1.0f), (0.100000001f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_791);
		(L_791)->SetAt(static_cast<il2cpp_array_size_t>(1), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_792);
		// data.wallSizes[2] = new Vector3(1, 0.1f, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_793 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_794 = L_793.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_795;
		memset((&L_795), 0, sizeof(L_795));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_795), (1.0f), (0.100000001f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_794);
		(L_794)->SetAt(static_cast<il2cpp_array_size_t>(2), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_795);
		// data.wallSizes[3] = new Vector3(11, 0.1f, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_796 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_797 = L_796.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_798;
		memset((&L_798), 0, sizeof(L_798));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_798), (11.0f), (0.100000001f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_797);
		(L_797)->SetAt(static_cast<il2cpp_array_size_t>(3), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_798);
		// data.wallSizes[4] = new Vector3(11, 0.1f, 1);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_799 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_800 = L_799.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_801;
		memset((&L_801), 0, sizeof(L_801));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_801), (11.0f), (0.100000001f), (1.0f), /*hidden argument*/NULL);
		NullCheck(L_800);
		(L_800)->SetAt(static_cast<il2cpp_array_size_t>(4), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_801);
		// data.wallSizes[5] = new Vector3(1, 0.1f, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_802 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_803 = L_802.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_804;
		memset((&L_804), 0, sizeof(L_804));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_804), (1.0f), (0.100000001f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_803);
		(L_803)->SetAt(static_cast<il2cpp_array_size_t>(5), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_804);
		// data.wallSizes[6] = new Vector3(1, 0.1f, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_805 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_806 = L_805.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_807;
		memset((&L_807), 0, sizeof(L_807));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_807), (1.0f), (0.100000001f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_806);
		(L_806)->SetAt(static_cast<il2cpp_array_size_t>(6), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_807);
		// data.wallSizes[7] = new Vector3(1, 0.1f, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_808 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_809 = L_808.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_810;
		memset((&L_810), 0, sizeof(L_810));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_810), (1.0f), (0.100000001f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_809);
		(L_809)->SetAt(static_cast<il2cpp_array_size_t>(7), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_810);
		// data.wallSizes[8] = new Vector3(1, 0.1f, 5);
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_811 = V_0;
		Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4* L_812 = L_811.get_wallSizes_6();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_813;
		memset((&L_813), 0, sizeof(L_813));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_813), (1.0f), (0.100000001f), (5.0f), /*hidden argument*/NULL);
		NullCheck(L_812);
		(L_812)->SetAt(static_cast<il2cpp_array_size_t>(8), (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E )L_813);
	}

IL_26b0:
	{
		// return data;
		stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512  L_814 = V_0;
		return L_814;
	}
}
// System.Void datas::goStage(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void datas_goStage_m25C4F57045373560EC4458957FEF4E28A2E43D09 (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * __this, int32_t ___n0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// currentStageNum = n;
		int32_t L_0 = ___n0;
		((datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_StaticFields*)il2cpp_codegen_static_fields_for(datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0_il2cpp_TypeInfo_var))->set_currentStageNum_0(L_0);
		// SceneManager.LoadScene("Main");
		IL2CPP_RUNTIME_CLASS_INIT(SceneManager_tEC9D10ECC0377F8AE5AEEB5A789FFD24364440FA_il2cpp_TypeInfo_var);
		SceneManager_LoadScene_m7DAF30213E99396ECBDB1BD40CC34CCF36902092(_stringLiteral3F86111F44D66C543B732847E04E3C2A5B38BB3D, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void datas::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void datas__ctor_mE6BBE9C089031DEEA352E2A6D402729C8D064E8D (datas_tCF0039EC221EA6FC302E1B88E5F95D71AC0E96C0 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: stageData
IL2CPP_EXTERN_C void stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshal_pinvoke(const stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512& unmarshaled, stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_pinvoke& marshaled)
{
	marshaled.___playerPos_0 = unmarshaled.get_playerPos_0();
	if (unmarshaled.get_inPoss_1() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_inPoss_Length = (unmarshaled.get_inPoss_1())->max_length;
		marshaled.___inPoss_1 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_inPoss_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_inPoss_Length); i++)
		{
			(marshaled.___inPoss_1)[i] = (unmarshaled.get_inPoss_1())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___inPoss_1 = NULL;
	}
	if (unmarshaled.get_sekiPoss_2() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_sekiPoss_Length = (unmarshaled.get_sekiPoss_2())->max_length;
		marshaled.___sekiPoss_2 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_sekiPoss_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_sekiPoss_Length); i++)
		{
			(marshaled.___sekiPoss_2)[i] = (unmarshaled.get_sekiPoss_2())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___sekiPoss_2 = NULL;
	}
	marshaled.___goalPos_3 = unmarshaled.get_goalPos_3();
	marshaled.___goalSize_4 = unmarshaled.get_goalSize_4();
	if (unmarshaled.get_wallPoss_5() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_wallPoss_Length = (unmarshaled.get_wallPoss_5())->max_length;
		marshaled.___wallPoss_5 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_wallPoss_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_wallPoss_Length); i++)
		{
			(marshaled.___wallPoss_5)[i] = (unmarshaled.get_wallPoss_5())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___wallPoss_5 = NULL;
	}
	if (unmarshaled.get_wallSizes_6() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_wallSizes_Length = (unmarshaled.get_wallSizes_6())->max_length;
		marshaled.___wallSizes_6 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_wallSizes_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_wallSizes_Length); i++)
		{
			(marshaled.___wallSizes_6)[i] = (unmarshaled.get_wallSizes_6())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___wallSizes_6 = NULL;
	}
}
IL2CPP_EXTERN_C void stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshal_pinvoke_back(const stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_pinvoke& marshaled, stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  unmarshaled_playerPos_temp_0;
	memset((&unmarshaled_playerPos_temp_0), 0, sizeof(unmarshaled_playerPos_temp_0));
	unmarshaled_playerPos_temp_0 = marshaled.___playerPos_0;
	unmarshaled.set_playerPos_0(unmarshaled_playerPos_temp_0);
	if (marshaled.___inPoss_1 != NULL)
	{
		if (unmarshaled.get_inPoss_1() == NULL)
		{
			unmarshaled.set_inPoss_1(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_inPoss_1())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_inPoss_1())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___inPoss_1)[i]);
		}
	}
	if (marshaled.___sekiPoss_2 != NULL)
	{
		if (unmarshaled.get_sekiPoss_2() == NULL)
		{
			unmarshaled.set_sekiPoss_2(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_sekiPoss_2())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_sekiPoss_2())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___sekiPoss_2)[i]);
		}
	}
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  unmarshaled_goalPos_temp_3;
	memset((&unmarshaled_goalPos_temp_3), 0, sizeof(unmarshaled_goalPos_temp_3));
	unmarshaled_goalPos_temp_3 = marshaled.___goalPos_3;
	unmarshaled.set_goalPos_3(unmarshaled_goalPos_temp_3);
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  unmarshaled_goalSize_temp_4;
	memset((&unmarshaled_goalSize_temp_4), 0, sizeof(unmarshaled_goalSize_temp_4));
	unmarshaled_goalSize_temp_4 = marshaled.___goalSize_4;
	unmarshaled.set_goalSize_4(unmarshaled_goalSize_temp_4);
	if (marshaled.___wallPoss_5 != NULL)
	{
		if (unmarshaled.get_wallPoss_5() == NULL)
		{
			unmarshaled.set_wallPoss_5(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_wallPoss_5())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_wallPoss_5())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___wallPoss_5)[i]);
		}
	}
	if (marshaled.___wallSizes_6 != NULL)
	{
		if (unmarshaled.get_wallSizes_6() == NULL)
		{
			unmarshaled.set_wallSizes_6(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_wallSizes_6())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_wallSizes_6())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___wallSizes_6)[i]);
		}
	}
}
// Conversion method for clean up from marshalling of: stageData
IL2CPP_EXTERN_C void stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshal_pinvoke_cleanup(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_pinvoke& marshaled)
{
	if (marshaled.___inPoss_1 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___inPoss_1);
		marshaled.___inPoss_1 = NULL;
	}
	if (marshaled.___sekiPoss_2 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___sekiPoss_2);
		marshaled.___sekiPoss_2 = NULL;
	}
	if (marshaled.___wallPoss_5 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___wallPoss_5);
		marshaled.___wallPoss_5 = NULL;
	}
	if (marshaled.___wallSizes_6 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___wallSizes_6);
		marshaled.___wallSizes_6 = NULL;
	}
}
// Conversion methods for marshalling of: stageData
IL2CPP_EXTERN_C void stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshal_com(const stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512& unmarshaled, stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_com& marshaled)
{
	marshaled.___playerPos_0 = unmarshaled.get_playerPos_0();
	if (unmarshaled.get_inPoss_1() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_inPoss_Length = (unmarshaled.get_inPoss_1())->max_length;
		marshaled.___inPoss_1 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_inPoss_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_inPoss_Length); i++)
		{
			(marshaled.___inPoss_1)[i] = (unmarshaled.get_inPoss_1())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___inPoss_1 = NULL;
	}
	if (unmarshaled.get_sekiPoss_2() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_sekiPoss_Length = (unmarshaled.get_sekiPoss_2())->max_length;
		marshaled.___sekiPoss_2 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_sekiPoss_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_sekiPoss_Length); i++)
		{
			(marshaled.___sekiPoss_2)[i] = (unmarshaled.get_sekiPoss_2())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___sekiPoss_2 = NULL;
	}
	marshaled.___goalPos_3 = unmarshaled.get_goalPos_3();
	marshaled.___goalSize_4 = unmarshaled.get_goalSize_4();
	if (unmarshaled.get_wallPoss_5() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_wallPoss_Length = (unmarshaled.get_wallPoss_5())->max_length;
		marshaled.___wallPoss_5 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_wallPoss_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_wallPoss_Length); i++)
		{
			(marshaled.___wallPoss_5)[i] = (unmarshaled.get_wallPoss_5())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___wallPoss_5 = NULL;
	}
	if (unmarshaled.get_wallSizes_6() != NULL)
	{
		il2cpp_array_size_t _unmarshaled_wallSizes_Length = (unmarshaled.get_wallSizes_6())->max_length;
		marshaled.___wallSizes_6 = il2cpp_codegen_marshal_allocate_array<Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E >(_unmarshaled_wallSizes_Length);
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_unmarshaled_wallSizes_Length); i++)
		{
			(marshaled.___wallSizes_6)[i] = (unmarshaled.get_wallSizes_6())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
		}
	}
	else
	{
		marshaled.___wallSizes_6 = NULL;
	}
}
IL2CPP_EXTERN_C void stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshal_com_back(const stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_com& marshaled, stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  unmarshaled_playerPos_temp_0;
	memset((&unmarshaled_playerPos_temp_0), 0, sizeof(unmarshaled_playerPos_temp_0));
	unmarshaled_playerPos_temp_0 = marshaled.___playerPos_0;
	unmarshaled.set_playerPos_0(unmarshaled_playerPos_temp_0);
	if (marshaled.___inPoss_1 != NULL)
	{
		if (unmarshaled.get_inPoss_1() == NULL)
		{
			unmarshaled.set_inPoss_1(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_inPoss_1())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_inPoss_1())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___inPoss_1)[i]);
		}
	}
	if (marshaled.___sekiPoss_2 != NULL)
	{
		if (unmarshaled.get_sekiPoss_2() == NULL)
		{
			unmarshaled.set_sekiPoss_2(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_sekiPoss_2())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_sekiPoss_2())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___sekiPoss_2)[i]);
		}
	}
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  unmarshaled_goalPos_temp_3;
	memset((&unmarshaled_goalPos_temp_3), 0, sizeof(unmarshaled_goalPos_temp_3));
	unmarshaled_goalPos_temp_3 = marshaled.___goalPos_3;
	unmarshaled.set_goalPos_3(unmarshaled_goalPos_temp_3);
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  unmarshaled_goalSize_temp_4;
	memset((&unmarshaled_goalSize_temp_4), 0, sizeof(unmarshaled_goalSize_temp_4));
	unmarshaled_goalSize_temp_4 = marshaled.___goalSize_4;
	unmarshaled.set_goalSize_4(unmarshaled_goalSize_temp_4);
	if (marshaled.___wallPoss_5 != NULL)
	{
		if (unmarshaled.get_wallPoss_5() == NULL)
		{
			unmarshaled.set_wallPoss_5(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_wallPoss_5())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_wallPoss_5())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___wallPoss_5)[i]);
		}
	}
	if (marshaled.___wallSizes_6 != NULL)
	{
		if (unmarshaled.get_wallSizes_6() == NULL)
		{
			unmarshaled.set_wallSizes_6(reinterpret_cast<Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*>((Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4*)SZArrayNew(Vector3U5BU5D_t5FB88EAA33E46838BDC2ABDAEA3E8727491CB9E4_il2cpp_TypeInfo_var, 1)));
		}
		il2cpp_array_size_t _arrayLength = (unmarshaled.get_wallSizes_6())->max_length;
		for (int32_t i = 0; i < ARRAY_LENGTH_AS_INT32(_arrayLength); i++)
		{
			(unmarshaled.get_wallSizes_6())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), (marshaled.___wallSizes_6)[i]);
		}
	}
}
// Conversion method for clean up from marshalling of: stageData
IL2CPP_EXTERN_C void stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshal_com_cleanup(stageData_t1135DF103877F1B881FB23FA34851F4FF8BC0512_marshaled_com& marshaled)
{
	if (marshaled.___inPoss_1 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___inPoss_1);
		marshaled.___inPoss_1 = NULL;
	}
	if (marshaled.___sekiPoss_2 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___sekiPoss_2);
		marshaled.___sekiPoss_2 = NULL;
	}
	if (marshaled.___wallPoss_5 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___wallPoss_5);
		marshaled.___wallPoss_5 = NULL;
	}
	if (marshaled.___wallSizes_6 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.___wallSizes_6);
		marshaled.___wallSizes_6 = NULL;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Toggle_get_isOn_m2B1F3640101A6FCDA6B5AF27924FFD10E3A89A6C_inline (Toggle_t68F5A84CDD2BBAEA866F42EB4E0C9F2B431D612E * __this, const RuntimeMethod* method)
{
	{
		// get { return m_IsOn; }
		bool L_0 = __this->get_m_IsOn_24();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m129FC0ADA02FECBED3C0B1A809AE84A5AEE1CF09_inline (String_t* __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_m_stringLength_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Subtraction_m2725C96965D5C0B1F9715797E51762B13A5FED58_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___b1, const RuntimeMethod* method)
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0 = ___a0;
		float L_1 = L_0.get_x_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_2 = ___b1;
		float L_3 = L_2.get_x_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_4 = ___a0;
		float L_5 = L_4.get_y_3();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_6 = ___b1;
		float L_7 = L_6.get_y_3();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_8 = ___a0;
		float L_9 = L_8.get_z_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_10 = ___b1;
		float L_11 = L_10.get_z_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_12), ((float)il2cpp_codegen_subtract((float)L_1, (float)L_3)), ((float)il2cpp_codegen_subtract((float)L_5, (float)L_7)), ((float)il2cpp_codegen_subtract((float)L_9, (float)L_11)), /*hidden argument*/NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Multiply_m9EA3D18290418D7B410C7D11C4788C13BFD2C30A_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, float ___d1, const RuntimeMethod* method)
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0 = ___a0;
		float L_1 = L_0.get_x_2();
		float L_2 = ___d1;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_3 = ___a0;
		float L_4 = L_3.get_y_3();
		float L_5 = ___d1;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_6 = ___a0;
		float L_7 = L_6.get_z_4();
		float L_8 = ___d1;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_9), ((float)il2cpp_codegen_multiply((float)L_1, (float)L_2)), ((float)il2cpp_codegen_multiply((float)L_4, (float)L_5)), ((float)il2cpp_codegen_multiply((float)L_7, (float)L_8)), /*hidden argument*/NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_10 = V_0;
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Division_mE5ACBFB168FED529587457A83BA98B7DB32E2A05_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, float ___d1, const RuntimeMethod* method)
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0 = ___a0;
		float L_1 = L_0.get_x_2();
		float L_2 = ___d1;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_3 = ___a0;
		float L_4 = L_3.get_y_3();
		float L_5 = ___d1;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_6 = ___a0;
		float L_7 = L_6.get_z_4();
		float L_8 = ___d1;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_9), ((float)((float)L_1/(float)L_2)), ((float)((float)L_4/(float)L_5)), ((float)((float)L_7/(float)L_8)), /*hidden argument*/NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_10 = V_0;
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  Vector3_op_Addition_mEE4F672B923CCB184C39AABCA33443DB218E50E0_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___a0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___b1, const RuntimeMethod* method)
{
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0 = ___a0;
		float L_1 = L_0.get_x_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_2 = ___b1;
		float L_3 = L_2.get_x_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_4 = ___a0;
		float L_5 = L_4.get_y_3();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_6 = ___b1;
		float L_7 = L_6.get_y_3();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_8 = ___a0;
		float L_9 = L_8.get_z_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_10 = ___b1;
		float L_11 = L_10.get_z_4();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_12), ((float)il2cpp_codegen_add((float)L_1, (float)L_3)), ((float)il2cpp_codegen_add((float)L_5, (float)L_7)), ((float)il2cpp_codegen_add((float)L_9, (float)L_11)), /*hidden argument*/NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method)
{
	{
		float L_0 = ___x0;
		__this->set_x_2(L_0);
		float L_1 = ___y1;
		__this->set_y_3(L_1);
		float L_2 = ___z2;
		__this->set_z_4(L_2);
		return;
	}
}
