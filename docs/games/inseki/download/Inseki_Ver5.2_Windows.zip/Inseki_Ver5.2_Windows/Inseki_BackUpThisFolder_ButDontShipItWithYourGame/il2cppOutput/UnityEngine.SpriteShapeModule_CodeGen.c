﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





extern const CustomAttributesCacheGenerator g_UnityEngine_SpriteShapeModule_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_SpriteShapeModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_SpriteShapeModule_CodeGenModule = 
{
	"UnityEngine.SpriteShapeModule.dll",
	0,
	NULL,
	0,
	NULL,
	NULL,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_UnityEngine_SpriteShapeModule_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
